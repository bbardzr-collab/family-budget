# ЭТАП 7 — Отчёт: Доходы и расходы

Статус: **реализовано, проверено, готово к приёмке**. Ниже — отчёт по всем 9 пунктам из ТЗ (раздел 25).

---

## 1. Файлы изменены/созданы

**Новый домен `src/features/transactions/`**
- `schemas.ts` — Zod-схема формы (`transactionFormSchema`), нормализация суммы из строки (запятая/точка → `"1234.50"`)
- `queryKeys.ts` — `transactionsKeys`
- `api.ts` — `fetchTransactions`, `createTransaction`, `updateTransaction`, `deleteTransaction`
- `errors.ts` — `getTransactionErrorMessage`
- `hooks.ts` — `useTransactions`, `useCreateTransaction`, `useUpdateTransaction`, `useDeleteTransaction`
- `TransactionFormModal.tsx` — переиспользуемая форма добавления/редактирования (расход/доход)
- `DeleteTransactionModal.tsx` — подтверждение удаления
- `schemas.test.ts` — 20 тестов валидации
- `TransactionFormModal.test.tsx` — 7 тестов формы

**Изменённые файлы**
- `src/pages/TransactionsPage.tsx` — полностью переписан: был `StagePlaceholder`, стал рабочий экран `/app/transactions`
- `src/pages/TransactionsPage.test.tsx` — новый, 7 тестов
- `src/pages/HomePage.tsx` — Quick Actions «Расход»/«Доход» и EmptyState-кнопка «Добавить операцию» теперь открывают `TransactionFormModal` вместо заглушки `QuickActionInfoModal`
- `src/pages/HomePage.test.tsx` — обновлены моки (`@/features/transactions/hooks`) и один тест (кнопка больше не `disabled`); добавлен тест клика по Quick Action «Расход»
- `src/layouts/AppLayout.tsx` — FAB: пункты «Расход»/«Доход» открывают `TransactionFormModal`, «Цель»/«План» — по-прежнему заглушка
- `src/utils/formatDate.ts` — добавлена `toDateInputValue()` (значение для `<input type="date">`)

**Миграции — не добавлено ни одной.** Обоснование — см. п.2/4.

---

## 2. Migrations

Новых миграций в этом этапе **нет**. Это осознанное архитектурное решение (ТЗ, п.9, явно допускает оба варианта):

Существующие RLS-политики `transactions_insert_own` / `transactions_update_own_or_admin` / `transactions_delete_own_or_admin` (миграция `0010_rls_policies.sql`, без изменений с Этапа 3) уже полностью и корректно реализуют все требования безопасности п.8-9 — это было перепроверено прямым чтением файла миграции и подтверждено 14 SQL-тестами на реальной базе (см. п.4). Добавлять RPC (`create_transaction`/`update_transaction`) поверх уже достаточной RLS означало бы не «минимальное изменение», а лишнюю сущность — ТЗ прямо просит не менять архитектуру без необходимости (шапка ТЗ).

---

## 3. Как реализовано создание операции

Поток: `TransactionFormModal` (React Hook Form + `zodResolver(transactionFormSchema)`) → `useCreateTransaction().mutateAsync(...)` → `createTransaction()` в `features/transactions/api.ts` → прямой `supabase.from('transactions').insert(...)` (без RPC, см. п.2) → RLS проверяет `with check` → при успехе: `Modal` закрывается, `toast({type:'success', ...})`, инвалидация `transactionsKeys.list(familyId)` и `dashboardKeys.all` в `onSuccess` мутации.

**Сумма** — единственный нетривиальный момент. Ввод «1000», «1000.50», «1000,50» проходит через `amountInputSchema` (`schemas.ts`):
1. `trim()` → замена первой запятой на точку;
2. `regex /^\d{1,12}(\.\d{1,2})?$/` — отклоняет всё, что не число с максимум 2 знаками после точки (в т.ч. второй разделитель, если он ещё остался);
3. отдельная проверка «не все нули» (отклоняет `0`, `0.00`);
4. **нормализация только строковыми операциями** (`split('.')` + `padEnd(2,'0')`) — ни одного умножения/деления на 100 и ни одного промежуточного `parseFloat` до этого шага, то есть классический баг `0.1+0.2!==0.3` здесь структурно невозможен;
5. итоговая строка `"1234.50"` уходит в `createTransaction`/`updateTransaction` как есть — `Number(...)` вообще не вызывается на пути записи (см. `api.ts`, комментарий там же): PostgREST/Postgres сами приводят текстовое значение к `numeric(14,2)`.

**Дата** — `<input type="date">`, по умолчанию `toDateInputValue()` (сегодня, `yyyy-MM-dd`), в списке операций отображается через уже существующий `formatDate()` (`ДД.ММ.ГГГГ`).

**income_source** — показывается в форме только при `type === 'income'`; при сабмите принудительно приводится к `null`, если `type === 'expense'`, независимо от того, что осталось в скрытом поле формы.

**category_id** — нигде не передаётся ни в `insert`, ни в `update` → остаётся `NULL` (проверено SQL-тестом №14, см. п.4).

---

## 4. Как защищены INSERT/UPDATE/DELETE

Полагаемся на уже существующие RLS-политики (`0010_rls_policies.sql`), без изменений:

```sql
create policy transactions_insert_own on public.transactions
  for insert
  with check (public.is_family_member(family_id) and user_id = auth.uid());

create policy transactions_update_own_or_admin on public.transactions
  for update
  using (user_id = auth.uid() or public.is_family_admin(family_id))
  with check (public.is_family_member(family_id) and (user_id = auth.uid() or public.is_family_admin(family_id)));

create policy transactions_delete_own_or_admin on public.transactions
  for delete
  using (user_id = auth.uid() or public.is_family_admin(family_id));
```

`family_id`/`user_id` в `createTransaction` **приходят с клиента** (`currentFamily.id` из `FamilyContext`, `user.id` из `AuthContext`) — но это структурно безопасно: гарантию даёт не доверие к клиенту, а сервер. `is_family_member()` (миграция `0009`) внутри фильтрует `fm.status = 'active'`, так что подменить `family_id` на чужую семью нельзя, даже если когда-то было членство и оно стало неактивным; `user_id = auth.uid()` сверяется с JWT сервера — подменить чужой `user_id` невозможно вне зависимости от того, что отправит клиент. `updateTransaction`, в свою очередь, **никогда не передаёт `family_id`/`user_id`** в теле `UPDATE` — сменить владельца операции через редактирование архитектурно нельзя.

**Прямая проверка на реальной базе** (методология Этапов 5-6: временные `auth.users`/`families`/`family_members`, импersonация через `set local role` + `set local request.jwt.claims`, один `execute_sql`-вызов, `temp table test_results`). Family A (admin A1 + child A2), Family B (admin B1):

| # | Проверка | Результат |
|---|---|---|
| 1 | A1 создаёт операцию в своей семье от своего имени | PASS |
| 2 | A1 пытается создать операцию с `family_id` = чужая семья B (подмена) | **PASS (отклонено)** — `new row violates row-level security policy` |
| 3 | A1 пытается создать операцию с `user_id` = A2 (подмена чужого user_id в своей же семье) | **PASS (отклонено)** — RLS |
| 4 | A2 (CHILD) создаёт свою операцию | PASS |
| 5 | anon (без авторизации) пытается создать операцию | **PASS (отклонено)** — `permission denied for function is_family_member` |
| 6 | A1 обновляет свою операцию | PASS |
| 7 | A1 (ADMIN) обновляет операцию A2 (другой член своей семьи — у admin есть право) | PASS |
| 8 | A2 (CHILD, не admin) пытается обновить операцию A1 | **PASS (0 строк)** |
| 9 | B1 (чужая семья) пытается обновить операцию семьи A | **PASS (0 строк)** |
| 10 | B1 пытается удалить операцию семьи A | **PASS (0 строк)** |
| 11 | A2 (CHILD) пытается удалить операцию A1 (не своя, не admin) | **PASS (0 строк)** |
| 12 | A2 удаляет свою операцию | PASS |
| 13 | A1 (ADMIN) удаляет операцию | PASS |
| 14 | `category_id` остаётся `NULL` у всех созданных операций | PASS |

Все 14/14 — PASS. Все временные данные удалены; проверено нулём «осиротевших» строк в `auth.users`, `public.users`, `families`, `family_members`, `transactions`. `get_advisors(security)` после проверки — новых предупреждений, связанных с Этапом 7, нет (список тот же, что и в Этапе 6: ожидаемые `SECURITY DEFINER`-предупреждения по RPC Этапа 5 — новых RPC в Этапе 7 не создавалось).

---

## 5. Как Dashboard ведёт себя после добавления операции

`useCreateTransaction`/`useUpdateTransaction`/`useDeleteTransaction` в `onSuccess` вызывают:
```ts
queryClient.invalidateQueries({ queryKey: transactionsKeys.list(currentFamily?.id) })
queryClient.invalidateQueries({ queryKey: dashboardKeys.all })
```
`dashboardKeys.all = ['dashboard']` — инвалидация по этому префиксу задевает и `useDashboardSummary`, и `useRecentTransactions` независимо от их параметров (период/лимит), поэтому оба Dashboard-блока сами перезапрашивают данные с сервера. Никакого ручного пересчёта сумм на клиенте нет — `get_dashboard_summary` (Этап 6, `SECURITY INVOKER`) как считал `sum(...) filter (where type=...)` по реальной таблице `transactions`, так и продолжает — Этап 7 просто добавил в эту таблицу настоящие строки.

---

## 6. Результат `npm run build`

```
tsc -b && vite build
✓ 2969 modules transformed.
✓ built in 616ms
```
**0 ошибок.** Предупреждение про «chunk larger than 500 kB» — то же информационное, что и на Этапе 6, вне рамок этого этапа.

## 7. Результат `npm run lint`

```
✖ 5 problems (0 errors, 5 warnings)
```
**0 ошибок.** 4 предупреждения — уже знакомые `react-refresh/only-export-components` (Этапы 4-6). Одно новое: `react-hooks/incompatible-library` в `TransactionFormModal.tsx` — React Compiler не мемоизирует `watch()` из react-hook-form (первое использование `watch` в проекте). Это информационное предупреждение о пропуске мемоизации одного хука, не ошибка корректности; альтернатива (дублировать поле `type` в отдельный `useState`, синхronизируемый в `useEffect`) заменяет один линт-warning на **ошибку** `react-hooks/set-state-in-effect` — выбран вариант с warning, не с error.

## 8. Результат `npm run test`

```
Test Files  15 passed (15)
     Tests  79 passed (79)
```
**Все тесты зелёные.** Из них новые на этом этапе: 20 (`schemas.test.ts`) + 7 (`TransactionFormModal.test.tsx`) + 7 (`TransactionsPage.test.tsx`) = 34, плюс обновлён и дополнен `HomePage.test.tsx` (было 5 тестов, стало 6). Итого было 45 тестов на конец Этапа 6 → стало 79.

---

## 9. Проблемы и как исправлены

- **Ложный `getByLabelText` в тестах формы**: изначально `Input` для «Сумма»/«Дата» получал проп `required`, из-за чего `<label>` рендерил визуальную звёздочку `*` внутри того же элемента — accessible-name становился `"Сумма*"`, и точное совпадение `getByLabelText('Сумма')` переставало находить поле. Другие формы проекта (`CreateFamilyForm`, `InviteMemberModal`) `required` на `Input`/`Select` никогда не передают именно по этой причине (плюс формы и так используют `noValidate` — браузерная валидация всё равно отключена). **Исправлено** — убрал `required` с этих двух полей, оставив обязательность только в Zod-схеме (как и везде в проекте).
- **`react-hooks/set-state-in-effect` (ошибка линта)**: первая версия синхронизировала тип операции через отдельный `useState`, обновляемый внутри того же `useEffect`, что и `reset()` формы при открытии модалки — новый React Compiler ESLint-rule справедливо считает вызов raw `setState` внутри эффекта источником каскадных ререндеров. **Исправлено** — вернулся к `watch('type')` из react-hook-form как единственному источнику истины для отображения (ценой одного информационного warning вместо ошибки, см. п.7).
- **Зависание теста с `userEvent` под fake timers**: тест клика по Quick Action «Расход» в `HomePage.test.tsx` подвисал на 5 секунд и падал по таймауту — `describe`-блок уже использует `vi.useFakeTimers()` (нужно для детерминированного приветствия по времени суток), а `userEvent.click` внутри fake timers ждёt внутренний `setTimeout`, который никогда не срабатывает без ручного `vi.advanceTimersByTime`. **Исправлено** — использован синхронный `fireEvent.click` вместо `userEvent` в этом конкретном тесте (как и остальные клик-тесты в файлах с fake timers).
- **Обновление существующего теста Этапа 6**: `HomePage.test.tsx` ожидал, что кнопка «Добавить операцию» в пустом состоянии — `disabled` (Этап 6, заглушка). С Этапом 7 кнопка стала рабочей. **Исправлено** — тест обновлён (`toBeEnabled()` вместо `toBeDisabled()`), добавлен мок `@/features/transactions/hooks` (чтобы `TransactionFormModal`, теперь вложенный в `HomePage`, не тянул реальный Supabase-клиент в юнит-тест — тот же паттерн мокинга на границе feature-хуков, что и для `family`/`dashboard`).
- Других известных проблем нет. Тестовые/фейковые финансовые операции в реальной БД не остались — все временные QA-данные (Family A/B, 3 пользователя, все тестовые операции) удалены после проверки, подтверждено нулём «осиротевших» строк.

---

## Security checklist (ТЗ, п.23)

| Пункт | Статус |
|---|---|
| RLS включена на `transactions` | ✅ (`0010`, без изменений) |
| INSERT защищён | ✅ (`transactions_insert_own`, проверено тестами 1-5) |
| UPDATE защищён | ✅ (`transactions_update_own_or_admin`, проверено тестами 6-9) |
| DELETE защищён | ✅ (`transactions_delete_own_or_admin`, проверено тестами 10-13) |
| Нельзя подменить `user_id` | ✅ (тест 3) |
| Нельзя получить/изменить чужую семью | ✅ (тесты 2, 9, 10) |
| `service_role` не используется на фронтенде | ✅ (только `supabase` anon-клиент, как и раньше) |
| Суммы не хранятся как float | ✅ (`NUMERIC(14,2)` в БД; на клиенте — только строковая нормализация, `Number()` не вызывается на пути записи) |
| Нет секретов в Git | ✅ (изменений в `.env*`/ключах не было) |
| Нет тестовых финансовых операций в БД | ✅ (все QA-данные удалены и проверены) |
| `category_id` остаётся `NULL` до Этапа 8 | ✅ (тест 14; нигде в коде не передаётся) |

---

Этап 7 реализован полностью в рамках заданных границ. Категории, бюджеты, цели, планы, recurring, аналитика, уведомления, Google Calendar на этом этапе не появились.

**ЭТАП 7 ГОТОВ. ЖДУ ПРОВЕРКУ.**
