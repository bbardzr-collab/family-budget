# Отчёт: ЭТАП 17 — Уведомления

## 1. Какие файлы созданы

**Backend (миграции):**
- `supabase/migrations/0033_stage17_notifications.sql` — основная миграция этапа.
- `supabase/migrations/0034_stage17_fix_zero_amount_formatting.sql` — точечное исправление найденной живым тестом ошибки форматирования суммы (см. п.6).

**Frontend:**
- `src/features/notifications/queryKeys.ts` — query keys (`notificationsKeys`, `notificationPrefsKeys`).
- `src/features/notifications/api.ts` — тонкий слой доступа к данным (`fetchNotifications`, `fetchUnreadNotificationsCount`, `markNotificationRead`, `markAllNotificationsRead`, `deleteNotification`, `fetchNotificationPrefs`, `updateNotificationPrefs`, типы `NotificationType`/`NotificationItem`/`NotificationPrefs`).
- `src/features/notifications/errors.ts` — `getNotificationErrorMessage`.
- `src/features/notifications/labels.ts` — подписи/описания/порядок типов для настроек.
- `src/features/notifications/iconMap.tsx` — иконка на тип уведомления.
- `src/features/notifications/hooks.ts` — React Query hooks (п.7 ниже).
- `src/features/notifications/links.ts` — `getNotificationTarget()` (переход по клику).
- `src/features/notifications/NotificationRow.tsx` — строка уведомления (переиспользуется в дропдауне и на странице).
- `src/features/notifications/NotificationSettingsSection.tsx` — блок настроек на `/app/settings`.
- `src/components/NotificationBell.tsx` — колокольчик с бейджем и попапом.
- `src/pages/NotificationsPage.tsx` — страница `/app/notifications`.
- Тесты: `src/features/notifications/errors.test.ts`, `src/features/notifications/links.test.ts`, `src/features/notifications/NotificationSettingsSection.test.tsx`, `src/pages/NotificationsPage.test.tsx`, `src/components/NotificationBell.test.tsx`.

## 2. Какие файлы изменены

- `src/types/database.ts` — перегенерирован (`mcp__Supabase__generate_typescript_types`): `notifications.event_key`, новые RPC-сигнатуры.
- `src/utils/formatDate.ts` — добавлена `formatRelativeDateTime()` ("Сегодня, 08:30"/"Вчера, 14:02"/полная дата).
- `src/components/Header.tsx` — заглушка-колокольчик заменена на `<NotificationBell />`.
- `src/app/routes.tsx` — добавлен маршрут `/app/notifications`.
- `src/app/navigation.ts` — заголовок страницы для `/app/notifications`.
- `src/pages/SettingsPage.tsx` — добавлен блок `<NotificationSettingsSection />`; текст плейсхолдера "Остальные настройки" сужен (уведомления больше не входят в него, привязка к этапу сдвинута на "Этап 18" — там, где действительно остались профиль/тема).
- `README.md` — новый раздел «Уведомления».

Ни один файл предыдущих этапов не удалён и не переписан заново — только точечные добавления в существующие Header/routes/navigation/SettingsPage.

## 3. Какие migrations добавлены

**`0033_stage17_notifications.sql`** (применена как `stage17_notifications_ddl` — см. важное замечание в п.11 про дублирующую запись в истории миграций):
- `notifications.event_key text` + партиционный уникальный индекс `notifications_user_event_key_unique (user_id, event_key) WHERE event_key IS NOT NULL` — дедупликация.
- Индексы `notifications(user_id)`, `notifications(user_id, is_read)`, `notifications(created_at)` — по п.27 ТЗ (при аудите выяснилось, что часть из них уже существовала с более раннего этапа; недостающие добавлены).
- `create_notification()` — единственная точка вставки, `SECURITY DEFINER`, `EXECUTE` отозван у `public/anon/authenticated`; учитывает `user_settings.notification_prefs` (тип отключён → тихо не создаёт запись).
- `mark_notification_read(notification_id)`, `mark_all_notifications_read()`, `delete_notification(notification_id)` — клиентские RPC, `SECURITY INVOKER`.
- `check_budget_notifications(family_id, period)` + триггерная функция `transactions_notify_budget_events()` + триггер `trg_transactions_notify_budget_events` (AFTER INSERT/UPDATE/DELETE на `transactions`) — генерация `budget_exceeded`/`limit_reached`.
- `goal_check_auto_complete()` (Этап 11) расширена — хук `goal_achieved` внутри уже существующего атомарного `active → completed` перехода.
- `generate_due_planned_expenses()` (Этап 13) расширена — хук `payment_due` внутри уже существующей ветки "новое напоминание".
- Backfill `user_settings.notification_prefs` для существующих пользователей + `handle_new_auth_user()` расширена, чтобы новые пользователи сразу получали дефолтные настройки уведомлений.

**`0034_stage17_fix_zero_amount_formatting.sql`** — `CREATE OR REPLACE` для `check_budget_notifications()` и `generate_due_planned_expenses()`: исправлен формат суммы в тексте уведомления (см. п.6). Сигнатуры, права, триггеры не изменились — только текст форматирования внутри тела.

Обе миграции — только новые файлы; ни одна ранее применённая миграция (0001–0032) не редактировалась.

## 4. Какие RPC добавлены/изменены

| RPC | Статус | SECURITY | Кто может вызвать с клиента |
|---|---|---|---|
| `create_notification()` | Новая | DEFINER | Никто — `EXECUTE` отозван у public/anon/authenticated, вызывается только function-to-function |
| `check_budget_notifications()` | Новая | DEFINER | Никто — тот же internal-only паттерн |
| `transactions_notify_budget_events()` | Новая (триггерная) | DEFINER | Не вызывается напрямую — только через триггер на `transactions` |
| `mark_notification_read(notification_id)` | Новая | INVOKER | authenticated (проверяет `user_id = auth.uid()`) |
| `mark_all_notifications_read()` | Новая | INVOKER | authenticated |
| `delete_notification(notification_id)` | Новая | INVOKER | authenticated |
| `goal_check_auto_complete()` | Изменена (Этап 11) | DEFINER (без изменений) | Не вызывается напрямую — триггер на `goal_contributions` |
| `generate_due_planned_expenses()` | Изменена (Этап 13) | DEFINER (без изменений) | authenticated (как и раньше) |
| `handle_new_auth_user()` | Изменена (Этап 3) | DEFINER (без изменений) | Не вызывается напрямую — триггер на `auth.users` |

`get_notifications()` **не создавалась как RPC** — ТЗ формулирует её как "предпочтительно" (в отличие от императивного "создать" для трёх остальных), а список уведомлений — простой однотабличный `SELECT`, полностью покрытый RLS `notifications_select_own`. Решение по аналогии с Этапом 12 (`planned_expenses`), где по той же причине не создавался отдельный RPC для списка. Реализовано как обычный `supabase.from('notifications').select(...)` в `api.ts`.

## 5. Как работает система уведомлений

**Хранение.** Всё в существующей таблице `notifications` (`family_id`, `user_id`, `type`, `title`, `message`, `payload`, `is_read`, `channel`, `created_at`) + один новый столбец `event_key` для дедупликации. Отдельная таблица настроек не создавалась — `user_settings.notification_prefs` (jsonb, дефолт `{payment_due: true, budget_exceeded: true, limit_reached: true, goal_achieved: true, family_invite: true}`).

**Генерация — только на сервере, из реальных данных:**
- `payment_due` — при вызове `generate_due_planned_expenses()` (уже существующий Этап-13 механизм ручного/автоматического опроса регулярных платежей); создаётся ровно в момент появления нового `planned_expense`, что и так происходит не чаще одного раза на дату благодаря существующей уникальности `(recurring_transaction_id, planned_date)` — отдельный `event_key` не нужен, естественная дедупликация уже была.
- `budget_exceeded`/`limit_reached` — новый триггер на `transactions` (AFTER INSERT/UPDATE/DELETE) пересчитывает состояние бюджета семьи и категорий за затронутый месяц и создаёт уведомления через `create_notification()` с `event_key`, включающим текущие пороговые значения (`total_amount`/`limit_amount`) — благодаря `ON CONFLICT (user_id, event_key) DO NOTHING` одно и то же превышение не плодит копии, а реальное изменение бюджета/лимита администратором создаёт новый `event_key` и, соответственно, новое уведомление.
- `goal_achieved` — расширен существующий триггер `goal_check_auto_complete()` (Этап 11): уведомление создаётся ровно в момент атомарного перехода цели `active → completed`, который по конструкции происходит не более одного раза на цель.
- `family_invite` — не генерируется автоматически на этом этапе (см. п.9 «Известные ограничения»).

**Доставка на клиент.** Колокольчик в `Header.tsx` показывает бейдж (реальный `useUnreadNotificationsCount()`, лёгкий count-запрос) и по клику открывает попап с последними 5 уведомлениями (`useNotifications({ limit: 5 })`) + ссылку "Посмотреть все уведомления" → `/app/notifications`. Страница `/app/notifications` — вкладки "Все"/"Непрочитанные", кнопка "Прочитать все" (видна только при наличии непрочитанных), клик по уведомлению помечает его прочитанным (оптимистично) и переходит в соответствующий раздел (`getNotificationTarget()` — по `payload`, например `budget_id`/`goal_id`).

**Приватность CHILD** обеспечена не отдельной системой, а самой структурой генерации: `payment_due` в принципе адресуется только `recurring_transactions.user_id` (одному человеку, никогда всей семье), `budget_exceeded`/`limit_reached` содержат только тот же безопасный семейный агрегат, что CHILD и так видит на `/app/budget`/`/app/analytics` с Этапа 16, а `goal_achieved` для личной цели уходит только владельцу — child не входит в цикл рассылки, если он не сам владелец.

## 6. Какие security tests выполнены

Живые SQL-тесты на двух фиктивных семьях (Family A: admin_a/adult_a/child_a, Family B: admin_b/adult_b/child_b — 6 пользователей `auth.users`+`public.users`, созданы напрямую в БД с явного разрешения пользователя, полностью удалены после тестов). Проверены все 5 обязательных сценариев ТЗ (п.28) плюс дополнительные:

1. **User A получает свои уведомления, User B — нет.** `admin_a`: `own_count = 6`, попытка отфильтровать по `family_id` чужой семьи → `0`, попытка получить строку `user_id` чужого пользователя (в том же запросе SELECT) → `0`. `admin_b`: `own_count = 1`, попытка по `family_id` семьи A → `0`. Дополнительно проверено **внутри одной семьи**: `adult_a` не видит уведомления `admin_a` (`0` строк) — изоляция не только межсемейная, но и между членами одной семьи.
2. **User A передаёт ID уведомления User B в `mark_notification_read`.** И `admin_b` (чужая семья), и `adult_a` (та же семья, чужой пользователь) получили `NOTIFICATION_NOT_FOUND` при попытке пометить прочитанным уведомление `admin_a`.
3. **User A меняет `is_read` чужого уведомления напрямую (`UPDATE`, в обход RPC).** И `adult_a`, и `admin_b` — `0` реально изменённых строк (RLS отфильтровала перед `UPDATE`, не ошибка — тем же способом, что подтверждает `WITH ... RETURNING`); контрольный `UPDATE` от настоящего владельца (`admin_a`) в той же схеме дал `1` — методика теста подтверждена рабочей.
4. **Family A не получает уведомления Family B.** Подтверждено в сценарии 1 в обе стороны.
5. **CHILD не получает уведомление, раскрывающее чужие данные.** `child_a`: `payment_due` (принадлежит `admin_a`) → `0`; `goal_achieved` личной цели `adult_a` → `0`; при этом `budget_exceeded` (безопасный агрегат) → `1`, `goal_achieved` семейной цели → `1` — CHILD корректно получает безопасные и не получает запрещённые уведомления.

Дополнительно:
- **Прямой `INSERT` в `notifications` с клиента заблокирован** — даже `admin_a`, пытающийся вставить уведомление сам себе напрямую (в обход `create_notification()`), получает `new row violates row-level security policy` (у таблицы нет `INSERT`-политики).
- **`mark_all_notifications_read()` затрагивает только вызывающего** — после вызова от имени `adult_a` непрочитанные `admin_a` (та же семья!) и `admin_b` (чужая семья) остались нетронутыми.
- **`delete_notification()` с чужим id** — `admin_b` пытается удалить уведомление `admin_a` → `NOTIFICATION_NOT_FOUND`.
- **Дедупликация проверена на реальных данных**, а не только по конструкции кода: три транзакции подряд довели категорию до 200% лимита — `limit_reached` создалось один раз (не три), `event_key` совпал; после изменения `limit_amount` администратором тот же сценарий создал новое уведомление под новым `event_key`; повторный вклад в уже достигнутую цель не создал второго `goal_achieved`.
- **`user_settings.notification_prefs` гейтинг** проверен на реальной генерации: `limit_reached` отключён для `child_a` → при новом срабатывании лимита `child_a` уведомление не получил, `admin_a`/`adult_a` (не отключали) — получили.
- **`payment_due` не создаёт `transaction`** — после вызова `generate_due_planned_expenses()` количество строк в `transactions` семьи не изменилось (создался только `planned_expense` + уведомление).
- `mcp__Supabase__get_advisors(type: "security")` после обеих миграций — находки те же, что и на предыдущих этапах (ожидаемые WARN про `SECURITY DEFINER`, вызываемые `authenticated`, для уже существующих helper-RPC проекта); ни одной новой находки, специфичной для Этапа 17.

Все фикстуры (6 пользователей, 2 семьи, категория, бюджет, лимит, регулярный платёж, 2 цели, транзакции, уведомления) полностью удалены после тестов — подтверждено нулевым остатком по всем 15 задействованным таблицам.

**Побочная находка.** Один из живых тестов (расход ровно равен лимиту категории, переплата = 0) выявил реальный баг форматирования: `to_char(0, 'FM999G999G999D00')` в Postgres возвращает `".00"` без ведущего нуля, из-за чего сообщение читалось как "превысили лимит на .00 ₽". Исправлено миграцией `0034` (маска `FM999G999G990D00` — последняя "9" целой части заменена на "0", которая печатается всегда). Проверено повторным тестом: сообщения с суммой `0` и с обычными суммами (включая разделители тысяч) форматируются корректно.

## 7. Какие обычные tests выполнены

Frontend, Vitest + React Testing Library, добавлено 5 новых файлов:
- `errors.test.ts` — все ветки `getNotificationErrorMessage` (NOTIFICATION_NOT_FOUND, NOT_AUTHENTICATED, RLS/policy, PGRST116, сеть, неизвестная ошибка).
- `links.test.ts` — `getNotificationTarget` для всех 5 типов.
- `NotificationSettingsSection.test.tsx` — loading/error/5 переключателей в правильном порядке/сохранение при выключении/toast при ошибке.
- `NotificationsPage.test.tsx` — loading/error/empty (все и непрочитанные)/переключение вкладок/видимость "Прочитать все"/пометка прочитанным при открытии/пропуск повторной мутации для уже прочитанного/удаление/содержимое строки.
- `NotificationBell.test.tsx` — счётчик (0/число/"99+")/открытие-закрытие попапа (клик, клик снаружи, Escape)/loading/error/empty попапа/пометка прочитанным и закрытие при клике по уведомлению/ссылка на полный список.

## 8. Результат build

```
npm run build
✓ 3625 modules transformed.
✓ built in 3.52s
```
Успешно, ошибок нет (предупреждение о размере chunk — существовало и до Этапа 17, не связано с этим этапом).

## 9. Результат lint

```
npm run lint
✖ 16 problems (0 errors, 16 warnings)
```
0 ошибок. 15 из 16 warnings — уже существовавшие ранее (React Compiler `watch()`-несовместимость react-hook-form, `react-refresh/only-export-components` в файлах иконок других разделов). Один новый warning того же класса — `react-refresh/only-export-components` в новом `src/features/notifications/iconMap.tsx` (та же ситуация, что и у `features/goals/iconMap.tsx`/`features/categories/iconMap.tsx` — карта иконок неизбежно экспортирует не-компонент рядом с JSX; это общепринятый в проекте паттерн, а не проблема, требующая исправления).

## 10. Результат test

```
npx vitest run
Test Files  42 passed (42)
     Tests  382 passed (382)
```
Все тесты зелёные, включая 38 новых (382 против 344 на конец Этапа 16) — регрессий в предыдущих этапах не обнаружено.

## 11. Известные ограничения

- **`family_invite` не генерируется автоматически.** Модель приглашений (Этап 5, `family_invitations`) основана исключительно на shareable-токене — в таблице нет `user_id`/email получателя, то есть на момент создания приглашения реального адресата определить невозможно. Согласно прямому указанию ТЗ ("если модель приглашения основана только на shareable token без user_id, не ломай существующую архитектуру — уведомление создаётся только там, где существует реальный получатель"), тип реализован в схеме/UI (иконка, лейбл, переход `getNotificationTarget` → `/app/family`), но автогенерация для него сознательно не создана. Потребует отдельного решения на будущем этапе, если модель приглашений будет расширена email-адресатом.
- **Realtime не подключён.** Обновление счётчика/списка — через `refetchInterval: 30_000` у `useUnreadNotificationsCount()` (сам список без принудительного интервала, обновляется по стандартным триггерам React Query — фокус окна, мутации, возврат на страницу). Supabase Realtime в проекте нигде не используется, поэтому переделывать архитектуру ради него на этом этапе не стали (прямое указание ТЗ, п.23).
- **Дублирующая запись в истории миграций Supabase.** Из-за случайной ошибки при первом применении миграции (передан пустой/комментарийный SQL вместо реального содержимого) в истории миграций проекта на сервере остались **две** записи для одного и того же файла: `stage17_notifications` (версия `20260922054049`, пустая — не выполнила ни одной DDL-операции, безвредна) и `stage17_notifications_ddl` (версия `20260922054152`, реальное содержимое `0033_stage17_notifications.sql`, применено успешно). Локально в репозитории — один файл `0033_stage17_notifications.sql`, соответствующий второй, настоящей записи. Расхождение не влияет на работу приложения (пустая миграция не изменила схему), но стоит иметь в виду при будущем аудите истории миграций проекта на Supabase.
- Bundle-size warning (>500kB) при `npm run build` — существовал и до Этапа 17, вне scope.
- Все пункты, явно вынесенные из scope (push-уведомления браузера, Service Worker, Web Push, Firebase, Telegram, email, SMS, WhatsApp, автоматическая отправка сообщений, AI-уведомления, мобильное приложение, PWA-функциональность) — не затрагивались.

---

**ЭТАП 17 ГОТОВ. ЖДУ ПРОВЕРКУ.**
