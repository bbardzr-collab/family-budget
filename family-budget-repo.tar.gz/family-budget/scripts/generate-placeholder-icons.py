"""
Генератор ВРЕМЕННЫХ placeholder PWA-иконок.


Эти иконки — заглушки для Этапа 1 (чтобы manifest.json был валиден
и приложение можно было установить на домашний экран). Перед релизом
их нужно заменить на финальные иконки из дизайн-системы.

Запуск: python3 scripts/generate-placeholder-icons.py
"""

from PIL import Image, ImageDraw, ImageFont

PRIMARY = (91, 79, 232)  # #5B4FE8 — совпадает с theme_color в manifest
WHITE = (255, 255, 255)

OUT_DIR = "public/icons"


def draw_wallet_glyph(draw: ImageDraw.ImageDraw, size: int, color, scale: float = 1.0) -> None:
    """Простой узнаваемый глиф — стилизованный кошелёк/карточка с символом рубля."""
    pad = size * (1 - scale) / 2 + size * 0.22
    left, top, right, bottom = pad, size * 0.32, size - pad, size * 0.68
    radius = size * 0.06
    draw.rounded_rectangle([left, top, right, bottom], radius=radius, outline=color, width=max(2, int(size * 0.035)))
    # "монетка"/застёжка кошелька
    coin_r = size * 0.07
    cx, cy = right - coin_r * 1.4, (top + bottom) / 2
    draw.ellipse([cx - coin_r, cy - coin_r, cx + coin_r, cy + coin_r], fill=color)


def make_icon(size: int, filename: str, maskable: bool = False) -> None:
    img = Image.new("RGBA", (size, size), PRIMARY + (255,))
    draw = ImageDraw.Draw(img)

    if maskable:
        # Maskable-иконки: контент должен помещаться в безопасную зону ~80%
        draw_wallet_glyph(draw, size, WHITE, scale=0.62)
    else:
        # Скруглённые углы для обычной иконки
        mask = Image.new("L", (size, size), 0)
        mask_draw = ImageDraw.Draw(mask)
        mask_draw.rounded_rectangle([0, 0, size, size], radius=size * 0.22, fill=255)
        rounded = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        rounded.paste(img, (0, 0), mask)
        img = rounded
        draw = ImageDraw.Draw(img)
        draw_wallet_glyph(draw, size, WHITE, scale=0.8)

    img.save(f"{OUT_DIR}/{filename}")
    print(f"created {OUT_DIR}/{filename}")


if __name__ == "__main__":
    make_icon(192, "icon-192.png")
    make_icon(512, "icon-512.png")
    make_icon(512, "icon-512-maskable.png", maskable=True)
    make_icon(180, "apple-touch-icon.png")
