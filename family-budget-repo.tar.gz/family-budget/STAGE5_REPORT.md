# ЭТАП 5 — Отчёт: Создание семьи + приглашения членов семьи

Статус: **реализовано, проверено, готово к приёмке**. Ниже — отчёт по всем 19 пунктам из ТЗ.

---

## 1. Файлы созданы

**Миграции (`supabase/migrations/`)**
- `0012_family_rpcs.sql`
- `0013_harden_family_functions.sql`
- `0014_fix_cancel_invitation_status.sql`

**Frontend — новый домен `src/features/family/`**
- `roles.ts` — человекочитаемые подписи ролей/статусов
- `errors.ts` — маппинг кодов ошибок RPC → русский текст
- `api.ts` — типизированные обёртки над `supabase.rpc(...)` / `.from(...)`
- `queryKeys.ts` — фабрика ключей React Query
- `hooks.ts` — все `useQuery`/`useMutation` хуки домена
- `FamilyContext.tsx` — контекст текущей семьи/роли
- `schemas.ts` — Zod-схемы форм (`createFamilySchema`, `inviteMemberSchema`)
- `clipboard.ts` — копирование ссылки-приглашения с fallback
- `CreateFamilyForm.tsx` — форма создания семьи
- `InviteMemberModal.tsx` — модалка создания приглашения

**Тесты**
- `src/features/family/roles.test.ts`
- `src/features/family/CreateFamilyForm.test.tsx`
- `src/features/family/InviteMemberModal.test.tsx`
- `src/pages/FamilyPage.test.tsx`
- `src/pages/auth/InvitePage.test.tsx`
- `src/pages/HomePage.test.tsx`

---

## 2. Файлы изменены

- `src/types/database.ts` — перегенерирован (добавлены новые RPC-функции в `Functions`)
- `src/layouts/AppLayout.tsx` — обёрнут в `<FamilyProvider>`
- `src/features/auth/PublicOnlyRoute.tsx` — поддержка `?redirect=` (безопасный, только относительные пути вида `/...`, без `//`)
- `src/pages/HomePage.tsx` — реальное состояние «нет семьи / есть семья» вместо заглушки
- `src/pages/FamilyPage.tsx` — полноценная страница «Семья» (участники, приглашения, для ADMIN)
- `src/pages/auth/InvitePage.tsx` — полноценная обработка ссылки-приглашения

---

## 3. Миграции — что добавлено

| Файл | Содержимое |
|---|---|
| `0012_family_rpcs.sql` | Частичный уникальный индекс `family_members_one_active_per_user`; CHECK `family_invitations_role_not_admin`; удаление 3 INSERT/UPDATE RLS-политик; функции `family_invitation_ttl()`, `create_family()`, `create_family_invitation()`, `cancel_family_invitation()`, `get_invitation_by_token()`, `accept_family_invitation()` |
| `0013_harden_family_functions.sql` | `set search_path = public` для `family_invitation_ttl()` (устранение предупреждения Supabase advisor `function_search_path_mutable`) |
| `0014_fix_cancel_invitation_status.sql` | **Реальный баг**, найденный на security-проверке: `cancel_family_invitation` использовала `status = 'revoked'`, а constraint `family_invitations_status_check` (из `0003`) допускает только `pending/accepted/expired/cancelled`. Функция ломалась при отмене. Исправлено на `status = 'cancelled'`. |

Все миграции применены к реальному проекту Supabase (`ttgsdllidpafxwhkttly`) через `apply_migration` и лежат в `supabase/migrations/`.

---

## 4. RPC / функции — созданы

Все — `SECURITY DEFINER`, `set search_path = public`, `auth.uid()` определяет пользователя на сервере (ничего чувствительного не принимается от клиента):

1. **`create_family(p_name text) returns uuid`** — атомарно создаёт семью + запись ADMIN в `family_members` (`family_settings` создаются существующим триггером Этапа 3, не дублируются)
2. **`create_family_invitation(p_role text) returns table(...)`** — только ADMIN, роль ограничена `adult`/`child`, токен — `extensions.gen_random_bytes` (crypto-random, 64 hex-символа)
3. **`cancel_family_invitation(p_invitation_id uuid) returns void`** — только ADMIN своей семьи, только для `pending`
4. **`get_invitation_by_token(p_token text) returns table(...)`** — единственный способ анонимного просмотра приглашения; отдаёт только `family_name/role/status/expires_at/is_valid`, без token/id/invited_by; лениво помечает просроченные `pending` → `expired`
5. **`accept_family_invitation(p_token text) returns uuid`** — атомарное присоединение, `FOR UPDATE` против гонки двойного accept
6. **`family_invitation_ttl()`** — вспомогательная функция, централизует TTL = 7 дней

`GRANT EXECUTE` — только `authenticated`, кроме `get_invitation_by_token` (`anon` + `authenticated`).

---

## 5. RLS — что изменено

**Удалено полностью** (закрывает обход бизнес-правил через прямой REST-запрос):
- `families_insert_self`
- `family_invitations_insert_admin`
- `family_invitations_update_admin`

Теперь создание семьи, создание/отмена приглашений возможны **только** через RPC. SELECT-политики (кто что видит) не менялись — они были поставлены на Этапе 3/4 и работают верно.

**Добавлено на уровне схемы (не RLS, но та же цель — структурная защита):**
- CHECK `family_invitations_role_not_admin` — ADMIN нельзя выдать через приглашение, даже прямым INSERT в обход RLS
- Частичный уникальный индекс `family_members_one_active_per_user` — гарантия «одна активная семья на пользователя» на уровне БД

---

## 6. Как работает создание семьи

`CreateFamilyForm` → `useCreateFamily()` → `api.createFamily(name)` → `supabase.rpc('create_family', {p_name})`. Внутри функции: если у `auth.uid()` уже есть `status='active'` в `family_members` — `FAMILY_ALREADY_EXISTS`; иначе одной транзакцией создаётся `families` и `family_members` (роль `admin`, статус `active`). Триггер Этапа 3 создаёт `family_settings` и 17 базовых категорий. При гонке (два параллельных запроса) partial unique index даёт `unique_violation`, который перехватывается и превращается в тот же `FAMILY_ALREADY_EXISTS`, откатывая уже вставленную `families`-строку целиком (никогда не остаётся «половинчатой» семьи).

## 7. Как работают приглашения

Только ADMIN, `InviteMemberModal` → `useCreateInvitation` → RPC `create_family_invitation(role)`. Токен — 64 hex-символа из `gen_random_bytes(32)`, непредсказуем. Ссылка собирается на клиенте: `${origin}/invite/${token}`. Доставка — только по ссылке (email не реализован, согласно ТЗ). Список приглашений на странице «Семья» виден только ADMIN, отмена — только для `pending`, статус меняется на `cancelled` (не удаление строки — история сохраняется).

## 8. Как работает принятие приглашения

`/invite/:token` → `InvitePage` → `useInvitationPreview(token)` вызывает `get_invitation_by_token` (доступно даже анонимам, показывает только safe-поля). Если `is_valid=false` — понятное сообщение без технических деталей (по статусу: не найдено / истекло / отменено / уже принято). Если пользователь не авторизован — предложение войти/зарегистрироваться с `?redirect=/invite/<token>`, чтобы вернуться сюда после логина. Если авторизован — кнопка «Присоединиться» → `accept_family_invitation(token)`: под `FOR UPDATE` блокирует строку приглашения, проверяет `pending` и срок, проверяет, что у пользователя ещё нет активной семьи, вставляет `family_members` (роль из приглашения — `adult`/`child`, никогда `admin`), помечает приглашение `accepted`. Успех → редирект на `/app/family`.

## 9. Как обеспечено «одна активная семья на пользователя»

Два независимых уровня защиты:
1. **RPC-проверка** в начале `create_family` и `accept_family_invitation` — читает `family_members` на `status='active'` для `auth.uid()` и явно бросает `FAMILY_ALREADY_EXISTS`.
2. **Частичный уникальный индекс** `family_members_one_active_per_user on family_members(user_id) where status='active'` — гарантия на уровне БД, которая держится даже при гонке двух параллельных запросов (проверено вручную двумя параллельными SQL-сессиями — см. п.18).

## 10. Какие категории создаются автоматически

Не менялось на этом этапе — используется существующий триггер Этапа 3 (`0008_family_settings_trigger.sql`), срабатывающий при создании семьи. Создаётся 17 категорий: 11 OBLIGATORY, 5 WANTS, 1 OTHER — подтверждено повторной проверкой на этом этапе.

## 11. Как реализован FamilyContext

`FamilyProvider` — тонкая обёртка над одним вызовом `useMyMembership()` (React Query). Ничего не копируется в собственный `useState` — избегаем рассинхронизации с сервером. Наружу отдаются производные значения: `currentFamily`, `currentMembership`, `role`, `isAdmin`/`isAdult`/`isChild`, `hasFamily`, `loading` (из `isLoading`, намеренно не из `isFetching`, чтобы фоновые перезапросы не мигали UI), `refetch`. Подключён в `AppLayout`, доступен во всех страницах `/app/*`.

## 12. Как реализованы React Query хуки

`src/features/family/hooks.ts`: `useMyMembership`, `useFamilyMembers(familyId)`, `useFamilyInvitations(familyId, isAdmin)` (включён только когда `isAdmin`, чтобы не дёргать RPC зря), `useInvitationPreview(token)`, и мутации `useCreateFamily`, `useCreateInvitation(familyId)`, `useCancelInvitation(familyId)`, `useAcceptInvitation`. Каждая мутация в `onSuccess` вызывает `queryClient.invalidateQueries` на соответствующий ключ (`familyKeys.membership`/`.invitations(familyId)` и т.д.) — обновление UI без ручного `location.reload()`.

## 13. Какие тесты добавлены

- `roles.test.ts` — 4 набора, метки ролей/статусов
- `CreateFamilyForm.test.tsx` — 4 теста: валидация короткого/пустого имени, успешный trim+submit, ошибка `FAMILY_ALREADY_EXISTS`
- `InviteMemberModal.test.tsx` — 3 теста: нет опции «Администратор», успешное создание+копирование ссылки, ошибка `FORBIDDEN`
- `FamilyPage.test.tsx` — 4 теста: нет семьи, загрузка, вид ADMIN (участники+роли+приглашения+кнопка), вид не-ADMIN (нет кнопки/списка приглашений)
- `InvitePage.test.tsx` — 4 теста: невалидное приглашение, неавторизованный (редирект после логина), авторизованный успешный accept, ошибка `FAMILY_ALREADY_EXISTS`
- `HomePage.test.tsx` — 2 теста: нет семьи (форма + подсказка, без фиктивных `₽`), есть семья (название вместо формы)

Итого 38 тестов во всём проекте (17 новых на этом этапе), 11 test-файлов.

## 14. Результат `npm run build`

```
tsc -b && vite build
✓ 2955 modules transformed.
✓ built in 629ms
```
**0 ошибок.** Единственное предупреждение — «chunk larger than 500 kB» (информационное, не ошибка; было и на предыдущих этапах, code-splitting вне рамок ТЗ Этапа 5).

## 15. Результат `npm run lint`

```
✖ 4 problems (0 errors, 4 warnings)
```
**0 ошибок.** Все 4 предупреждения — `react-refresh/only-export-components` на файлах-контекстах (`ThemeContext.tsx`, `Toast.tsx`, `AuthContext.tsx`, и теперь `FamilyContext.tsx`) — это установившийся, принятый на предыдущих этапах паттерн (контекст экспортирует и компонент, и хук), не новая проблема.

## 16. Результат `npm run test`

```
Test Files  11 passed (11)
     Tests  38 passed (38)
```
**Все тесты зелёные.** (По пути был найден и исправлен баг в самом тесте `FamilyPage.test.tsx` — `getByText('Анна Иванова')` неоднозначно совпадал с `sr-only`-текстом `Avatar` и видимым именем в списке; исправлено уточнением селектора `{ selector: 'p' }`. Баг был в тесте, не в приложении.)

## 17. Какие security-проверки проведены

Вручную через SQL (`set local role` + `request.jwt.claims` для имперсонации, 3 временных пользователя), затем всё удалено без следа. Проверено (соответствует п.39 ТЗ + расширено):

- Прямой INSERT в `families`/`family_members`/`family_invitations` в обход RPC — заблокирован (нет соответствующих INSERT-политик)
- Создание семьи через RPC от анонима — `NOT_AUTHENTICATED`
- Повторное создание семьи тем же пользователем — `FAMILY_ALREADY_EXISTS`
- Гонка двух параллельных `create_family` от одного пользователя — только одна семья создаётся (partial unique index)
- Создание приглашения не-ADMIN — `FORBIDDEN`
- Попытка создать приглашение с ролью `admin` — `INVALID_ROLE`, плюс CHECK-constraint как второй рубеж
- Отмена приглашения не-ADMIN / из чужой семьи — `FORBIDDEN`
- Двойная отмена того же приглашения — `INVITATION_NOT_PENDING`
- **Отмена приглашения ADMIN своей семьи — падала с ошибкой constraint (найденный баг), после фикса 0014 проходит чисто**
- Просмотр приглашения анонимом по токену — отдаются только safe-поля, без token/id/invited_by
- Просроченный токен — лениво помечается `expired`, `accept` возвращает `INVITATION_NOT_PENDING`/некорректный статус
- Двойной accept одного токена (в т.ч. гонка) — второй запрос получает `INVITATION_NOT_PENDING`
- CHILD пытается создать/отменить приглашение — `FORBIDDEN`
- Видимость участников/приглашений между разными семьями — не пересекается
- Длина токена — ровно 64 символа (проверено отдельно)

Все ~30 сценариев прошли. Дополнительно запущены `get_advisors` (security + performance) после всех миграций: новых критических предупреждений нет. Есть 2 информационных (`INFO`) уведомления об отсутствующих индексах на новых внешних ключах (`families.created_by`, `family_invitations.invited_by`) — не блокирующие, не в рамках ТЗ этого этапа (индексация — задача производительности, не безопасности; можно рассмотреть в одном из следующих этапов). Предупреждения `anon_security_definer_function_executable`/`authenticated_security_definer_function_executable` по новым RPC — ожидаемые и намеренные (это и есть архитектура этого этапа: RPC обязаны быть выполняемы `authenticated`, а `get_invitation_by_token` — ещё и `anon`).

## 18. Что нужно проверить вручную в Supabase Dashboard

- Ничего нового сверх того, что уже было отмечено на Этапе 4 (email-подтверждение и т.п.). Специфичных для Этапа 5 ручных шагов в Dashboard не требуется — все RPC/RLS/constraint применены миграциями и проверены программно.
- Рекомендуется (не обязательно) при желании визуально свериться в Table Editor, что `family_invitations` не содержит «зависших» тестовых строк — они уже удалены, но это можно перепроверить глазами.

## 19. Что осталось нерешённым / известные ограничения

- Индексы на `families.created_by` и `family_invitations.invited_by` отсутствуют (INFO-уровень, не блокирует Этап 5, можно добавить позже).
- Email-доставка приглашений сознательно не реализована (вне рамок Этапа 5, только ссылка).
- Явное истечение приглашений (cron/scheduled job) не реализовано — используется ленивая проверка «при обращении», что соответствует ТЗ этого этапа.
- Других известных проблем нет.

---

Этап 5 реализован полностью в рамках заданных границ, ничего лишнего (бюджеты, цели, аналитика, повторяющиеся операции, уведомления, Google Calendar, PWA, Vercel) не добавлено.

**Жду команды «ЭТАП 5 ПРИНЯТ» для перехода к Этапу 6.**
