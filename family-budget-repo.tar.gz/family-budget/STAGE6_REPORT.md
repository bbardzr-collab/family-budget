# ЭТАП 6 — Отчёт: Главная страница / Dashboard

Статус: **реализовано, проверено, готово к приёмке**. Ниже — отчёт по всем 14 пунктам из ТЗ (раздел 39).

---

## 1. Файлы созданы

**Миграции (`supabase/migrations/`)**
- `0015_dashboard_summary.sql`
- `0016_fix_dashboard_summary_anon_grant.sql` (фикс найденного бага — см. п.13)

**Frontend — новый домен `src/features/dashboard/`**
- `api.ts` — `fetchDashboardSummary`, `fetchRecentTransactions`
- `queryKeys.ts` — `dashboardKeys`
- `hooks.ts` — `useDashboardSummary`, `useRecentTransactions`
- `period.ts` — `getCurrentMonthRange()` (первый/последний день текущего месяца)
- `greeting.ts` — `getTimeGreeting`, `getGreeting`
- `quickActions.ts` — `QUICK_ACTIONS` (единый список для Dashboard-блока и FAB)
- `QuickActionInfoModal.tsx` — общая модалка «появится на Этапе N» для Quick Actions и FAB

**Утилиты**
- `src/utils/formatMoney.ts`
- `src/utils/formatMoney.test.ts`

---

## 2. Файлы изменены

- `src/pages/HomePage.tsx` — полностью переписан: теперь это Dashboard (раньше — заглушка «Добро пожаловать»)
- `src/pages/HomePage.test.tsx` — переписан под новое поведение (было 2 теста Этапа 5, стало 5 тестов Этапа 6)
- `src/components/ui/Amount.tsx` — использует `formatMoney` вместо `formatCurrency` (корректные копейки)
- `src/utils/formatDate.ts` — добавлена `formatMonthYear()` («Сентябрь 2026»)
- `src/layouts/AppLayout.tsx` — шире контейнер контента (`max-w-3xl` → `max-w-6xl`, см. п.28); Floating Action Button теперь раскрывает speed-dial меню с 4 быстрыми действиями вместо одной универсальной модалки
- `src/features/auth/AuthContext.tsx` — `signOut()` теперь вызывает `queryClient.clear()` (ТЗ, п.23)
- `src/types/database.ts` — перегенерирован, добавлена `get_dashboard_summary` в `Functions`
- `src/App.test.tsx` — расширена заглушка `supabase.from(...)` (была рассчитана только на `users.eq().single()`, теперь поддерживает произвольную цепочку `select/eq/order/limit` + `single/maybeSingle`, т.к. HomePage теперь дополнительно запрашивает `family_members` через `FamilyProvider`)

---

## 3. RPC / миграции — что добавлено

**`get_dashboard_summary(p_period_start date, p_period_end date)`** — единственная новая функция.

Осознанно **`SECURITY INVOKER`**, а не `DEFINER` (в отличие от всех RPC Этапа 5): функция ничего не обходит, а оборачивает обычный агрегатный `SELECT` к `transactions`/`family_members`, выполняющийся под правами самого вызывающего пользователя. Это значит, что уже существующие RLS-политики Этапа 3 (`transactions_select_role_aware`) применяются к агрегату ровно так же, как к прямому `SELECT`: ADMIN/ADULT видят сумму по всей семье, CHILD — только по своим операциям. `family_id` не принимается параметром — семья определяется только через `family_members` по `auth.uid()`.

`0016` — фикс-миграция (см. п.13): отдельный `revoke execute ... from anon`.

---

## 4. React Query hooks — что создано

- `useDashboardSummary()` — сводка за текущий месяц, ключ `dashboardKeys.summary(familyId, periodStart, periodEnd)`
- `useRecentTransactions(limit = 8)` — последние операции, ключ `dashboardKeys.recentTransactions(familyId, limit)`

Оба enabled только когда `currentFamily?.id` есть. Ключи параметризованы `familyId` — при смене семьи старые данные просто не попадают ни под один активный ключ (отдельная ручная инвалидация не нужна); при logout весь кэш чистится целиком (`queryClient.clear()` в `AuthContext.signOut`, п.23).

---

## 5. Как рассчитываются доходы/расходы/остаток

`SELECT coalesce(sum(amount) filter (where type='income'), 0)` / аналогично для `expense`, `balance = income - expenses` — всё внутри `get_dashboard_summary`, целиком на стороне PostgreSQL (`NUMERIC(14,2)`, без JS floating-point арифметики). Период — `[первый день, последний день текущего месяца]`, считается один раз в `getCurrentMonthRange()` и передаётся в RPC как `date`-параметры. Фронтенд не суммирует ничего сам — только форматирует уже готовые числа через `formatMoney()`.

## 6. Какие реальные данные используются

Всё на Dashboard, для чего уже есть таблица — реальные данные из Supabase: финансовая сводка (`transactions` через RPC), последние операции (`transactions`, только нужные поля + `limit`), участники семьи (`family_members`+`users`, тот же хук `useFamilyMembers`, что и на странице «Семья»), название семьи и приветствие (`FamilyContext`/`public.users.full_name`). Там, где источника данных ещё нет (бюджет — Этап 10, ближайшие события — Этапы 12-13/17), показано честное пустое состояние без единой захардкоженной цифры — ни «150 000 ₽», ни любых других демо-сумм в реальном `/app` нет.

## 7. Как работает состояние пользователя без семьи

`FamilyContext.hasFamily === false` → `HomePage` рендерит `NoFamilyState`: «Добро пожаловать!» + два переключаемых блока — «Создать семью» (та же `CreateFamilyForm` из Этапа 5) и «У меня есть приглашение» (пояснение, что присоединение возможно только по ссылке `/invite/:token` — отдельного ввода кода приглашения в архитектуре 1.0 нет, поэтому кнопка раскрывает уже готовую подсказку, а не новый флоу).

## 8. Как работает loading/error/empty

- **Loading**: пока `FamilyContext.loading` — полноэкранный `DashboardSkeleton` (не показываем «0 ₽» до реальной загрузки, п.20). Когда семья уже известна, каждый блок (сводка/операции/участники) грузится независимо и показывает свой `Skeleton`, не блокируя остальную страницу.
- **Error**: `useDashboardSummary`/`useRecentTransactions` в состоянии ошибки показывают `ErrorState` («Не удалось загрузить данные» + кнопка «Повторить» → `refetch()`), без текста SQL-ошибки на экране (сообщение всегда одна и та же понятная строка).
- **Empty**: пустой бюджет, пустые операции (с кнопкой «Добавить операцию», disabled), пустые события, пустой список участников — везде используется `EmptyState` с понятным текстом, без демо-данных.

## 9. Какие тесты добавлены

- `src/utils/formatMoney.test.ts` — 4 теста: целая сумма, копейки (125000.50 → корректные 2 знака), ноль, отрицательная сумма
- `src/pages/HomePage.test.tsx` — 5 тестов: Skeleton при неизвестной семье, состояние «нет семьи», полный Dashboard с суммами 0 ₽ и пустыми состояниями бюджета/операций/событий, отрицательный остаток с текстовым состоянием («Расходы превышают доходы»), ошибка загрузки без технических деталей

Итого 45 тестов во всём проекте (9 новых на этом этапе), 12 test-файлов. Также пришлось поправить один существующий тест (`src/App.test.tsx`) — его заглушка Supabase была неполной для нового запроса `family_members`, это баг тестовой инфраструктуры, а не приложения (см. п.13).

## 10. Результат `npm run build`

```
tsc -b && vite build
✓ 2962 modules transformed.
✓ built in 714ms
```
**0 ошибок.** Предупреждение про «chunk larger than 500 kB» — информационное, было и раньше, code-splitting вне рамок этого этапа.

## 11. Результат `npm run lint`

```
✖ 4 problems (0 errors, 4 warnings)
```
**0 ошибок.** Все 4 предупреждения — уже знакомый `react-refresh/only-export-components` на файлах-контекстах (не новые, тот же паттерн с Этапа 4-5).

## 12. Результат `npm run test`

```
Test Files  12 passed (12)
     Tests  45 passed (45)
```
**Все тесты зелёные.**

## 13. Результат проверки RLS / security (ТЗ, п.37)

Создано две временные семьи с реальными пользователями через SQL-имперсонацию (`set local role authenticated; set local request.jwt.claims`), как и на Этапе 5: **Family A** (ADMIN A1 + CHILD A2, операции на 10000/3000/500) и **Family B** (ADMIN B1, операции на 20000/7000). Проверено:

| Проверка | Результат |
|---|---|
| A1 (ADMIN) видит `get_dashboard_summary` = сумма по всей своей семье (10000/3500/6500) | PASS |
| A1 не видит `transactions` семьи B напрямую | PASS |
| A1 не видит `family_members` семьи B напрямую | PASS |
| A2 (CHILD) видит `get_dashboard_summary` = **только свои** операции (0/500), не всю семью | PASS |
| B1 (ADMIN) видит сумму только своей семьи (20000/7000/13000), без утечки из A | PASS |
| B1 не видит `transactions` семьи A напрямую | PASS |
| anon (без авторизации) не может вызвать `get_dashboard_summary` | **сначала FAIL, затем PASS после фикса** |

**Найденный и исправленный баг**: первая проверка вызова `get_dashboard_summary` от анонима показала, что функция выполнилась и дошла до `raise exception 'NOT_AUTHENTICATED'` — то есть анониму физически разрешили *вызвать* функцию (просто внутри неё сработала проверка на отсутствие пользователя). Ожидалось, что вызов будет отклонён на уровне привилегий (`permission denied`), как у остальных RPC. Причина — миграция `0015` отозвала `EXECUTE` только у роли `public` (`revoke all ... from public`), но в этом Supabase-проекте роль `anon` получает `EXECUTE` на новые функции schema `public` не только через `PUBLIC`, а напрямую (тот же нюанс, который в Этапе 5 уже был явно учтён отдельной строкой `revoke execute ... from anon` для `create_family`/`cancel_family_invitation`/`create_family_invitation`/`accept_family_invitation`, но по невнимательности пропущен здесь). Исправлено миграцией `0016` (`revoke execute on function public.get_dashboard_summary(date, date) from anon`). Проверено запросом к `information_schema.routine_privileges` (anon больше не в списке) и повторным вызовом от anon (`permission denied for function get_dashboard_summary`). Все временные пользователи/семьи/операции удалены после проверки — подтверждено нулём «осиротевших» строк в `auth.users`, `public.users`, `families`, `family_members`, `transactions`.

Дополнительно проверены `get_advisors` (security) — новых предупреждений, связанных с Этапом 6, нет; уже известный набор (SECURITY DEFINER функции Этапа 5, ожидаемо) не изменился.

## 14. Какие проблемы остались

- **Визуальная проверка брейкпоинтов (320/375/390/430/768/1024, п.29-30) сделана только код-ревью классов Tailwind (`grid-cols-1 sm:grid-cols-3`, `md:grid-cols-2`, `flex-col sm:flex-row`), а не скриншотами** — Playwright не установлен в проекте, а для реального рендера Dashboard нужна настоящая авторизованная сессия с данными (в отличие от статичных модалок/дропдаунов Этапа 2). Если нужно — могу отдельно поднять Playwright и снять скриншоты по всем брейкпоинтам.
- Индексы `families.created_by`/`family_invitations.invited_by` по-прежнему без покрытия (см. отчёт Этапа 5, INFO-уровень, не блокирует).
- Других известных проблем нет — бюджет, операции, цели, планы, аналитика, уведомления, Google Calendar на этом этапе сознательно не реализовывались.

---

Этап 6 реализован полностью в рамках заданных границ. Реальных финансовых операций, бюджетов, целей, планов, recurring, аналитики, уведомлений и Google Calendar на этом этапе не появилось — только архитектурно готовый Dashboard поверх уже существующих данных.

**Жду команды «ЭТАП 6 ПРИНЯТ» для перехода к Этапу 7.**
