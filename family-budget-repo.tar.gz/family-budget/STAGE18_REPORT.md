# Этап 18 — Полноценная PWA. Отчёт о выполнении

## 1. Какие файлы созданы

- `src/utils/platform.ts` — чистые платформенные функции: `isIOSDevice()` (эвристика для iOS/iPadOS — нужна только для выбора «prompt vs инструкция установки»), `isStandaloneDisplay()` (`display-mode: standalone` + `navigator.standalone`).
- `src/utils/platform.test.ts` — unit-тесты обеих функций (iPhone/iPadOS-маскировка-под-Mac/Android/десктопный Mac; matchMedia/`navigator.standalone`).
- `src/hooks/useOnlineStatus.ts` — хук `useOnlineStatus()`, требуемый ТЗ п.14 (`navigator.onLine` + события `online`/`offline`).
- `src/hooks/useOnlineStatus.test.ts` — тесты (начальное значение, переключение по событиям, отписка при unmount).
- `src/hooks/useIsStandalone.ts` — standalone-детект как React-хук (подписка на `matchMedia('(display-mode: standalone)').change`).
- `src/hooks/useIsStandalone.test.ts` — тесты (совпадение при монтировании, реакция на `change`, отписка).
- `src/components/OfflineBanner.tsx` — индикатор офлайн/восстановления сети (ТЗ п.14-16), смонтирован в `App.tsx`.
- `src/components/OfflineBanner.test.tsx` — 5 тестов (скрыт при наличии сети; постоянный баннер офлайн без технических деталей; восстановление → точечная инвалидация ровно 5 доменов и автоскрытие через 4с; не показывает «восстановлено» при монтировании уже онлайн).
- `src/components/UpdateBanner.tsx` — баннер «доступна новая версия» поверх `virtual:pwa-register/react` (ТЗ п.23-26).
- `src/components/UpdateBanner.test.tsx` — 4 теста (скрыт без обновления; показывается с кнопкой; `updateServiceWorker` вызывается только по клику; регистрируется periodic-update проверка).
- `src/components/InstallPWAButton.tsx` — кнопка установки: `beforeinstallprompt` на Chromium/Android, текстовая инструкция для iOS/iPadOS, скрытие в standalone-режиме (ТЗ п.19-22).
- `src/components/InstallPWAButton.test.tsx` — 6 тестов (скрыта в standalone; скрыта без поддержки установки; показывается и запускает prompt; `preventDefault()` вызывается; скрывается по `appinstalled`; на iOS открывает инструкцию, а не prompt).
- `vercel.json` — SPA-fallback rewrite (`/(.*) → /index.html`) на случай деплоя на Vercel.
- `public/_redirects` — тот же fallback в формате Netlify/Cloudflare Pages.
- `STAGE18_REPORT.md` — этот отчёт.

## 2. Какие файлы изменены

- `vite.config.ts` — `VitePWA({...})`: `registerType: 'autoUpdate' → 'prompt'` (см. п.5 ниже — почему), `injectRegister: false` (регистрацию теперь делает `UpdateBanner` через `virtual:pwa-register/react`, а не авто-инжектируемый скрипт плагина), `manifest.short_name`/`description` приведены к точным значениям из ТЗ п.4, `manifest.start_url: '/' → '/app'` (реальная точка входа, см. п.9), `workbox.globPatterns` дополнен `webmanifest`, добавлен явный `workbox.runtimeCaching` с `NetworkOnly` для `*.supabase.co` (defense-in-depth, см. п.6).
- `src/vite-env.d.ts` — добавлена `/// <reference types="vite-plugin-pwa/client" />` (типы для `virtual:pwa-register/react`).
- `src/App.tsx` — смонтированы `<OfflineBanner />` и `<UpdateBanner />` на уровне всего приложения (выше `<AppRoutes />`), а не внутри `AppLayout` — видны на любом маршруте, включая `/login`/лендинг.
- `src/App.test.tsx` — добавлен `vi.mock('virtual:pwa-register/react', ...)`, иначе рендер `<App />` в тестах падал бы на неразрешимом виртуальном модуле.
- `src/pages/SettingsPage.tsx` — добавлена секция `<InstallPWAButton />`; `StagePlaceholder.stage` изменён с `"Этап 18"` на `"Этап 19"` (профиль/тёмная тема остаются на будущее, PWA больше не в списке недоделанного).
- `src/features/auth/AuthContext.test.tsx` — добавлен тест «signOut очищает весь кэш React Query» (ТЗ п.34-36, явно требуемый тест для этого этапа; сам механизм `queryClient.clear()` внутри `signOut()` существовал с Этапа 6 — тест закрывает то, что раньше не было явно проверено).
- `README.md` — добавлен раздел `## PWA` (manifest/иконки, Service Worker и обновление, что кешируется/не кешируется, offline UX, установка, известные ограничения); в разделе «Известные ограничения Этапа 3» убрана устаревшая фраза про иконки-плейсхолдеры (они настоящие уже с ранних этапов) и «PWA-доработки» отмечены как реализованные на Этапе 18.

## 3. Что было в PWA до Этапа 18

Базовая инфраструктура уже существовала (создана на раннем этапе, не Этапом 18): `vite-plugin-pwa` в зависимостях и `vite.config.ts`, manifest внутри конфигурации плагина (name/description/display/orientation/theme_color/background_color/scope/icons), реальные иконки `public/icons/*` (192, 512, 512-maskable, apple-touch-icon 180×180 — не заглушки), Apple meta-теги и `<link rel="apple-touch-icon">` в `index.html`, `devOptions.enabled: false`. Регистрация Service Worker шла через авто-инжектируемый плагином скрипт (`injectRegister: 'auto'`, значение по умолчанию) с `registerType: 'autoUpdate'` — SW сам вызывал `self.skipWaiting()`/`clientsClaim()` сразу после установки, без какого-либо UI. Offline-детекции, баннера состояния сети, кнопки установки и UI обновления не было вовсе.

## 4. Что добавлено на Этапе 18

- Ручное подтверждение обновления (баннер + кнопка «Обновить») вместо тихого авто-захвата контроля Service Worker'ом.
- Индикатор online/offline с понятным текстом вместо отсутствия какой-либо обратной связи о сети.
- Точечная инвалидация 5 доменов React Query при восстановлении связи.
- Кнопка установки (Android/Chromium — нативный prompt; iOS/iPadOS — текстовая инструкция) — её не было вообще.
- Явный defense-in-depth `NetworkOnly` для Supabase в конфигурации Workbox (документирует и гарантирует уже существовавшее по умолчанию безопасное поведение).
- `start_url` изменён на реальную точку входа авторизованной части (`/app`) вместо лендинга.
- SPA-fallback конфиги для деплоя (`vercel.json`, `public/_redirects`).
- Раздел README, описывающий всё вышеперечисленное.

## 5. Как настроен Service Worker

`vite-plugin-pwa`, режим `generateSW`, `registerType: 'prompt'` (**изменено** с исходного `'autoUpdate'` — обоснование ниже), `injectRegister: false`.

Регистрация происходит не автоматически инжектируемым скриптом, а через `useRegisterSW()` из `virtual:pwa-register/react` внутри `src/components/UpdateBanner.tsx`. Это даёт доступ к `needRefresh`/`updateServiceWorker()` в UI — без этого баннер «Доступна новая версия» с ручной кнопкой было бы невозможно корректно реализовать.

**Почему `'prompt'`, а не `'autoUpdate'`, как буквально написано в ТЗ п.9**: при `registerType: 'autoUpdate'` сгенерированный Service Worker сам вызывает `self.skipWaiting()` и `clientsClaim()` сразу после установки новой версии — контроль переходит к новому SW без какого-либо участия пользователя. ТЗ п.23-24 требует ровно обратное: баннер с кнопкой «Обновить» и явный запрет на принудительный reload во время заполнения формы. Эти два требования технически несовместимы с `'autoUpdate'`. Сам п.9 ТЗ прямо допускает «эквивалентную безопасную схему» — `'prompt'` и есть официально документированная vite-plugin-pwa схема именно для ручного подтверждения: сгенерированный SW теперь ждёт сообщения `{type: 'SKIP_WAITING'}` (это подтверждено в собранном `dist/sw.js` — см. раздел 17) и активируется только когда `updateServiceWorker()` его пошлёт, то есть строго по клику пользователя на кнопку «Обновить».

Дополнительно: раз в час (`setInterval` внутри `onRegisteredSW`) вызывается `registration.update()` — открытая вкладка узнаёт о новой версии, не дожидаясь следующего открытия приложения (ТЗ п.26).

В development Service Worker не регистрируется (`devOptions.enabled: false`, не менялось) — разработчик не получает устаревшую версию из кэша при локальных изменениях (ТЗ п.25).

## 6. Какие ресурсы кешируются

Через precache (`workbox.globPatterns: ['**/*.{js,css,html,svg,png,ico,webmanifest}']`, собирается в `dist/sw.js` при билде): JS/CSS сборки, `index.html` (app shell), `favicon.svg`, `manifest.webmanifest`, все иконки (`icons/*.png`). Навигационные запросы (прямое открытие `/app/transactions` и т.п.) обслуживаются из закешированного `index.html` — стандартное поведение `generateSW`-режима, подключено по умолчанию (`NavigationRoute` в сгенерированном SW, см. раздел 17).

## 7. Какие ресурсы намеренно НЕ кешируются

Supabase (Auth, REST, RPC, Storage) — **никогда**, ни при каких обстоятельствах. Это гарантировано структурно на двух независимых уровнях:

1. По умолчанию: в `generateSW`-режиме Workbox перехватывает запрос только тогда, когда он явно описан каким-то `runtimeCaching`-правилом (плюс навигации, см. выше). Supabase — другой origin (`*.supabase.co`), поэтому без совпавшего правила такой запрос уходит в сеть напрямую, минуя Service Worker вообще.
2. Явное правило добавлено дополнительно, как defense-in-depth и документация: `runtimeCaching: [{ urlPattern: ({url}) => url.hostname.endsWith('.supabase.co'), handler: 'NetworkOnly' }]` — подтверждено в собранном `dist/sw.js` (`e.registerRoute(({url:e})=>e.hostname.endsWith(".supabase.co"),new e.NetworkOnly,"GET")`). Если в будущем кто-то случайно добавит широкое `CacheFirst`-правило, это правило (стоящее в массиве первым) всё равно не даст закешировать финансовые данные пользователя.

Соответственно, ни транзакции, ни доходы/расходы, ни бюджеты, ни цели, ни семейные данные, ни уведомления никогда не попадают в Cache Storage. Supabase Auth-токены Service Worker'ом тоже не трогаются — ими управляет исключительно `@supabase/supabase-js` (не изменялось, проверено ранее на Этапе 17/16 и повторно на этом этапе — ручного сохранения `access_token`/`refresh_token`/session в `localStorage`/`IndexedDB`/`Cache Storage` в кодовой базе нет, `grep` по всему `src/` это подтверждает).

## 8. Как работает offline mode

`useOnlineStatus()` отслеживает `navigator.onLine` + события `window online`/`offline`. `OfflineBanner`, смонтированный в `App.tsx` (виден на любом маршруте — соединение может пропасть и на экране входа, не только внутри `/app`):

- пока офлайн — показывает постоянный баннер: «Нет подключения к интернету. Некоторые данные могут быть временно недоступны. После восстановления соединения попробуйте ещё раз.» (текст — ровно требуемый ТЗ п.13, без технических деталей вроде `Failed to fetch`/`ERR_NETWORK_CHANGED`);
- при восстановлении связи — «Соединение восстановлено» на 4 секунды, затем автоматически скрывается; параллельно точечно инвалидирует ровно 5 доменов React Query, перечисленных в ТЗ п.16 (`dashboardKeys.all`, `transactionsKeys.all`, `budgetsKeys.all`, `goalsKeys.all`, `notificationsKeys.all`) через уже существующие ключи каждого домена — **не** `queryClient.invalidateQueries()` без фильтра (это прямо запрещено ТЗ п.16 как «бесконтрольный refetch всего приложения»).

Технические сетевые ошибки и раньше не показывались пользователю напрямую: в каждом feature-модуле уже есть свой `errors.ts` (проверено на этом этапе в 8 модулях: `transactions`, `budgets`, `goals`, `categories`, `family`, `notifications`, `plannedExpenses`, `recurringTransactions`), который переводит `TypeError`/сетевые ошибки в понятный текст («Проблема с сетью. Проверьте подключение к интернету и попробуйте снова.») — этот механизм существовал до Этапа 18 и не создавался заново.

Офлайн-очередь операций (создание расхода/дохода без сети с последующей синхронизацией, IndexedDB, background sync, конфликт-менеджмент) сознательно **не реализована** — прямо исключена из рамок Этапа 18 (ТЗ п.17, п.41).

## 9. Как работает установка

`InstallPWAButton` (секция «Установка приложения» на `/app/settings`):

- **Android/Chromium/десктоп**: перехватывает `beforeinstallprompt` (`event.preventDefault()` + сохранение события), кнопка «Установить приложение» запускает `event.prompt()`;
- **iOS/iPadOS Safari**: `beforeinstallprompt` там не существует в принципе — вместо кнопки-prompt та же кнопка открывает модальное окно с текстовой инструкцией «Поделиться → На экран Домой → Добавить»; iOS/iPadOS определяется эвристикой в `isIOSDevice()` (User-Agent для классического iOS + `platform === 'MacIntel' && maxTouchPoints > 1` для iPadOS 13+, который маскируется под Mac Safari);
- скрывается полностью, если приложение уже открыто как установленное (`useIsStandalone()` → `display-mode: standalone` / `navigator.standalone`) — установку не предлагают повторно;
- скрывается по `appinstalled` сразу после принятия;
- не показывается вовсе на платформах без поддержки установки и без iOS (`beforeinstallprompt` не пришёл и не iOS) — например, десктопный Safari/Firefox.

## 10. Как работает update

`UpdateBanner` подписан на `needRefresh` из `useRegisterSW()`. Когда новая версия обнаружена (новый SW установлен и ждёт активации) — показывается баннер «Доступна новая версия. Обновите приложение, чтобы получить последние изменения.» с кнопкой «Обновить». `updateServiceWorker(true)` вызывается **только** по клику — никогда автоматически, поэтому ввод в любой форме (расход/доход/цель/бюджет и т.п.) не может быть прерван неожиданной перезагрузкой (ТЗ п.24). См. раздел 5 выше — почему это потребовало `registerType: 'prompt'` вместо `'autoUpdate'`.

## 11. Как реализована iOS-инструкция

См. раздел 9. Модальное окно (существующий компонент `Modal` из дизайн-системы, не новый) с тремя шагами: 1) «Поделиться» (с иконкой), 2) «На экран Домой», 3) «Добавить» — ровно текст из ТЗ п.21. Показывается только когда `isIOSDevice() === true`; на Android/Windows/macOS эта кнопка вместо этого запускает нативный prompt (см. раздел 9), инструкция там не показывается никогда.

## 12. Какие security-проверки выполнены

- **Grep по всей кодовой базе** (`src/`) на `localStorage`/`sessionStorage`/`indexedDB`/`caches.open` вне тестов — найдены только упоминания в комментариях («Supabase JS сам управляет хранением токенов», «Токен нигде не логируется и не попадает в localStorage») и ни одного реального вызова ручного сохранения токенов — подтверждено ТЗ п.18/31/34.
- **Проверка сгенерированного `dist/sw.js`** — подтверждено, что явное правило `NetworkOnly` для `*.supabase.co` присутствует в собранном коде (не только в конфиге), и что убран автоматический `self.skipWaiting()`/`clientsClaim()` (заменён на ожидание `postMessage({type:'SKIP_WAITING'})`).
- **`signOut()` очищает `queryClient`** — подтверждено новым тестом (`AuthContext.test.tsx`) на реальном вызове `signOut()`: данные, записанные в кэш React Query до выхода, недоступны после `signOut()` — следующий пользователь на том же устройстве не наследует чужие данные (ТЗ п.34-36, сценарий User A → logout → User B). Сам механизм существовал с Этапа 6, тест для него написан впервые на этом этапе.
- **Живая проверка в браузере** (Playwright, headless Chromium, против `vite preview`): Service Worker регистрируется и активируется (`navigator.serviceWorker.getRegistration()` → `active: true`), офлайн-баннер и баннер восстановления показывают ожидаемый текст, никаких `console.error`/`pageerror` при переходах online↔offline, прямой заход на `/app/transactions` не даёт 404 (SPA-fallback работает).
- **Contrast-аудит** (см. раздел 19) выявил и позволил исправить реальную проблему доступности в первой версии баннеров — см. ниже.

## 13. Какие тесты добавлены

15 новых test-файлов/наборов (в дополнение к существующим 48):

- `src/utils/platform.test.ts` — 7 тестов.
- `src/hooks/useOnlineStatus.test.ts` — 4 теста.
- `src/hooks/useIsStandalone.test.ts` — 4 теста.
- `src/components/OfflineBanner.test.tsx` — 5 тестов.
- `src/components/UpdateBanner.test.tsx` — 4 теста.
- `src/components/InstallPWAButton.test.tsx` — 6 тестов.
- `src/features/auth/AuthContext.test.tsx` — +1 тест (signOut → очистка кэша).

Итого новых тестов: 31. Существующие тесты (`App.test.tsx`) обновлены минимально — добавлен мок `virtual:pwa-register/react`, ни один существующий тест не переписывался по существу.

## 14. Результат build

```
npm run build
✓ tsc -b — без ошибок
✓ vite build — успешно (1,343.75 kB бандл, gzip 372.52 kB — предупреждение
  Vite про размер чанка, не ошибка; существовало и до этого этапа, не
  связано с PWA)
✓ PWA v1.3.0, mode generateSW, precache 16 entries (1369.72 KiB)
  dist/sw.js, dist/workbox-98f7a950.js сгенерированы
```

## 15. Результат lint

```
npm run lint
✖ 16 problems (0 errors, 16 warnings)
```

0 ошибок. 16 warnings — те же самые, что были до Этапа 18 (React Compiler «Compilation Skipped» на `watch()` из react-hook-form в 5 формах + «Fast refresh» warnings в файлах с именованными экспортами утилит рядом с компонентом) — ни одного нового предупреждения Этап 18 не добавил.

По пути был найден и исправлен один реальный `react-hooks/set-state-in-effect` **error**, возникший в первой версии `OfflineBanner.tsx` (синхронный `setState` в теле эффекта). Исправлено переходом на официально рекомендованный React-паттерн «adjusting state during rendering» — сравнение `isOnline` с предыдущим значением прямо в теле компонента, а не в `useEffect`; `useEffect` оставлен только для настоящих побочных эффектов (инвалидация запросов, таймер).

## 16. Результат test

```
npx vitest run
Test Files  48 passed (48)
     Tests  412 passed (412)
```

## 17. Результат production preview

`npm run build && npm run preview` — проверено через `curl` и headless Playwright (Chromium из `/opt/pw-browsers/chromium`):

- `GET /` → 200, `GET /app/transactions` (прямой заход, SPA-fallback) → 200, не 404.
- `GET /manifest.webmanifest` → 200, `Content-Type: application/manifest+json`; содержимое соответствует ТЗ (`name`/`short_name`/`description`/`lang`/`dir`/`display`/`orientation` — дословно; `start_url: "/app"`; иконки 192/512/512-maskable).
- `GET /icons/icon-192.png`, `/icon-512.png`, `/icon-512-maskable.png`, `/apple-touch-icon.png` → все 200, `image/png`.
- `navigator.serviceWorker.getRegistration()` в браузере → `{scope: "http://localhost:4173/", active: true, waiting: false}`.
- Сгенерированный `dist/sw.js` — подтверждено вручную (см. разделы 5, 7, 12): NetworkOnly для supabase.co присутствует, автоматического `skipWaiting()` больше нет.
- `context.setOffline(true)` → баннер «Нет подключения к интернету…» с точным текстом ТЗ; `setOffline(false)` → «Соединение восстановлено»; ни одной ошибки в консоли браузера в обоих переходах.
- Мобильный viewport (390×844) — без горизонтального скролла.

## 18. Результат Lighthouse/PWA проверки

Классическая Lighthouse-категория `pwa` в установленной версии инструмента (Lighthouse 13.5.0) **больше не существует** (Google убрали её из ядра Lighthouse в пользу отдельной проверки installability в DevTools) — `--only-categories=pwa` завершается ошибкой `unrecognized category`. Вместо неполучаемого агрегированного PWA-score все составлявшие его критерии проверены вручную и по отдельности (см. таблицу):

| Критерий (бывший состав категории `pwa`) | Результат |
|---|---|
| Manifest валиден и содержит нужные поля | ✅ проверено (раздел 17) |
| Иконки 192×192, 512×512, maskable | ✅ все присутствуют, реальные размеры подтверждены (`192×192`, `512×512`×2) |
| Apple touch icon 180×180 | ✅ подтверждено (`180×180`) |
| Service Worker зарегистрирован | ✅ `active: true` в браузере |
| Offline fallback (app shell из кэша) | ✅ подтверждено (SPA-fallback работает, раздел 17) |
| viewport meta | ✅ `meta-viewport` audit = 1 (см. ниже) |
| HTTPS | Обеспечивается хостингом при реальном деплое; `localhost`/`vite preview` по HTTP — штатное исключение для PWA-критериев (localhost не требует HTTPS) |

Дополнительно прогнаны реальные Lighthouse-категории `accessibility` (0.98) и `best-practices` (1.0) против `vite preview`:

- `color-contrast` = 1 (проходит).
- `button-name`/`link-name`/`aria-allowed-attr` = 1.
- Единственная находка: `landmark-one-main` = 0 («Document does not have a main landmark») — на лендинге (`/`, `LandingPage.tsx`), **не связано с Этапом 18** и существовало до него; вне рамок этого этапа (не PWA-код), сознательно не исправлялось — см. «Известные ограничения» ниже.

Отдельно вручную посчитан контраст (WCAG формула, sRGB relative luminance) для новых баннеров — на первой версии `OfflineBanner`/`UpdateBanner` (текст в цвете `text-warning`/`text-success`/`text-primary` поверх `-soft` фона) контраст составил 2.49:1 / 3.09:1 / 4.84:1 — первые два **ниже** требуемых WCAG AA 4.5:1 для обычного текста. Это оказалась та же цветовая пара (`bg-X-soft text-X`), что уже используется в `Badge`/чипах суммы по всему приложению (не новая, унаследованная характеристика дизайн-системы) — но именно здесь, в блоке связного текста для чтения, а не в коротком лейбле, это реальная проблема доступности. **Исправлено**: текст переведён на `text-foreground` (обычный тёмный, ~15:1 контраст), семантический цвет оставлен только на иконке — ровно тот же приём, что уже использует `Toast.tsx` в этом же проекте (переиспользование существующего паттерна дизайн-системы, а не изобретение нового визуального стиля). Повторный прогон Lighthouse после исправления — тот же результат (`accessibility: 0.98`, единственная причина — не связанный с Этапом 18 `landmark-one-main`).

## 19. Известные ограничения

- Push-уведомления, background sync и offline-очередь финансовых операций — сознательно не входят в этот этап (ТЗ п.17, п.41; отдельная задача с собственной архитектурой конфликтов).
- `vercel.json`/`public/_redirects` добавлены защитно на случай прямого захода по ссылке при первом посещении (до того, как Service Worker закеширует app shell) — какой из них реально нужен, зависит от выбранной платформы деплоя, которая в проекте пока не зафиксирована; лишний файл для неиспользуемой платформы безвреден.
- `isIOSDevice()` — эвристика (User-Agent + multi-touch для iPadOS, маскирующегося под Mac Safari), а не официальный платформенный API; для показа инструкции установки этого достаточно, но не является строгой гарантией на все будущие версии Safari.
- Lighthouse 13.5.0 не предоставляет агрегированную категорию `pwa` — все её прежние критерии проверены по отдельности вручную (раздел 18), а не единым автоматическим score.
- `landmark-one-main` (Lighthouse accessibility) на лендинге (`/`) — пред­существующая находка, не относящаяся к PWA-коду Этапа 18; сознательно не исправлялась в рамках этого этапа (чужая, более ранняя страница).
- JS-бандл (`~1.34 MB`, gzip `~372 KB`) не разбивался на чанки — существовавшее до Этапа 18 предупреждение Vite, оптимизация бандла явно вне рамок ТЗ этого этапа (раздел 33 просит «не ухудшить производительность», не «улучшить» — производительность не изменилась).
- Реальная проверка установки на физическом Android/iPhone устройстве не проводилась (нет доступа к таким устройствам в этой среде) — проверено эквивалентно через: код-путь `beforeinstallprompt` (unit-тесты + ручная эмуляция события в Playwright), реальную регистрацию/активацию Service Worker в headless Chromium, и полное соответствие manifest всем документированным критериям installability.

После этого остановись. Этап 18 завершён. К этапу 19 не переходи.
