# ЭТАП 4 — Отчёт: Authentication

Статус: реализовано и проверено (build/lint/test — зелёные). Семья, приглашения, финансовые
данные и всё, что за пределами authentication, **не затронуто** — по правилам этапа.

---

## 1. Какие файлы созданы

- `src/features/auth/schemas.ts` — Zod-схемы: `registerSchema`, `loginSchema`,
  `forgotPasswordSchema`, `resetPasswordSchema` (+ выведенные типы).
- `src/features/auth/authErrors.ts` — `getAuthErrorMessage(error)`: маппинг ошибок Supabase
  в понятные русскоязычные сообщения.
- `src/features/auth/ProtectedRoute.tsx` — guard для `/app/*`.
- `src/features/auth/PublicOnlyRoute.tsx` — guard для `/login`, `/register`.
- `src/features/auth/PasswordField.tsx` — обёртка над `Input` с переключателем
  видимости пароля (глаз, lucide-react, `aria-label`).
- `src/pages/auth/ResetPasswordPage.tsx` — экран `/reset-password`.
- `src/features/auth/AuthContext.test.tsx` — тесты критичной логики `AuthProvider`.
- `src/features/auth/ProtectedRoute.test.tsx` — тесты `ProtectedRoute`.
- `src/pages/auth/LoginPage.test.tsx` — тесты формы входа.
- `src/pages/auth/RegisterPage.test.tsx` — тесты формы регистрации.
- `STAGE4_REPORT.md` — этот отчёт.

## 2. Какие файлы изменены

- `src/features/auth/AuthContext.tsx` — полностью переписан: реальная интеграция с
  Supabase Auth (был статичный stub).
- `src/app/routes.tsx` — добавлены `ProtectedRoute`/`PublicOnlyRoute`, маршрут
  `/reset-password`.
- `src/pages/auth/LoginPage.tsx`, `RegisterPage.tsx`, `ForgotPasswordPage.tsx` — переписаны
  на реальные вызовы Supabase, RHF+Zod, loading/disabled, обработку ошибок.
- `src/pages/HomePage.tsx` — вместо демо-данных Этапа 2 — реальный welcome-экран
  («Добро пожаловать, {имя}» + плейсхолдер про создание семьи, п.25).
- `src/components/Sidebar.tsx`, `src/components/Header.tsx` — вместо `MOCK_USER`
  используют `useAuth()`; в `Sidebar` добавлена кнопка выхода.
- `src/components/ui/Input.tsx` — добавлен проп `rightElement?: ReactNode`
  (кликабельный элемент в поле, в отличие от декоративного `rightIcon`) — нужен для
  переключателя видимости пароля без дублирования стилей.
- `src/App.test.tsx` — переписан под новую защиту маршрутов.

## 3. Удалено

- `src/lib/mockData.ts` — после миграции `Header`/`Sidebar`/`HomePage` на реальные данные
  файл остался неиспользуемым (проверено через grep) и удалён, чтобы не путать с реальными
  данными авторизованного пользователя.

## 4. Как реализован AuthProvider

`src/features/auth/AuthContext.tsx`, React Context (без Zustand/Redux):

- При монтировании вызывает `supabase.auth.getSession()` для начальной сессии и
  одновременно подписывается на `supabase.auth.onAuthStateChange()`. Пока начальный
  запрос не завершился — `isLoading: true`; `ProtectedRoute`/`PublicOnlyRoute` в это время
  показывают `LoadingState`, а не редиректят — это и предотвращает мигание
  `Login → App → Login` при первой загрузке (п.3).
- Отдельный `useEffect` по изменению `user` подгружает профиль из `public.users`
  (обычная таблица под RLS, не часть Supabase Auth). Наружу `profile` отдаётся только
  пока есть `user` (`profile: user ? profile : null` в мемоизированном значении контекста) —
  так после logout не может «просочиться» устаревший профиль, и при этом не нужно
  синхронно дёргать `setState` в эффекте на каждый рендер (это принципиально: при первой
  версии `eslint-plugin-react-hooks` (`set-state-in-effect`) справедливо ругался на
  синхронный `setProfile(null)` в эффекте — переделано на производное значение).
  Подписка на `onAuthStateChange` корректно отписывается (`subscription.unsubscribe()`)
  при unmount.
- Методы `signUp`, `signIn`, `signOut`, `resetPassword`, `updatePassword`,
  `refreshSession` — тонкие обёртки над `supabase.auth.*`, возвращают `{ error }`
  (кроме `signOut`), не создают собственных JWT/токенов и не пишут ничего в
  localStorage вручную — сессией полностью управляет `@supabase/supabase-js`.
- `resetPassword` вычисляет `redirectTo` как `` `${window.location.origin}/reset-password` ``
  во время вызова — работает и на localhost, и на будущем production-домене без
  хардкода (п.10).

## 5. Как реализован ProtectedRoute

`src/features/auth/ProtectedRoute.tsx` — layout-компонент для `react-router-dom` v7:
пока `isLoading` — показывает `LoadingState` («Проверяем вход…»); если не авторизован —
`<Navigate to="/login" replace />`; если авторизован — `<Outlet />`. Обёрнут вокруг всего
поддерева `/app` в `routes.tsx`, поэтому `/app/transactions`, `/app/goals`, `/app/analytics`,
`/app/family`, `/app/settings` защищены автоматически, без дублирования на каждый роут.
Проверка идёт по `isAuthenticated` из `AuthContext`, который построен на реальной Supabase
session, а не на localStorage (п.12).

Симметрично — `PublicOnlyRoute.tsx` уводит уже авторизованного пользователя с `/login` и
`/register` на `/app` (п.14). `/forgot-password`, `/reset-password`, `/invite/:token`
оставлены публичными без guard — по п.13 (`/invite/:token` на этом этапе так и остаётся
заглушкой из Этапа 2).

## 6. Как реализована регистрация

`src/pages/auth/RegisterPage.tsx`: форма (Имя / Email / Пароль / Подтверждение) на
`react-hook-form` + `zodResolver(registerSchema)` (email обязателен и валиден; пароль ≥ 8
символов; подтверждение проверяется через `.refine()` с `path: ['confirmPassword']`).

По сабмиту — `signUp({ fullName, email, password })` →
`supabase.auth.signUp({ email, password, options: { data: { full_name } } })`.
Семья **не создаётся** — только учётная запись (п.5, п.26).

Обработка двух возможных настроек email confirmation без предположений о том, какая
активна (п.7): если Supabase сразу вернул `session` — `isAuthenticated` в контексте
становится `true`, и `PublicOnlyRoute` сам уводит с `/register` на `/app` (никакого
ручного `navigate()` в компоненте); если `session` нет — показывается экран
«Проверьте почту» с формулировкой «если требуется подтверждение» (не утверждает, что
оно точно требуется).

## 7. Как реализован Login

`src/pages/auth/LoginPage.tsx`: форма Email/Пароль на RHF+Zod, кнопка «Войти».
По сабмиту — `signIn({ email, password })` → `supabase.auth.signInWithPassword(...)`.
При ошибке — `getAuthErrorMessage(error)` рендерится в `role="alert"`. Успешный вход не
требует ручного редиректа: `isAuthenticated` меняется → `PublicOnlyRoute` уводит на `/app`
(п.8, п.27). Кнопка `disabled`/`isLoading` на время запроса — защита от двойного сабмита
(п.16).

## 8. Как реализован Logout

Кнопка выхода — `IconButton` в `Sidebar.tsx`, вызывает `signOut()` из `AuthContext`
→ `supabase.auth.signOut()`. Session Supabase очищается сама (без ручного localStorage);
`onAuthStateChange` обновляет `session` → `isAuthenticated: false` →
`ProtectedRoute` реактивно уводит на `/login` при следующей попытке доступа к `/app/*`
(п.9, п.28) — защищённые страницы недоступны через frontend-навигацию после выхода.

## 9. Как реализовано восстановление пароля

Два экрана:

- `/forgot-password` (`ForgotPasswordPage.tsx`) — поле Email → `resetPassword(email)` →
  `supabase.auth.resetPasswordForEmail(email, { redirectTo })` (п.10).
- `/reset-password` (`ResetPasswordPage.tsx`, новый) — рассчитан на переход по ссылке
  из письма Supabase. Используется встроенное поведение `supabase-js`
  (`detectSessionInUrl: true` по умолчанию) — сессия из recovery-ссылки устанавливается
  автоматически до рендера компонента, поэтому страница не парсит URL вручную, а просто
  ориентируется на `isLoading`/`isAuthenticated` из `useAuth()` (см. комментарий в файле).
  Форма — новый пароль + подтверждение (Zod, `.refine()`), сабмит →
  `updatePassword(password)` → `supabase.auth.updateUser({ password })`. Пароль нигде не
  попадает в URL (п.11, п.21).

## 10. Как создаётся public.users

Через существующий Postgres-триггер `handle_new_auth_user`
(`AFTER INSERT ON auth.users`, `SECURITY DEFINER`), добавленный ещё на Этапе 3 в
`supabase/migrations/0007_auth_sync_trigger.sql`. Проверено напрямую в БД перед
началом работы над Этапом 4 (`pg_trigger`/`pg_proc`):

```
trg_on_auth_user_created — AFTER INSERT ON auth.users, enabled ('O')

handle_new_auth_user():
  insert into public.users (id, full_name, avatar_url)
  values (new.id,
          coalesce(new.raw_user_meta_data ->> 'full_name', new.email, 'Новый пользователь'),
          new.raw_user_meta_data ->> 'avatar_url');
  insert into public.user_settings (user_id) values (new.id);
```

Триггер уже использует `full_name` из metadata и уже подставляет `user_settings` —
именно то, что требует п.6. **Дубликат не создавался** — переиспользован как есть.
Race condition с фронтендом исключена: фронтенд не пишет в `public.users` напрямую,
только читает (`select * from users where id = ...` в `AuthContext` для подгрузки
профиля).

## 11. Какие Supabase migrations добавлены/изменены

**Ни одной.** Миграций в Этапе 4 не потребовалось — весь нужный DB-слой (таблица
`users`, триггер `handle_new_auth_user`, RLS) уже существовал с Этапа 3
(`0001`…`0011`, список подтверждён через `list_migrations`). Этап 4 — чисто
frontend-этап поверх готовой схемы.

## 12. Какие настройки Supabase необходимо проверить вручную

Список ручных действий в Dashboard (ничего из этого нельзя ни проверить, ни
изменить через доступные инструменты — это настройки Auth-сервиса, не хранятся в БД):

1. **Authentication → Providers → Email → "Confirm email"** — нужно вручную посмотреть,
   включено ли подтверждение email. Интерфейс написан так, чтобы корректно работать
   в обоих случаях (п.7), но для точного тестирования сценария регистрации нужно знать
   текущее значение.
2. **Authentication → URL Configuration → Redirect URLs** — нужно добавить
   `http://localhost:5173/reset-password` (и позже — продакшен-домен) в allow-list,
   иначе `resetPasswordForEmail` вернёт письмо со ссылкой, которую Supabase отклонит
   при переходе.
3. **Authentication → Emails → SMTP** — по умолчанию Supabase использует встроенный
   ограниченный по частоте mailer; для полноценного end-to-end теста восстановления
   пароля (п.29) в проде стоит настроить собственный SMTP. Само по себе не блокирует
   Этап 4.
4. Проверить, что `.env.local` с реальными `VITE_SUPABASE_URL`/`VITE_SUPABASE_ANON_KEY`
   существует локально у каждого разработчика (в Git не должен попадать —
   `.gitignore` это уже обеспечивает, проверено).

## 13. Результат build

```
npm run build
✓ tsc -b — 0 ошибок
✓ vite build — успешно (661.90 kB / gzip 191.93 kB, есть info-предупреждение
  Vite про размер чанка — не ошибка, не связано с Этапом 4, можно адресовать
  через code-splitting на будущих этапах)
✓ PWA precache сгенерирован
```

Zero TypeScript errors — критерий п.34 выполнен.

## 14. Результат lint

```
npm run lint
✖ 3 problems (0 errors, 3 warnings)
```

Все 3 warning — `react-refresh/only-export-components`, для файлов, которые экспортируют
и компонент-провайдер, и хук (`ThemeContext.tsx` — существовал до Этапа 4 с тем же
warning; `Toast.tsx` — существовал до Этапа 4; `AuthContext.tsx` — новый, тот же паттерн).
Ошибок нет. По пути была найдена и исправлена настоящая проблема: `eslint-plugin-react-hooks`
(`set-state-in-effect`) указал на синхронный `setProfile(null)` в эффекте
`AuthContext.tsx` — переделано на производное значение `profile: user ? profile : null`
(см. п.4) вместо сброса состояния внутри эффекта.

## 15. Результат test

```
npm run test -- --run
Test Files  5 passed (5)
     Tests  17 passed (17)
```

Файлы и покрытие (п.33):

- `LoginPage.test.tsx` (4 теста) — пустая отправка → ошибки валидации, `signIn` не
  вызван; успешная отправка → `signIn` с правильными `{email, password}`; понятное
  сообщение об ошибке («Неверный email или пароль.») при `Invalid login credentials`;
  переключение видимости пароля по кнопке-глазу.
- `RegisterPage.test.tsx` (2 теста) — несовпадение паролей → ошибка «Пароли не
  совпадают», `signUp` не вызван; успешная регистрация → экран «Проверьте почту»,
  `signUp` вызван с корректными данными формы.
- `ProtectedRoute.test.tsx` (3 теста) — loading-состояние, редирект неавторизованного
  на `/login`, доступ авторизованного к защищённому контенту.
- `AuthContext.test.tsx` (4 теста) — loading → anonymous при отсутствии сессии; сразу
  authenticated, если сессия уже есть при первой загрузке (без мигания на /login);
  подписка/отписка от `onAuthStateChange`; `useAuth()` бросает понятную ошибку вне
  `AuthProvider`.
- `App.test.tsx` (4 теста) — landing-страница; редирект неавторизованного с `/app` на
  `/login`; главный экран авторизованному пользователю на `/app`; 404 на неизвестном
  маршруте.

Supabase-бэкенд через frontend unit-тесты не тестировался — все обращения к Supabase
замоканы через `vi.hoisted()` + `vi.mock('@/lib/supabase' | '@/features/auth/AuthContext')`,
как и требует п.33.

## 16. Какие проблемы остались / что не проверено автоматически

- **Email confirmation setting** — не удалось прочитать текущее значение через
  доступные инструменты (это настройка Auth-сервиса, не строка в БД) — см. п.12,
  пункт 1. Требуется ручная проверка в Dashboard.
- **Полный end-to-end сценарий восстановления пароля (п.29, шаги 3–8: реальное письмо
  → переход по ссылке → `/reset-password` → новый пароль → вход)** не проверялся
  «живьём» (нет доступа к почтовому ящику/SMTP из этой среды) — логика построена на
  задокументированном поведении `supabase-js` (`detectSessionInUrl`) и покрыта тем,
  что можно протестировать без реальной сессии восстановления (рендер экрана,
  валидация формы, вызов `updateUser`). Явно указываю это, как и требует п.29, вместо
  того чтобы заявлять, что сценарий «проверен».
- **Redirect URL allow-list в Supabase** нужно будет пополнить вручную (см. п.12,
  пункт 2) — иначе реальная ссылка восстановления пароля будет отклонена Supabase при
  переходе, хотя код на это уже рассчитан.
- **Responsive (320/375/390/430px) и accessibility** — не считаю нужным вводить новые
  примитивы: все auth-экраны построены на уже проверенных на Этапе 2 `Card`/`Input`/
  `Button`/`AuthLayout` (одноколоночная форма, без фиксированных ширин шире экрана).
  Аccessibility-моменты из п.32 реализованы явно: `label` на каждом поле через
  `Input`/`PasswordField`, `aria-label` на кнопке показать/скрыть пароль,
  `autoComplete="email"` на email, `autoComplete="current-password"` на пароле входа,
  `autoComplete="new-password"` на паролях регистрации/сброса, ошибки — через `role="alert"`
  под полем/формой. Визуальная проверка на реальных 320–430px не проводилась
  (нет живого браузера в этой сессии) — отмечаю как непроверенное, а не как «сделано».

---

Этап 4 завершён по духу и букве технического задания. Семья, приглашения, финансовые
данные и всё, что относится к Этапу 5+, не реализовывались.

Жду команду: **«ЭТАП 4 ПРИНЯТ»**.
