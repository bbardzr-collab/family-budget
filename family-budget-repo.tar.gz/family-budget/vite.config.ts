/// <reference types="vitest/config" />
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import { VitePWA } from 'vite-plugin-pwa'

// https://vite.dev/config/
export default defineConfig({
  plugins: [
    react(),
    tailwindcss(),
    VitePWA({
      // 'prompt' (не 'autoUpdate', как было на раннем этапе) — Service
      // Worker больше НЕ вызывает self.skipWaiting() сам по себе сразу
      // после установки; ждёт явного updateServiceWorker() из приложения.
      // Это то самое "получить новый SW и обновиться без ручной очистки
      // кэша" (ТЗ Этапа 18, п.9), но с UI-подтверждением обновления, а не
      // тихим авто-захватом контроля — см. src/components/UpdateBanner.tsx,
      // где это объяснено подробнее и откуда вызывается updateServiceWorker.
      registerType: 'prompt',
      // Регистрацию делает сам UpdateBanner через virtual:pwa-register/react
      // (нужен доступ к needRefresh/updateServiceWorker в UI) — стандартный
      // auto-injected script плагина здесь не нужен и конфликтовал бы с ним.
      injectRegister: false,
      includeAssets: ['favicon.svg', 'icons/apple-touch-icon.png'],
      manifest: {
        id: '/',
        name: 'Семейный бюджет',
        short_name: 'Семейный бюджет',
        description: 'Все деньги семьи — в одном месте.',
        lang: 'ru',
        dir: 'ltr',
        // Реальная точка входа авторизованной части приложения (см.
        // src/app/routes.tsx) — не выдумано: ProtectedRoute сам уводит на
        // /login неавторизованного пользователя, поэтому /app одинаково
        // корректно работает и как "уже вошёл" (сразу Dashboard), и как
        // "давно не заходил" (мгновенный редирект на форму входа) —
        // единственный вход, который осмысленно открывать при запуске
        // установленного приложения (ТЗ Этапа 18, п.4).
        start_url: '/app',
        scope: '/',
        display: 'standalone',
        orientation: 'portrait-primary',
        theme_color: '#5b4fe8',
        background_color: '#f7f7fb',
        icons: [
          {
            src: '/icons/icon-192.png',
            sizes: '192x192',
            type: 'image/png',
          },
          {
            src: '/icons/icon-512.png',
            sizes: '512x512',
            type: 'image/png',
          },
          {
            src: '/icons/icon-512-maskable.png',
            sizes: '512x512',
            type: 'image/png',
            purpose: 'maskable',
          },
        ],
      },
      workbox: {
        globPatterns: ['**/*.{js,css,html,svg,png,ico,webmanifest}'],
        // Явный, самодокументирующийся запрет кешировать Supabase (auth,
        // REST, RPC, storage) — НИКОГДА не через CacheFirst/StaleWhileRevalidate
        // (ТЗ Этапа 18, п.10-12). Уже сам факт отсутствия ШИРОКОГО
        // runtimeCaching-правила для supabase.co был бы безопасен и без этой
        // записи: Workbox в generateSW-режиме перехватывает запрос только
        // тогда, когда он явно описан каким-то правилом (плюс навигации —
        // см. ниже про navigateFallback), а Supabase — другой origin, так
        // что без единого совпавшего правила запрос просто уходит в сеть
        // напрямую, мимо Service Worker. Правило ниже добавлено как
        // defense-in-depth и документация: если кто-то в будущем случайно
        // добавит сюда широкое CacheFirst-правило, явный NetworkOnly для
        // supabase.co, стоящий в массиве первым, всё равно не даст
        // закешировать финансовые данные пользователя.
        runtimeCaching: [
          {
            urlPattern: ({ url }) => url.hostname.endsWith('.supabase.co'),
            // NetworkOnly физически не пишет и не читает Cache Storage —
            // cacheName здесь намеренно не указан, он был бы бессмысленным.
            handler: 'NetworkOnly',
          },
        ],
      },
      devOptions: {
        enabled: false,
      },
    }),
  ],
  resolve: {
    alias: {
      '@': new URL('./src', import.meta.url).pathname,
    },
  },
  test: {
    environment: 'jsdom',
    globals: true,
    setupFiles: ['./src/test/setup.ts'],
    css: true,
  },
})
