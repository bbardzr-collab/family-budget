# SECURITY AUDIT REPORT

Этап 21 — Глубокий аудит и усиление безопасности. Проект: «Семейный бюджет 1.0» (этапы 1–20 уже реализованы). Дата: 2026-09-26.

Методология: две независимые параллельные проверки — (A) статический аудит кодовой базы/конфигурации (XSS, mass assignment, secrets, зависимости, PWA/cache, headers, open redirect, frontend guards) и (B) живое SQL-тестирование Supabase/Postgres (RLS по всем 16 таблицам, SECURITY DEFINER функции, cross-family изоляция, IDOR через RPC, role escalation, приватность детей, безопасность приглашений/уведомлений, DB-constraints) с двумя полностью фиктивными семьями, все фикстуры удалены и очистка независимо перепроверена. Ключевые заявления (RLS включена на всех таблицах, `get_advisors(security)`) перепроверены мной лично напрямую через `mcp__Supabase__execute_sql`/`get_advisors` — совпадают.

**Не даю формулировку «безопасность полностью гарантирована»** — ниже везде используются формулировки «проверено», «протестировано», «не обнаружено в рамках проведённого аудита», «ограничение», «требует production-конфигурации».

---

## Общий статус

**PASS WITH LIMITATIONS**

Критических (P0) и высоких (P1, кроме одного — см. ниже) живых уязвимостей в приложении и базе данных **не обнаружено** в рамках проведённого аудита: RLS, cross-family изоляция, приватность детей, RPC/SECURITY DEFINER, защита от IDOR и role escalation — всё выдержало полный тест-матрикс. Единственная найденная и исправленная проблема уровня P1 — полное отсутствие HTTP security headers на уровне деплоя (не уязвимость в данных, а отсутствие defense-in-depth защиты от clickjacking и части браузерных атак). Ограничения (не блокирующие PASS): headers физически применяются только Vercel-эджем при реальном деплое — их фактическое присутствие в ответе сервера не проверялось в этой сессии (нет доступа к продовому деплою); отсутствие DB-уровневого rate-limiting на `get_invitation_by_token` — требует production-настройки (Supabase Auth/edge/WAF), не код.

---

## Найденные уязвимости

| ID | Severity | Область | Проблема | Исправление | Test |
|----|----------|---------|----------|-------------|------|
| SEC-01 | **P1** | Security headers / Clickjacking | `vercel.json` не содержал ни одного HTTP security header — ни `Content-Security-Policy`, ни `X-Frame-Options`/`frame-ancestors`, ни `X-Content-Type-Options`, ни `Referrer-Policy`, ни `Permissions-Policy`, ни `Strict-Transport-Security`. Приложение (аутентифицированные финансовые данные) технически могло быть загружено в `<iframe>` любым сторонним origin — классический вектор clickjacking. | Добавлен блок `headers` в `vercel.json` для всех маршрутов: `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`, `Referrer-Policy: strict-origin-when-cross-origin`, `Permissions-Policy` (запрет camera/microphone/geolocation/payment/usb/gyroscope/magnetometer/interest-cohort — ни одна из этих возможностей не используется приложением, проверено грепом), `Content-Security-Policy` (`default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self' https://*.supabase.co wss://*.supabase.co; manifest-src 'self'; worker-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'; object-src 'none'`), `Strict-Transport-Security: max-age=63072000; includeSubDomains` (без `preload` — необратимое включение в браузерные preload-списки не делается без явного запроса пользователя). CSP спроектирована по факту используемых ресурсов (не шаблон): подтверждено, что в проекте нет внешних шрифтов/CDN/скриптов (только self-hosted иконки/манифест), нет inline `<script>`, есть только 2 места inline `style={{...}}` (`ProgressBar.tsx`, `AnalyticsPage.tsx`) — отсюда `style-src 'unsafe-inline'`, но НЕ `script-src 'unsafe-inline'`. | Автоматический regression-тест невозможен для HTTP-заголовков деплоя (`vite build`/`vite preview` не применяют `vercel.json` — заголовки накладывает исключительно Vercel edge в реальном деплое). Проверено: `npm run build` проходит без ошибок с новым `vercel.json`; сам JSON синтаксически корректен. **Фактическое присутствие заголовков в HTTP-ответе продового деплоя не проверялось в этой сессии** — см. «Что осталось сделать». |
| SEC-02 | P3 | Input validation (auth) | `passwordSchema` (`src/features/auth/schemas.ts`) не имела верхней границы длины — можно было отправить произвольно длинную строку (мегабайты) в форму регистрации/сброса пароля. Supabase Auth (GoTrue) хеширует пароль через bcrypt, который физически учитывает только первые 72 байта — не уязвимость взлома аккаунта, а вектор бессмысленной траты ресурсов сервера аутентификации на excessively long input. | Добавлена `.max(72, 'Максимум 72 символа')` — граница привязана к реальному пределу bcrypt, не произвольное число. | 5 новых тестов в `src/features/auth/schemas.test.ts` (новый файл): принимает ровно 72 символа, отклоняет 73, отклоняет экстремально длинный ввод (10 000 симв.), нижняя граница (8 симв.) не затронута, `loginSchema` (форма входа, не создания пароля) намеренно не проверяет длину. |
| SEC-03 | P3 (информационно, не фиксится в коде) | RPC / rate limiting | `get_invitation_by_token(p_token text)` — единственная `SECURITY DEFINER`-функция, исполняемая ролью `anon` (подтверждено `get_advisors`). Это осознанный дизайн (превью названия семьи/роли до регистрации по приглашению) и раскрывает только нефинансовые метаданные под защитой 256-битного случайного токена — не уязвимость сама по себе. Однако на уровне БД нет rate-limiting попыток подбора токена. | Не исправлялось в коде — требует production-конфигурации инфраструктуры (Supabase Auth rate-limit настройки / edge-уровень / WAF), а не кода приложения; ТЗ этапа прямо запрещает придумывать собственный rate-limiter без необходимости. | Зафиксировано как ограничение (см. §«Что осталось сделать»). |

**Побочная находка при обязательной финальной верификации (не уязвимость, но задокументирована для прозрачности):** 2 pre-existing теста (`RecurringTransactionsSection.test.tsx`, `PlannedExpensesSection.test.tsx`, Этапы 12-13) использовали захардкоженную дату-литерал ('2026-09-25'), которая была «далеко в будущем» только на момент написания теста — к моменту прогона на Этапе 21 (2026-09-26) эта дата уже наступила в прошлом, из-за чего оба теста ложно проваливались (правило/план стало вычисляться как «Просрочено» вместо ожидаемого «Активна»/«Запланировано»). Это не имеет отношения к безопасности и не связано с изменениями этого этапа, но было необходимо исправить точечно (заменить литерал на дату, вычисляемую на 5 лет вперёд от реального «сегодня»), чтобы `npm run test` оставался осмысленным индикатором регрессии — без этого я не мог бы честно утверждать, что build/test проходят после security-фиксов (ТЗ §38-39). Бизнес-логика/архитектура не тронуты, изменены только 2 тестовых файла.

---

## RLS
**PASS.** RLS включена на всех 16 таблиц (`relrowsecurity=true`, перепроверено лично). Полная матрица политик по каждой таблице (SELECT/INSERT/UPDATE/DELETE) собрана и соответствует документированному дизайну: CHILD видит только свои `transactions`/`recurring_transactions`/`planned_expenses`, но семейно-общие `budgets`/`budget_categories`/`goals` (без права писать в семейные записи), не видит чужие `goal_contributions`/`notifications`. `family_settings`/`user_settings`/`calendar_connections` — доступ только себе/своей семье. Ни одна таблица не имеет случайно широкой политики (`USING (true)` без ограничения).

## Cross-family isolation
**PASS.** Живым SQL-тестом (impersonation через `set_config('request.jwt.claims', ...)`) на двух фиктивных семьях подтверждено: SELECT одной семьи не возвращает ни одной строки другой ни по одной из 16 таблиц; UPDATE/DELETE чужой семьи затрагивают 0 строк (проверено через `RETURNING` самого write-запроса, не через последующий SELECT — во избежание ложноположительного результата).

## Child privacy
**PASS.** Повторно (после Этапа 16) подтверждено на живых данных: CHILD не видит чужие personal-транзакции/recurring/planned; видит только `goal_type='family'` цель, не видит личную цель другого ребёнка; не видит чужие `goal_contributions`, включая взнос администратора в *видимую* семейную цель; не видит чужие `notifications`; не может INSERT/UPDATE семейную цель или бюджет.

## Authentication
**PASS.** Protected routes (`ProtectedRoute`) корректно редиректят неаутентифицированного пользователя на `/login`; `PublicOnlyRoute` защищает обратное. Открытые redirect-параметры (`?redirect=`) валидируются явной проверкой `startsWith('/') && !startsWith('//')` — open redirect не найден. `resetPasswordForEmail` строит `redirectTo` из `window.location.origin`, не из пользовательского ввода.

## Authorization
**PASS.** Role-escalation живым тестом: self-promotion в admin — 0 строк; понижение/удаление последнего активного admin — заблокировано триггером (`LAST_ADMIN_PROTECTED`) как через прямой UPDATE/DELETE, так и через RPC `leave_family()`; попытка вступить в чужую семью без приглашения — RLS отклоняет INSERT. UI-скрытие действий для CHILD (не единственная защита, но подтверждено, что сервер всё равно блокирует) задокументировано отдельно.

## SECURITY DEFINER
**PASS.** 33 функции с `SECURITY DEFINER` в `public` — у всех `search_path=public` явно установлен (риска подмены search_path не найдено). Ни одна не доверяет клиентскому `family_id`/`user_id` — все определяют семью/пользователя через `auth.uid()` + membership. `create_notification()` и триггерные функции — `EXECUTE` отозван у всех клиентских ролей (internal-only). `get_advisors(security)` — 20 WARN, все ожидаемые (19 authenticated-executable RPC — весь намеренный публичный API поверхность, 1 anon-executable — `get_invitation_by_token`, см. SEC-03) — перепроверено лично, совпадает.

## IDOR
**PASS.** Передача чужих ID (goal id, notification id, invitation id) в `get_goal_summary`, `mark_notification_read`, `delete_notification`, `add_goal_contribution`, `cancel_family_invitation` и др. — везде либо ошибка (`*_NOT_FOUND`/`FORBIDDEN`), либо `null`/пустой результат, никогда доступ/изменение чужих данных.

## XSS
**PASS.** Ноль употреблений `dangerouslySetInnerHTML`/`innerHTML` во всём `src/`. Весь пользовательский текст рендерится через обычную JSX-интерполяцию (автоэкранирование React).

## SQL Injection
**PASS.** Клиент не строит `.or()`/`.filter()`-строки из пользовательского ввода (классическая PostgREST-уязвимость) — поиск/фильтры идут через именованные параметры RPC (`get_transactions_page`/`get_transactions_totals`), не конкатенацию.

## Secrets
**PASS.** `.env.local` содержит только `VITE_SUPABASE_URL`/`VITE_SUPABASE_ANON_KEY` (подтверждено — это anon-ключ, `role: anon` в payload JWT, не `service_role`). `.gitignore` корректно исключает `.env`/`.env.local`. Полнотекстовый грep по `service_role`/`secret`/`private_key`/`access_token`/`refresh_token`/`password`/`API_SECRET` не нашёл ни одного захардкоженного секрета — только имена типов/полей форм. Проект не является git-репозиторием — истории коммитов для сканирования нет (зафиксировано явно, не скрыто).

## Storage
**N/A.** Supabase Storage не используется — 0 buckets в проекте (`select count(*) from storage.buckets` → 0). Ничего не добавлено (по правилу этапа — не добавлять новую функциональность).

## Edge Functions
**N/A.** Edge Functions в проекте не существуют (директории `supabase/functions` нет).

## PWA security
**PASS.** `vite.config.ts` — `workbox.runtimeCaching` содержит ровно одно правило: `*.supabase.co` → `NetworkOnly` (Cache Storage физически не используется для этого origin). `globPatterns` прекэширует только статические build-ассеты — никаких API-ответов. `signOut()` вызывает `queryClient.clear()` — React Query кэш полностью очищается при выходе, подтверждено существующим тестом `AuthContext.test.tsx`.

## Cache isolation
**PASS.** Ни `localStorage`, ни `sessionStorage`, ни `IndexedDB` не используются приложением для хранения финансовых данных — только `@supabase/supabase-js` внутренне хранит токен сессии в `localStorage` (стандартное поведение самой библиотеки, не приложения). Сценарий User A logout → User B login не оставляет данных User A в памяти (React Query) благодаря `queryClient.clear()`.

## Dependencies
**PASS.** `npm audit` — 0 known vulnerabilities (critical/high/moderate/low: все 0) из 647 resolved-зависимостей (prod+dev). Апгрейды не производились (не требуются).

## Security headers
**PASS WITH LIMITATIONS.** Исправлено в коде (см. SEC-01) — полный набор заголовков добавлен в `vercel.json`. **Ограничение**: заголовки накладываются исключительно Vercel edge при реальном деплое; `vite build`/`vite preview` их не применяют, поэтому фактическое присутствие в HTTP-ответе продового домена не было проверено в рамках этой сессии (нет доступа к живому production-деплою) — требует ручной проверки после следующего деплоя (например, `curl -I` на прод-URL).

## Tests
**PASS.** `npx vitest run` → **487/487 passed** (57 файлов; было 482/482 на конец Этапа 20 — добавлено 5 новых тестов на границу длины пароля).

## Build
**PASS.** `npm run lint` → 0 errors / 16 warnings (все — pre-existing `react-hooks/incompatible-library`/`react-refresh/only-export-components`, без изменений с прошлых этапов, не связаны с security-правками). `npm run build` → успешно, `dist/sw.js`/`workbox-*.js` сгенерированы корректно (16 записей прекэша, 1371 KiB).

---

## Изменённые файлы

| Файл | Изменение |
|------|-----------|
| `vercel.json` | Добавлен блок `headers` — CSP/X-Frame-Options/X-Content-Type-Options/Referrer-Policy/Permissions-Policy/HSTS для всех маршрутов (SEC-01) |
| `src/features/auth/schemas.ts` | `passwordSchema` получила `.max(72, ...)` — граница, привязанная к пределу bcrypt (SEC-02) |
| `src/features/auth/schemas.test.ts` | **Новый файл.** 5 регресс-тестов на границу длины пароля |
| `src/features/recurringTransactions/RecurringTransactionsSection.test.tsx` | Точечный фикс даты-хрупкости pre-existing теста (не security, см. «Найденные уязвимости» выше) |
| `src/features/plannedExpenses/PlannedExpensesSection.test.tsx` | Тот же точечный фикс даты-хрупкости |

**Ничего больше не изменено.** RLS-политики, SECURITY DEFINER функции, триггеры, схема БД, бизнес-логика, UI/UX, архитектура — не тронуты (нет ни одной новой миграции в этом этапе).

## Что осталось сделать (честно, с приоритетом и причиной)

| # | Приоритет | Описание | Почему не сделано в этом этапе |
|---|-----------|----------|-----------------------------------|
| 1 | Требует проверки после деплоя | Фактическое присутствие HTTP-заголовков (SEC-01) в ответе продового домена не проверено — `vercel.json` применяется только реальным Vercel-эджем, недоступным из этой сессии. | Нет доступа к живому production-деплою из текущего окружения. Рекомендация: после следующего деплоя выполнить `curl -I https://<домен>` и убедиться, что все 6 заголовков присутствуют. |
| 2 | P3, ограничение инфраструктуры | Rate-limiting на `get_invitation_by_token` (подбор токена приглашения) отсутствует на уровне БД. | Требует production-настройки (Supabase Auth rate-limit / edge / WAF), не кода приложения — ТЗ прямо запрещает придумывать собственный rate-limiter без необходимости. |
| 3 | P3, задокументированное наблюдение на будущее | `calendar_connections.access_token`/`refresh_token` — колонки готовы к хранению OAuth-токенов для Google Calendar, но фича не реализована (таблица пуста, 0 строк). Если/когда фича будет реализована в будущем этапе, эти токены следует шифровать (например, через Supabase Vault), а не хранить в открытом виде. | Фича вне объёма Этапа 21 (нет новых функций); менять пустую, неиспользуемую таблицу сейчас значило бы упреждающе проектировать несуществующий функционал — вне правил этапа. |
| 4 | P3, не блокирует PASS | 3 наблюдения из статического аудита ранее упомянутые как «требуют cross-check» (`CategoriesPage`/`GoalsPage`/`SettingsPage` не скрывают create/edit UI от CHILD) — перепроверены живым SQL-тестом: RLS на `categories`/`goals` блокирует запись для CHILD независимо от UI. Не является уязвимостью (сервер — реальная граница), поэтому не исправлялось — исправление было бы чисто косметическим UI-изменением вне рамок security-этапа. | UI-hiding — не security-граница (ТЗ, п.35); реальная защита уже на месте на уровне RLS. |

---

Этап 21 завершён.

**Security status:** PASS WITH LIMITATIONS

**Critical issues (P0):** не найдено.

**High issues (P1):** 1 найдена — SEC-01 (отсутствие HTTP security headers / защиты от clickjacking) — **исправлена** (см. `vercel.json`), фактическое применение на проде требует проверки после деплоя (см. «Что осталось сделать», п.1).

**Fixed:** SEC-01 (security headers), SEC-02 (верхняя граница длины пароля) + 2 pre-existing тестовых бага даты-хрупкости, найденных при обязательной финальной верификации.

**Remaining:** SEC-03 (rate-limiting приглашений — требует production-инфраструктуры, не кода), проверка заголовков после реального деплоя, будущее шифрование OAuth-токенов calendar_connections если/когда фича будет реализована — все три задокументированы как ограничения, не как открытые уязвимости.

**Tests:** 487/487 passing (57 файлов).

**Build:** `npm run lint` — 0 errors / 16 pre-existing warnings; `npm run build` — успешно.

**Changed files:** `vercel.json`, `src/features/auth/schemas.ts`, `src/features/auth/schemas.test.ts` (новый), `src/features/recurringTransactions/RecurringTransactionsSection.test.tsx`, `src/features/plannedExpenses/PlannedExpensesSection.test.tsx`.

К этапу 22 не переходи.
