import { createElement, useState } from 'react'
import { ArrowDownCircle, ArrowUpCircle, CalendarClock, MoreVertical, Pause, Pencil, Play, Trash2 } from 'lucide-react'
import { Badge, Card, CardContent, Dropdown, EmptyState, ErrorState, IconButton, Skeleton } from '@/components/ui'
import { useToast } from '@/components/ui/Toast'
import { cn } from '@/utils/cn'
import { formatDate, toDateInputValue } from '@/utils/formatDate'
import { formatMoney } from '@/utils/formatMoney'
import { getCategoryIcon } from '@/features/categories/iconMap'
import { RECURRING_FREQUENCY_LABELS, RECURRING_STATUS_BADGE_VARIANT, RECURRING_STATUS_LABELS } from './labels'
import { getRecurringTransactionStatus, sortRecurringTransactions } from './status'
import { useRecurringTransactions, useSetRecurringTransactionActive } from './hooks'
import { getRecurringTransactionErrorMessage } from './errors'
import {
  RecurringTransactionFormModal,
  type EditableRecurringTransaction,
} from './RecurringTransactionFormModal'
import { DeleteRecurringTransactionModal } from './DeleteRecurringTransactionModal'
import type { RecurringTransactionListItem } from './api'

interface RecurringTransactionsSectionProps {
  /** Управляется родителем (TransactionsPage) — единая кнопка "Добавить" в шапке переключает поведение по активной вкладке. */
  createOpen: boolean
  onCreateClose: () => void
}

/**
 * Название строки списка — у recurring_transactions нет своего поля
 * title/name (ТЗ описывает схему без него), поэтому здесь используется тот
 * же вывод, что и в RPC generate_due_planned_expenses при создании
 * напоминания (миграция 0029): категория → источник дохода → родовое
 * "Доход"/"Расход". Единственный источник истины для этого вывода — RPC;
 * здесь — независимая клиентская копия ровно того же правила для
 * отображения строки списка (не завязана на существование уже созданного
 * напоминания).
 */
function deriveTitle(item: RecurringTransactionListItem): string {
  return item.category?.name ?? item.incomeSource ?? (item.type === 'income' ? 'Доход' : 'Расход')
}

/**
 * Содержимое вкладки "Повторяющиеся" на /app/transactions?section=recurring
 * (Этап 13). Само правило НИКОГДА не создаёт запись в transactions — эта
 * секция управляет только правилами (создание/редактирование/пауза/
 * удаление). Превращение "наступившего" события в фактическую операцию
 * происходит целиком во вкладке "План" (Этап 12, уже готовый UI) — там же,
 * где показываются подготовленные для этого правила напоминания.
 */
export function RecurringTransactionsSection({ createOpen, onCreateClose }: RecurringTransactionsSectionProps) {
  const { toast } = useToast()
  const { data: recurringTransactions, isLoading, isError, refetch } = useRecurringTransactions()
  const setActiveMutation = useSetRecurringTransactionActive()

  const [editingItem, setEditingItem] = useState<EditableRecurringTransaction | null>(null)
  const [deletingItem, setDeletingItem] = useState<RecurringTransactionListItem | null>(null)

  const items = recurringTransactions ?? []
  const sorted = sortRecurringTransactions(items)
  const today = toDateInputValue()

  const showEmpty = !isLoading && !isError && items.length === 0

  async function handleToggleActive(item: RecurringTransactionListItem) {
    try {
      await setActiveMutation.mutateAsync({ id: item.id, isActive: !item.isActive })
      toast({ type: 'success', title: item.isActive ? 'Правило приостановлено' : 'Правило возобновлено' })
    } catch (error) {
      toast({ type: 'error', title: getRecurringTransactionErrorMessage(error) })
    }
  }

  function handleSelect(item: RecurringTransactionListItem, value: string) {
    if (value === 'edit') {
      setEditingItem({
        id: item.id,
        type: item.type,
        amount: item.amount,
        categoryId: item.categoryId,
        incomeSource: item.incomeSource,
        frequency: item.frequency,
        intervalConfig: item.intervalConfig,
        startDate: item.startDate,
      })
    } else if (value === 'toggle-active') {
      void handleToggleActive(item)
    } else if (value === 'delete') {
      setDeletingItem(item)
    }
  }

  return (
    <div className="flex flex-col gap-6">
      <Card>
        <CardContent className="pt-6">
          {isLoading && (
            <div className="flex flex-col gap-3" role="status" aria-label="Загружаем правила…">
              {[0, 1, 2].map((i) => (
                <Skeleton key={i} className="h-14 w-full" />
              ))}
            </div>
          )}

          {isError && <ErrorState title="Не удалось загрузить повторяющиеся операции" onRetry={() => void refetch()} />}

          {showEmpty && (
            <EmptyState
              icon={CalendarClock}
              title="Повторяющихся операций пока нет"
              description="Настройте правило для регулярных платежей — аренда, подписки, зарплата — и не забывайте их подтверждать."
            />
          )}

          {!isLoading && !isError && sorted.length > 0 && (
            <ul className="flex flex-col divide-y divide-border">
              {sorted.map((item) => (
                <RecurringTransactionRow
                  key={item.id}
                  item={item}
                  status={getRecurringTransactionStatus(item, today)}
                  onSelect={(value) => handleSelect(item, value)}
                />
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      <RecurringTransactionFormModal open={createOpen} onClose={onCreateClose} />
      <RecurringTransactionFormModal
        open={Boolean(editingItem)}
        recurringTransaction={editingItem}
        onClose={() => setEditingItem(null)}
      />
      <DeleteRecurringTransactionModal
        recurringTransaction={deletingItem ? { ...deletingItem, title: deriveTitle(deletingItem) } : null}
        onClose={() => setDeletingItem(null)}
      />
    </div>
  )
}

function RecurringTransactionRow({
  item,
  status,
  onSelect,
}: {
  item: RecurringTransactionListItem
  status: ReturnType<typeof getRecurringTransactionStatus>
  onSelect: (value: string) => void
}) {
  const isIncome = item.type === 'income'
  const title = deriveTitle(item)

  const dropdownItems = [
    { value: 'edit', label: 'Редактировать', icon: <Pencil /> },
    {
      value: 'toggle-active',
      label: item.isActive ? 'Приостановить' : 'Возобновить',
      icon: item.isActive ? <Pause /> : <Play />,
    },
    { value: 'delete', label: 'Удалить правило', icon: <Trash2 />, destructive: true },
  ]

  return (
    <li className={cn('flex items-center gap-3 py-3 first:pt-0 last:pb-0', !item.isActive && 'opacity-70')}>
      <div
        className={cn(
          'flex size-9 shrink-0 items-center justify-center rounded-full',
          isIncome ? 'bg-success-soft text-success' : 'bg-muted text-muted-foreground',
        )}
      >
        {isIncome ? (
          <ArrowUpCircle className="size-4" aria-hidden="true" />
        ) : (
          <ArrowDownCircle className="size-4" aria-hidden="true" />
        )}
      </div>

      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-1.5">
          <p className="truncate text-sm font-medium text-foreground">{title}</p>
          <Badge variant={RECURRING_STATUS_BADGE_VARIANT[status]}>{RECURRING_STATUS_LABELS[status]}</Badge>
        </div>
        <p className="flex items-center gap-1 truncate text-xs text-muted-foreground">
          <span>{RECURRING_FREQUENCY_LABELS[item.frequency]}</span>
          <span aria-hidden="true">·</span>
          <span>Следующее: {formatDate(item.nextRunDate)}</span>
          {!isIncome && item.category && (
            <>
              <span aria-hidden="true">·</span>
              {createElement(getCategoryIcon(item.category.icon), { className: 'size-3 shrink-0', 'aria-hidden': true })}
              <span className="truncate">{item.category.name}</span>
            </>
          )}
        </p>
        {item.userName && <p className="truncate text-xs text-muted-foreground">Ответственный: {item.userName}</p>}
      </div>

      <span className="shrink-0 text-sm font-semibold tabular-nums text-foreground">{formatMoney(item.amount)}</span>

      <Dropdown
        trigger={<IconButton icon={MoreVertical} aria-label={`Действия с правилом ${title}`} size="sm" />}
        items={dropdownItems}
        onSelect={onSelect}
      />
    </li>
  )
}
