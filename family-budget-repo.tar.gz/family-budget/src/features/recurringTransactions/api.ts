import { supabase } from '@/lib/supabase'

/**
 * Тонкий слой доступа к данным повторяющихся операций (Этап 13) — только
 * запросы, никакой React, по аналогии с features/plannedExpenses/api.ts и
 * features/transactions/api.ts.
 *
 * Таблица recurring_transactions существует без изменений с Этапа 3.
 * Аудит этого этапа (Task #59-60) нашёл ровно два пробела относительно
 * текущего ТЗ и закрыл их миграцией 0029 (триггер same-family + триггер,
 * принудительно проставляющий next_run_date = start_date при создании) —
 * никакой новой таблицы, никакого пересоздания recurring_transactions.
 *
 * INSERT здесь всегда user_id = сам вызывающий (RLS-политика
 * recurring_transactions_insert_own требует user_id = auth.uid() — ADMIN НЕ
 * может создать правило "от имени" другого члена семьи, в отличие от
 * planned_expenses). Поэтому CreateRecurringTransactionInput не принимает
 * userId — он всегда берётся из текущей сессии (см. hooks.ts/useAuth).
 *
 * next_run_date НЕ передаётся при создании осознанно (см. миграцию 0029,
 * BEFORE INSERT триггер recurring_transactions_set_initial_next_run_date) —
 * сервер сам проставляет его равным start_date, что бы ни прислал клиент;
 * здесь достаточно placeholder-значения, требуемого NOT NULL-колонкой.
 */

export type RecurringTransactionType = 'income' | 'expense'
export type RecurringFrequency = 'weekly' | 'monthly' | 'yearly'

export interface RecurringTransactionCategory {
  id: string
  name: string
  icon: string | null
  isActive: boolean
}

export interface RecurringTransactionListItem {
  id: string
  type: RecurringTransactionType
  amount: number
  categoryId: string | null
  category: RecurringTransactionCategory | null
  incomeSource: string | null
  frequency: RecurringFrequency
  /** Сырой JSONB, {interval: number, day?: number, month?: number} — см. buildIntervalConfig. */
  intervalConfig: Record<string, number> | null
  startDate: string
  endDate: string | null
  nextRunDate: string
  isActive: boolean
  userId: string
  userName: string | null
  createdAt: string
}

interface RecurringTransactionQueryRow {
  id: string
  type: string
  amount: number
  category_id: string | null
  category: { id: string; name: string; icon: string | null; is_active: boolean } | null
  income_source: string | null
  frequency: string
  interval_config: Record<string, number> | null
  start_date: string
  end_date: string | null
  next_run_date: string
  is_active: boolean
  user_id: string
  owner: { id: string; full_name: string | null } | null
  created_at: string
}

function mapRow(row: RecurringTransactionQueryRow): RecurringTransactionListItem {
  return {
    id: row.id,
    type: row.type as RecurringTransactionType,
    amount: row.amount,
    categoryId: row.category_id,
    category: row.category
      ? { id: row.category.id, name: row.category.name, icon: row.category.icon, isActive: row.category.is_active }
      : null,
    incomeSource: row.income_source,
    frequency: row.frequency as RecurringFrequency,
    intervalConfig: row.interval_config,
    startDate: row.start_date,
    endDate: row.end_date,
    nextRunDate: row.next_run_date,
    isActive: row.is_active,
    userId: row.user_id,
    userName: row.owner?.full_name ?? null,
    createdAt: row.created_at,
  }
}

const SELECT_FIELDS =
  'id, type, amount, category_id, category:categories(id, name, icon, is_active), income_source, frequency, interval_config, start_date, end_date, next_run_date, is_active, user_id, owner:users(id, full_name), created_at'

/** Полный список правил повторяющихся операций семьи для /app/transactions (вкладка «Повторяющиеся»). */
export async function fetchRecurringTransactions(familyId: string): Promise<RecurringTransactionListItem[]> {
  const { data, error } = await supabase
    .from('recurring_transactions')
    .select(SELECT_FIELDS)
    .eq('family_id', familyId)
    .order('next_run_date', { ascending: true })
    .order('created_at', { ascending: true })

  if (error) throw error
  return ((data ?? []) as unknown as RecurringTransactionQueryRow[]).map(mapRow)
}

/**
 * {interval, day?, month?} — ровно тот формат, что дан в ТЗ (weekly:
 * {interval}, monthly: {interval, day}, yearly: {interval, month, day}).
 * day/month всегда выводятся из start_date автоматически (а не отдельными
 * полями формы) — так они структурно не могут разойтись с самим start_date.
 * Разбор строки "yyyy-MM-dd" вручную (split), а не через `new Date(...)`,
 * чтобы не словить сдвиг на день из-за локальной таймзоны при последующем
 * .getDate()/.getMonth() (тот же принцип, что и в utils/formatDate.ts —
 * никаких Date-объектов для чистой работы со строкой даты).
 */
export function buildIntervalConfig(
  frequency: RecurringFrequency,
  interval: number,
  startDateIso: string,
): Record<string, number> {
  const [, monthStr, dayStr] = startDateIso.split('-')
  const day = Number(dayStr)
  const month = Number(monthStr)

  if (frequency === 'weekly') return { interval }
  if (frequency === 'monthly') return { interval, day }
  return { interval, month, day }
}

export interface CreateRecurringTransactionInput {
  familyId: string
  userId: string
  type: RecurringTransactionType
  amount: string
  categoryId: string | null
  incomeSource: string | null
  frequency: RecurringFrequency
  interval: number
  startDate: string
  endDate: string | null
}

export async function createRecurringTransaction(
  input: CreateRecurringTransactionInput,
): Promise<RecurringTransactionListItem> {
  const { data, error } = await supabase
    .from('recurring_transactions')
    .insert({
      family_id: input.familyId,
      user_id: input.userId,
      type: input.type,
      amount: input.amount as unknown as number,
      category_id: input.categoryId,
      income_source: input.incomeSource,
      frequency: input.frequency,
      interval_config: buildIntervalConfig(input.frequency, input.interval, input.startDate),
      start_date: input.startDate,
      end_date: input.endDate,
      // next_run_date — placeholder, перезаписывается сервером (см. комментарий выше).
      next_run_date: input.startDate,
    })
    .select(SELECT_FIELDS)
    .single()

  if (error) throw error
  return mapRow(data as unknown as RecurringTransactionQueryRow)
}

export interface UpdateRecurringTransactionInput {
  id: string
  type: RecurringTransactionType
  amount: string
  categoryId: string | null
  incomeSource: string | null
  frequency: RecurringFrequency
  interval: number
  startDate: string
  endDate: string | null
}

/**
 * next_run_date сознательно НЕ входит в payload — на UPDATE сервер его не
 * трогает (BEFORE INSERT-триггер срабатывает только при создании), поэтому
 * редактирование суммы/категории/расписания не сбрасывает уже
 * запланированное следующее срабатывание правила (Этап 13, решение
 * зафиксировано в комментарии миграции 0029).
 */
export async function updateRecurringTransaction(
  input: UpdateRecurringTransactionInput,
): Promise<RecurringTransactionListItem> {
  const { data, error } = await supabase
    .from('recurring_transactions')
    .update({
      type: input.type,
      amount: input.amount as unknown as number,
      category_id: input.categoryId,
      income_source: input.incomeSource,
      frequency: input.frequency,
      interval_config: buildIntervalConfig(input.frequency, input.interval, input.startDate),
      start_date: input.startDate,
      end_date: input.endDate,
    })
    .eq('id', input.id)
    .select(SELECT_FIELDS)
    .single()

  if (error) throw error
  return mapRow(data as unknown as RecurringTransactionQueryRow)
}

/** Пауза/возобновление правила (ТЗ) — is_active НЕ влияет на end_date/next_run_date. */
export async function setRecurringTransactionActive(id: string, isActive: boolean): Promise<void> {
  const { data, error } = await supabase
    .from('recurring_transactions')
    .update({ is_active: isActive })
    .eq('id', id)
    .select('id')
    .single()

  if (error) throw error
  if (!data) {
    throw { message: 'Правило не найдено или у вас нет прав его изменить.', code: 'PGRST116' }
  }
}

/**
 * Удаление правила. planned_expenses.recurring_transaction_id → ON DELETE
 * SET NULL (миграция 0004) — уже созданные напоминания НЕ удаляются вместе
 * с правилом, они просто теряют связь с ним.
 */
export async function deleteRecurringTransaction(id: string): Promise<void> {
  const { error, count } = await supabase.from('recurring_transactions').delete({ count: 'exact' }).eq('id', id)
  if (error) throw error
  if (!count) {
    throw { message: 'Правило не найдено или у вас нет прав его удалить.', code: 'PGRST116' }
  }
}

export interface DuePlannedExpenseResult {
  plannedExpenseId: string
  recurringTransactionId: string
  plannedDate: string
  title: string
  amount: number
  type: RecurringTransactionType
}

/**
 * "Система обнаруживает событие" (ТЗ, шаг 1 схемы) — RPC
 * generate_due_planned_expenses (миграция 0029). НИКОГДА не создаёт
 * transactions — только planned_expenses(status=planned), которые пользователь
 * увидит и явно подтвердит во вкладке «План» (Этап 12, уже готовый UI).
 * Вызывается автоматически при заходе в приложение (см. hooks.ts), а не по
 * запросу пользователя — сама подготовка напоминания не требует
 * подтверждения, требует его только превращение напоминания в операцию.
 */
export async function generateDuePlannedExpenses(): Promise<DuePlannedExpenseResult[]> {
  const { data, error } = await supabase.rpc('generate_due_planned_expenses')
  if (error) throw error
  return (data ?? []) as unknown as DuePlannedExpenseResult[]
}

/**
 * Превью следующей даты по расписанию — тонкая обёртка над RPC
 * calculate_recurring_next_run_date (единственный источник истины для шага
 * расписания, используется и здесь, и внутри generate_due_planned_expenses,
 * см. миграцию 0029 — алгоритм не дублируется на клиенте).
 */
export async function calculateNextRunDatePreview(
  currentDate: string,
  frequency: RecurringFrequency,
  intervalConfig: Record<string, number>,
): Promise<string> {
  const { data, error } = await supabase.rpc('calculate_recurring_next_run_date', {
    p_current: currentDate,
    p_frequency: frequency,
    p_interval_config: intervalConfig,
  })
  if (error) throw error
  return data as unknown as string
}
