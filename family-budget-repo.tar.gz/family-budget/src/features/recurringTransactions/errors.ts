/**
 * Перевод ошибок операций с повторяющимися операциями в понятные человеку
 * сообщения — по аналогии с features/plannedExpenses/errors.ts. Ошибки
 * триггера recurring_transactions_check_same_family и RPC
 * generate_due_planned_expenses (миграция 0029) приходят как
 * `raise exception '<CODE>: ...'`, остальное — стандартные коды
 * PostgREST/Postgres для прямых CRUD-операций.
 */

interface MatchableError {
  message?: string
  code?: string
}

export function getRecurringTransactionErrorMessage(error: unknown): string {
  if (!error) return 'Неизвестная ошибка. Попробуйте ещё раз.'

  if (error instanceof TypeError) {
    return 'Проблема с сетью. Проверьте подключение к интернету и попробуйте снова.'
  }

  const { message, code } = (error as MatchableError) ?? {}
  const text = (message ?? String(error)).toLowerCase()

  // Триггер recurring_transactions_check_same_family (миграция 0029) —
  // попытка использовать категорию другой семьи (user_id здесь всегда сам
  // вызывающий, см. api.ts, поэтому RECURRING_USER_NOT_IN_FAMILY на
  // практике не возникает при обычном использовании формы).
  if (text.includes('recurring_user_not_in_family')) {
    return 'Ответственный не состоит в этой семье.'
  }
  if (text.includes('recurring_category_not_in_family')) {
    return 'Выбранная категория недоступна для этой семьи.'
  }

  if (text.includes('no_family')) {
    return 'Сначала создайте семью или присоединитесь к ней.'
  }

  if (code === '23514' || text.includes('check constraint') || text.includes('violates check')) {
    return 'Некорректные данные правила — проверьте сумму и остальные поля.'
  }

  if (text.includes('row-level security') || text.includes('policy')) {
    return 'Недостаточно прав для этого действия.'
  }

  if (code === 'PGRST116') {
    return 'Правило не найдено или у вас нет прав на это действие.'
  }

  if (text.includes('fetch') || text.includes('network')) {
    return 'Проблема с сетью. Проверьте подключение к интернету и попробуйте снова.'
  }

  return 'Не получилось выполнить действие. Попробуйте ещё раз чуть позже.'
}
