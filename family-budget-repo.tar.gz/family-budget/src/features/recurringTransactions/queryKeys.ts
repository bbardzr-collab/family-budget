/**
 * Единый источник ключей React Query для домена "повторяющиеся операции"
 * (Этап 13) — параметризован familyId, тот же принцип, что и
 * plannedExpensesKeys/budgetsKeys.
 */
export const recurringTransactionsKeys = {
  all: ['recurring-transactions'] as const,
  list: (familyId: string | undefined) => [...recurringTransactionsKeys.all, 'list', familyId] as const,
}
