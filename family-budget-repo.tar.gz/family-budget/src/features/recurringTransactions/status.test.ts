import { describe, expect, it } from 'vitest'
import { getRecurringTransactionStatus, sortRecurringTransactions } from './status'
import type { RecurringTransactionListItem } from './api'

function item(overrides: Partial<RecurringTransactionListItem> & Pick<RecurringTransactionListItem, 'id'>): RecurringTransactionListItem {
  return {
    type: 'expense',
    amount: 1000,
    categoryId: null,
    category: null,
    incomeSource: null,
    frequency: 'monthly',
    intervalConfig: { interval: 1 },
    startDate: '2026-09-01',
    endDate: null,
    nextRunDate: '2026-09-20',
    isActive: true,
    userId: 'user-1',
    userName: 'Анна',
    createdAt: '2026-09-01T00:00:00Z',
    ...overrides,
  }
}

describe('getRecurringTransactionStatus (Этап 13)', () => {
  const today = '2026-09-21'

  it('активное правило с будущей/сегодняшней датой next_run_date — "active"', () => {
    expect(getRecurringTransactionStatus(item({ id: 'x', nextRunDate: '2026-09-21' }), today)).toBe('active')
    expect(getRecurringTransactionStatus(item({ id: 'x', nextRunDate: '2026-09-25' }), today)).toBe('active')
  })

  it('активное правило с next_run_date в прошлом — "overdue"', () => {
    expect(getRecurringTransactionStatus(item({ id: 'x', nextRunDate: '2026-09-10' }), today)).toBe('overdue')
  })

  it('is_active=false — "paused", даже если даты в прошлом', () => {
    expect(
      getRecurringTransactionStatus(item({ id: 'x', isActive: false, nextRunDate: '2026-09-10' }), today),
    ).toBe('paused')
  })

  it('end_date в прошлом — "expired", НЕ "overdue" (приоритет истечения срока)', () => {
    expect(
      getRecurringTransactionStatus(
        item({ id: 'x', endDate: '2026-09-15', nextRunDate: '2026-09-10' }),
        today,
      ),
    ).toBe('expired')
  })

  it('end_date в будущем не влияет на статус', () => {
    expect(
      getRecurringTransactionStatus(item({ id: 'x', endDate: '2027-01-01', nextRunDate: '2026-09-25' }), today),
    ).toBe('active')
  })

  it('пауза имеет приоритет над "истёк срок" (оба условия истинны одновременно)', () => {
    expect(
      getRecurringTransactionStatus(
        item({ id: 'x', isActive: false, endDate: '2026-09-01', nextRunDate: '2026-09-01' }),
        today,
      ),
    ).toBe('paused')
  })
})

describe('sortRecurringTransactions (Этап 13)', () => {
  it('сортирует по возрастанию next_run_date', () => {
    const items = [
      item({ id: 'c', nextRunDate: '2026-09-28' }),
      item({ id: 'a', nextRunDate: '2026-09-20' }),
      item({ id: 'b', nextRunDate: '2026-09-25' }),
    ]
    expect(sortRecurringTransactions(items).map((i) => i.id)).toEqual(['a', 'b', 'c'])
  })

  it('при совпадении дат — стабильно по createdAt', () => {
    const items = [
      item({ id: 'later', nextRunDate: '2026-09-25', createdAt: '2026-09-05T00:00:00Z' }),
      item({ id: 'earlier', nextRunDate: '2026-09-25', createdAt: '2026-09-01T00:00:00Z' }),
    ]
    expect(sortRecurringTransactions(items).map((i) => i.id)).toEqual(['earlier', 'later'])
  })

  it('не мутирует исходный массив', () => {
    const items = [item({ id: 'b', nextRunDate: '2026-09-28' }), item({ id: 'a', nextRunDate: '2026-09-20' })]
    const original = [...items]
    sortRecurringTransactions(items)
    expect(items).toEqual(original)
  })
})
