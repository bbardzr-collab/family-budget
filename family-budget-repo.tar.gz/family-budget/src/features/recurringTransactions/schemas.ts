import { z } from 'zod'

/**
 * Валидация формы повторяющейся операции (Этап 13). Локальная копия
 * нормализации суммы — тот же паттерн самодостаточности фичи, что уже
 * применён в features/transactions/schemas.ts, features/goals/schemas.ts,
 * features/plannedExpenses/schemas.ts.
 */
function normalizeAmountString(value: string): string {
  const [intPart, decPart = ''] = value.split('.')
  const cents = decPart.padEnd(2, '0').slice(0, 2)
  return `${intPart}.${cents}`
}

const AMOUNT_PATTERN = /^\d{1,12}(\.\d{1,2})?$/

export const recurringAmountSchema = z
  .string()
  .trim()
  .min(1, 'Введите сумму')
  .transform((value) => value.replace(',', '.'))
  .refine((value) => AMOUNT_PATTERN.test(value), {
    message: 'Введите сумму числом, например 1500 или 1500,50',
  })
  .refine((value) => !/^0+(\.0{1,2})?$/.test(value), {
    message: 'Сумма должна быть больше нуля',
  })
  .transform((value) => normalizeAmountString(value))

export const RECURRING_TYPES = ['expense', 'income'] as const
export const RECURRING_FREQUENCIES = ['weekly', 'monthly', 'yearly'] as const

/**
 * interval — "повторять каждые N недель/месяцев/лет" (ТЗ: interval_config =
 * {interval: N, ...}). day/month НЕ отдельные поля формы — выводятся из
 * startDate на границе сети (см. features/recurringTransactions/api.ts,
 * buildIntervalConfig), чтобы они структурно не могли разойтись с самой
 * датой начала.
 */
export const recurringTransactionFormSchema = z
  .object({
    type: z.enum(RECURRING_TYPES),
    amount: recurringAmountSchema,
    categoryId: z.string().optional().or(z.literal('')),
    incomeSource: z
      .string()
      .trim()
      .max(200, 'Источник дохода слишком длинный — максимум 200 символов')
      .optional()
      .or(z.literal('')),
    frequency: z.enum(RECURRING_FREQUENCIES),
    interval: z
      .string()
      .trim()
      .min(1, 'Укажите интервал')
      .refine((value) => /^\d{1,3}$/.test(value), { message: 'Целое число от 1 до 365' })
      .refine((value) => Number(value) >= 1 && Number(value) <= 365, { message: 'От 1 до 365' }),
    startDate: z.string().min(1, 'Укажите дату начала'),
    endDate: z.string().optional().or(z.literal('')),
  })
  .superRefine((values, ctx) => {
    if (values.endDate && values.endDate < values.startDate) {
      ctx.addIssue({
        code: 'custom',
        path: ['endDate'],
        message: 'Дата окончания не может быть раньше даты начала',
      })
    }
  })

export type RecurringTransactionFormValues = z.infer<typeof recurringTransactionFormSchema>
