import type { RecurringTransactionListItem } from './api'

/**
 * Статус — ВСЕГДА производное значение, вычисляемое на лету из существующих
 * полей, а не отдельная колонка/поле формы (ТЗ, критическое требование):
 * ничего не удаляется и не переключается автоматически.
 *
 * Порядок проверки важен: пауза (is_active=false, только явное действие
 * пользователя) имеет приоритет над остальным — приостановленное правило не
 * показывается ни "истёкшим", ни "просроченным", хотя даты у него по-прежнему
 * могут быть в прошлом.
 */
export type RecurringTransactionStatus = 'active' | 'paused' | 'expired' | 'overdue'

export function getRecurringTransactionStatus(
  item: Pick<RecurringTransactionListItem, 'isActive' | 'endDate' | 'nextRunDate'>,
  todayIsoDate: string,
): RecurringTransactionStatus {
  if (!item.isActive) return 'paused'
  if (item.endDate && item.endDate < todayIsoDate) return 'expired'
  if (item.nextRunDate < todayIsoDate) return 'overdue'
  return 'active'
}

/** По возрастанию next_run_date (ближайшее списание — сверху), затем по createdAt — стабильно. */
export function sortRecurringTransactions(
  items: RecurringTransactionListItem[],
): RecurringTransactionListItem[] {
  return [...items].sort((a, b) => {
    const byDate = a.nextRunDate.localeCompare(b.nextRunDate)
    if (byDate !== 0) return byDate
    return a.createdAt.localeCompare(b.createdAt)
  })
}
