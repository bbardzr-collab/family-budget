import type { RecurringFrequency } from './api'
import type { RecurringTransactionStatus } from './status'

/** Русские подписи периодичности (ТЗ). */
export const RECURRING_FREQUENCY_LABELS: Record<RecurringFrequency, string> = {
  weekly: 'Еженедельно',
  monthly: 'Ежемесячно',
  yearly: 'Ежегодно',
}

/** Единица интервала во множественном числе, для текста "Повторять каждые N …" и превью дат. */
export const RECURRING_FREQUENCY_UNIT: Record<RecurringFrequency, string> = {
  weekly: 'нед.',
  monthly: 'мес.',
  yearly: 'г.',
}

/**
 * Статус — производное состояние (ТЗ): "Активна" / "На паузе" (is_active=false,
 * НИКОГДА не выставляется автоматически) / "Истёк срок" (end_date < сегодня,
 * правило никогда не удаляется автоматически) / "Просрочено" (next_run_date <
 * сегодня — платёж ждёт подготовки напоминания/подтверждения, см. status.ts).
 */
export const RECURRING_STATUS_LABELS: Record<RecurringTransactionStatus, string> = {
  active: 'Активна',
  paused: 'На паузе',
  expired: 'Истёк срок',
  overdue: 'Просрочено',
}

export const RECURRING_STATUS_BADGE_VARIANT: Record<RecurringTransactionStatus, 'default' | 'success' | 'warning'> =
  {
    active: 'success',
    paused: 'default',
    expired: 'default',
    overdue: 'warning',
  }
