import { createElement, useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { ArrowDownCircle, ArrowUpCircle, ChevronRight } from 'lucide-react'
import { Button, Input, Modal, Select, Text } from '@/components/ui'
import { useToast } from '@/components/ui/Toast'
import { cn } from '@/utils/cn'
import { formatDate, toDateInputValue } from '@/utils/formatDate'
import { useAuth } from '@/features/auth/AuthContext'
import { useFamily } from '@/features/family/FamilyContext'
import { useCategories } from '@/features/categories/hooks'
import { getCategoryIcon } from '@/features/categories/iconMap'
import { CategoryPickerModal } from '@/features/categories/CategoryPickerModal'
import {
  recurringTransactionFormSchema,
  RECURRING_FREQUENCIES,
  type RecurringTransactionFormValues,
} from './schemas'
import { RECURRING_FREQUENCY_LABELS, RECURRING_FREQUENCY_UNIT } from './labels'
import { useCreateRecurringTransaction, useUpdateRecurringTransaction } from './hooks'
import { getRecurringTransactionErrorMessage } from './errors'
import { buildIntervalConfig, calculateNextRunDatePreview, type RecurringFrequency } from './api'

/** Минимально необходимые для формы поля — общие для RecurringTransactionListItem. */
export interface EditableRecurringTransaction {
  id: string
  type: 'income' | 'expense'
  amount: number
  categoryId: string | null
  incomeSource: string | null
  frequency: RecurringFrequency
  intervalConfig: Record<string, number> | null
  startDate: string
}

interface RecurringTransactionFormModalProps {
  open: boolean
  onClose: () => void
  /** Если передан — форма работает в режиме редактирования. */
  recurringTransaction?: EditableRecurringTransaction | null
}

function buildDefaultValues(item: EditableRecurringTransaction | null | undefined): RecurringTransactionFormValues {
  if (item) {
    return {
      type: item.type,
      amount: String(item.amount),
      categoryId: item.categoryId ?? '',
      incomeSource: item.incomeSource ?? '',
      frequency: item.frequency,
      interval: String(item.intervalConfig?.interval ?? 1),
      startDate: item.startDate,
      endDate: '',
    }
  }
  return {
    type: 'expense',
    amount: '',
    categoryId: '',
    incomeSource: '',
    frequency: 'monthly',
    interval: '1',
    startDate: toDateInputValue(),
    endDate: '',
  }
}

const FREQUENCY_OPTIONS = RECURRING_FREQUENCIES.map((value) => ({ value, label: RECURRING_FREQUENCY_LABELS[value] }))

/**
 * Единая форма создания/редактирования правила повторяющейся операции
 * (Этап 13). user_id (владелец правила) — ВСЕГДА текущий пользователь
 * (RLS recurring_transactions_insert_own требует user_id = auth.uid(), см.
 * api.ts) — в форме сознательно нет выбора ответственного, в отличие от
 * PlannedExpenseFormModal.
 *
 * day/month внутри interval_config выводятся из startDate на сервере при
 * отправке (см. buildIntervalConfig в api.ts) — здесь пользователь задаёт
 * только "каждые сколько" периодов (interval).
 */
export function RecurringTransactionFormModal({
  open,
  onClose,
  recurringTransaction = null,
}: RecurringTransactionFormModalProps) {
  const { toast } = useToast()
  const { user } = useAuth()
  const { currentFamily } = useFamily()
  const { data: categories } = useCategories()

  const isEdit = Boolean(recurringTransaction)
  const createMutation = useCreateRecurringTransaction()
  const updateMutation = useUpdateRecurringTransaction()
  const isSubmittingMutation = createMutation.isPending || updateMutation.isPending
  const [formError, setFormError] = useState<string | null>(null)
  const [categoryPickerOpen, setCategoryPickerOpen] = useState(false)
  const [nextPreview, setNextPreview] = useState<string | null>(null)

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<RecurringTransactionFormValues>({
    resolver: zodResolver(recurringTransactionFormSchema),
    defaultValues: buildDefaultValues(recurringTransaction),
  })

  useEffect(() => {
    if (open) {
      reset(buildDefaultValues(recurringTransaction))
      setFormError(null)
    }
  }, [open, recurringTransaction, reset])

  const type = watch('type')
  const categoryId = watch('categoryId')
  const frequency = watch('frequency')
  const interval = watch('interval')
  const startDate = watch('startDate')
  const selectedCategory = categories?.find((c) => c.id === categoryId) ?? null

  // Превью "затем спишется" — второе вхождение расписания, через RPC
  // calculate_recurring_next_run_date (единственный источник истины для
  // шага расписания, см. миграцию 0029 и api.ts). Первое вхождение — всегда
  // сам startDate, превью для него не нужно, показывается напрямую.
  useEffect(() => {
    if (!open) return
    const intervalNumber = Number(interval)
    if (!startDate || !Number.isInteger(intervalNumber) || intervalNumber < 1) {
      setNextPreview(null)
      return
    }
    let cancelled = false
    const config = buildIntervalConfig(frequency, intervalNumber, startDate)
    calculateNextRunDatePreview(startDate, frequency, config)
      .then((date) => {
        if (!cancelled) setNextPreview(date)
      })
      .catch(() => {
        if (!cancelled) setNextPreview(null)
      })
    return () => {
      cancelled = true
    }
  }, [open, frequency, interval, startDate])

  function handleTypeChange(nextType: 'income' | 'expense') {
    setValue('type', nextType, { shouldValidate: true })
    if (nextType === 'income') {
      setValue('categoryId', '', { shouldValidate: true })
    } else {
      setValue('incomeSource', '', { shouldValidate: true })
    }
  }

  function handleClose() {
    setFormError(null)
    onClose()
  }

  const onSubmit = handleSubmit(async (values) => {
    setFormError(null)
    const incomeSource = values.type === 'income' ? values.incomeSource?.trim() || null : null
    const categoryId2 = values.type === 'expense' ? values.categoryId || null : null
    const intervalNumber = Number(values.interval)
    const endDate = values.endDate || null

    try {
      if (isEdit && recurringTransaction) {
        await updateMutation.mutateAsync({
          id: recurringTransaction.id,
          type: values.type,
          amount: values.amount,
          categoryId: categoryId2,
          incomeSource,
          frequency: values.frequency,
          interval: intervalNumber,
          startDate: values.startDate,
          endDate,
        })
        toast({ type: 'success', title: 'Правило сохранено' })
      } else {
        if (!currentFamily?.id || !user?.id) throw new Error('NO_FAMILY')
        await createMutation.mutateAsync({
          familyId: currentFamily.id,
          userId: user.id,
          type: values.type,
          amount: values.amount,
          categoryId: categoryId2,
          incomeSource,
          frequency: values.frequency,
          interval: intervalNumber,
          startDate: values.startDate,
          endDate,
        })
        toast({ type: 'success', title: 'Повторяющаяся операция создана' })
      }
      handleClose()
    } catch (error) {
      setFormError(getRecurringTransactionErrorMessage(error))
    }
  })

  const busy = isSubmitting || isSubmittingMutation

  return (
    <Modal open={open} onClose={handleClose} title={isEdit ? 'Изменить правило' : 'Новая повторяющаяся операция'}>
      <form className="flex flex-col gap-4" onSubmit={onSubmit} noValidate>
        <div className="grid grid-cols-2 gap-2" role="group" aria-label="Тип операции">
          <TypeToggleButton
            active={type === 'expense'}
            icon={ArrowDownCircle}
            label="Расход"
            onClick={() => handleTypeChange('expense')}
          />
          <TypeToggleButton
            active={type === 'income'}
            icon={ArrowUpCircle}
            label="Доход"
            onClick={() => handleTypeChange('income')}
          />
        </div>

        <Input
          label="Сумма"
          inputMode="decimal"
          placeholder="0"
          autoComplete="off"
          error={errors.amount?.message}
          {...register('amount')}
        />

        {type === 'income' && (
          <Input
            label="Источник дохода"
            placeholder="Зарплата, подработка…"
            autoComplete="off"
            error={errors.incomeSource?.message}
            {...register('incomeSource')}
          />
        )}

        {type === 'expense' && (
          <div className="flex flex-col gap-1.5">
            <span className="text-sm font-medium text-foreground">Категория</span>
            <button
              type="button"
              onClick={() => setCategoryPickerOpen(true)}
              className={cn(
                'flex h-11 items-center gap-2 rounded-md border border-input bg-card px-3 text-left text-base text-foreground transition-colors',
                'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
              )}
            >
              <span className="flex size-6 shrink-0 items-center justify-center rounded-full bg-muted text-muted-foreground">
                {createElement(getCategoryIcon(selectedCategory?.icon), { className: 'size-3.5', 'aria-hidden': true })}
              </span>
              <span className="min-w-0 flex-1 truncate">
                {selectedCategory ? selectedCategory.name : 'Без категории'}
              </span>
              <ChevronRight className="size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
            </button>
          </div>
        )}

        <div className="grid grid-cols-2 gap-3">
          <Select label="Периодичность" options={FREQUENCY_OPTIONS} error={errors.frequency?.message} {...register('frequency')} />
          <Input
            label={`Интервал, ${RECURRING_FREQUENCY_UNIT[frequency]}`}
            inputMode="numeric"
            placeholder="1"
            error={errors.interval?.message}
            {...register('interval')}
          />
        </div>

        <Input label="Дата начала" type="date" error={errors.startDate?.message} {...register('startDate')} />

        <Input
          label="Дата окончания"
          type="date"
          helperText="Необязательно — оставьте пустым, если правило бессрочное"
          error={errors.endDate?.message}
          {...register('endDate')}
        />

        {startDate && !errors.startDate && !errors.interval && (
          <Text variant="small" className="text-muted-foreground">
            Первое списание: {formatDate(startDate)}
            {nextPreview && <>, затем {formatDate(nextPreview)}</>}
          </Text>
        )}

        {formError && (
          <p role="alert" className="text-sm text-destructive">
            {formError}
          </p>
        )}

        <Button type="submit" size="lg" isLoading={busy} disabled={busy}>
          {isEdit ? 'Сохранить' : 'Создать правило'}
        </Button>
      </form>

      <CategoryPickerModal
        open={categoryPickerOpen}
        onClose={() => setCategoryPickerOpen(false)}
        categories={categories ?? []}
        selectedCategoryId={categoryId || null}
        onSelect={(nextCategoryId) => setValue('categoryId', nextCategoryId ?? '', { shouldValidate: true })}
      />
    </Modal>
  )
}

function TypeToggleButton({
  active,
  icon: Icon,
  label,
  onClick,
}: {
  active: boolean
  icon: typeof ArrowDownCircle
  label: string
  onClick: () => void
}) {
  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={onClick}
      className={cn(
        'flex h-11 items-center justify-center gap-2 rounded-md border text-sm font-medium transition-colors',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background',
        active
          ? 'border-primary bg-primary-soft text-primary'
          : 'border-border bg-card text-muted-foreground hover:bg-muted',
      )}
    >
      <Icon className="size-4" aria-hidden="true" />
      {label}
    </button>
  )
}
