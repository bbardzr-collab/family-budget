import { describe, expect, it } from 'vitest'
import { buildIntervalConfig } from './api'

/**
 * buildIntervalConfig — тесты на разбор даты вручную (split), а не через
 * `new Date(...)`, чтобы day/month не сдвигались из-за локальной таймзоны
 * теста (тот же класс проверки, что и для utils/formatDate.ts).
 */
describe('buildIntervalConfig (Этап 13)', () => {
  it('weekly — только interval, без day/month', () => {
    expect(buildIntervalConfig('weekly', 2, '2026-09-21')).toEqual({ interval: 2 })
  })

  it('monthly — interval + day из start_date', () => {
    expect(buildIntervalConfig('monthly', 1, '2026-09-05')).toEqual({ interval: 1, day: 5 })
  })

  it('yearly — interval + month + day из start_date', () => {
    expect(buildIntervalConfig('yearly', 1, '2026-10-05')).toEqual({ interval: 1, month: 10, day: 5 })
  })

  it('корректно берёт последний день месяца (31) без сдвига', () => {
    expect(buildIntervalConfig('monthly', 1, '2026-01-31')).toEqual({ interval: 1, day: 31 })
  })

  it('корректно берёт первый день года (1 января) без сдвига на предыдущий год', () => {
    expect(buildIntervalConfig('yearly', 1, '2026-01-01')).toEqual({ interval: 1, month: 1, day: 1 })
  })
})
