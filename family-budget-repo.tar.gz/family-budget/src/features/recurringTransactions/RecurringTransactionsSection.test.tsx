import { fireEvent, render, screen, within } from '@testing-library/react'
import { ToastProvider } from '@/components/ui/Toast'
import { RecurringTransactionsSection } from './RecurringTransactionsSection'
import type { RecurringTransactionListItem } from './api'

const {
  mockUseRecurringTransactions,
  mockCreateMutateAsync,
  mockUpdateMutateAsync,
  mockDeleteMutateAsync,
  mockSetActiveMutateAsync,
  mockUseFamily,
  mockUseCategories,
  mockUseAuth,
} = vi.hoisted(() => ({
  mockUseRecurringTransactions: vi.fn(),
  mockCreateMutateAsync: vi.fn(),
  mockUpdateMutateAsync: vi.fn(),
  mockDeleteMutateAsync: vi.fn(),
  mockSetActiveMutateAsync: vi.fn(),
  mockUseFamily: vi.fn(),
  mockUseCategories: vi.fn(),
  mockUseAuth: vi.fn(),
}))

vi.mock('./hooks', () => ({
  useRecurringTransactions: mockUseRecurringTransactions,
  useCreateRecurringTransaction: () => ({ mutateAsync: mockCreateMutateAsync, isPending: false }),
  useUpdateRecurringTransaction: () => ({ mutateAsync: mockUpdateMutateAsync, isPending: false }),
  useDeleteRecurringTransaction: () => ({ mutateAsync: mockDeleteMutateAsync, isPending: false }),
  useSetRecurringTransactionActive: () => ({ mutateAsync: mockSetActiveMutateAsync, isPending: false }),
}))

vi.mock('@/features/family/FamilyContext', () => ({
  useFamily: mockUseFamily,
}))

vi.mock('@/features/categories/hooks', () => ({
  useCategories: mockUseCategories,
}))

// RecurringTransactionFormModal сознательно не даёт выбрать владельца правила
// (RLS recurring_transactions_insert_own требует user_id = auth.uid(), см.
// api.ts) — вместо этого форма берёт id из useAuth(), поэтому, в отличие от
// PlannedExpensesSection.test.tsx, этому файлу нужен и мок AuthContext.
vi.mock('@/features/auth/AuthContext', () => ({
  useAuth: mockUseAuth,
}))

const CATEGORIES = [
  { id: 'cat-1', name: 'Аренда', type: 'NEEDS' as const, icon: 'home', isActive: true, isCustom: false },
]

// Этап 21 (security audit) — регресс-фикс на дату-хрупкость теста, найденный
// при финальной верификации: буквальная дата '2026-09-25' была "заведомо
// далёкой в будущем" только на момент написания теста (Этап 13, 2026-09-21) —
// к моменту прогона на реальных часах (после Этапа 20) эта дата уже стала
// прошлым, и правило стало вычисляться как "Просрочено" вместо "Активна".
// Вычисляем дату на несколько лет вперёд от реального "сегодня" вместо
// литерала, чтобы тест не зависел от того, когда именно он запускается —
// не security-фикс сам по себе, но необходим, чтобы `npm run test` оставался
// осмысленным индикатором регрессии для проверки security-исправлений этого
// этапа (ТЗ Этапа 21, §38-39).
const FAR_FUTURE_DATE = (() => {
  const d = new Date()
  d.setFullYear(d.getFullYear() + 5)
  return d.toISOString().slice(0, 10)
})()

function makeRecurring(overrides: Partial<RecurringTransactionListItem> = {}): RecurringTransactionListItem {
  return {
    id: 'rec-1',
    type: 'expense',
    amount: 45000,
    categoryId: 'cat-1',
    category: { id: 'cat-1', name: 'Аренда', icon: 'home', isActive: true },
    incomeSource: null,
    frequency: 'monthly',
    intervalConfig: { interval: 1, day: 25 },
    startDate: '2026-08-25',
    endDate: null,
    nextRunDate: FAR_FUTURE_DATE,
    isActive: true,
    userId: 'user-1',
    userName: 'Иван',
    createdAt: '2026-08-01T00:00:00Z',
    ...overrides,
  }
}

function renderSection(props: Partial<React.ComponentProps<typeof RecurringTransactionsSection>> = {}) {
  return render(
    <ToastProvider>
      <RecurringTransactionsSection createOpen={false} onCreateClose={vi.fn()} {...props} />
    </ToastProvider>,
  )
}

describe('RecurringTransactionsSection (Этап 13)', () => {
  beforeEach(() => {
    // Без vi.useFakeTimers() — по тому же принципу, что и
    // PlannedExpensesSection.test.tsx: fireEvent + await screen.findByText
    // прекрасно работают с реальными таймерами, а статусы ниже проверяются
    // через даты, заведомо далёкие в прошлом/будущем от реального "сегодня".
    mockUseFamily.mockReturnValue({ currentFamily: { id: 'family-1' } })
    mockUseCategories.mockReturnValue({ data: CATEGORIES, isLoading: false, isError: false })
    mockUseAuth.mockReturnValue({ user: { id: 'user-1' } })
    mockCreateMutateAsync.mockReset().mockResolvedValue({})
    mockUpdateMutateAsync.mockReset().mockResolvedValue({})
    mockDeleteMutateAsync.mockReset().mockResolvedValue(undefined)
    mockSetActiveMutateAsync.mockReset().mockResolvedValue(undefined)
  })

  it('пустое состояние: "Повторяющихся операций пока нет"', () => {
    mockUseRecurringTransactions.mockReturnValue({ data: [], isLoading: false, isError: false, refetch: vi.fn() })

    renderSection()

    expect(screen.getByText('Повторяющихся операций пока нет')).toBeInTheDocument()
  })

  it('показывает строку правила с названием/периодичностью/суммой/статусом', () => {
    mockUseRecurringTransactions.mockReturnValue({
      data: [makeRecurring()],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderSection()

    // "Аренда" встречается дважды в строке (заголовок + категория) — оба
    // вхождения происходят от одного и того же item.category.name.
    expect(screen.getAllByText('Аренда').length).toBeGreaterThan(0)
    expect(screen.getByText('Ежемесячно')).toBeInTheDocument()
    expect(screen.getByText('45 000 ₽')).toBeInTheDocument()
    expect(screen.getByText('Активна')).toBeInTheDocument()
  })

  it('правило с next_run_date в прошлом показывает статус "Просрочено"', () => {
    mockUseRecurringTransactions.mockReturnValue({
      data: [makeRecurring({ id: 'rec-overdue', nextRunDate: '2020-01-01' })],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderSection()

    expect(screen.getByText('Просрочено')).toBeInTheDocument()
  })

  it('приостановленное правило показывает статус "На паузе", даже если next_run_date в прошлом', () => {
    mockUseRecurringTransactions.mockReturnValue({
      data: [makeRecurring({ id: 'rec-paused', isActive: false, nextRunDate: '2020-01-01' })],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderSection()

    expect(screen.getByText('На паузе')).toBeInTheDocument()
    expect(screen.queryByText('Просрочено')).not.toBeInTheDocument()
  })

  it('"Приостановить" вызывает мутацию сразу, без диалога подтверждения', async () => {
    mockUseRecurringTransactions.mockReturnValue({
      data: [makeRecurring()],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderSection()

    fireEvent.click(screen.getByRole('button', { name: /Действия с правилом/i }))
    fireEvent.click(screen.getByRole('menuitem', { name: 'Приостановить' }))

    expect(await screen.findByText('Правило приостановлено')).toBeInTheDocument()
    expect(mockSetActiveMutateAsync).toHaveBeenCalledWith({ id: 'rec-1', isActive: false })
  })

  it('"Возобновить" доступно для приостановленного правила и вызывает мутацию', async () => {
    mockUseRecurringTransactions.mockReturnValue({
      data: [makeRecurring({ isActive: false })],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderSection()

    fireEvent.click(screen.getByRole('button', { name: /Действия с правилом/i }))
    fireEvent.click(screen.getByRole('menuitem', { name: 'Возобновить' }))

    expect(await screen.findByText('Правило возобновлено')).toBeInTheDocument()
    expect(mockSetActiveMutateAsync).toHaveBeenCalledWith({ id: 'rec-1', isActive: true })
  })

  it('удаление правила требует подтверждения и вызывает мутацию', async () => {
    mockUseRecurringTransactions.mockReturnValue({
      data: [makeRecurring()],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderSection()

    fireEvent.click(screen.getByRole('button', { name: /Действия с правилом/i }))
    fireEvent.click(screen.getByRole('menuitem', { name: 'Удалить правило' }))

    const dialog = screen.getByRole('dialog', { name: 'Удалить правило?' })
    expect(dialog.textContent).toContain('«Аренда»')
    fireEvent.click(within(dialog).getByRole('button', { name: 'Удалить' }))

    expect(await screen.findByText('Правило удалено')).toBeInTheDocument()
    expect(mockDeleteMutateAsync).toHaveBeenCalledWith('rec-1')
  })

  it('редактирование: форма предзаполнена, сабмит вызывает мутацию обновления (next_run_date не отправляется)', async () => {
    mockUseRecurringTransactions.mockReturnValue({
      data: [makeRecurring()],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderSection()

    fireEvent.click(screen.getByRole('button', { name: /Действия с правилом/i }))
    fireEvent.click(screen.getByRole('menuitem', { name: 'Редактировать' }))

    const dialog = screen.getByRole('dialog', { name: 'Изменить правило' })
    expect(within(dialog).getByLabelText('Сумма')).toHaveValue('45000')
    expect(within(dialog).getByLabelText('Дата начала')).toHaveValue('2026-08-25')

    fireEvent.click(within(dialog).getByRole('button', { name: 'Сохранить' }))

    expect(await screen.findByText('Правило сохранено')).toBeInTheDocument()
    expect(mockUpdateMutateAsync).toHaveBeenCalledWith(
      expect.objectContaining({ id: 'rec-1', amount: '45000.00', frequency: 'monthly', interval: 1 }),
    )
    // UpdateRecurringTransactionInput структурно не содержит nextRunDate
    // (см. api.ts) — сервер не трогает next_run_date при обновлении правила.
    expect(mockUpdateMutateAsync).not.toHaveBeenCalledWith(expect.objectContaining({ nextRunDate: expect.anything() }))
  })

  it('создание: корректные данные вызывают мутацию создания с familyId и userId текущего пользователя', async () => {
    mockUseRecurringTransactions.mockReturnValue({ data: [], isLoading: false, isError: false, refetch: vi.fn() })

    renderSection({ createOpen: true })

    const dialog = screen.getByRole('dialog', { name: 'Новая повторяющаяся операция' })
    fireEvent.change(within(dialog).getByLabelText('Сумма'), { target: { value: '5000' } })
    fireEvent.change(within(dialog).getByLabelText('Дата начала'), { target: { value: '2026-09-25' } })
    fireEvent.click(within(dialog).getByRole('button', { name: 'Создать правило' }))

    expect(await screen.findByText('Повторяющаяся операция создана')).toBeInTheDocument()
    expect(mockCreateMutateAsync).toHaveBeenCalledWith(
      expect.objectContaining({
        familyId: 'family-1',
        userId: 'user-1',
        amount: '5000.00',
        frequency: 'monthly',
        interval: 1,
        startDate: '2026-09-25',
      }),
    )
  })

  it('создание: нулевая сумма отклоняется валидацией, мутация не вызывается', async () => {
    mockUseRecurringTransactions.mockReturnValue({ data: [], isLoading: false, isError: false, refetch: vi.fn() })

    renderSection({ createOpen: true })

    const dialog = screen.getByRole('dialog', { name: 'Новая повторяющаяся операция' })
    fireEvent.change(within(dialog).getByLabelText('Сумма'), { target: { value: '0' } })
    fireEvent.click(within(dialog).getByRole('button', { name: 'Создать правило' }))

    expect(await within(dialog).findByText('Сумма должна быть больше нуля')).toBeInTheDocument()
    expect(mockCreateMutateAsync).not.toHaveBeenCalled()
  })
})
