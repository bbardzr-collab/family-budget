import { describe, expect, it } from 'vitest'
import { recurringTransactionFormSchema } from './schemas'

/**
 * Тесты валидации формы повторяющейся операции (Этап 13) — минимальный
 * набор: создание — корректное правило принято, отрицательная/нулевая сумма
 * запрещены, интервал вне диапазона запрещён, дата окончания раньше даты
 * начала запрещена.
 */
describe('recurringTransactionFormSchema (Этап 13)', () => {
  const base = {
    type: 'expense' as const,
    amount: '15000',
    categoryId: '',
    incomeSource: '',
    frequency: 'monthly' as const,
    interval: '1',
    startDate: '2026-09-25',
    endDate: '',
  }

  it('принимает корректное правило без категории и даты окончания', () => {
    expect(recurringTransactionFormSchema.safeParse(base).success).toBe(true)
  })

  it('принимает правило с категорией и датой окончания', () => {
    const result = recurringTransactionFormSchema.safeParse({
      ...base,
      categoryId: 'cat-1',
      endDate: '2027-01-01',
    })
    expect(result.success).toBe(true)
  })

  it('отклоняет нулевую и отрицательную сумму', () => {
    expect(recurringTransactionFormSchema.safeParse({ ...base, amount: '0' }).success).toBe(false)
    expect(recurringTransactionFormSchema.safeParse({ ...base, amount: '-100' }).success).toBe(false)
  })

  it('отклоняет пустую сумму', () => {
    expect(recurringTransactionFormSchema.safeParse({ ...base, amount: '' }).success).toBe(false)
  })

  it('отклоняет более 2 знаков после запятой', () => {
    expect(recurringTransactionFormSchema.safeParse({ ...base, amount: '1000.999' }).success).toBe(false)
  })

  it('нормализует запятую как десятичный разделитель и дополняет копейки', () => {
    const result = recurringTransactionFormSchema.safeParse({ ...base, amount: '1500,5' })
    expect(result.success).toBe(true)
    if (result.success) expect(result.data.amount).toBe('1500.50')
  })

  it('отклоняет сумму за пределами NUMERIC(14,2) (Этап 20 — недостающий тест, тот же паттерн, что у остальных денежных схем)', () => {
    expect(recurringTransactionFormSchema.safeParse({ ...base, amount: '1'.repeat(13) }).success).toBe(false)
  })

  it('принимает максимально допустимую сумму 999999999999.99 (Этап 20 — регресс-тест на границу NUMERIC(14,2))', () => {
    expect(recurringTransactionFormSchema.safeParse({ ...base, amount: '999999999999.99' }).success).toBe(true)
  })

  it('отклоняет интервал 0 и нецелые значения', () => {
    expect(recurringTransactionFormSchema.safeParse({ ...base, interval: '0' }).success).toBe(false)
    expect(recurringTransactionFormSchema.safeParse({ ...base, interval: '1.5' }).success).toBe(false)
    expect(recurringTransactionFormSchema.safeParse({ ...base, interval: '' }).success).toBe(false)
  })

  it('отклоняет интервал больше 365', () => {
    expect(recurringTransactionFormSchema.safeParse({ ...base, interval: '400' }).success).toBe(false)
  })

  it('принимает интервал на границах диапазона (1 и 365)', () => {
    expect(recurringTransactionFormSchema.safeParse({ ...base, interval: '1' }).success).toBe(true)
    expect(recurringTransactionFormSchema.safeParse({ ...base, interval: '365' }).success).toBe(true)
  })

  it('требует дату начала', () => {
    expect(recurringTransactionFormSchema.safeParse({ ...base, startDate: '' }).success).toBe(false)
  })

  it('отклоняет дату окончания раньше даты начала', () => {
    const result = recurringTransactionFormSchema.safeParse({
      ...base,
      startDate: '2026-09-25',
      endDate: '2026-09-01',
    })
    expect(result.success).toBe(false)
    if (!result.success) {
      expect(result.error.issues.some((i) => i.path.includes('endDate'))).toBe(true)
    }
  })

  it('принимает дату окончания, равную дате начала', () => {
    const result = recurringTransactionFormSchema.safeParse({
      ...base,
      startDate: '2026-09-25',
      endDate: '2026-09-25',
    })
    expect(result.success).toBe(true)
  })

  it('категория необязательна (нет ошибок при пустой строке-сентинеле)', () => {
    expect(recurringTransactionFormSchema.safeParse({ ...base, categoryId: '' }).success).toBe(true)
  })
})
