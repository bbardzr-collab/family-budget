import { useState } from 'react'
import { Button, Modal, Text } from '@/components/ui'
import { useToast } from '@/components/ui/Toast'
import { formatMoney } from '@/utils/formatMoney'
import { useDeleteRecurringTransaction } from './hooks'
import { getRecurringTransactionErrorMessage } from './errors'
import type { RecurringTransactionType } from './api'

interface DeleteRecurringTransactionModalProps {
  recurringTransaction: { id: string; type: RecurringTransactionType; amount: number; title: string } | null
  onClose: () => void
}

/**
 * Подтверждение удаления правила. planned_expenses.recurring_transaction_id
 * → ON DELETE SET NULL (миграция 0004) — уже созданные напоминания и тем
 * более фактические операции НЕ затрагиваются удалением самого правила.
 */
export function DeleteRecurringTransactionModal({
  recurringTransaction,
  onClose,
}: DeleteRecurringTransactionModalProps) {
  const { toast } = useToast()
  const deleteMutation = useDeleteRecurringTransaction()
  const [error, setError] = useState<string | null>(null)

  async function handleConfirm() {
    if (!recurringTransaction) return
    setError(null)
    try {
      await deleteMutation.mutateAsync(recurringTransaction.id)
      toast({ type: 'success', title: 'Правило удалено' })
      onClose()
    } catch (err) {
      setError(getRecurringTransactionErrorMessage(err))
    }
  }

  function handleClose() {
    setError(null)
    onClose()
  }

  return (
    <Modal
      open={Boolean(recurringTransaction)}
      onClose={handleClose}
      title="Удалить правило?"
      footer={
        <>
          <Button variant="outline" onClick={handleClose}>
            Отмена
          </Button>
          <Button
            variant="destructive"
            onClick={() => void handleConfirm()}
            isLoading={deleteMutation.isPending}
            disabled={deleteMutation.isPending}
          >
            Удалить
          </Button>
        </>
      }
    >
      <Text variant="secondary">
        {recurringTransaction &&
          `«${recurringTransaction.title}» на сумму ${formatMoney(recurringTransaction.amount)} `}
        будет удалено без возможности восстановления. Уже созданные напоминания и операции сохранятся, но
        потеряют связь с этим правилом — новые напоминания создаваться не будут.
      </Text>
      {error && (
        <p role="alert" className="mt-3 text-sm text-destructive">
          {error}
        </p>
      )}
    </Modal>
  )
}
