import { supabase } from '@/lib/supabase'
import type { Tables } from '@/types/database'
import type { FamilyRole, InvitableRole } from './roles'

/**
 * Тонкий слой доступа к данным семьи (Этап 5, п.34) — только запросы,
 * никакой бизнес-логики и никакого React. Хуки в hooks.ts оборачивают эти
 * функции в TanStack Query.
 */

export type FamilyRow = Tables<'families'>
export type FamilyMemberRow = Tables<'family_members'>
export type FamilyInvitationRow = Tables<'family_invitations'>
export type FamilySettingsRow = Tables<'family_settings'>

export interface MembershipWithFamily extends FamilyMemberRow {
  family: FamilyRow
}

export interface FamilyMemberWithProfile extends FamilyMemberRow {
  profile: Pick<Tables<'users'>, 'id' | 'full_name' | 'avatar_url'> | null
}

/** Только нужные для списка поля — без token/invited_by (ТЗ, п.18, 28). */
export type InvitationListItem = Pick<
  FamilyInvitationRow,
  'id' | 'role' | 'status' | 'expires_at' | 'created_at'
>

export interface InvitationPreview {
  familyName: string | null
  role: string | null
  status: string
  expiresAt: string | null
  isValid: boolean
}

export interface CreatedInvitation {
  id: string
  token: string
  role: string
  expiresAt: string
  createdAt: string
}

/** Активное членство текущего пользователя + вложенная запись семьи, если она есть. */
export async function fetchMyMembership(userId: string): Promise<MembershipWithFamily | null> {
  const { data, error } = await supabase
    .from('family_members')
    .select('*, family:families(*)')
    .eq('user_id', userId)
    .eq('status', 'active')
    .maybeSingle()

  if (error) throw error
  return (data as MembershipWithFamily | null) ?? null
}

/**
 * Список участников семьи с профилем (имя/аватар) — для страницы Family.
 * Только активные (Этап 15, п.4) — участник, покинувший семью или удалённый
 * ADMIN'ом (status='inactive', см. updateFamilyMemberRole/removeFamilyMember/
 * leaveFamily ниже), больше не отображается в списке. Историю его финансовых
 * данных это не затрагивает — удаляется/меняется только сама строка
 * членства, а не transactions/goals/planned_expenses/recurring_transactions.
 */
export async function fetchFamilyMembers(familyId: string): Promise<FamilyMemberWithProfile[]> {
  const { data, error } = await supabase
    .from('family_members')
    .select('*, profile:users(id, full_name, avatar_url)')
    .eq('family_id', familyId)
    .eq('status', 'active')
    .order('joined_at', { ascending: true })

  if (error) throw error
  return (data as FamilyMemberWithProfile[]) ?? []
}

/**
 * Изменение роли участника (adult <-> child, Этап 15, п.11) — прямой RLS-
 * защищённый UPDATE (family_members_update_admin, Этап 3: только ADMIN своей
 * семьи), тем же принципом, что и другие прямые CRUD-мутации проекта. Защиту
 * "не понизить единственного admin" и "роль — только admin/adult/child"
 * обеспечивают CHECK-constraint и триггер family_members_guard_admin_invariant
 * (миграция 0031) — не дублируется здесь на клиенте. `.select('id').single()`
 * гарантирует явную ошибку (PGRST116), если RLS отфильтровала строку (участник
 * другой семьи) — а не молчаливый no-op.
 */
export async function updateFamilyMemberRole(memberId: string, role: FamilyRole): Promise<void> {
  const { error } = await supabase.from('family_members').update({ role }).eq('id', memberId).select('id').single()
  if (error) throw error
}

/**
 * "Удаление" участника ADMIN'ом (Этап 15, п.13) — soft: status -> 'inactive',
 * НЕ DELETE строки. Ничего не удаляет из transactions/goals/planned_expenses/
 * recurring_transactions — у них нет FK на family_members.id. Тот же путь
 * (RLS + триггер), что и смена роли выше.
 */
export async function removeFamilyMember(memberId: string): Promise<void> {
  const { error } = await supabase
    .from('family_members')
    .update({ status: 'inactive' })
    .eq('id', memberId)
    .select('id')
    .single()
  if (error) throw error
}

/**
 * Самостоятельный выход из семьи (Этап 15, п.14) — через RPC leave_family(),
 * а не прямой UPDATE: у adult/child нет RLS-прав на UPDATE собственной же
 * строки family_members (family_members_update_admin — только ADMIN).
 * Сервер сам находит активное членство вызывающего по auth.uid() и отклоняет
 * попытку единственного admin'а покинуть семью (LAST_ADMIN_PROTECTED).
 */
export async function leaveFamily(): Promise<void> {
  const { error } = await supabase.rpc('leave_family')
  if (error) throw error
}

/**
 * Переименование семьи (Этап 15, п.15) — прямой RLS-защищённый UPDATE
 * (families_update_admin, Этап 3: только ADMIN своей семьи). Валидация
 * (trim/длина) — на клиенте через renameFamilySchema (см. schemas.ts),
 * тем же набором правил, что и при создании семьи.
 */
export async function renameFamily(familyId: string, name: string): Promise<void> {
  const { error } = await supabase.from('families').update({ name }).eq('id', familyId).select('id').single()
  if (error) throw error
}

/**
 * Настройки семьи (Этап 15, п.30) — сейчас используется только для
 * read-only отображения валюты (RUB по умолчанию, families_settings создаётся
 * триггером handle_new_family на Этапе 3). child_visibility НЕ читается и не
 * используется здесь — это задел под Этап 16, тонкая приватность ребёнка
 * реализуется отдельно.
 */
export async function fetchFamilySettings(familyId: string): Promise<FamilySettingsRow | null> {
  const { data, error } = await supabase.from('family_settings').select('*').eq('family_id', familyId).maybeSingle()
  if (error) throw error
  return data
}

/**
 * Список приглашений семьи — только для ADMIN (см. RLS
 * family_invitations_select_admin). У остальных ролей RLS молча вернёт
 * пустой список, поэтому хук вызывает это только когда isAdmin=true.
 * Явно не выбираем token/invited_by — они не нужны списку (п.18).
 */
export async function fetchFamilyInvitations(familyId: string): Promise<InvitationListItem[]> {
  const { data, error } = await supabase
    .from('family_invitations')
    .select('id, role, status, expires_at, created_at')
    .eq('family_id', familyId)
    .order('created_at', { ascending: false })

  if (error) throw error
  return data ?? []
}

/** Создаёт семью (families + family_members(admin) + стандартные категории) атомарно. */
export async function createFamily(name: string): Promise<string> {
  const { data, error } = await supabase.rpc('create_family', { p_name: name })
  if (error) throw error
  return data
}

export async function createFamilyInvitation(role: InvitableRole): Promise<CreatedInvitation> {
  const { data, error } = await supabase.rpc('create_family_invitation', { p_role: role })
  if (error) throw error
  const row = data?.[0]
  if (!row) throw new Error('Приглашение не удалось создать.')
  return {
    id: row.id,
    token: row.token,
    role: row.role,
    expiresAt: row.expires_at,
    createdAt: row.created_at,
  }
}

export async function cancelFamilyInvitation(invitationId: string): Promise<void> {
  const { error } = await supabase.rpc('cancel_family_invitation', { p_invitation_id: invitationId })
  if (error) throw error
}

/** Публичная проверка приглашения — работает и без авторизации (п.20, 28). */
export async function getInvitationByToken(token: string): Promise<InvitationPreview> {
  const { data, error } = await supabase.rpc('get_invitation_by_token', { p_token: token })
  if (error) throw error
  const row = data?.[0]
  if (!row) {
    return { familyName: null, role: null, status: 'not_found', expiresAt: null, isValid: false }
  }
  return {
    familyName: row.family_name,
    role: row.role,
    status: row.status,
    expiresAt: row.expires_at,
    isValid: row.is_valid,
  }
}

export async function acceptFamilyInvitation(token: string): Promise<string> {
  const { data, error } = await supabase.rpc('accept_family_invitation', { p_token: token })
  if (error) throw error
  return data
}
