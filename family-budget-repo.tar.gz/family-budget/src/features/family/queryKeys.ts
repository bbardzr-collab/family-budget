/** Единый источник ключей React Query для домена "семья" (Этап 5, п.34-35; Этап 15, п.28). */
export const familyKeys = {
  all: ['family'] as const,
  membership: (userId: string | undefined) => [...familyKeys.all, 'membership', userId] as const,
  members: (familyId: string | undefined) => [...familyKeys.all, 'members', familyId] as const,
  invitations: (familyId: string | undefined) => [...familyKeys.all, 'invitations', familyId] as const,
  invitationPreview: (token: string | undefined) => [...familyKeys.all, 'invitation-preview', token] as const,
  settings: (familyId: string | undefined) => [...familyKeys.all, 'settings', familyId] as const,
}
