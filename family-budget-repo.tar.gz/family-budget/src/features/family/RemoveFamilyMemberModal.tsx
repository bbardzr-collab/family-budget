import { useState } from 'react'
import { Button, Modal, Text } from '@/components/ui'
import { useToast } from '@/components/ui/Toast'
import { useRemoveMember } from './hooks'
import { getFamilyErrorMessage } from './errors'
import { roleLabel } from './roles'

interface RemoveFamilyMemberModalProps {
  member: { id: string; name: string; role: string } | null
  familyId: string
  onClose: () => void
}

/**
 * Подтверждение удаления участника из семьи (Этап 15, п.13). Удаление —
 * soft (family_members.status -> 'inactive', см. api.ts) и НЕ трогает
 * transactions/goals/planned_expenses/recurring_transactions участника —
 * история сохраняется, удаляется только само членство в семье.
 */
export function RemoveFamilyMemberModal({ member, familyId, onClose }: RemoveFamilyMemberModalProps) {
  const { toast } = useToast()
  const removeMember = useRemoveMember(familyId)
  const [error, setError] = useState<string | null>(null)

  async function handleConfirm() {
    if (!member) return
    setError(null)
    try {
      await removeMember.mutateAsync(member.id)
      toast({ type: 'success', title: 'Участник удалён из семьи' })
      onClose()
    } catch (err) {
      setError(getFamilyErrorMessage(err))
    }
  }

  function handleClose() {
    setError(null)
    onClose()
  }

  return (
    <Modal
      open={Boolean(member)}
      onClose={handleClose}
      title="Удалить участника?"
      footer={
        <>
          <Button variant="outline" onClick={handleClose}>
            Отмена
          </Button>
          <Button
            variant="destructive"
            onClick={() => void handleConfirm()}
            isLoading={removeMember.isPending}
            disabled={removeMember.isPending}
          >
            Удалить
          </Button>
        </>
      }
    >
      <Text variant="secondary">
        {member && (
          <>
            Вы уверены, что хотите удалить «{member.name}» ({roleLabel(member.role)}) из семьи? Их операции, цели и
            планы сохранятся в истории, но доступ к семье будет закрыт.
          </>
        )}
      </Text>
      {error && (
        <p role="alert" className="mt-3 text-sm text-destructive">
          {error}
        </p>
      )}
    </Modal>
  )
}
