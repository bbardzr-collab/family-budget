import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { Copy, UserPlus } from 'lucide-react'
import { Button, Modal, Select, Text } from '@/components/ui'
import { useToast } from '@/components/ui/Toast'
import { formatDate } from '@/utils/formatDate'
import { inviteMemberSchema, type InviteMemberFormValues } from './schemas'
import { useCreateInvitation } from './hooks'
import { getFamilyErrorMessage } from './errors'
import { INVITABLE_ROLE_OPTIONS, roleLabel } from './roles'
import { copyToClipboard } from './clipboard'

interface InviteMemberModalProps {
  open: boolean
  onClose: () => void
  familyId: string
}

interface CreatedLink {
  url: string
  role: string
  expiresAt: string
}

/**
 * Modal «Пригласить члена семьи» (Этап 5, п.12, 17). Email не запрашивается —
 * приглашение в версии 1.0 работает только по ссылке (п.12). После
 * успешного создания показываем ссылку и кнопку «Скопировать ссылку» —
 * ссылка формируется на фронтенде из window.location.origin (п.16), сам
 * token — только с сервера (create_family_invitation).
 */
export function InviteMemberModal({ open, onClose, familyId }: InviteMemberModalProps) {
  const { toast } = useToast()
  const createInvitation = useCreateInvitation(familyId)
  const [createdLink, setCreatedLink] = useState<CreatedLink | null>(null)
  const [formError, setFormError] = useState<string | null>(null)

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<InviteMemberFormValues>({ resolver: zodResolver(inviteMemberSchema) })

  function handleClose() {
    setCreatedLink(null)
    setFormError(null)
    reset()
    onClose()
  }

  const onSubmit = handleSubmit(async (values) => {
    setFormError(null)
    try {
      const invitation = await createInvitation.mutateAsync(values.role)
      setCreatedLink({
        url: `${window.location.origin}/invite/${invitation.token}`,
        role: invitation.role,
        expiresAt: invitation.expiresAt,
      })
    } catch (error) {
      setFormError(getFamilyErrorMessage(error))
    }
  })

  async function handleCopy() {
    if (!createdLink) return
    const ok = await copyToClipboard(createdLink.url)
    toast(
      ok
        ? { type: 'success', title: 'Ссылка скопирована' }
        : {
            type: 'error',
            title: 'Не удалось скопировать',
            description: 'Скопируйте ссылку вручную из поля выше.',
          },
    )
  }

  return (
    <Modal open={open} onClose={handleClose} title={createdLink ? 'Приглашение создано' : 'Пригласить члена семьи'}>
      {createdLink ? (
        <div className="flex flex-col gap-4">
          <Text variant="secondary">
            Приглашение для роли «{roleLabel(createdLink.role)}» действительно до{' '}
            {formatDate(createdLink.expiresAt)}. Отправьте эту ссылку тому, кого приглашаете.
          </Text>
          <div className="break-all rounded-md border border-border bg-muted p-3 text-sm text-foreground">
            {createdLink.url}
          </div>
          <Button type="button" onClick={() => void handleCopy()} className="self-start">
            <Copy className="size-4" aria-hidden="true" />
            Скопировать ссылку
          </Button>
        </div>
      ) : (
        <form className="flex flex-col gap-4" onSubmit={onSubmit} noValidate>
          <Select
            label="Роль"
            placeholder="Выберите роль"
            options={INVITABLE_ROLE_OPTIONS}
            error={errors.role?.message}
            {...register('role')}
          />

          {formError && (
            <p role="alert" className="text-sm text-destructive">
              {formError}
            </p>
          )}

          <Button type="submit" isLoading={isSubmitting} disabled={isSubmitting}>
            <UserPlus className="size-4" aria-hidden="true" />
            Создать приглашение
          </Button>
        </form>
      )}
    </Modal>
  )
}
