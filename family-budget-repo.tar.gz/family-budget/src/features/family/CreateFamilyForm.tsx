import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { Users } from 'lucide-react'
import { Button, Input } from '@/components/ui'
import { createFamilySchema, type CreateFamilyFormValues } from './schemas'
import { useCreateFamily } from './hooks'
import { getFamilyErrorMessage } from './errors'
import { useToast } from '@/components/ui/Toast'

interface CreateFamilyFormProps {
  onCreated?: () => void
}

/**
 * Форма «Создайте семью» (Этап 5, п.2). Переиспользуемый компонент —
 * используется на /app, когда у пользователя ещё нет активной семьи.
 * Обычный Input/Button из общего UI-набора, своих стилей не заводим (п.17).
 */
export function CreateFamilyForm({ onCreated }: CreateFamilyFormProps) {
  const { toast } = useToast()
  const createFamily = useCreateFamily()

  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<CreateFamilyFormValues>({ resolver: zodResolver(createFamilySchema) })

  const onSubmit = handleSubmit(async (values) => {
    try {
      await createFamily.mutateAsync(values.name)
      toast({ type: 'success', title: 'Семья создана' })
      onCreated?.()
    } catch (error) {
      setError('name', { message: getFamilyErrorMessage(error) })
    }
  })

  return (
    <form className="flex flex-col gap-4" onSubmit={onSubmit} noValidate>
      <div className="flex flex-col items-center gap-2 text-center">
        <div className="flex size-12 items-center justify-center rounded-full bg-accent">
          <Users className="size-6 text-primary" aria-hidden="true" />
        </div>
        <div>
          <h2 className="font-semibold text-foreground">Создайте семью</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Один пользователь может состоять только в одной семье. Вы автоматически станете её
            администратором.
          </p>
        </div>
      </div>

      <Input
        label="Название семьи"
        placeholder="Семья Ивановых"
        autoComplete="off"
        error={errors.name?.message}
        {...register('name')}
      />

      <Button type="submit" size="lg" isLoading={isSubmitting} disabled={isSubmitting}>
        Создать семью
      </Button>
    </form>
  )
}
