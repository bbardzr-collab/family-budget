/**
 * Перевод ошибок наших же SECURITY DEFINER RPC (Этап 5) и прямых RLS/триггер-
 * защищённых мутаций (Этап 15) в понятные человеку сообщения (ТЗ, п.36).
 *
 * В отличие от authErrors.ts (где сообщения приходят от Supabase Auth/GoTrue
 * и текст не под нашим контролем — там сопоставление по подстроке надёжнее),
 * здесь текст ошибки — это ровно то, что наши функции сами передают в
 * `raise exception 'КОД'` (см. supabase/migrations/0012_family_rpcs.sql,
 * 0014_fix_cancel_invitation_status.sql, 0031_family_roles_management.sql).
 * RPC бросают голый код (`raise exception 'КОД'`) — сопоставляем точным
 * совпадением. Новый триггер family_members_guard_admin_invariant (Этап 15)
 * бросает код с пояснением через двоеточие (`'КОД: текст'`, тот же формат,
 * что и триггеры Этапов 12-13) — для него, а также для стандартных кодов
 * PostgREST/RLS у прямых UPDATE (updateFamilyMemberRole/removeFamilyMember/
 * renameFamily, см. api.ts), сопоставляем по подстроке, тем же принципом,
 * что features/recurringTransactions/errors.ts.
 */

interface MatchableError {
  message?: string
  name?: string
  code?: string
}

const MESSAGES: Record<string, string> = {
  NOT_AUTHENTICATED: 'Нужно войти в аккаунт, чтобы выполнить это действие.',
  USER_PROFILE_NOT_FOUND: 'Не удалось найти ваш профиль. Попробуйте перезайти в аккаунт.',
  FAMILY_NAME_TOO_SHORT: 'Название семьи слишком короткое — минимум 2 символа.',
  FAMILY_NAME_TOO_LONG: 'Название семьи слишком длинное.',
  FAMILY_ALREADY_EXISTS: 'Вы уже состоите в семье. В версии 1.0 можно быть только в одной семье.',
  NO_FAMILY: 'У вас пока нет семьи.',
  FORBIDDEN: 'Недостаточно прав для этого действия.',
  INVALID_ROLE: 'Такую роль нельзя назначить через приглашение.',
  INVITATION_NOT_FOUND: 'Приглашение не найдено.',
  INVITATION_NOT_PENDING: 'Это приглашение уже недействительно (отменено, использовано или истекло).',
}

export function getFamilyErrorMessage(error: unknown): string {
  if (!error) return 'Неизвестная ошибка. Попробуйте ещё раз.'

  if (error instanceof TypeError) {
    return 'Проблема с сетью. Проверьте подключение к интернету и попробуйте снова.'
  }

  const { message, code } = (error as MatchableError) ?? {}
  const trimmed = (message ?? String(error)).trim()

  const known = MESSAGES[trimmed]
  if (known) return known

  const text = trimmed.toLowerCase()

  // Триггер family_members_guard_admin_invariant (миграция 0031, Этап 15,
  // п.12) — нельзя понизить/удалить/покинуть единственного admin семьи.
  if (text.includes('last_admin_protected')) {
    return 'Нельзя удалить или изменить роль единственного администратора семьи.'
  }

  if (text.includes('row-level security') || text.includes('policy')) {
    return 'Недостаточно прав для этого действия.'
  }

  // Прямые UPDATE (updateFamilyMemberRole/removeFamilyMember/renameFamily) —
  // RLS отфильтровала строку (участник/семья не ваши) → .single() бросает
  // PGRST116 вместо молчаливого no-op (тот же принцип, что в других фичах).
  if (code === 'PGRST116') {
    return 'Участник или семья не найдены, либо у вас нет прав на это действие.'
  }

  // Сетевые ошибки Supabase (fetch не смог достучаться) обычно не содержат
  // наш код в message — подстрахуемся тем же эвристическим правилом, что и authErrors.ts.
  if (text.includes('fetch') || text.includes('network')) {
    return 'Проблема с сетью. Проверьте подключение к интернету и попробуйте снова.'
  }

  return 'Не получилось выполнить действие. Попробуйте ещё раз чуть позже.'
}
