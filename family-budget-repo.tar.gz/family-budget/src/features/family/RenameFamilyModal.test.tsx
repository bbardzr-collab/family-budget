import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { ToastProvider } from '@/components/ui/Toast'
import { RenameFamilyModal } from './RenameFamilyModal'

const { mockMutateAsync } = vi.hoisted(() => ({ mockMutateAsync: vi.fn() }))

vi.mock('./hooks', () => ({
  useRenameFamily: () => ({ mutateAsync: mockMutateAsync, isPending: false }),
}))

function renderModal(props: Partial<{ open: boolean; onClose: () => void }> = {}) {
  return render(
    <ToastProvider>
      <RenameFamilyModal
        open={props.open ?? true}
        onClose={props.onClose ?? vi.fn()}
        familyId="fam-1"
        currentName="Семья Ивановых"
      />
    </ToastProvider>,
  )
}

describe('RenameFamilyModal (Этап 15, п.15)', () => {
  beforeEach(() => {
    mockMutateAsync.mockReset()
  })

  it('предзаполняет поле текущим названием семьи', () => {
    renderModal()
    expect(screen.getByLabelText('Название семьи')).toHaveValue('Семья Ивановых')
  })

  it('не даёт сохранить слишком короткое название и не вызывает мутацию', async () => {
    const user = userEvent.setup()
    renderModal()

    const input = screen.getByLabelText('Название семьи')
    await user.clear(input)
    await user.type(input, 'A')
    await user.click(screen.getByRole('button', { name: 'Сохранить' }))

    expect(await screen.findByText(/не короче 2 символов/i)).toBeInTheDocument()
    expect(mockMutateAsync).not.toHaveBeenCalled()
  })

  it('вызывает renameFamily с trim-нутым названием при успешной валидации', async () => {
    mockMutateAsync.mockResolvedValue(undefined)
    const onClose = vi.fn()
    const user = userEvent.setup()
    renderModal({ onClose })

    const input = screen.getByLabelText('Название семьи')
    await user.clear(input)
    await user.type(input, '  Семья Петровых  ')
    await user.click(screen.getByRole('button', { name: 'Сохранить' }))

    await waitFor(() => expect(mockMutateAsync).toHaveBeenCalledWith('Семья Петровых'))
    await waitFor(() => expect(onClose).toHaveBeenCalled())
  })

  it('показывает серверную ошибку и не закрывает модалку', async () => {
    mockMutateAsync.mockRejectedValue({ message: 'FORBIDDEN' })
    const onClose = vi.fn()
    const user = userEvent.setup()
    renderModal({ onClose })

    await user.click(screen.getByRole('button', { name: 'Сохранить' }))

    expect(await screen.findByText(/недостаточно прав/i)).toBeInTheDocument()
    expect(onClose).not.toHaveBeenCalled()
  })
})
