import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { ToastProvider } from '@/components/ui/Toast'
import { InviteMemberModal } from './InviteMemberModal'

const { mockMutateAsync } = vi.hoisted(() => ({ mockMutateAsync: vi.fn() }))

vi.mock('./hooks', () => ({
  useCreateInvitation: () => ({ mutateAsync: mockMutateAsync }),
}))

function renderModal(onClose = vi.fn()) {
  return render(
    <ToastProvider>
      <InviteMemberModal open onClose={onClose} familyId="fam-1" />
    </ToastProvider>,
  )
}

describe('InviteMemberModal', () => {
  beforeEach(() => {
    mockMutateAsync.mockReset()
    // jsdom не реализует execCommand — подстрахуем legacy-fallback копирования.
    document.execCommand = vi.fn().mockReturnValue(true)
  })

  it('предлагает выбрать роль только "Взрослый"/"Ребёнок" — без ADMIN (п.25)', () => {
    renderModal()
    const options = screen.getAllByRole('option').map((option) => option.textContent)
    expect(options).not.toContain('Администратор')
    expect(options.some((label) => label?.includes('Взрослый'))).toBe(true)
    expect(options.some((label) => label?.includes('Ребёнок'))).toBe(true)
  })

  it('создаёт приглашение и показывает ссылку с кнопкой копирования', async () => {
    mockMutateAsync.mockResolvedValue({
      id: 'inv-1',
      token: 'a'.repeat(64),
      role: 'child',
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      createdAt: new Date().toISOString(),
    })
    const user = userEvent.setup()
    renderModal()

    await user.selectOptions(screen.getByLabelText('Роль'), 'child')
    await user.click(screen.getByRole('button', { name: /создать приглашение/i }))

    expect(await screen.findByText(/приглашение создано/i)).toBeInTheDocument()
    expect(screen.getByText(new RegExp(`/invite/${'a'.repeat(64)}`))).toBeInTheDocument()
    expect(screen.getByRole('button', { name: /скопировать ссылку/i })).toBeInTheDocument()
    expect(mockMutateAsync).toHaveBeenCalledWith('child')
  })

  it('показывает понятную ошибку, если приглашающий не ADMIN', async () => {
    mockMutateAsync.mockRejectedValue({ message: 'FORBIDDEN' })
    const user = userEvent.setup()
    renderModal()

    await user.selectOptions(screen.getByLabelText('Роль'), 'adult')
    await user.click(screen.getByRole('button', { name: /создать приглашение/i }))

    await waitFor(() =>
      expect(screen.getByRole('alert')).toHaveTextContent('Недостаточно прав для этого действия.'),
    )
  })
})
