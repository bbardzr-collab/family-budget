/**
 * Роль участника семьи — человекочитаемое отображение (Этап 5, п.11).
 * Технические значения enum (admin/adult/child) пользователю не показываем.
 */

export type FamilyRole = 'admin' | 'adult' | 'child'

/** Роли, которые можно выдать через приглашение (ADMIN нельзя — п.25). */
export type InvitableRole = Extract<FamilyRole, 'adult' | 'child'>

const ROLE_LABELS: Record<FamilyRole, string> = {
  admin: 'Администратор',
  adult: 'Взрослый',
  child: 'Ребёнок',
}

export function roleLabel(role: string): string {
  return ROLE_LABELS[role as FamilyRole] ?? role
}

export const INVITABLE_ROLE_OPTIONS: Array<{ value: InvitableRole; label: string }> = [
  { value: 'adult', label: 'Взрослый' },
  { value: 'child', label: 'Ребёнок' },
]

const STATUS_LABELS: Record<string, string> = {
  active: 'Активен',
  inactive: 'Неактивен',
}

export function memberStatusLabel(status: string): string {
  return STATUS_LABELS[status] ?? status
}

const INVITATION_STATUS_LABELS: Record<string, string> = {
  pending: 'Ожидает',
  accepted: 'Принято',
  expired: 'Истекло',
  cancelled: 'Отменено',
}

export function invitationStatusLabel(status: string): string {
  return INVITATION_STATUS_LABELS[status] ?? status
}
