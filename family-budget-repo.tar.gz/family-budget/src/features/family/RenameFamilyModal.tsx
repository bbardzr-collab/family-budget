import { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { Button, Input, Modal } from '@/components/ui'
import { useToast } from '@/components/ui/Toast'
import { renameFamilySchema, type RenameFamilyFormValues } from './schemas'
import { useRenameFamily } from './hooks'
import { getFamilyErrorMessage } from './errors'

interface RenameFamilyModalProps {
  open: boolean
  onClose: () => void
  familyId: string
  currentName: string
}

/**
 * Переименование семьи (Этап 15, п.15) — только ADMIN, см. FamilyPage.tsx.
 *
 * formError НЕ сбрасывается внутри useEffect (react-hooks/set-state-in-effect
 * запрещает setState синхронно в теле эффекта, и здесь нет watch() из
 * react-hook-form, который снял бы эту проверку) — handleClose ниже уже
 * обнуляет formError на каждом закрытии (тот же приём, что в
 * GoalContributionFormModal.tsx/BudgetCategoryFormModal.tsx).
 */
export function RenameFamilyModal({ open, onClose, familyId, currentName }: RenameFamilyModalProps) {
  const { toast } = useToast()
  const renameFamily = useRenameFamily(familyId)
  const [formError, setFormError] = useState<string | null>(null)

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<RenameFamilyFormValues>({
    resolver: zodResolver(renameFamilySchema),
    defaultValues: { name: currentName },
  })

  useEffect(() => {
    if (open) {
      reset({ name: currentName })
    }
  }, [open, currentName, reset])

  function handleClose() {
    setFormError(null)
    onClose()
  }

  const onSubmit = handleSubmit(async (values) => {
    setFormError(null)
    try {
      await renameFamily.mutateAsync(values.name)
      toast({ type: 'success', title: 'Название семьи изменено' })
      onClose()
    } catch (error) {
      setFormError(getFamilyErrorMessage(error))
    }
  })

  return (
    <Modal open={open} onClose={handleClose} title="Переименовать семью">
      <form className="flex flex-col gap-4" onSubmit={onSubmit} noValidate>
        <Input
          label="Название семьи"
          placeholder="Семья Ивановых"
          autoComplete="off"
          error={errors.name?.message}
          {...register('name')}
        />

        {formError && (
          <p role="alert" className="text-sm text-destructive">
            {formError}
          </p>
        )}

        <Button type="submit" isLoading={isSubmitting} disabled={isSubmitting}>
          Сохранить
        </Button>
      </form>
    </Modal>
  )
}
