import { z } from 'zod'

/**
 * Название семьи (Этап 5, п.2; переиспользуется при переименовании — Этап 15,
 * п.15): обязательное, минимум 2 символа, разумный максимум, пробелы по
 * краям обрезаются (trim). Ровно те же правила, что проверяет сервер в
 * create_family() (FAMILY_NAME_TOO_SHORT/FAMILY_NAME_TOO_LONG, миграция
 * 0012) — клиентская валидация не расходится с серверной.
 */
const familyNameField = z
  .string()
  .trim()
  .min(2, 'Название семьи должно быть не короче 2 символов')
  .max(100, 'Название семьи слишком длинное — максимум 100 символов')

export const createFamilySchema = z.object({ name: familyNameField })
export type CreateFamilyFormValues = z.infer<typeof createFamilySchema>

/** Переименование семьи (Этап 15, п.15) — та же валидация, что и создание. */
export const renameFamilySchema = z.object({ name: familyNameField })
export type RenameFamilyFormValues = z.infer<typeof renameFamilySchema>

/** Роль приглашения — только adult/child, ADMIN недоступен (п.25). */
export const inviteMemberSchema = z.object({
  role: z.enum(['adult', 'child'], { message: 'Выберите роль' }),
})
export type InviteMemberFormValues = z.infer<typeof inviteMemberSchema>
