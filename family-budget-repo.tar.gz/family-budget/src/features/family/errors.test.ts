import { getFamilyErrorMessage } from './errors'

/**
 * Этап 15, п.12, 34, 36-37 — новые коды ошибок, которых не было на Этапе 5:
 * LAST_ADMIN_PROTECTED (триггер family_members_guard_admin_invariant,
 * миграция 0031) и PGRST116 (прямые UPDATE updateFamilyMemberRole/
 * removeFamilyMember/renameFamily, когда RLS отфильтровала строку — участник
 * или семья другой семьи, см. api.ts).
 */
describe('getFamilyErrorMessage (Этап 15)', () => {
  it('LAST_ADMIN_PROTECTED (текст после двоеточия, как бросает триггер) -> понятное сообщение', () => {
    const error = { message: 'LAST_ADMIN_PROTECTED: family 00000000-0000-0000-0000-000000000001 must always keep at least one active admin' }
    expect(getFamilyErrorMessage(error)).toBe('Нельзя удалить или изменить роль единственного администратора семьи.')
  })

  it('PGRST116 (RLS отфильтровала строку — участник/семья другой семьи) -> понятное сообщение, а не сырой код', () => {
    const error = { code: 'PGRST116', message: 'JSON object requested, multiple (or no) rows returned' }
    expect(getFamilyErrorMessage(error)).toBe('Участник или семья не найдены, либо у вас нет прав на это действие.')
  })

  it('ошибка RLS/policy по подстроке -> "недостаточно прав"', () => {
    const error = { message: 'new row violates row-level security policy for table "family_members"' }
    expect(getFamilyErrorMessage(error)).toBe('Недостаточно прав для этого действия.')
  })

  it('существующие RPC-коды Этапа 5 по-прежнему сопоставляются точно (регрессия)', () => {
    expect(getFamilyErrorMessage({ message: 'FORBIDDEN' })).toBe('Недостаточно прав для этого действия.')
    expect(getFamilyErrorMessage({ message: 'NO_FAMILY' })).toBe('У вас пока нет семьи.')
  })

  it('неизвестная ошибка -> общий понятный fallback, а не technical-текст', () => {
    expect(getFamilyErrorMessage({ message: 'something_unexpected' })).toBe(
      'Не получилось выполнить действие. Попробуйте ещё раз чуть позже.',
    )
  })

  it('сетевая ошибка (TypeError) -> сообщение про сеть', () => {
    expect(getFamilyErrorMessage(new TypeError('Failed to fetch'))).toBe(
      'Проблема с сетью. Проверьте подключение к интернету и попробуйте снова.',
    )
  })
})
