import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Button, Modal, Text } from '@/components/ui'
import { useToast } from '@/components/ui/Toast'
import { useLeaveFamily } from './hooks'
import { getFamilyErrorMessage } from './errors'

interface LeaveFamilyModalProps {
  open: boolean
  onClose: () => void
  /** Только для текста подсказки — реальная защита всегда на сервере (Этап 15, п.12, 14). */
  isSoleAdmin: boolean
}

/**
 * Подтверждение самостоятельного выхода из семьи (Этап 15, п.14). Единственный
 * admin не может покинуть семью — сервер (leave_family(), миграция 0031)
 * отклонит это с LAST_ADMIN_PROTECTED; isSoleAdmin здесь используется только
 * чтобы заранее по-человечески объяснить это в интерфейсе, а не как граница
 * безопасности (та же оговорка, что и во всём остальном UI этого этапа).
 */
export function LeaveFamilyModal({ open, onClose, isSoleAdmin }: LeaveFamilyModalProps) {
  const { toast } = useToast()
  const navigate = useNavigate()
  const leaveFamily = useLeaveFamily()
  const [error, setError] = useState<string | null>(null)

  async function handleConfirm() {
    setError(null)
    try {
      await leaveFamily.mutateAsync()
      toast({ type: 'success', title: 'Вы покинули семью' })
      onClose()
      navigate('/app/family', { replace: true })
    } catch (err) {
      setError(getFamilyErrorMessage(err))
    }
  }

  function handleClose() {
    setError(null)
    onClose()
  }

  return (
    <Modal
      open={open}
      onClose={handleClose}
      title="Покинуть семью?"
      footer={
        <>
          <Button variant="outline" onClick={handleClose}>
            Отмена
          </Button>
          <Button
            variant="destructive"
            onClick={() => void handleConfirm()}
            isLoading={leaveFamily.isPending}
            disabled={leaveFamily.isPending || isSoleAdmin}
          >
            Покинуть семью
          </Button>
        </>
      }
    >
      {isSoleAdmin ? (
        <Text variant="secondary">
          Вы — единственный администратор семьи, поэтому не можете её покинуть: в семье всегда должен оставаться
          хотя бы один администратор.
        </Text>
      ) : (
        <Text variant="secondary">
          Вы уверены, что хотите покинуть семью? Доступ к её операциям, бюджету и целям будет закрыт. Ваши личные
          данные (аккаунт) не будут удалены.
        </Text>
      )}
      {error && (
        <p role="alert" className="mt-3 text-sm text-destructive">
          {error}
        </p>
      )}
    </Modal>
  )
}
