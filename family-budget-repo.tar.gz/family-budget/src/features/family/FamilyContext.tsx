import { createContext, useContext, useMemo, type ReactNode } from 'react'
import type { FamilyRow, FamilyMemberRow } from './api'
import type { FamilyRole } from './roles'
import { useMyMembership } from './hooks'

/**
 * Текущий семейный контекст пользователя (Этап 5, п.9).
 *
 * В версии 1.0 пользователь состоит максимум в одной активной семье, поэтому
 * никакого family switcher нет — currentFamily однозначно определяется
 * активным членством. Server state целиком живёт в TanStack Query
 * (useMyMembership, см. hooks.ts) — этот контекст не копирует данные в
 * собственный useState, а только добавляет производные поля (role/isAdmin/…),
 * как и требует ТЗ (п.34: "React Context — для текущего контекста и derived state").
 */
interface FamilyContextValue {
  currentFamily: FamilyRow | null
  currentMembership: FamilyMemberRow | null
  role: FamilyRole | null
  isAdmin: boolean
  isAdult: boolean
  isChild: boolean
  loading: boolean
  hasFamily: boolean
  refetch: () => void
}

const FamilyContext = createContext<FamilyContextValue | undefined>(undefined)

export function FamilyProvider({ children }: { children: ReactNode }) {
  const { data, isLoading, isFetching, refetch } = useMyMembership()

  const value = useMemo<FamilyContextValue>(() => {
    const currentMembership = data ?? null
    const currentFamily = data?.family ?? null
    const role = (currentMembership?.role as FamilyRole | undefined) ?? null

    return {
      currentFamily,
      currentMembership,
      role,
      isAdmin: role === 'admin',
      isAdult: role === 'adult',
      isChild: role === 'child',
      // isLoading — только самая первая загрузка; повторные фоновые
      // refetch (isFetching) не должны заново показывать LoadingState на
      // весь экран (тот же принцип, что и в AuthContext на Этапе 4).
      loading: isLoading,
      hasFamily: Boolean(currentFamily),
      refetch: () => void refetch(),
    }
  }, [data, isLoading, refetch])

  // isFetching намеренно не влияет на value.loading — избегаем мигания
  // экрана при фоновых обновлениях после mutation (создание/принятие приглашения).
  void isFetching

  return <FamilyContext.Provider value={value}>{children}</FamilyContext.Provider>
}

export function useFamily(): FamilyContextValue {
  const context = useContext(FamilyContext)
  if (!context) {
    throw new Error('useFamily должен использоваться внутри <FamilyProvider>')
  }
  return context
}
