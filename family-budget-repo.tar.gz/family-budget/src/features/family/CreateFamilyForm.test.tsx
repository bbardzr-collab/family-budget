import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { ToastProvider } from '@/components/ui/Toast'
import { CreateFamilyForm } from './CreateFamilyForm'

const { mockMutateAsync } = vi.hoisted(() => ({ mockMutateAsync: vi.fn() }))

vi.mock('./hooks', () => ({
  useCreateFamily: () => ({ mutateAsync: mockMutateAsync }),
}))

function renderForm(onCreated?: () => void) {
  return render(
    <ToastProvider>
      <CreateFamilyForm onCreated={onCreated} />
    </ToastProvider>,
  )
}

describe('CreateFamilyForm', () => {
  beforeEach(() => {
    mockMutateAsync.mockReset()
  })

  it('показывает ошибку валидации при слишком коротком названии и не вызывает createFamily', async () => {
    const user = userEvent.setup()
    renderForm()

    await user.type(screen.getByLabelText('Название семьи'), 'A')
    await user.click(screen.getByRole('button', { name: /создать семью/i }))

    expect(await screen.findByText(/не короче 2 символов/i)).toBeInTheDocument()
    expect(mockMutateAsync).not.toHaveBeenCalled()
  })

  it('не отправляет форму с пустым названием (обязательное поле)', async () => {
    const user = userEvent.setup()
    renderForm()

    await user.click(screen.getByRole('button', { name: /создать семью/i }))

    expect(await screen.findByText(/не короче 2 символов/i)).toBeInTheDocument()
    expect(mockMutateAsync).not.toHaveBeenCalled()
  })

  it('вызывает createFamily с trim-нутым названием и onCreated при успехе', async () => {
    mockMutateAsync.mockResolvedValue('11111111-1111-1111-1111-111111111111')
    const onCreated = vi.fn()
    const user = userEvent.setup()
    renderForm(onCreated)

    await user.type(screen.getByLabelText('Название семьи'), '  Семья Ивановых  ')
    await user.click(screen.getByRole('button', { name: /создать семью/i }))

    await waitFor(() => expect(mockMutateAsync).toHaveBeenCalledWith('Семья Ивановых'))
    expect(onCreated).toHaveBeenCalled()
  })

  it('показывает ошибку сервера, если пользователь уже состоит в семье', async () => {
    mockMutateAsync.mockRejectedValue({ message: 'FAMILY_ALREADY_EXISTS' })
    const user = userEvent.setup()
    renderForm()

    await user.type(screen.getByLabelText('Название семьи'), 'Вторая семья')
    await user.click(screen.getByRole('button', { name: /создать семью/i }))

    expect(await screen.findByText(/уже состоите в семье/i)).toBeInTheDocument()
  })
})
