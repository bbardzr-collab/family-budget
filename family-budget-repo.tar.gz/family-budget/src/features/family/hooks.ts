import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useAuth } from '@/features/auth/AuthContext'
import type { FamilyRole, InvitableRole } from './roles'
import { familyKeys } from './queryKeys'
import {
  acceptFamilyInvitation,
  cancelFamilyInvitation,
  createFamily,
  createFamilyInvitation,
  fetchFamilyInvitations,
  fetchFamilyMembers,
  fetchFamilySettings,
  fetchMyMembership,
  getInvitationByToken,
  leaveFamily,
  removeFamilyMember,
  renameFamily,
  updateFamilyMemberRole,
} from './api'

/**
 * Server state — через TanStack Query (ТЗ, п.34). React Context (см.
 * FamilyContext.tsx) использует только этот хук и не хранит копию данных
 * в своём состоянии — он лишь добавляет производные поля (role/isAdmin/...).
 */
export function useMyMembership() {
  const { user, isAuthenticated } = useAuth()
  return useQuery({
    queryKey: familyKeys.membership(user?.id),
    queryFn: () => fetchMyMembership(user!.id),
    enabled: isAuthenticated && Boolean(user?.id),
  })
}

export function useFamilyMembers(familyId: string | undefined) {
  return useQuery({
    queryKey: familyKeys.members(familyId),
    queryFn: () => fetchFamilyMembers(familyId!),
    enabled: Boolean(familyId),
  })
}

/** Вызывать только когда isAdmin=true — у остальных ролей список всё равно пуст (RLS). */
export function useFamilyInvitations(familyId: string | undefined, isAdmin: boolean) {
  return useQuery({
    queryKey: familyKeys.invitations(familyId),
    queryFn: () => fetchFamilyInvitations(familyId!),
    enabled: Boolean(familyId) && isAdmin,
  })
}

export function useFamilySettings(familyId: string | undefined) {
  return useQuery({
    queryKey: familyKeys.settings(familyId),
    queryFn: () => fetchFamilySettings(familyId!),
    enabled: Boolean(familyId),
  })
}

export function useInvitationPreview(token: string | undefined) {
  return useQuery({
    queryKey: familyKeys.invitationPreview(token),
    queryFn: () => getInvitationByToken(token!),
    enabled: Boolean(token),
    retry: false,
  })
}

export function useCreateFamily() {
  const queryClient = useQueryClient()
  const { user } = useAuth()
  return useMutation({
    mutationFn: (name: string) => createFamily(name),
    onSuccess: () => {
      // Инвалидация вместо ручного refresh страницы (п.35).
      void queryClient.invalidateQueries({ queryKey: familyKeys.membership(user?.id) })
    },
  })
}

export function useCreateInvitation(familyId: string | undefined) {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (role: InvitableRole) => createFamilyInvitation(role),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: familyKeys.invitations(familyId) })
    },
  })
}

export function useCancelInvitation(familyId: string | undefined) {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (invitationId: string) => cancelFamilyInvitation(invitationId),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: familyKeys.invitations(familyId) })
    },
  })
}

export function useAcceptInvitation() {
  const queryClient = useQueryClient()
  const { user } = useAuth()
  return useMutation({
    mutationFn: (token: string) => acceptFamilyInvitation(token),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: familyKeys.membership(user?.id) })
    },
  })
}

/** Смена роли участника (adult <-> child), Этап 15, п.11, 28. */
export function useUpdateMemberRole(familyId: string | undefined) {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: ({ memberId, role }: { memberId: string; role: FamilyRole }) => updateFamilyMemberRole(memberId, role),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: familyKeys.members(familyId) })
    },
  })
}

/** "Удаление" участника ADMIN'ом (soft, status -> inactive), Этап 15, п.13, 28. */
export function useRemoveMember(familyId: string | undefined) {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (memberId: string) => removeFamilyMember(memberId),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: familyKeys.members(familyId) })
    },
  })
}

/**
 * Самостоятельный выход из семьи (Этап 15, п.14, 28). Инвалидирует именно
 * membership(userId) — это то, что читает FamilyContext, поэтому после
 * успешного выхода приложение сразу переключается в состояние "нет семьи"
 * без перезагрузки страницы (тот же принцип, что useAcceptInvitation выше).
 */
export function useLeaveFamily() {
  const queryClient = useQueryClient()
  const { user } = useAuth()
  return useMutation({
    mutationFn: () => leaveFamily(),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: familyKeys.membership(user?.id) })
    },
  })
}

/**
 * Переименование семьи (Этап 15, п.15, 28). Инвалидирует membership(userId) —
 * fetchMyMembership вкладывает `family:families(*)`, поэтому FamilyContext
 * (заголовок Dashboard и других разделов) получает новое имя без
 * перезагрузки страницы, тем же путём, что и остальные семейные мутации.
 */
export function useRenameFamily(familyId: string | undefined) {
  const queryClient = useQueryClient()
  const { user } = useAuth()
  return useMutation({
    mutationFn: (name: string) => renameFamily(familyId!, name),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: familyKeys.membership(user?.id) })
    },
  })
}
