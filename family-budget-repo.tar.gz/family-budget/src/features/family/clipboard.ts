/**
 * Копирование ссылки-приглашения в буфer обмена (Этап 5, п.17).
 * `navigator.clipboard` доступен не везде (требует secure context, может
 * быть запрещён политикой браузера) — на этот случай пробуем legacy
 * fallback через скрытый textarea + document.execCommand('copy').
 * Возвращает false, если не получилось ни одним способом — вызывающий код
 * сам решает, как сообщить об этом пользователю (Toast).
 */
export async function copyToClipboard(text: string): Promise<boolean> {
  if (navigator.clipboard?.writeText && window.isSecureContext) {
    try {
      await navigator.clipboard.writeText(text)
      return true
    } catch {
      // падаем в fallback ниже
    }
  }

  try {
    const textarea = document.createElement('textarea')
    textarea.value = text
    textarea.setAttribute('readonly', '')
    textarea.style.position = 'fixed'
    textarea.style.opacity = '0'
    textarea.style.pointerEvents = 'none'
    document.body.appendChild(textarea)
    textarea.focus()
    textarea.select()
    const successful = document.execCommand('copy')
    document.body.removeChild(textarea)
    return successful
  } catch {
    return false
  }
}
