import { invitationStatusLabel, memberStatusLabel, roleLabel } from './roles'

describe('roleLabel', () => {
  it('переводит технические роли в человекочитаемые значения (Этап 5, п.11)', () => {
    expect(roleLabel('admin')).toBe('Администратор')
    expect(roleLabel('adult')).toBe('Взрослый')
    expect(roleLabel('child')).toBe('Ребёнок')
  })

  it('возвращает исходное значение для неизвестной роли, а не падает', () => {
    expect(roleLabel('unknown')).toBe('unknown')
  })
})

describe('memberStatusLabel', () => {
  it('переводит статус участника', () => {
    expect(memberStatusLabel('active')).toBe('Активен')
    expect(memberStatusLabel('inactive')).toBe('Неактивен')
  })
})

describe('invitationStatusLabel', () => {
  it('переводит статус приглашения', () => {
    expect(invitationStatusLabel('pending')).toBe('Ожидает')
    expect(invitationStatusLabel('accepted')).toBe('Принято')
    expect(invitationStatusLabel('expired')).toBe('Истекло')
    expect(invitationStatusLabel('cancelled')).toBe('Отменено')
  })
})
