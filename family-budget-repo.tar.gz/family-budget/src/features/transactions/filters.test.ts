import {
  CATEGORY_FILTER_ALL,
  CATEGORY_FILTER_NONE,
  DEFAULT_FILTERS,
  isDefaultFilters,
  resolveDateRange,
  toQueryFilters,
  type TransactionFilters,
} from './filters'

function filters(overrides: Partial<TransactionFilters> = {}): TransactionFilters {
  return { ...DEFAULT_FILTERS, ...overrides }
}

describe('resolveDateRange (Этап 9, п.3, 26)', () => {
  // "Сейчас" зафиксировано в среду, 16 сентября 2026 — удобная середина
  // месяца и недели для проверки границ во все стороны.
  const NOW = new Date(2026, 8, 16, 15, 30) // 16.09.2026 15:30 местного времени

  it('"Сегодня" — от и до равны текущей календарной дате', () => {
    expect(resolveDateRange({ period: 'today', customFrom: '', customTo: '' }, NOW)).toEqual({
      from: '2026-09-16',
      to: '2026-09-16',
    })
  })

  it('"Эта неделя" — понедельник-воскресенье (ru-локаль, неделя с понедельника)', () => {
    // 16.09.2026 — среда → неделя 14.09 (пн) – 20.09 (вс).
    expect(resolveDateRange({ period: 'week', customFrom: '', customTo: '' }, NOW)).toEqual({
      from: '2026-09-14',
      to: '2026-09-20',
    })
  })

  it('"Этот месяц" — 1-е число до последнего дня месяца', () => {
    expect(resolveDateRange({ period: 'month', customFrom: '', customTo: '' }, NOW)).toEqual({
      from: '2026-09-01',
      to: '2026-09-30',
    })
  })

  it('"Прошлый месяц" — корректный переход через границу месяца', () => {
    expect(resolveDateRange({ period: 'lastMonth', customFrom: '', customTo: '' }, NOW)).toEqual({
      from: '2026-08-01',
      to: '2026-08-31',
    })
  })

  it('"Прошлый месяц" — корректный переход через границу ГОДА (январь → декабрь прошлого года)', () => {
    const januaryNow = new Date(2026, 0, 15) // 15.01.2026
    expect(resolveDateRange({ period: 'lastMonth', customFrom: '', customTo: '' }, januaryNow)).toEqual({
      from: '2025-12-01',
      to: '2025-12-31',
    })
  })

  it('"Этот год" — 1 января до 31 декабря', () => {
    expect(resolveDateRange({ period: 'year', customFrom: '', customTo: '' }, NOW)).toEqual({
      from: '2026-01-01',
      to: '2026-12-31',
    })
  })

  it('"Произвольный период" — использует ровно указанные даты', () => {
    expect(
      resolveDateRange({ period: 'custom', customFrom: '2026-09-01', customTo: '2026-09-15' }, NOW),
    ).toEqual({ from: '2026-09-01', to: '2026-09-15' })
  })

  it('"Произвольный период" без выбранных границ — безопасный дефолт, а не null/пустая строка', () => {
    const range = resolveDateRange({ period: 'custom', customFrom: '', customTo: '' }, NOW)
    expect(range.from).toBe('2026-09-01')
    expect(range.to).toBe('2026-09-16')
  })
})

describe('toQueryFilters (Этап 9, п.4, 16)', () => {
  const NOW = new Date(2026, 8, 16)

  it('type="all" передаётся как есть', () => {
    expect(toQueryFilters(filters({ type: 'all' }), NOW).type).toBe('all')
  })

  it('categoryId="all" → categoryMode="all", categoryId=null', () => {
    const result = toQueryFilters(filters({ type: 'expense', categoryId: CATEGORY_FILTER_ALL }), NOW)
    expect(result.categoryMode).toBe('all')
    expect(result.categoryId).toBeNull()
  })

  it('categoryId="none" → categoryMode="none", categoryId=null (это "Без категории", а не отсутствие фильтра)', () => {
    const result = toQueryFilters(filters({ type: 'expense', categoryId: CATEGORY_FILTER_NONE }), NOW)
    expect(result.categoryMode).toBe('none')
    expect(result.categoryId).toBeNull()
  })

  it('конкретный id категории → categoryMode="specific" с этим id', () => {
    const result = toQueryFilters(filters({ type: 'expense', categoryId: 'cat-42' }), NOW)
    expect(result.categoryMode).toBe('specific')
    expect(result.categoryId).toBe('cat-42')
  })

  it('доход: категория ВСЕГДА игнорируется, даже если в фильтре осталось конкретное значение (ТЗ, п.4)', () => {
    const result = toQueryFilters(filters({ type: 'income', categoryId: 'cat-42' }), NOW)
    expect(result.categoryMode).toBe('all')
    expect(result.categoryId).toBeNull()
  })

  it('поиск обрезается (trim)', () => {
    expect(toQueryFilters(filters({ search: '  кафе  ' }), NOW).search).toBe('кафе')
  })

  it('сортировка передаётся как есть', () => {
    expect(toQueryFilters(filters({ sort: 'date_asc' }), NOW).sort).toBe('date_asc')
  })
})

describe('isDefaultFilters (ТЗ, п.18)', () => {
  it('дефолтные фильтры считаются дефолтными', () => {
    expect(isDefaultFilters(DEFAULT_FILTERS)).toBe(true)
  })

  it('изменённый тип — уже не дефолт', () => {
    expect(isDefaultFilters(filters({ type: 'expense' }))).toBe(false)
  })

  it('изменённый период — уже не дефолт', () => {
    expect(isDefaultFilters(filters({ period: 'today' }))).toBe(false)
  })

  it('изменённая категория — уже не дефолт', () => {
    expect(isDefaultFilters(filters({ categoryId: 'cat-1' }))).toBe(false)
  })

  it('непустой поиск (даже из одних пробелов после trim пустой) — не считается изменением', () => {
    expect(isDefaultFilters(filters({ search: '   ' }))).toBe(true)
    expect(isDefaultFilters(filters({ search: 'кафе' }))).toBe(false)
  })

  it('изменённая сортировка — уже не дефолт', () => {
    expect(isDefaultFilters(filters({ sort: 'date_asc' }))).toBe(false)
  })
})
