import { supabase } from '@/lib/supabase'
import type { Tables } from '@/types/database'
import type { TransactionType } from './schemas'
import type { TransactionQueryFilters } from './filters'

/**
 * Тонкий слой доступа к данным операций (Этап 7, п.17, 21) — только
 * запросы, никакой бизнес-логики и никакого React, по аналогии с
 * features/family/api.ts и features/dashboard/api.ts.
 *
 * ─── Архитектурное решение по INSERT/UPDATE/DELETE (ТЗ, п.8-9) ───
 * В отличие от Этапа 5 (create_family, create_family_invitation, ...),
 * здесь НЕТ новых SECURITY DEFINER RPC — операции идут напрямую через
 * Supabase поверх уже существующих RLS-политик (supabase/migrations/0010,
 * transactions_insert_own / transactions_update_own_or_admin /
 * transactions_delete_own_or_admin). Это осознанный выбор, а не пропуск:
 *
 *  - transactions_insert_own: `with check (is_family_member(family_id) and
 *    user_id = auth.uid())`. family_id и user_id ПРИХОДЯТ с клиента (см.
 *    createTransaction ниже), но это структурно безопасно: Postgres
 *    отклонит INSERT, если user_id клиента не равен auth.uid() сервера —
 *    подделать чужой user_id невозможно вне зависимости от того, что
 *    отправит клиент. Точно так же family_id может быть только семьёй, в
 *    которой auth.uid() — активный участник (is_family_member), иначе
 *    INSERT отклоняется. Гарантию даёт RLS на сервере, а не доверие к
 *    значению от клиента.
 *  - transactions_update_own_or_admin / transactions_delete_own_or_admin:
 *    `using (user_id = auth.uid() or is_family_admin(family_id))` — сама
 *    видимость строки для UPDATE/DELETE уже ограничена Postgres. updateTransaction
 *    ниже никогда не передаёт family_id/user_id в теле UPDATE (нельзя
 *    сменить владельца операции через редактирование) — меняются только
 *    прикладные поля (type/amount/date/income_source/comment).
 *
 * category_id (Этап 8, п.16, 18): теперь передаётся при создании/изменении
 * расхода — nullable, "без категории" остаётся полноценным валидным
 * состоянием, а не временной заглушкой Этапа 7.
 */

export type TransactionRow = Tables<'transactions'>

export interface TransactionCategory {
  id: string
  name: string
  icon: string | null
  isActive: boolean
}

export interface TransactionListItem {
  id: string
  type: TransactionType
  amount: number
  transactionDate: string
  incomeSource: string | null
  comment: string | null
  userId: string
  /** Имя автора операции (Этап 9, п.9) — null, если профиль почему-то недоступен. */
  createdByName: string | null
  categoryId: string | null
  category: TransactionCategory | null
}

interface TransactionQueryRow {
  id: string
  type: string
  amount: number
  transaction_date: string
  income_source: string | null
  comment: string | null
  user_id: string
  user: { id: string; full_name: string | null } | null
  category_id: string | null
  category: { id: string; name: string; icon: string | null; is_active: boolean } | null
}

function mapRow(row: TransactionQueryRow): TransactionListItem {
  return {
    id: row.id,
    type: row.type as TransactionType,
    amount: row.amount,
    transactionDate: row.transaction_date,
    incomeSource: row.income_source,
    comment: row.comment,
    userId: row.user_id,
    createdByName: row.user?.full_name ?? null,
    categoryId: row.category_id,
    category: row.category
      ? { id: row.category.id, name: row.category.name, icon: row.category.icon, isActive: row.category.is_active }
      : null,
  }
}

// Категория и автор встраиваются тем же способом, что и профиль участника в
// features/family/api.ts::fetchFamilyMembers (`profile:users(...)`) — один
// запрос вместо отдельного N+1 fetch на каждую операцию списка (ТЗ, п.24).
const SELECT_FIELDS =
  'id, type, amount, transaction_date, income_source, comment, user_id, user:users(id, full_name), category_id, category:categories(id, name, icon, is_active)'

/**
 * Полный список операций семьи для страницы /app/transactions (в отличие
 * от dashboard/api.ts::fetchRecentTransactions — без лимита, с
 * income_source/user_id/категорией, нужными для отображения и для прав на
 * редактирование/удаление конкретной строки в UI).
 */
export async function fetchTransactions(familyId: string): Promise<TransactionListItem[]> {
  const { data, error } = await supabase
    .from('transactions')
    .select(SELECT_FIELDS)
    .eq('family_id', familyId)
    .order('transaction_date', { ascending: false })
    .order('created_at', { ascending: false })

  if (error) throw error
  return ((data ?? []) as unknown as TransactionQueryRow[]).map(mapRow)
}

export interface CreateTransactionInput {
  familyId: string
  userId: string
  type: TransactionType
  /** Нормализованная строка с ровно 2 знаками после точки, см. schemas.ts. */
  amount: string
  transactionDate: string
  incomeSource: string | null
  comment: string | null
  /** Значимо только для расхода — для дохода всегда null (Этап 8, п.1, 16). */
  categoryId: string | null
}

export async function createTransaction(input: CreateTransactionInput): Promise<TransactionListItem> {
  const { data, error } = await supabase
    .from('transactions')
    .insert({
      family_id: input.familyId,
      user_id: input.userId,
      type: input.type,
      // Сгенерированный тип столбца — number (numeric маппится в number), но
      // мы намеренно передаём уже нормализованную строку "1234.50" как есть —
      // PostgREST/Postgres сами приведут text → numeric(14,2) без прохода
      // через двоичный float на нашей стороне. Единственный чистый Number(...)
      // в этом файле (только для типов, не для вычислений) — см. комментарий выше.
      amount: input.amount as unknown as number,
      transaction_date: input.transactionDate,
      income_source: input.incomeSource,
      comment: input.comment,
      category_id: input.categoryId,
    })
    .select(SELECT_FIELDS)
    .single()

  if (error) throw error
  return mapRow(data as unknown as TransactionQueryRow)
}

export interface UpdateTransactionInput {
  id: string
  type: TransactionType
  amount: string
  transactionDate: string
  incomeSource: string | null
  comment: string | null
  categoryId: string | null
}

export async function updateTransaction(input: UpdateTransactionInput): Promise<TransactionListItem> {
  const { data, error } = await supabase
    .from('transactions')
    .update({
      type: input.type,
      amount: input.amount as unknown as number,
      transaction_date: input.transactionDate,
      income_source: input.incomeSource,
      comment: input.comment,
      category_id: input.categoryId,
      // family_id/user_id здесь намеренно отсутствуют — см. комментарий в
      // начале файла: редактирование не может сменить владельца/семью операции.
    })
    .eq('id', input.id)
    .select(SELECT_FIELDS)
    .single()

  if (error) throw error
  return mapRow(data as unknown as TransactionQueryRow)
}

/**
 * DELETE защищён только RLS (transactions_delete_own_or_admin) — как и в
 * fetchRecentTransactions, дополнительный .eq('family_id', ...) здесь не
 * нужен: id уже уникален, а фактическую защиту от чужих данных обеспечивает
 * RLS, а не фильтр на клиенте.
 */
export async function deleteTransaction(id: string): Promise<void> {
  const { error, count } = await supabase
    .from('transactions')
    .delete({ count: 'exact' })
    .eq('id', id)

  if (error) throw error
  // RLS тихо отфильтровывает недоступные строки — DELETE от чужой операции
  // не вернёт ошибку, а просто не затронет ни одной строки. Без этой проверки
  // UI показал бы "успех" там, где на самом деле ничего не удалилось.
  if (!count) {
    throw { message: 'Операция не найдена или у вас нет прав её удалить.', code: 'PGRST116' }
  }
}

/**
 * Есть ли у семьи хоть одна операция (без учёта фильтров) — используется
 * только чтобы различить два разных пустых состояния /app/transactions
 * (ТЗ, п.22): "операций нет вообще" (family.transactions.count === 0) и
 * "по фильтрам ничего не найдено" (пустая ТЕКУЩАЯ, отфильтрованная выборка).
 * head:true — считает строки, не скачивая их (ТЗ, п.24).
 */
export async function fetchHasAnyTransaction(familyId: string): Promise<boolean> {
  const { count, error } = await supabase
    .from('transactions')
    .select('id', { count: 'exact', head: true })
    .eq('family_id', familyId)

  if (error) throw error
  return (count ?? 0) > 0
}

// ─────────────────────── Фильтрованный/постраничный журнал (Этап 9) ───────────────────────
//
// В отличие от fetchTransactions() выше (полный список без фильтров, лимитов
// и постраничности — используется только там, где он уже применялся раньше),
// список /app/transactions теперь идёт через SQL-функции get_transactions_page
// / get_transactions_totals (миграция 0019). Причина — не архитектурная
// прихоть, а два требования ТЗ, которые PostgREST-запрос не решает без
// !inner-джойна, ломающего сам смысл LEFT JOIN (см. комментарий в миграции):
// поиск одновременно по comment/income_source И по названию категории, и
// агрегированные итоги ПОЛНОЙ отфильтрованной выборки (не только одной
// загруженной страницы).

export interface TransactionListPage {
  items: TransactionListItem[]
  hasMore: boolean
}

interface TransactionsPageRow {
  id: string
  type: string
  amount: number
  transaction_date: string
  income_source: string | null
  comment: string | null
  user_id: string
  user_full_name: string | null
  category_id: string | null
  category_name: string | null
  category_icon: string | null
  category_is_active: boolean | null
  created_at: string
}

function mapPageRow(row: TransactionsPageRow): TransactionListItem {
  return {
    id: row.id,
    type: row.type as TransactionType,
    amount: row.amount,
    transactionDate: row.transaction_date,
    incomeSource: row.income_source,
    comment: row.comment,
    userId: row.user_id,
    createdByName: row.user_full_name,
    categoryId: row.category_id,
    category: row.category_id
      ? {
          id: row.category_id,
          name: row.category_name ?? '',
          icon: row.category_icon,
          isActive: row.category_is_active ?? true,
        }
      : null,
  }
}

/**
 * Одна страница отфильтрованного журнала операций (ТЗ, п.2-8, 13-14).
 *
 * hasMore определяется без отдельного COUNT-запроса: запрашивается на одну
 * строку больше лимита (limit + 1); если строк вернулось больше limit —
 * значит, есть следующая страница, и лишняя строка отбрасывается на клиенте.
 * Дешевле, чем `{count:'exact'}` на каждый запрос страницы.
 */
export async function fetchTransactionsPage(
  filters: TransactionQueryFilters,
  limit: number,
  offset: number,
): Promise<TransactionListPage> {
  const { data, error } = await supabase.rpc('get_transactions_page', {
    p_type: filters.type,
    p_date_from: filters.dateFrom,
    p_date_to: filters.dateTo,
    p_category_mode: filters.categoryMode,
    p_category_id: filters.categoryId ?? undefined,
    p_search: filters.search || undefined,
    p_sort: filters.sort,
    p_limit: limit + 1,
    p_offset: offset,
  })

  if (error) throw error
  const rows = (data ?? []) as TransactionsPageRow[]
  const hasMore = rows.length > limit
  return { items: rows.slice(0, limit).map(mapPageRow), hasMore }
}

export interface TransactionsTotals {
  income: number
  expenses: number
  balance: number
}

/**
 * Итоги ТЕКУЩЕЙ отфильтрованной выборки (ТЗ, п.12) — НЕ то же самое, что
 * Dashboard "за текущий месяц" (features/dashboard/api.ts::fetchDashboardSummary):
 * период и остальные фильтры здесь произвольные, задаются на этой странице.
 */
export async function fetchTransactionsTotals(filters: TransactionQueryFilters): Promise<TransactionsTotals> {
  const { data, error } = await supabase.rpc('get_transactions_totals', {
    p_type: filters.type,
    p_date_from: filters.dateFrom,
    p_date_to: filters.dateTo,
    p_category_mode: filters.categoryMode,
    p_category_id: filters.categoryId ?? undefined,
    p_search: filters.search || undefined,
  })

  if (error) throw error
  const row = data?.[0]
  return { income: row?.income ?? 0, expenses: row?.expenses ?? 0, balance: row?.balance ?? 0 }
}
