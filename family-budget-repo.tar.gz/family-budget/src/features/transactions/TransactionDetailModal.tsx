import { createElement, type ReactNode } from 'react'
import { Pencil, Trash2 } from 'lucide-react'
import { Amount, Button, Modal, Text } from '@/components/ui'
import { getCategoryIcon } from '@/features/categories/iconMap'
import { formatDate } from '@/utils/formatDate'
import type { TransactionListItem } from './api'

interface TransactionDetailModalProps {
  transaction: TransactionListItem | null
  onClose: () => void
  onEdit: () => void
  onDelete: () => void
}

function DetailRow({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-4 py-2.5">
      <span className="text-sm text-muted-foreground">{label}</span>
      <span className="text-right text-sm font-medium text-foreground">{children}</span>
    </div>
  )
}

/**
 * Подробности операции (ТЗ, п.9) — единственная точка входа для просмотра
 * операции целиком (клик по строке в списке). Отдельной страницы операции
 * нет, как и требует ТЗ ("не создавай отдельную страницу").
 */
export function TransactionDetailModal({ transaction, onClose, onEdit, onDelete }: TransactionDetailModalProps) {
  if (!transaction) return null
  const isIncome = transaction.type === 'income'

  return (
    <Modal
      open={Boolean(transaction)}
      onClose={onClose}
      title={isIncome ? 'Доход' : 'Расход'}
      footer={
        <>
          <Button variant="outline" onClick={onClose}>
            Закрыть
          </Button>
          <Button variant="destructive" onClick={onDelete}>
            <Trash2 className="size-4" aria-hidden="true" />
            Удалить
          </Button>
          <Button variant="primary" onClick={onEdit}>
            <Pencil className="size-4" aria-hidden="true" />
            Редактировать
          </Button>
        </>
      }
    >
      <div className="flex flex-col divide-y divide-border">
        <div className="flex items-center justify-between gap-4 pb-3">
          <Text variant="secondary">Сумма</Text>
          <Amount value={isIncome ? transaction.amount : -transaction.amount} size="lg" tone="auto" showSign />
        </div>

        <DetailRow label="Дата">{formatDate(transaction.transactionDate)}</DetailRow>

        {!isIncome && (
          <DetailRow label="Категория">
            <span className="inline-flex items-center gap-1.5">
              {createElement(getCategoryIcon(transaction.category?.icon), { className: 'size-3.5', 'aria-hidden': true })}
              {transaction.category
                ? `${transaction.category.name}${transaction.category.isActive ? '' : ' (выключена)'}`
                : 'Без категории'}
            </span>
          </DetailRow>
        )}

        {isIncome && <DetailRow label="Источник дохода">{transaction.incomeSource ?? '—'}</DetailRow>}

        <DetailRow label="Комментарий">{transaction.comment ?? '—'}</DetailRow>

        <DetailRow label="Добавил(а)">{transaction.createdByName ?? '—'}</DetailRow>
      </div>
    </Modal>
  )
}
