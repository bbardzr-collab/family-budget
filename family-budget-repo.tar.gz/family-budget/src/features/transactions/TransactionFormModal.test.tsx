import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { ToastProvider } from '@/components/ui/Toast'
import { TransactionFormModal } from './TransactionFormModal'
import type { TransactionListItem } from './api'

const { mockCreateMutateAsync, mockUpdateMutateAsync, mockUseCategories } = vi.hoisted(() => ({
  mockCreateMutateAsync: vi.fn(),
  mockUpdateMutateAsync: vi.fn(),
  mockUseCategories: vi.fn(),
}))

vi.mock('./hooks', () => ({
  useCreateTransaction: () => ({ mutateAsync: mockCreateMutateAsync, isPending: false }),
  useUpdateTransaction: () => ({ mutateAsync: mockUpdateMutateAsync, isPending: false }),
}))

// Категории (Этап 8) — мокаем на границе feature-хуков, тем же паттерном,
// что и создание/обновление операций выше.
vi.mock('@/features/categories/hooks', () => ({
  useCategories: mockUseCategories,
}))

const CATEGORIES = [
  { id: 'cat-obligatory', name: 'Продукты', type: 'OBLIGATORY' as const, icon: 'shopping-cart', isActive: true, isCustom: false },
  { id: 'cat-wants', name: 'Кафе', type: 'WANTS' as const, icon: 'utensils', isActive: true, isCustom: false },
  { id: 'cat-inactive', name: 'Старая категория', type: 'OTHER' as const, icon: null, isActive: false, isCustom: true },
]

function renderModal(props: Partial<React.ComponentProps<typeof TransactionFormModal>> = {}) {
  return render(
    <ToastProvider>
      <TransactionFormModal open onClose={vi.fn()} defaultType="expense" {...props} />
    </ToastProvider>,
  )
}

describe('TransactionFormModal (Этап 7, п.1, 22; Этап 8, п.16-19)', () => {
  beforeEach(() => {
    mockCreateMutateAsync.mockReset()
    mockUpdateMutateAsync.mockReset()
    mockCreateMutateAsync.mockResolvedValue({})
    mockUpdateMutateAsync.mockResolvedValue({})
    mockUseCategories.mockReset()
    mockUseCategories.mockReturnValue({ data: CATEGORIES, isLoading: false, isError: false })
  })

  it('в режиме расхода показывает Сумму/Дату/Категорию/Комментарий, но не "Источник дохода"', () => {
    renderModal({ defaultType: 'expense' })

    expect(screen.getByLabelText('Сумма')).toBeInTheDocument()
    expect(screen.getByLabelText('Дата')).toBeInTheDocument()
    expect(screen.getByText('Категория')).toBeInTheDocument()
    expect(screen.getByLabelText('Комментарий')).toBeInTheDocument()
    expect(screen.queryByLabelText('Источник дохода')).not.toBeInTheDocument()
    expect(screen.getByRole('button', { name: /добавить расход/i })).toBeInTheDocument()
  })

  it('в режиме дохода дополнительно показывает "Источник дохода", но не показывает поле "Категория" (Этап 8, п.1, 16)', () => {
    renderModal({ defaultType: 'income' })

    expect(screen.getByLabelText('Источник дохода')).toBeInTheDocument()
    expect(screen.queryByText('Категория')).not.toBeInTheDocument()
    expect(screen.getByRole('button', { name: /добавить доход/i })).toBeInTheDocument()
  })

  it('переключение типа внутри формы показывает/скрывает поле "Источник дохода" и "Категория"', async () => {
    const user = userEvent.setup()
    renderModal({ defaultType: 'expense' })

    expect(screen.queryByLabelText('Источник дохода')).not.toBeInTheDocument()
    expect(screen.getByText('Категория')).toBeInTheDocument()

    await user.click(screen.getByRole('button', { name: 'Доход' }))
    expect(screen.getByLabelText('Источник дохода')).toBeInTheDocument()
    expect(screen.queryByText('Категория')).not.toBeInTheDocument()

    await user.click(screen.getByRole('button', { name: 'Расход' }))
    expect(screen.queryByLabelText('Источник дохода')).not.toBeInTheDocument()
    expect(screen.getByText('Категория')).toBeInTheDocument()
  })

  it('выбор категории через CategoryPickerModal подставляет её в кнопку выбора и в сабмит', async () => {
    const user = userEvent.setup()
    renderModal({ defaultType: 'expense' })

    await user.click(screen.getByRole('button', { name: /без категории/i }))
    expect(screen.getByRole('dialog', { name: 'Категория' })).toBeInTheDocument()

    await user.click(screen.getByRole('button', { name: 'Кафе' }))
    expect(screen.queryByRole('dialog', { name: 'Категория' })).not.toBeInTheDocument()
    expect(screen.getByRole('button', { name: /кафе/i })).toBeInTheDocument()

    await user.type(screen.getByLabelText('Сумма'), '500')
    await user.click(screen.getByRole('button', { name: /добавить расход/i }))

    expect(mockCreateMutateAsync).toHaveBeenCalledWith(expect.objectContaining({ categoryId: 'cat-wants' }))
  })

  it('без выбора категории сабмит расхода отправляет categoryId=null ("Без категории" — валидное состояние, ТЗ п.18)', async () => {
    const user = userEvent.setup()
    renderModal({ defaultType: 'expense' })

    await user.type(screen.getByLabelText('Сумма'), '500')
    await user.click(screen.getByRole('button', { name: /добавить расход/i }))

    expect(mockCreateMutateAsync).toHaveBeenCalledWith(expect.objectContaining({ categoryId: null }))
  })

  it('доход всегда отправляется с categoryId=null, даже если категория была выбрана до переключения типа', async () => {
    const user = userEvent.setup()
    renderModal({ defaultType: 'expense' })

    await user.click(screen.getByRole('button', { name: /без категории/i }))
    await user.click(screen.getByRole('button', { name: 'Кафе' }))

    await user.click(screen.getByRole('button', { name: 'Доход' }))
    await user.type(screen.getByLabelText('Сумма'), '1000')
    await user.type(screen.getByLabelText('Источник дохода'), 'Подарок')
    await user.click(screen.getByRole('button', { name: /добавить доход/i }))

    expect(mockCreateMutateAsync).toHaveBeenCalledWith(expect.objectContaining({ categoryId: null }))
  })

  it('показывает ошибку валидации при пустой сумме', async () => {
    const user = userEvent.setup()
    renderModal({ defaultType: 'expense' })

    await user.click(screen.getByRole('button', { name: /добавить расход/i }))

    expect(await screen.findByText('Введите сумму')).toBeInTheDocument()
    expect(mockCreateMutateAsync).not.toHaveBeenCalled()
  })

  it('расход: сабмит вызывает мутацию создания с amount без запятой, income_source=null', async () => {
    const user = userEvent.setup()
    renderModal({ defaultType: 'expense' })

    await user.type(screen.getByLabelText('Сумма'), '1500,50')
    await user.type(screen.getByLabelText('Комментарий'), 'Продукты')
    await user.click(screen.getByRole('button', { name: /добавить расход/i }))

    expect(mockCreateMutateAsync).toHaveBeenCalledWith(
      expect.objectContaining({
        type: 'expense',
        amount: '1500.50',
        incomeSource: null,
        comment: 'Продукты',
      }),
    )
  })

  it('доход: сабмит вызывает мутацию создания с указанным источником дохода', async () => {
    const user = userEvent.setup()
    renderModal({ defaultType: 'income' })

    await user.type(screen.getByLabelText('Сумма'), '50000')
    await user.type(screen.getByLabelText('Источник дохода'), 'Зарплата')
    await user.click(screen.getByRole('button', { name: /добавить доход/i }))

    expect(mockCreateMutateAsync).toHaveBeenCalledWith(
      expect.objectContaining({
        type: 'income',
        amount: '50000.00',
        incomeSource: 'Зарплата',
      }),
    )
  })

  it('редактирование: форма предзаполнена данными операции и сабмит вызывает мутацию обновления', async () => {
    const user = userEvent.setup()
    const transaction: TransactionListItem = {
      id: 'tx-1',
      type: 'expense',
      amount: 750,
      transactionDate: '2026-09-10',
      incomeSource: null,
      comment: 'Такси',
      userId: 'user-1',
      createdByName: null,
      categoryId: null,
      category: null,
    }

    renderModal({ defaultType: 'expense', transaction })

    expect(screen.getByLabelText('Сумма')).toHaveValue('750.00')
    expect(screen.getByLabelText('Комментарий')).toHaveValue('Такси')
    expect(screen.getByRole('button', { name: /сохранить/i })).toBeInTheDocument()

    await user.click(screen.getByRole('button', { name: /сохранить/i }))

    expect(mockUpdateMutateAsync).toHaveBeenCalledWith(
      expect.objectContaining({ id: 'tx-1', type: 'expense', amount: '750.00', categoryId: null }),
    )
  })

  it('редактирование операции с отключённой категорией: она показывается как выбранная, с меткой "Выключена" (Этап 8, п.19)', async () => {
    const user = userEvent.setup()
    const transaction: TransactionListItem = {
      id: 'tx-2',
      type: 'expense',
      amount: 200,
      transactionDate: '2026-09-01',
      incomeSource: null,
      comment: null,
      userId: 'user-1',
      createdByName: null,
      categoryId: 'cat-inactive',
      category: { id: 'cat-inactive', name: 'Старая категория', icon: null, isActive: false },
    }

    renderModal({ defaultType: 'expense', transaction })

    expect(screen.getByRole('button', { name: /старая категория/i })).toBeInTheDocument()

    await user.click(screen.getByRole('button', { name: /старая категория/i }))
    expect(screen.getByText('Текущая категория')).toBeInTheDocument()
    expect(screen.getByText('Выключена')).toBeInTheDocument()
  })

  it('редактирование операции без категории: форма открывается нормально с "Без категории" (Этап 8, п.19)', () => {
    const transaction: TransactionListItem = {
      id: 'tx-3',
      type: 'expense',
      amount: 100,
      transactionDate: '2026-09-01',
      incomeSource: null,
      comment: null,
      userId: 'user-1',
      createdByName: null,
      categoryId: null,
      category: null,
    }

    renderModal({ defaultType: 'expense', transaction })

    expect(screen.getByRole('button', { name: /без категории/i })).toBeInTheDocument()
  })
})
