import { useState } from 'react'
import { Button, Modal, Text } from '@/components/ui'
import { useToast } from '@/components/ui/Toast'
import { formatMoney } from '@/utils/formatMoney'
import { useDeleteTransaction } from './hooks'
import { getTransactionErrorMessage } from './errors'
import type { TransactionListItem } from './api'

interface DeleteTransactionModalProps {
  transaction: TransactionListItem | null
  onClose: () => void
}

/**
 * Подтверждение удаления операции (ТЗ, п.19-20) — реальное удаление строки
 * через RLS-защищённый DELETE (deleteTransaction), а не просто скрытие в UI.
 */
export function DeleteTransactionModal({ transaction, onClose }: DeleteTransactionModalProps) {
  const { toast } = useToast()
  const deleteTransactionMutation = useDeleteTransaction()
  const [error, setError] = useState<string | null>(null)

  async function handleConfirm() {
    if (!transaction) return
    setError(null)
    try {
      await deleteTransactionMutation.mutateAsync(transaction.id)
      toast({ type: 'success', title: 'Операция удалена' })
      onClose()
    } catch (err) {
      setError(getTransactionErrorMessage(err))
    }
  }

  function handleClose() {
    setError(null)
    onClose()
  }

  return (
    <Modal
      open={Boolean(transaction)}
      onClose={handleClose}
      title="Удалить операцию?"
      footer={
        <>
          <Button variant="outline" onClick={handleClose}>
            Отмена
          </Button>
          <Button
            variant="destructive"
            onClick={() => void handleConfirm()}
            isLoading={deleteTransactionMutation.isPending}
            disabled={deleteTransactionMutation.isPending}
          >
            Удалить
          </Button>
        </>
      }
    >
      <Text variant="secondary">
        {transaction &&
          `${transaction.type === 'income' ? 'Доход' : 'Расход'} на сумму ${formatMoney(
            transaction.amount,
          )} будет удалён без возможности восстановления.`}
      </Text>
      {error && (
        <p role="alert" className="mt-3 text-sm text-destructive">
          {error}
        </p>
      )}
    </Modal>
  )
}
