import { keepPreviousData, useInfiniteQuery, useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useAuth } from '@/features/auth/AuthContext'
import { useFamily } from '@/features/family/FamilyContext'
import { dashboardKeys } from '@/features/dashboard/queryKeys'
import { budgetsKeys } from '@/features/budgets/queryKeys'
import { analyticsKeys } from '@/features/analytics/queryKeys'
import { transactionsKeys } from './queryKeys'
import { TRANSACTIONS_PAGE_SIZE, type TransactionQueryFilters } from './filters'
import {
  createTransaction,
  deleteTransaction,
  fetchHasAnyTransaction,
  fetchTransactions,
  fetchTransactionsPage,
  fetchTransactionsTotals,
  updateTransaction,
  type CreateTransactionInput,
  type UpdateTransactionInput,
} from './api'

/**
 * Server state операций — через TanStack Query (ТЗ, п.17, 34), по тому же
 * принципу, что и features/family/hooks.ts и features/dashboard/hooks.ts.
 *
 * Все мутации инвалидируют dashboardKeys.all (Dashboard должен сразу
 * отражать новую операцию) и transactionsKeys.all — это ОБЩИЙ префикс сразу
 * для всех форм списка операций (list/filteredList/totals/hasAny, см.
 * queryKeys.ts), а не только той, что использовалась на момент Этапа 7:
 * иначе, например, создание операции обновило бы старый нефильтрованный
 * список, но не итоги/пагинированный журнал Этапа 9, и наоборот.
 *
 * budgetsKeys.all добавлен на Этапе 10: расход/доход операции меняет
 * фактические потрачено/остаток/процент бюджета месяца (get_monthly_budget_summary
 * пересчитывает их из transactions на сервере), поэтому без этой инвалидации
 * страница /app/budget и превью бюджета на Dashboard показывали бы устаревшие
 * цифры после добавления/редактирования/удаления операции.
 *
 * analyticsKeys.all добавлен на Этапе 14 по той же причине: все агрегаты
 * /app/analytics (сводка/динамика/категории/источники дохода) считаются на
 * сервере из тех же transactions, и без этой инвалидации страница
 * аналитики показывала бы устаревшие цифры до истечения кэша.
 */
function invalidateTransactionQueries(queryClient: ReturnType<typeof useQueryClient>) {
  void queryClient.invalidateQueries({ queryKey: transactionsKeys.all })
  void queryClient.invalidateQueries({ queryKey: dashboardKeys.all })
  void queryClient.invalidateQueries({ queryKey: budgetsKeys.all })
  void queryClient.invalidateQueries({ queryKey: analyticsKeys.all })
}

/** Полный список без фильтров/пагинации — оставлен как есть для мест, где он уже использовался. */
export function useTransactions() {
  const { currentFamily } = useFamily()
  return useQuery({
    queryKey: transactionsKeys.list(currentFamily?.id),
    queryFn: () => fetchTransactions(currentFamily!.id),
    enabled: Boolean(currentFamily?.id),
  })
}

/** Есть ли у семьи хоть одна операция вообще — только чтобы отличить два empty state (ТЗ, п.22). */
export function useHasAnyTransactions() {
  const { currentFamily } = useFamily()
  return useQuery({
    queryKey: transactionsKeys.hasAny(currentFamily?.id),
    queryFn: () => fetchHasAnyTransaction(currentFamily!.id),
    enabled: Boolean(currentFamily?.id),
  })
}

/**
 * Постраничный отфильтрованный журнал /app/transactions (ТЗ, п.13-17) —
 * useInfiniteQuery, а не обычный useQuery: одна и та же query оборачивает и
 * первую страницу, и накопление следующих через "Загрузить ещё" (ТЗ, п.13),
 * без ручного управления массивом загруженных операций в useState.
 *
 * queryKey включает filters целиком (ТЗ, п.16) — при изменении ЛЮБОГО
 * фильтра ключ меняется, React Query сам начинает новый запрос с первой
 * страницы; offset/pageParam НЕ входит в ключ явно — им управляет сам
 * useInfiniteQuery через getNextPageParam/pageParam.
 *
 * placeholderData: keepPreviousData (ТЗ, п.21) — при смене фильтра экран не
 * "обнуляется" в скелетон целиком, предыдущие данные остаются на экране, пока
 * не придёт новый ответ (isFetching у страницы отличит "мы обновляем
 * список" от исходной первой загрузки, см. TransactionsPage).
 */
export function useTransactionsList(filters: TransactionQueryFilters) {
  const { currentFamily } = useFamily()
  return useInfiniteQuery({
    queryKey: transactionsKeys.filteredList(currentFamily?.id, filters),
    queryFn: ({ pageParam }) => fetchTransactionsPage(filters, TRANSACTIONS_PAGE_SIZE, pageParam),
    initialPageParam: 0,
    getNextPageParam: (lastPage, allPages) =>
      lastPage.hasMore ? allPages.length * TRANSACTIONS_PAGE_SIZE : undefined,
    enabled: Boolean(currentFamily?.id),
    placeholderData: keepPreviousData,
  })
}

/** Итоги ТЕКУЩЕЙ отфильтрованной выборки (ТЗ, п.12) — отдельный запрос от списка (та же логика, что список/сумма Dashboard — два независимых запроса). */
export function useTransactionsTotals(filters: TransactionQueryFilters) {
  const { currentFamily } = useFamily()
  return useQuery({
    queryKey: transactionsKeys.totals(currentFamily?.id, filters),
    queryFn: () => fetchTransactionsTotals(filters),
    enabled: Boolean(currentFamily?.id),
    placeholderData: keepPreviousData,
  })
}

type CreateTransactionFormInput = Omit<CreateTransactionInput, 'familyId' | 'userId'>

export function useCreateTransaction() {
  const queryClient = useQueryClient()
  const { user } = useAuth()
  const { currentFamily } = useFamily()

  return useMutation({
    mutationFn: (input: CreateTransactionFormInput) => {
      if (!user?.id) throw new Error('NOT_AUTHENTICATED')
      if (!currentFamily?.id) throw new Error('NO_FAMILY')
      return createTransaction({ ...input, familyId: currentFamily.id, userId: user.id })
    },
    onSuccess: () => invalidateTransactionQueries(queryClient),
  })
}

export function useUpdateTransaction() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (input: UpdateTransactionInput) => updateTransaction(input),
    onSuccess: () => invalidateTransactionQueries(queryClient),
  })
}

export function useDeleteTransaction() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (id: string) => deleteTransaction(id),
    onSuccess: () => invalidateTransactionQueries(queryClient),
  })
}
