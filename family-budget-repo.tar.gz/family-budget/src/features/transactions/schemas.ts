import { z } from 'zod'

/**
 * Строковый ввод суммы → нормализованная десятичная строка "1234.50".
 *
 * ТЗ Этапа 7 (п.4-5) явно требует: обязательное поле, число, > 0, максимум
 * 2 знака после запятой, без отрицательных/NaN/Infinity, разумный максимум
 * (границы NUMERIC(14,2) — 12 цифр целой части + 2 дробной), и должно
 * одинаково приниматься "1000", "1000.50" И "1000,50" (запятая как разделитель).
 *
 * Вся нормализация — только строковыми операциями (split/padEnd), без единого
 * умножения/деления на 100 и без parseFloat на промежуточном шаге — именно
 * так, чтобы не словить типичные JS float-баги (0.1 + 0.2 !== 0.3) при работе
 * с деньгами. Итоговое Number(...) от уже нормализованной 2-знаковой строки
 * происходит только один раз, на границе сети (см. features/transactions/api.ts).
 */
function normalizeAmountString(value: string): string {
  const [intPart, decPart = ''] = value.split('.')
  const cents = decPart.padEnd(2, '0').slice(0, 2)
  return `${intPart}.${cents}`
}

// До 12 цифр целой части + опционально точка и 1-2 цифры дробной —
// ровно граница NUMERIC(14,2): максимум 999 999 999 999.99.
const AMOUNT_PATTERN = /^\d{1,12}(\.\d{1,2})?$/

export const amountInputSchema = z
  .string()
  .trim()
  .min(1, 'Введите сумму')
  .transform((value) => value.replace(',', '.'))
  .refine((value) => AMOUNT_PATTERN.test(value), {
    message: 'Введите сумму числом, например 1500 или 1500,50',
  })
  .refine((value) => !/^0+(\.0{1,2})?$/.test(value), {
    message: 'Сумма должна быть больше нуля',
  })
  .transform((value) => normalizeAmountString(value))

export const TRANSACTION_TYPES = ['expense', 'income'] as const
export type TransactionType = (typeof TRANSACTION_TYPES)[number]

/**
 * Единая форма для расхода и дохода (ТЗ, п.1: "один переиспользуемый
 * компонент TransactionForm"). income_source значим только для type=income —
 * для expense поле не показывается и принудительно приводится к null перед
 * отправкой (см. TransactionFormModal.onSubmit), а не запрещается здесь через
 * superRefine, чтобы скрытое поле не мешало валидации при переключении типа.
 */
export const transactionFormSchema = z.object({
  type: z.enum(TRANSACTION_TYPES),
  amount: amountInputSchema,
  transactionDate: z.string().min(1, 'Укажите дату'),
  incomeSource: z
    .string()
    .trim()
    .max(200, 'Источник дохода слишком длинный — максимум 200 символов')
    .optional()
    .or(z.literal('')),
  comment: z
    .string()
    .trim()
    .max(500, 'Комментарий слишком длинный — максимум 500 символов')
    .optional()
    .or(z.literal('')),
  // Категория (Этап 8, п.16, 18) — значима только для расхода; для дохода
  // категории не используются (ТЗ, п.1) и принудительно приводятся к null
  // перед отправкой (см. TransactionFormModal.onSubmit), как и income_source
  // для расхода. '' — сентинел "без категории", а не невалидное значение —
  // category_id в БД nullable именно для этого случая (п.18).
  categoryId: z.string().optional().or(z.literal('')),
})

export type TransactionFormValues = z.infer<typeof transactionFormSchema>
