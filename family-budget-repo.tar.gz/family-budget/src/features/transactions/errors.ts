/**
 * Перевод ошибок операций (создание/изменение/удаление transactions) в
 * понятные человеку сообщения (ТЗ, п.21) — по аналогии с
 * features/family/errors.ts. В отличие от family (там ошибки приходят из
 * наших же RPC с кодом в message), здесь INSERT/UPDATE/DELETE идут напрямую
 * через Supabase PostgREST поверх RLS — ошибки either код Postgres, либо
 * текст "row-level security", либо (для UPDATE/DELETE без затронутых строк
 * из-за RLS) PGRST116 от .single().
 */

interface MatchableError {
  message?: string
  code?: string
}

export function getTransactionErrorMessage(error: unknown): string {
  if (!error) return 'Неизвестная ошибка. Попробуйте ещё раз.'

  if (error instanceof TypeError) {
    return 'Проблема с сетью. Проверьте подключение к интернету и попробуйте снова.'
  }

  const { message, code } = (error as MatchableError) ?? {}
  const text = (message ?? String(error)).toLowerCase()

  // RLS отклонила INSERT/UPDATE (WITH CHECK не прошёл) — попытка создать/
  // изменить операцию не в своей семье или не от своего имени.
  if (text.includes('row-level security') || text.includes('policy')) {
    return 'Недостаточно прав для этого действия.'
  }

  // .single() после UPDATE/DELETE, которые из-за RLS не затронули ни одной
  // строки (запись либо не найдена, либо принадлежит чужой семье/пользователю).
  if (code === 'PGRST116') {
    return 'Операция не найдена или у вас нет прав её изменить.'
  }

  if (text.includes('fetch') || text.includes('network')) {
    return 'Проблема с сетью. Проверьте подключение к интернету и попробуйте снова.'
  }

  return 'Не получилось выполнить действие. Попробуйте ещё раз чуть позже.'
}
