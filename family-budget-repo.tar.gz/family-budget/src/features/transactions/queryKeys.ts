import type { TransactionQueryFilters } from './filters'

/**
 * Единый источник ключей React Query для домена "операции" (Этап 7, п.17;
 * расширено в Этапе 9).
 *
 * `list` — полный список без фильтров/пагинации, используется только там,
 * где он и раньше использовался (см. hooks.ts::useTransactions). Журнал
 * /app/transactions с Этапа 9 использует отдельные, параметризованные
 * реальными query-фильтрами ключи `filteredList`/`totals`/`hasAny` — они
 * специально имеют другую "форму" (не совпадают по количеству элементов с
 * `list`), поэтому все они инвалидируются вместе только через общий префикс
 * `transactionsKeys.all` (см. hooks.ts — мутации инвалидируют именно его).
 */
export const transactionsKeys = {
  all: ['transactions'] as const,
  list: (familyId: string | undefined) => [...transactionsKeys.all, 'list', familyId] as const,
  filteredList: (familyId: string | undefined, filters: TransactionQueryFilters) =>
    [...transactionsKeys.all, 'filteredList', familyId, filters] as const,
  totals: (familyId: string | undefined, filters: TransactionQueryFilters) =>
    [...transactionsKeys.all, 'totals', familyId, filters] as const,
  hasAny: (familyId: string | undefined) => [...transactionsKeys.all, 'hasAny', familyId] as const,
}
