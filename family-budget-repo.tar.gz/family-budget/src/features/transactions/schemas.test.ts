import { transactionFormSchema } from './schemas'

function baseValues(overrides: Partial<Record<string, unknown>> = {}) {
  return {
    type: 'expense',
    amount: '1000',
    transactionDate: '2026-09-18',
    incomeSource: '',
    comment: '',
    ...overrides,
  }
}

describe('transactionFormSchema — сумма (Этап 7, п.4-5, 33)', () => {
  it('отклоняет пустую сумму', () => {
    const result = transactionFormSchema.safeParse(baseValues({ amount: '' }))
    expect(result.success).toBe(false)
  })

  it('отклоняет ноль', () => {
    const result = transactionFormSchema.safeParse(baseValues({ amount: '0' }))
    expect(result.success).toBe(false)
  })

  it('отклоняет "0.00"', () => {
    const result = transactionFormSchema.safeParse(baseValues({ amount: '0.00' }))
    expect(result.success).toBe(false)
  })

  it('отклоняет отрицательную сумму', () => {
    const result = transactionFormSchema.safeParse(baseValues({ amount: '-100' }))
    expect(result.success).toBe(false)
  })

  it('отклоняет нечисловой ввод', () => {
    const result = transactionFormSchema.safeParse(baseValues({ amount: 'abc' }))
    expect(result.success).toBe(false)
  })

  it('отклоняет больше двух знаков после запятой', () => {
    const result = transactionFormSchema.safeParse(baseValues({ amount: '10.999' }))
    expect(result.success).toBe(false)
  })

  it('отклоняет сумму за пределами NUMERIC(14,2) (13 цифр в целой части)', () => {
    const result = transactionFormSchema.safeParse(baseValues({ amount: '1234567890123' }))
    expect(result.success).toBe(false)
  })

  it('принимает целое число: "1000" → "1000.00"', () => {
    const result = transactionFormSchema.safeParse(baseValues({ amount: '1000' }))
    expect(result.success).toBe(true)
    if (result.success) expect(result.data.amount).toBe('1000.00')
  })

  it('принимает сумму с точкой: "1000.50" → "1000.50"', () => {
    const result = transactionFormSchema.safeParse(baseValues({ amount: '1000.50' }))
    expect(result.success).toBe(true)
    if (result.success) expect(result.data.amount).toBe('1000.50')
  })

  it('принимает сумму с запятой: "1000,50" → "1000.50" (ТЗ, п.4 — оба разделителя)', () => {
    const result = transactionFormSchema.safeParse(baseValues({ amount: '1000,50' }))
    expect(result.success).toBe(true)
    if (result.success) expect(result.data.amount).toBe('1000.50')
  })

  it('принимает максимально допустимую сумму 999999999999.99', () => {
    const result = transactionFormSchema.safeParse(baseValues({ amount: '999999999999.99' }))
    expect(result.success).toBe(true)
  })

  it('дополняет один десятичный знак нулём: "10,5" → "10.50"', () => {
    const result = transactionFormSchema.safeParse(baseValues({ amount: '10,5' }))
    expect(result.success).toBe(true)
    if (result.success) expect(result.data.amount).toBe('10.50')
  })

  it('пробелы вокруг суммы обрезаются', () => {
    const result = transactionFormSchema.safeParse(baseValues({ amount: '  1500  ' }))
    expect(result.success).toBe(true)
    if (result.success) expect(result.data.amount).toBe('1500.00')
  })
})

describe('transactionFormSchema — дата (ТЗ, п.6)', () => {
  it('отклоняет пустую дату', () => {
    const result = transactionFormSchema.safeParse(baseValues({ transactionDate: '' }))
    expect(result.success).toBe(false)
  })

  it('принимает валидную дату', () => {
    const result = transactionFormSchema.safeParse(baseValues({ transactionDate: '2026-01-05' }))
    expect(result.success).toBe(true)
  })
})

describe('transactionFormSchema — тип и опциональные поля', () => {
  it('отклоняет недопустимый type', () => {
    const result = transactionFormSchema.safeParse(baseValues({ type: 'transfer' }))
    expect(result.success).toBe(false)
  })

  it('принимает income с источником дохода', () => {
    const result = transactionFormSchema.safeParse(
      baseValues({ type: 'income', amount: '50000', incomeSource: 'Зарплата' }),
    )
    expect(result.success).toBe(true)
  })

  it('принимает expense без источника дохода', () => {
    const result = transactionFormSchema.safeParse(baseValues({ type: 'expense' }))
    expect(result.success).toBe(true)
  })

  it('комментарий длиннее 500 символов отклоняется', () => {
    const result = transactionFormSchema.safeParse(baseValues({ comment: 'а'.repeat(501) }))
    expect(result.success).toBe(false)
  })
})
