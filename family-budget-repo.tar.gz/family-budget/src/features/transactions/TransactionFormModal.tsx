import { createElement, useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { ArrowDownCircle, ArrowUpCircle, ChevronRight } from 'lucide-react'
import { Button, Input, Modal, Textarea } from '@/components/ui'
import { useToast } from '@/components/ui/Toast'
import { cn } from '@/utils/cn'
import { toDateInputValue } from '@/utils/formatDate'
import { useCategories } from '@/features/categories/hooks'
import { getCategoryIcon } from '@/features/categories/iconMap'
import { CategoryPickerModal } from '@/features/categories/CategoryPickerModal'
import { transactionFormSchema, type TransactionFormValues, type TransactionType } from './schemas'
import { useCreateTransaction, useUpdateTransaction } from './hooks'
import { getTransactionErrorMessage } from './errors'
import type { TransactionListItem } from './api'

/** Предзаполнение из планируемого расхода (Этап 12, п.14) — используется только при создании (transaction=null). */
export interface TransactionFormPrefill {
  amount: string
  categoryId: string | null
  transactionDate: string
  comment?: string | null
}

interface TransactionFormModalProps {
  open: boolean
  onClose: () => void
  /** Тип, с которым модалка открылась (какую кнопку нажали) — пользователь может переключить внутри формы. */
  defaultType: TransactionType
  /** Если передана — форма работает в режиме редактирования (ТЗ, п.19), поля предзаполняются. */
  transaction?: TransactionListItem | null
  /**
   * "Добавить фактический расход" из плана (Этап 12, п.14) — предзаполняет
   * amount/category/date/comment, но НЕ создаёт транзакцию сама: реальная
   * запись появляется только когда пользователь сам нажимает кнопку отправки
   * формы ниже, то есть explicit-confirm требование ТЗ выполняется тем же
   * механизмом, что и обычное создание операции. Игнорируется в режиме
   * редактирования (transaction имеет приоритет).
   */
  prefill?: TransactionFormPrefill | null
}

function buildDefaultValues(
  defaultType: TransactionType,
  transaction: TransactionListItem | null | undefined,
  prefill: TransactionFormPrefill | null | undefined,
): TransactionFormValues {
  if (transaction) {
    return {
      type: transaction.type,
      amount: transaction.amount.toFixed(2),
      transactionDate: transaction.transactionDate,
      incomeSource: transaction.incomeSource ?? '',
      comment: transaction.comment ?? '',
      categoryId: transaction.categoryId ?? '',
    }
  }
  if (prefill) {
    return {
      type: 'expense',
      amount: prefill.amount,
      transactionDate: prefill.transactionDate,
      incomeSource: '',
      comment: prefill.comment ?? '',
      categoryId: prefill.categoryId ?? '',
    }
  }
  return {
    type: defaultType,
    amount: '',
    transactionDate: toDateInputValue(),
    incomeSource: '',
    comment: '',
    categoryId: '',
  }
}

/**
 * Единая форма добавления/редактирования операции (ТЗ, п.1, 19) —
 * переиспользуется и для расхода, и для дохода, и для create, и для edit.
 * Тип переключается сегментированным контролом внутри формы (а не жёстко
 * фиксирован пропом) — это и даёт "поддержку смены типа" при редактировании
 * (п.19), и позволяет поправить случайный выбор при создании.
 */
export function TransactionFormModal({
  open,
  onClose,
  defaultType,
  transaction = null,
  prefill = null,
}: TransactionFormModalProps) {
  const { toast } = useToast()
  const isEdit = Boolean(transaction)
  const createTransactionMutation = useCreateTransaction()
  const updateTransactionMutation = useUpdateTransaction()
  const isSubmittingMutation = createTransactionMutation.isPending || updateTransactionMutation.isPending
  const [formError, setFormError] = useState<string | null>(null)
  const [categoryPickerOpen, setCategoryPickerOpen] = useState(false)
  // Все категории семьи (включая отключённые — нужны, чтобы показать текущую
  // выбранную категорию уже отредактированной операции, даже если она с тех
  // пор была отключена, см. CategoryPickerModal и ТЗ п.19).
  const { data: categories } = useCategories()

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<TransactionFormValues>({
    resolver: zodResolver(transactionFormSchema),
    defaultValues: buildDefaultValues(defaultType, transaction, prefill),
  })

  // RHF берёт defaultValues только один раз при монтировании формы, а модалка
  // не размонтируется между открытиями (Modal просто возвращает null при
  // open=false) — поэтому при каждом новом открытии (новый transaction или
  // новый defaultType) явно сбрасываем форму к актуальным значениям. reset()
  // здесь синхронизирует внешнее хранилище RHF с новыми пропами — ровно то,
  // для чего и предназначен эффект (в отличие от обычного useState).
  useEffect(() => {
    if (open) {
      reset(buildDefaultValues(defaultType, transaction, prefill))
      setFormError(null)
    }
  }, [open, defaultType, transaction, prefill, reset])

  // watch('type') — намеренно не через отдельный useState (пришлось бы
  // синхронизировать set-эффектом, а `npm run lint` в этом проекте настроен
  // как раз против raw setState внутри эффекта, react-hooks/set-state-in-effect).
  // watch() здесь единственный источник истины поля type; React Compiler не
  // мемоизирует эту функцию (предупреждение react-hooks/incompatible-library),
  // но это не ошибка и не влияет на корректность — сам react-hook-form
  // гарантирует ререндер при каждом изменении отслеживаемого поля.
  const type = watch('type')
  const categoryId = watch('categoryId')
  const selectedCategory = categories?.find((c) => c.id === categoryId) ?? null

  function handleTypeChange(nextType: TransactionType) {
    setValue('type', nextType, { shouldValidate: true })
    // Категория значима только для расхода (ТЗ, п.1, 16) — при переключении
    // на доход сбрасываем выбор, чтобы случайно не отправить category_id
    // вместе с доходом (хотя onSubmit и так принудительно обнулит его).
    if (nextType === 'income') {
      setValue('categoryId', '', { shouldValidate: true })
    }
  }

  function handleClose() {
    setFormError(null)
    onClose()
  }

  const onSubmit = handleSubmit(async (values) => {
    setFormError(null)
    // income_source значим только для дохода — принудительно в null для
    // расхода, независимо от того, что могло остаться в скрытом поле формы
    // (ТЗ, п.3: income_source = NULL для расходов).
    const incomeSource = values.type === 'income' ? values.incomeSource?.trim() || null : null
    const comment = values.comment?.trim() || null
    // Категория значима только для расхода — принудительно в null для
    // дохода, независимо от того, что могло остаться в скрытом поле формы
    // (Этап 8, п.1, 16, тот же принцип, что и income_source выше).
    const categoryId = values.type === 'expense' ? values.categoryId || null : null

    try {
      if (isEdit && transaction) {
        await updateTransactionMutation.mutateAsync({
          id: transaction.id,
          type: values.type,
          amount: values.amount,
          transactionDate: values.transactionDate,
          incomeSource,
          comment,
          categoryId,
        })
        toast({ type: 'success', title: 'Операция сохранена' })
      } else {
        await createTransactionMutation.mutateAsync({
          type: values.type,
          amount: values.amount,
          transactionDate: values.transactionDate,
          incomeSource,
          comment,
          categoryId,
        })
        toast({
          type: 'success',
          title: values.type === 'income' ? 'Доход добавлен' : 'Расход добавлен',
        })
      }
      handleClose()
    } catch (error) {
      setFormError(getTransactionErrorMessage(error))
    }
  })

  const busy = isSubmitting || isSubmittingMutation

  return (
    <Modal
      open={open}
      onClose={handleClose}
      title={isEdit ? 'Изменить операцию' : 'Добавить операцию'}
    >
      <form className="flex flex-col gap-4" onSubmit={onSubmit} noValidate>
        <div className="grid grid-cols-2 gap-2" role="group" aria-label="Тип операции">
          <TypeToggleButton
            active={type === 'expense'}
            icon={ArrowDownCircle}
            label="Расход"
            onClick={() => handleTypeChange('expense')}
          />
          <TypeToggleButton
            active={type === 'income'}
            icon={ArrowUpCircle}
            label="Доход"
            onClick={() => handleTypeChange('income')}
          />
        </div>

        <Input
          label="Сумма"
          inputMode="decimal"
          placeholder="0"
          autoComplete="off"
          error={errors.amount?.message}
          {...register('amount')}
        />

        <Input
          label="Дата"
          type="date"
          error={errors.transactionDate?.message}
          {...register('transactionDate')}
        />

        {type === 'income' && (
          <Input
            label="Источник дохода"
            placeholder="Зарплата, подработка…"
            autoComplete="off"
            error={errors.incomeSource?.message}
            {...register('incomeSource')}
          />
        )}

        {/* Категория — только для расхода, доходы категорий не используют (ТЗ, п.1, 16). */}
        {type === 'expense' && (
          <div className="flex flex-col gap-1.5">
            <span className="text-sm font-medium text-foreground">Категория</span>
            <button
              type="button"
              onClick={() => setCategoryPickerOpen(true)}
              className={cn(
                'flex h-11 items-center gap-2 rounded-md border border-input bg-card px-3 text-left text-base text-foreground transition-colors',
                'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
              )}
            >
              <span className="flex size-6 shrink-0 items-center justify-center rounded-full bg-muted text-muted-foreground">
                {/* createElement — см. комментарий в CategoryPickerModal.tsx
                    про react-hooks/static-components и динамический выбор
                    иконки по строке из БД. */}
                {createElement(getCategoryIcon(selectedCategory?.icon), {
                  className: 'size-3.5',
                  'aria-hidden': true,
                })}
              </span>
              <span className="min-w-0 flex-1 truncate">{selectedCategory ? selectedCategory.name : 'Без категории'}</span>
              <ChevronRight className="size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
            </button>
          </div>
        )}

        <Textarea
          label="Комментарий"
          placeholder="Необязательно"
          error={errors.comment?.message}
          {...register('comment')}
        />

        {formError && (
          <p role="alert" className="text-sm text-destructive">
            {formError}
          </p>
        )}

        <Button type="submit" size="lg" isLoading={busy} disabled={busy}>
          {isEdit ? 'Сохранить' : type === 'income' ? 'Добавить доход' : 'Добавить расход'}
        </Button>
      </form>

      <CategoryPickerModal
        open={categoryPickerOpen}
        onClose={() => setCategoryPickerOpen(false)}
        categories={categories ?? []}
        selectedCategoryId={categoryId || null}
        onSelect={(nextCategoryId) => setValue('categoryId', nextCategoryId ?? '', { shouldValidate: true })}
      />
    </Modal>
  )
}

function TypeToggleButton({
  active,
  icon: Icon,
  label,
  onClick,
}: {
  active: boolean
  icon: typeof ArrowDownCircle
  label: string
  onClick: () => void
}) {
  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={onClick}
      className={cn(
        'flex h-11 items-center justify-center gap-2 rounded-md border text-sm font-medium transition-colors',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background',
        active
          ? 'border-primary bg-primary-soft text-primary'
          : 'border-border bg-card text-muted-foreground hover:bg-muted',
      )}
    >
      <Icon className="size-4" aria-hidden="true" />
      {label}
    </button>
  )
}
