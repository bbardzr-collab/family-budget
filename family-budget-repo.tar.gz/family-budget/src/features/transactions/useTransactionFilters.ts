import { useCallback, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { TRANSACTION_TYPES, type TransactionType } from './schemas'
import {
  CATEGORY_FILTER_ALL,
  DEFAULT_FILTERS,
  PERIOD_PRESETS,
  type PeriodPreset,
  type SortOrder,
  type TransactionFilters,
  type TransactionTypeFilter,
} from './filters'

/**
 * URL ↔ состояние фильтров (ТЗ, п.17) — синхронизированы только "основные"
 * фильтры (тип/период/даты произвольного периода/категория), как явно
 * разрешает ТЗ ("не усложняй архитектуру ради второстепенных фильтров").
 * Поиск и сортировка — локальное состояние компонента, в URL не попадают.
 *
 * Единственный источник состояния (ТЗ, п.20): `filters`, который отдаёт этот
 * хук, — единственное место, которое читают TabsTrigger/FiltersPanel/список/
 * итоги. Ни один из них не хранит собственную параллельную копию значения.
 *
 * Значения из URL нарочно не являются границей безопасности (ТЗ, п.25) —
 * если в URL прилетит category=<чужой-id> или что угодно ещё, это в худшем
 * случае даст пустой результат (RLS в get_transactions_page/_totals
 * ограничивает выборку по семье пользователя до применения category-фильтра,
 * см. миграцию 0019) — а не операции другой семьи. Валидация ниже нужна
 * только чтобы не подставлять в запрос откровенно мусорное значение, а не
 * ради защиты данных.
*/

const TYPE_PARAM = 'type'
const PERIOD_PARAM = 'period'
const FROM_PARAM = 'from'
const TO_PARAM = 'to'
const CATEGORY_PARAM = 'category'

const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/
// 'none' или id категории — намеренно НЕ проверяем строго формат UUID: это
// не граница безопасности (см. комментарий выше про RLS), а просто защита от
// откровенного мусора в URL, поэтому подходит любая разумная короткая строка
// без пробелов/спецсимволов (id категорий в реальной БД — UUID из
// gen_random_uuid(), но тест-фикстуры проекта традиционно используют простые
// строки вроде "cat-1" — паттерн должен принимать оба варианта).
const CATEGORY_VALUE_PATTERN = /^[\w-]{1,64}$/

function parseType(value: string | null): TransactionTypeFilter {
  if (value && (TRANSACTION_TYPES as readonly string[]).includes(value)) return value as TransactionType
  return DEFAULT_FILTERS.type
}

function parsePeriod(value: string | null): PeriodPreset {
  if (value && (PERIOD_PRESETS as readonly string[]).includes(value)) return value as PeriodPreset
  return DEFAULT_FILTERS.period
}

function parseDate(value: string | null): string {
  return value && DATE_PATTERN.test(value) ? value : ''
}

function parseCategory(value: string | null): string {
  return value && CATEGORY_VALUE_PATTERN.test(value) ? value : CATEGORY_FILTER_ALL
}

export interface UseTransactionFiltersResult {
  filters: TransactionFilters
  /** Немедленное значение поля поиска — для controlled input (без debounce). */
  searchInput: string
  setType: (type: TransactionTypeFilter) => void
  setPeriod: (period: PeriodPreset) => void
  setCustomRange: (from: string, to: string) => void
  setCategory: (categoryId: string) => void
  setSearchInput: (value: string) => void
  setSort: (sort: SortOrder) => void
  resetFilters: () => void
}

export function useTransactionFilters(): UseTransactionFiltersResult {
  const [searchParams, setSearchParams] = useSearchParams()
  // Поиск и сортировка — намеренно НЕ в URL (см. комментарий выше), поэтому
  // локальный useState, а не производное значение от searchParams.
  const [searchInput, setSearchInput] = useState('')
  const [sort, setSort] = useState<SortOrder>(DEFAULT_FILTERS.sort)

  const type = parseType(searchParams.get(TYPE_PARAM))
  const period = parsePeriod(searchParams.get(PERIOD_PARAM))
  const customFrom = parseDate(searchParams.get(FROM_PARAM))
  const customTo = parseDate(searchParams.get(TO_PARAM))
  const categoryId = parseCategory(searchParams.get(CATEGORY_PARAM))

  const filters = useMemo<TransactionFilters>(
    () => ({ type, period, customFrom, customTo, categoryId, search: searchInput, sort }),
    [type, period, customFrom, customTo, categoryId, searchInput, sort],
  )

  const setType = useCallback(
    (nextType: TransactionTypeFilter) => {
      setSearchParams(
        (prev) => {
          const next = new URLSearchParams(prev)
          if (nextType === DEFAULT_FILTERS.type) next.delete(TYPE_PARAM)
          else next.set(TYPE_PARAM, nextType)
          return next
        },
        { replace: false },
      )
    },
    [setSearchParams],
  )

  const setPeriod = useCallback(
    (nextPeriod: PeriodPreset) => {
      setSearchParams(
        (prev) => {
          const next = new URLSearchParams(prev)
          if (nextPeriod === DEFAULT_FILTERS.period) next.delete(PERIOD_PARAM)
          else next.set(PERIOD_PARAM, nextPeriod)
          // Переключение прочь от "Произвольного периода" — старые from/to
          // больше не значимы, не оставляем их "призраком" в URL.
          if (nextPeriod !== 'custom') {
            next.delete(FROM_PARAM)
            next.delete(TO_PARAM)
          }
          return next
        },
        { replace: false },
      )
    },
    [setSearchParams],
  )

  const setCustomRange = useCallback(
    (from: string, to: string) => {
      setSearchParams(
        (prev) => {
          const next = new URLSearchParams(prev)
          next.set(PERIOD_PARAM, 'custom')
          if (from) next.set(FROM_PARAM, from)
          else next.delete(FROM_PARAM)
          if (to) next.set(TO_PARAM, to)
          else next.delete(TO_PARAM)
          return next
        },
        { replace: true },
      )
    },
    [setSearchParams],
  )

  const setCategory = useCallback(
    (nextCategoryId: string) => {
      setSearchParams(
        (prev) => {
          const next = new URLSearchParams(prev)
          if (nextCategoryId === CATEGORY_FILTER_ALL) next.delete(CATEGORY_PARAM)
          else next.set(CATEGORY_PARAM, nextCategoryId)
          return next
        },
        { replace: false },
      )
    },
    [setSearchParams],
  )

  const resetFilters = useCallback(() => {
    setSearchParams(new URLSearchParams(), { replace: false })
    setSearchInput('')
    setSort(DEFAULT_FILTERS.sort)
  }, [setSearchParams])

  return { filters, searchInput, setType, setPeriod, setCustomRange, setCategory, setSearchInput, setSort, resetFilters }
}
