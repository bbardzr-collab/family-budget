import { Search } from 'lucide-react'
import { Button, Input, Select, type SelectOption } from '@/components/ui'
import { CATEGORY_TYPE_ORDER } from '@/features/categories/constants'
import type { CategoryListItem } from '@/features/categories/api'
import {
  CATEGORY_FILTER_ALL,
  CATEGORY_FILTER_NONE,
  PERIOD_LABELS,
  PERIOD_PRESETS,
  QUICK_PERIODS,
  SORT_LABELS,
  type PeriodPreset,
  type SortOrder,
  type TransactionFilters,
} from './filters'

const PERIOD_OPTIONS: SelectOption[] = PERIOD_PRESETS.map((preset) => ({ value: preset, label: PERIOD_LABELS[preset] }))
const SORT_OPTIONS: SelectOption[] = (Object.keys(SORT_LABELS) as SortOrder[]).map((value) => ({
  value,
  label: SORT_LABELS[value],
}))

function buildCategoryOptions(categories: CategoryListItem[] | undefined): SelectOption[] {
  const base: SelectOption[] = [
    { value: CATEGORY_FILTER_ALL, label: 'Все категории' },
    { value: CATEGORY_FILTER_NONE, label: 'Без категории' },
  ]
  if (!categories?.length) return base

  // Сгруппированы по типу (тот же порядок, что и на /app/categories) —
  // визуальных заголовков групп нативный <select> не даёт, но порядок сам
  // по себе делает список читаемым. Отключённые категории не скрываются
  // (в отличие от CategoryPickerModal при выборе категории операции) —
  // иначе нечем было бы отфильтровать уже существующие операции, у которых
  // категория с тех пор отключена (ТЗ, п.4, тот же принцип, что и п.19-20).
  const sorted = [...categories].sort((a, b) => {
    const typeDiff = CATEGORY_TYPE_ORDER.indexOf(a.type) - CATEGORY_TYPE_ORDER.indexOf(b.type)
    return typeDiff !== 0 ? typeDiff : a.name.localeCompare(b.name, 'ru')
  })

  return [
    ...base,
    ...sorted.map((category) => ({
      value: category.id,
      label: category.isActive ? category.name : `${category.name} (выключена)`,
    })),
  ]
}

export interface TransactionFiltersPanelProps {
  filters: TransactionFilters
  searchInput: string
  categories: CategoryListItem[] | undefined
  canReset: boolean
  onPeriod: (period: PeriodPreset) => void
  onCustomRange: (from: string, to: string) => void
  onCategory: (categoryId: string) => void
  onSearchInput: (value: string) => void
  onSort: (sort: SortOrder) => void
  onReset: () => void
}

/**
 * Содержимое панели фильтров (ТЗ, п.2-3, 20-21) — один и тот же компонент
 * используется и в раскрытой desktop-панели, и внутри мобильного Bottom
 * Sheet (Modal), чтобы логика фильтров существовала в одном месте.
 */
export function TransactionFiltersPanel({
  filters,
  searchInput,
  categories,
  canReset,
  onPeriod,
  onCustomRange,
  onCategory,
  onSearchInput,
  onSort,
  onReset,
}: TransactionFiltersPanelProps) {
  const categoryOptions = buildCategoryOptions(categories)
  const categoryDisabled = filters.type === 'income'

  return (
    <div className="flex flex-col gap-4">
      <Input
        label="Поиск операций"
        placeholder="Комментарий, категория или источник дохода"
        leftIcon={<Search />}
        value={searchInput}
        onChange={(event) => onSearchInput(event.target.value)}
      />

      <div className="flex flex-col gap-1.5">
        <span className="text-sm font-medium text-foreground">Период</span>
        <div className="flex flex-wrap gap-2" role="group" aria-label="Быстрый выбор периода">
          {QUICK_PERIODS.map((preset) => (
            <Button
              key={preset}
              type="button"
              variant={filters.period === preset ? 'primary' : 'outline'}
              size="sm"
              aria-pressed={filters.period === preset}
              onClick={() => onPeriod(preset)}
            >
              {PERIOD_LABELS[preset]}
            </Button>
          ))}
        </div>
        <Select
          aria-label="Период"
          options={PERIOD_OPTIONS}
          value={filters.period}
          onChange={(event) => onPeriod(event.target.value as PeriodPreset)}
        />
      </div>

      {filters.period === 'custom' && (
        <div className="grid grid-cols-2 gap-3">
          <Input
            label="Дата от"
            type="date"
            value={filters.customFrom}
            onChange={(event) => onCustomRange(event.target.value, filters.customTo)}
          />
          <Input
            label="Дата до"
            type="date"
            value={filters.customTo}
            onChange={(event) => onCustomRange(filters.customFrom, event.target.value)}
          />
        </div>
      )}

      <Select
        label="Категория"
        options={categoryOptions}
        value={categoryDisabled ? CATEGORY_FILTER_ALL : filters.categoryId}
        onChange={(event) => onCategory(event.target.value)}
        disabled={categoryDisabled}
        helperText={categoryDisabled ? 'У доходов категорий нет' : undefined}
      />

      <Select
        label="Сортировка"
        options={SORT_OPTIONS}
        value={filters.sort}
        onChange={(event) => onSort(event.target.value as SortOrder)}
      />

      <Button type="button" variant="outline" onClick={onReset} disabled={!canReset}>
        Сбросить фильтры
      </Button>
    </div>
  )
}
