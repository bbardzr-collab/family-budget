import { endOfMonth, endOfWeek, endOfYear, startOfMonth, startOfWeek, startOfYear, subMonths } from 'date-fns'
import { ru } from 'date-fns/locale'
import { toDateInputValue } from '@/utils/formatDate'
import type { TransactionType } from './schemas'

/**
 * Единый источник состояния фильтров журнала операций (Этап 9, п.2-3, 20).
 * Всё, что показывает и на что реагирует /app/transactions, читается из
 * одного объекта TransactionFilters — ни один элемент интерфейса не хранит
 * свою "параллельную" копию текущего фильтра.
 *
 * ВАЖНО про даты (ТЗ, п.26): весь этот файл работает только с "местным"
 * календарным днём — через `new Date()` (локальное время браузера) и
 * date-fns/toDateInputValue (которые используют локальные геттеры года/
 * месяца/дня), НИКОГДА через `.toISOString()`. `"2026-09-18".toISOString()`-
 * style преобразование в UTC и обратно способно сдвинуть дату на день у
 * пользователя в другом часовом поясе — именно та ошибка, которой явно
 * требует избежать ТЗ этого этапа.
 */

export type TransactionTypeFilter = 'all' | TransactionType

export const PERIOD_PRESETS = ['today', 'week', 'month', 'lastMonth', 'year', 'custom'] as const
export type PeriodPreset = (typeof PERIOD_PRESETS)[number]

export const PERIOD_LABELS: Record<PeriodPreset, string> = {
  today: 'Сегодня',
  week: 'Эта неделя',
  month: 'Этот месяц',
  lastMonth: 'Прошлый месяц',
  year: 'Этот год',
  custom: 'Произвольный период',
}

/** Быстрые кнопки периода (ТЗ, п.19) — намеренно только 4 из 6 пресетов. */
export const QUICK_PERIODS: readonly PeriodPreset[] = ['today', 'week', 'month', 'year']

export type SortOrder = 'date_desc' | 'date_asc'

export const SORT_LABELS: Record<SortOrder, string> = {
  date_desc: 'Новые сначала',
  date_asc: 'Старые сначала',
}

/** 'all' — все категории, 'none' — "Без категории", иначе — id категории семьи. */
export type CategoryFilterValue = string
export const CATEGORY_FILTER_ALL: CategoryFilterValue = 'all'
export const CATEGORY_FILTER_NONE: CategoryFilterValue = 'none'

export interface TransactionFilters {
  type: TransactionTypeFilter
  period: PeriodPreset
  /** Значимы только при period === 'custom'. */
  customFrom: string
  customTo: string
  categoryId: CategoryFilterValue
  search: string
  sort: SortOrder
}

/** Размер страницы журнала операций (ТЗ, п.13: "например, 30-50 операций"). */
export const TRANSACTIONS_PAGE_SIZE = 30

export const DEFAULT_FILTERS: TransactionFilters = {
  type: 'all',
  period: 'month',
  customFrom: '',
  customTo: '',
  categoryId: CATEGORY_FILTER_ALL,
  search: '',
  sort: 'date_desc',
}

export interface ResolvedDateRange {
  from: string
  to: string
}

/**
 * Считает конкретные границы периода (ТЗ, п.3) на локальной дате пользователя.
 * Всегда возвращает КОНКРЕТНЫЕ даты (даже для "этот год") — запрос в базу
 * никогда не уходит вообще без диапазона.
 */
export function resolveDateRange(
  filters: Pick<TransactionFilters, 'period' | 'customFrom' | 'customTo'>,
  now: Date = new Date(),
): ResolvedDateRange {
  switch (filters.period) {
    case 'today': {
      const today = toDateInputValue(now)
      return { from: today, to: today }
    }
    case 'week':
      return {
        from: toDateInputValue(startOfWeek(now, { weekStartsOn: 1, locale: ru })),
        to: toDateInputValue(endOfWeek(now, { weekStartsOn: 1, locale: ru })),
      }
    case 'month':
      return { from: toDateInputValue(startOfMonth(now)), to: toDateInputValue(endOfMonth(now)) }
    case 'lastMonth': {
      const lastMonth = subMonths(now, 1)
      return { from: toDateInputValue(startOfMonth(lastMonth)), to: toDateInputValue(endOfMonth(lastMonth)) }
    }
    case 'year':
      return { from: toDateInputValue(startOfYear(now)), to: toDateInputValue(endOfYear(now)) }
    case 'custom':
      // Если пользователь ещё не выбрал одну из границ — безопасный дефолт
      // (начало месяца/сегодня), чтобы запрос никогда не улетал без диапазона
      // даже в момент переключения на "Произвольный период".
      return {
        from: filters.customFrom || toDateInputValue(startOfMonth(now)),
        to: filters.customTo || toDateInputValue(now),
      }
  }
}

export type CategoryFilterMode = 'all' | 'none' | 'specific'

export interface TransactionQueryFilters {
  type: TransactionTypeFilter
  dateFrom: string
  dateTo: string
  categoryMode: CategoryFilterMode
  categoryId: string | null
  /** Уже обрезанная строка поиска (без trim на стороне вызывающего). */
  search: string
  sort: SortOrder
}

/**
 * UI-фильтры (ТЗ-состояние) → параметры для реальных запросов (api.ts).
 *
 * Категория у дохода принципиально не действует (ТЗ, п.4: "для доходов
 * фильтр категории должен быть недоступен ИЛИ не влиять на доходы") — эта
 * функция гарантирует второе на уровне данных: даже если где-то в UI останется
 * не сброшенный выбор категории при вкладке "Доходы", в реальный запрос
 * категория не попадёт (categoryMode всегда 'all' для type === 'income').
 */
export function toQueryFilters(filters: TransactionFilters, now: Date = new Date()): TransactionQueryFilters {
  const { from, to } = resolveDateRange(filters, now)

  const categoryMode: CategoryFilterMode =
    filters.type === 'income'
      ? 'all'
      : filters.categoryId === CATEGORY_FILTER_ALL
        ? 'all'
        : filters.categoryId === CATEGORY_FILTER_NONE
          ? 'none'
          : 'specific'

  return {
    type: filters.type,
    dateFrom: from,
    dateTo: to,
    categoryMode,
    categoryId: categoryMode === 'specific' ? filters.categoryId : null,
    search: filters.search.trim(),
    sort: filters.sort,
  }
}

/** Есть ли хоть один изменённый относительно дефолта фильтр (ТЗ, п.18). */
export function isDefaultFilters(filters: TransactionFilters): boolean {
  return (
    filters.type === DEFAULT_FILTERS.type &&
    filters.period === DEFAULT_FILTERS.period &&
    filters.categoryId === DEFAULT_FILTERS.categoryId &&
    filters.search.trim() === '' &&
    filters.sort === DEFAULT_FILTERS.sort
  )
}
