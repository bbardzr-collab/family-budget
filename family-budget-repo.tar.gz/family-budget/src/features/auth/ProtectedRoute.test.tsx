import { render, screen } from '@testing-library/react'
import { MemoryRouter, Route, Routes } from 'react-router-dom'
import { ProtectedRoute } from './ProtectedRoute'

const { mockUseAuth } = vi.hoisted(() => ({ mockUseAuth: vi.fn() }))

vi.mock('./AuthContext', () => ({
  useAuth: mockUseAuth,
}))

function renderWithAuth(authValue: { isAuthenticated: boolean; isLoading: boolean }, initialEntries = ['/app']) {
  mockUseAuth.mockReturnValue(authValue)
  return render(
    <MemoryRouter initialEntries={initialEntries}>
      <Routes>
        <Route path="/login" element={<div>Login Page</div>} />
        <Route element={<ProtectedRoute />}>
          <Route path="/app" element={<div>Protected Content</div>} />
        </Route>
      </Routes>
    </MemoryRouter>,
  )
}

describe('ProtectedRoute', () => {
  it('показывает loading, пока состояние авторизации не определено', () => {
    renderWithAuth({ isAuthenticated: false, isLoading: true })
    expect(screen.getByText(/проверяем вход/i)).toBeInTheDocument()
  })

  it('перенаправляет неавторизованного пользователя на /login', () => {
    renderWithAuth({ isAuthenticated: false, isLoading: false })
    expect(screen.getByText('Login Page')).toBeInTheDocument()
    expect(screen.queryByText('Protected Content')).not.toBeInTheDocument()
  })

  it('показывает защищённый контент авторизованному пользователю', () => {
    renderWithAuth({ isAuthenticated: true, isLoading: false })
    expect(screen.getByText('Protected Content')).toBeInTheDocument()
  })
})
