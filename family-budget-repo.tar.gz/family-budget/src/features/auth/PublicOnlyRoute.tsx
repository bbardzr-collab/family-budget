import { Navigate, Outlet, useSearchParams } from 'react-router-dom'
import { LoadingState } from '@/components/ui'
import { useAuth } from './AuthContext'

/**
 * Для /login и /register (Этап 4, п.14): уже авторизованный пользователь,
 * открывший эти страницы, перенаправляется на /app вместо повторного входа.
 *
 * Этап 5, п.22: если на /login или /register попали со страницы приглашения
 * (кнопки «Войти»/«Создать аккаунт» на /invite/:token добавляют
 * ?redirect=/invite/<token>), после входа нужно вернуть пользователя туда
 * же, а не на /app. `redirect` принимается, только если это локальный путь
 * (начинается с одного "/", не "//") — иначе это открытый редирект наружу.
 */
export function PublicOnlyRoute() {
  const { isAuthenticated, isLoading } = useAuth()
  const [searchParams] = useSearchParams()

  if (isLoading) {
    return <LoadingState label="Загрузка…" className="min-h-screen" />
  }

  if (isAuthenticated) {
    const redirect = searchParams.get('redirect')
    const target = redirect && redirect.startsWith('/') && !redirect.startsWith('//') ? redirect : '/app'
    return <Navigate to={target} replace />
  }

  return <Outlet />
}
