/**
 * Перевод ошибок Supabase Auth в понятные человеку сообщения (Этап 4, п.15).
 * Технические детали (stack trace, коды Supabase) пользователю не показываем.
 *
 * Supabase-js не гарантирует стабильный `code` во всех версиях/провайдерах,
 * поэтому сопоставляем по тексту `message` (англоязычный, приходит от GoTrue) —
 * это самый надёжный способ без привязки к конкретной minor-версии SDK.
 */

interface MatchableError {
  message?: string
  name?: string
}

const RULES: Array<{ test: (message: string) => boolean; text: string }> = [
  {
    test: (m) => m.includes('invalid login credentials') || m.includes('invalid_credentials'),
    text: 'Неверный email или пароль.',
  },
  {
    test: (m) => m.includes('user already registered') || m.includes('already registered') || m.includes('user_already_exists'),
    text: 'Этот email уже зарегистрирован. Попробуйте войти или восстановить пароль.',
  },
  {
    test: (m) => m.includes('email not confirmed') || m.includes('email_not_confirmed'),
    text: 'Email ещё не подтверждён. Проверьте почту и перейдите по ссылке подтверждения.',
  },
  {
    test: (m) => m.includes('unable to validate email') || m.includes('invalid email') || m.includes('email_address_invalid'),
    text: 'Некорректный email.',
  },
  {
    test: (m) =>
      m.includes('password should be at least') ||
      m.includes('password is too weak') ||
      m.includes('weak_password') ||
      m.includes('should contain at least'),
    text: 'Пароль слишком простой или короткий — минимум 8 символов.',
  },
  {
    test: (m) =>
      m.includes('token has expired') ||
      m.includes('link is invalid or has expired') ||
      m.includes('otp_expired'),
    text: 'Ссылка восстановления устарела. Запросите новую на странице «Восстановление пароля».',
  },
  {
    test: (m) => m.includes('invalid') && (m.includes('token') || m.includes('link') || m.includes('code')),
    text: 'Ссылка восстановления недействительна. Запросите новую на странице «Восстановление пароля».',
  },
  {
    test: (m) => m.includes('email rate limit') || m.includes('over_email_send_rate_limit') || m.includes('rate limit'),
    text: 'Слишком много попыток. Подождите немного и попробуйте снова.',
  },
]

export function getAuthErrorMessage(error: unknown): string {
  if (!error) return 'Неизвестная ошибка. Попробуйте ещё раз.'

  // Сетевые ошибки: fetch не смог достучаться до Supabase вовсе.
  if (error instanceof TypeError || (error as MatchableError)?.name === 'AuthRetryableFetchError') {
    return 'Проблема с сетью. Проверьте подключение к интернету и попробуйте снова.'
  }

  const message = ((error as MatchableError)?.message ?? String(error)).toLowerCase()

  for (const rule of RULES) {
    if (rule.test(message)) return rule.text
  }

  return 'Неизвестная ошибка Supabase. Попробуйте ещё раз чуть позже.'
}
