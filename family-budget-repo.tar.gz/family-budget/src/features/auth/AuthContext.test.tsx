import { render, screen, waitFor } from '@testing-library/react'
import { AuthProvider, useAuth } from './AuthContext'
import { queryClient } from '@/lib/queryClient'

const { mockGetSession, mockOnAuthStateChange, mockFrom, mockSignOut } = vi.hoisted(() => ({
  mockGetSession: vi.fn(),
  mockOnAuthStateChange: vi.fn(),
  mockFrom: vi.fn(),
  mockSignOut: vi.fn(),
}))

vi.mock('@/lib/supabase', () => ({
  supabase: {
    auth: {
      getSession: mockGetSession,
      onAuthStateChange: mockOnAuthStateChange,
      signOut: mockSignOut,
    },
    from: mockFrom,
  },
}))

function Probe() {
  const { isLoading, isAuthenticated, user } = useAuth()
  if (isLoading) return <div>loading</div>
  return <div>{isAuthenticated ? `authed:${user?.email}` : 'anonymous'}</div>
}

describe('AuthProvider', () => {
  beforeEach(() => {
    mockGetSession.mockReset()
    mockOnAuthStateChange.mockReset()
    mockFrom.mockReset()
    mockOnAuthStateChange.mockReturnValue({ data: { subscription: { unsubscribe: vi.fn() } } })
    mockFrom.mockReturnValue({
      select: () => ({ eq: () => ({ single: () => Promise.resolve({ data: null, error: null }) }) }),
    })
  })

  it('показывает loading, пока не определена начальная сессия, затем anonymous при её отсутствии', async () => {
    mockGetSession.mockResolvedValue({ data: { session: null } })

    render(
      <AuthProvider>
        <Probe />
      </AuthProvider>,
    )

    expect(screen.getByText('loading')).toBeInTheDocument()
    await waitFor(() => expect(screen.getByText('anonymous')).toBeInTheDocument())
  })

  it('отражает сессию, если она уже есть при первой загрузке (без мигания на /login)', async () => {
    mockGetSession.mockResolvedValue({
      data: { session: { user: { id: 'u1', email: 'a@example.com', user_metadata: {} } } },
    })

    render(
      <AuthProvider>
        <Probe />
      </AuthProvider>,
    )

    await waitFor(() => expect(screen.getByText('authed:a@example.com')).toBeInTheDocument())
  })

  it('подписывается на onAuthStateChange и отписывается при unmount', async () => {
    mockGetSession.mockResolvedValue({ data: { session: null } })
    const unsubscribe = vi.fn()
    mockOnAuthStateChange.mockReturnValue({ data: { subscription: { unsubscribe } } })

    const { unmount } = render(
      <AuthProvider>
        <Probe />
      </AuthProvider>,
    )

    await waitFor(() => expect(mockOnAuthStateChange).toHaveBeenCalledTimes(1))
    unmount()
    expect(unsubscribe).toHaveBeenCalledTimes(1)
  })

  it('useAuth бросает понятную ошибку вне AuthProvider', () => {
    const consoleError = vi.spyOn(console, 'error').mockImplementation(() => {})
    expect(() => render(<Probe />)).toThrow('useAuth должен использоваться внутри <AuthProvider>')
    consoleError.mockRestore()
  })

  /**
   * Этап 18, п.34-36 — "User A → logout → User B" не должен унаследовать
   * чужие данные из памяти. Сам механизм (queryClient.clear() внутри
   * signOut) существует с Этапа 6/это не новое поведение этого этапа, но
   * ТЗ п.36 явно требует тест именно на этот сценарий для PWA-этапа —
   * проверяем здесь, рядом с реализацией signOut, а не изобретаем вторую
   * систему кэш-инвалидации.
   */
  it('signOut очищает весь кэш React Query (следующий пользователь не наследует чужие данные)', async () => {
    mockGetSession.mockResolvedValue({ data: { session: null } })
    mockSignOut.mockResolvedValue({ error: null })
    queryClient.setQueryData(['dashboard', 'summary', 'family-a'], { total: 12345 })
    expect(queryClient.getQueryData(['dashboard', 'summary', 'family-a'])).toBeDefined()

    function SignOutProbe() {
      const { signOut } = useAuth()
      return (
        <button type="button" onClick={() => void signOut()}>
          Выйти
        </button>
      )
    }

    render(
      <AuthProvider>
        <SignOutProbe />
      </AuthProvider>,
    )

    screen.getByRole('button', { name: 'Выйти' }).click()

    await waitFor(() => expect(mockSignOut).toHaveBeenCalledTimes(1))
    await waitFor(() =>
      expect(queryClient.getQueryData(['dashboard', 'summary', 'family-a'])).toBeUndefined(),
    )
  })
})
