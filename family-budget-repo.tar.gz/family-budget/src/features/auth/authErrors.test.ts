import { getAuthErrorMessage } from './authErrors'

/**
 * Этап 20 — до этого этапа `authErrors.ts` не имел собственного теста,
 * несмотря на то что аналогичные error-мапперы (family/notifications)
 * покрыты тестами с самого своего появления. Auth — самая высокорисковая
 * область для непроверенного маппинга сообщений.
 */
describe('getAuthErrorMessage (Этап 4, п.15 — регресс-тест Этапа 20)', () => {
  it('неверные учётные данные -> понятное сообщение', () => {
    expect(getAuthErrorMessage({ message: 'Invalid login credentials' })).toBe('Неверный email или пароль.')
  })

  it('email уже зарегистрирован -> понятное сообщение', () => {
    expect(getAuthErrorMessage({ message: 'User already registered' })).toBe(
      'Этот email уже зарегистрирован. Попробуйте войти или восстановить пароль.',
    )
  })

  it('email не подтверждён -> понятное сообщение', () => {
    expect(getAuthErrorMessage({ message: 'Email not confirmed' })).toBe(
      'Email ещё не подтверждён. Проверьте почту и перейдите по ссылке подтверждения.',
    )
  })

  it('некорректный email -> понятное сообщение', () => {
    expect(getAuthErrorMessage({ message: 'Unable to validate email address: invalid format' })).toBe(
      'Некорректный email.',
    )
  })

  it('слабый пароль -> понятное сообщение', () => {
    expect(getAuthErrorMessage({ message: 'Password should be at least 8 characters' })).toBe(
      'Пароль слишком простой или короткий — минимум 8 символов.',
    )
  })

  it('истёкшая ссылка восстановления -> понятное сообщение', () => {
    expect(getAuthErrorMessage({ message: 'Token has expired or is invalid' })).toBe(
      'Ссылка восстановления устарела. Запросите новую на странице «Восстановление пароля».',
    )
  })

  it('недействительная ссылка (code) -> понятное сообщение', () => {
    expect(getAuthErrorMessage({ message: 'invalid code' })).toBe(
      'Ссылка восстановления недействительна. Запросите новую на странице «Восстановление пароля».',
    )
  })

  it('rate limit -> понятное сообщение', () => {
    expect(getAuthErrorMessage({ message: 'Email rate limit exceeded' })).toBe(
      'Слишком много попыток. Подождите немного и попробуйте снова.',
    )
  })

  it('сетевая ошибка (TypeError) -> сообщение про сеть', () => {
    expect(getAuthErrorMessage(new TypeError('Failed to fetch'))).toBe(
      'Проблема с сетью. Проверьте подключение к интернету и попробуйте снова.',
    )
  })

  it('AuthRetryableFetchError -> сообщение про сеть', () => {
    expect(getAuthErrorMessage({ name: 'AuthRetryableFetchError', message: 'fetch failed' })).toBe(
      'Проблема с сетью. Проверьте подключение к интернету и попробуйте снова.',
    )
  })

  it('неизвестная ошибка -> общий fallback, без раскрытия технических деталей', () => {
    expect(getAuthErrorMessage({ message: 'some_unmapped_gotrue_error' })).toBe(
      'Неизвестная ошибка Supabase. Попробуйте ещё раз чуть позже.',
    )
  })

  it('пустая ошибка -> общий fallback без падения', () => {
    expect(getAuthErrorMessage(undefined)).toBe('Неизвестная ошибка. Попробуйте ещё раз.')
  })
})
