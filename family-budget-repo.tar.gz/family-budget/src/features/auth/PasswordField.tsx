import { forwardRef, useState } from 'react'
import { Eye, EyeOff } from 'lucide-react'
import { Input, type InputProps } from '@/components/ui'

/**
 * Поле пароля с переключателем видимости (Этап 4, п.19).
 * Обёртка над общим Input — своих стилей не заводим (ТЗ, п.17).
 */
export const PasswordField = forwardRef<HTMLInputElement, Omit<InputProps, 'type' | 'rightElement'>>(
  function PasswordField(props, ref) {
    const [visible, setVisible] = useState(false)

    return (
      <Input
        ref={ref}
        type={visible ? 'text' : 'password'}
        rightElement={
          <button
            type="button"
            onClick={() => setVisible((current) => !current)}
            aria-label={visible ? 'Скрыть пароль' : 'Показать пароль'}
            // p-2.5 вокруг иконки 24px (лучидовский размер по умолчанию) —
            // зона касания 44×44 (Этап 19, п.36).
            className="pointer-events-auto rounded-md p-2.5 hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            {visible ? <EyeOff aria-hidden="true" /> : <Eye aria-hidden="true" />}
          </button>
        }
        {...props}
      />
    )
  },
)
