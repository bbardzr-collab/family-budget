import { Navigate, Outlet, useLocation } from 'react-router-dom'
import { LoadingState } from '@/components/ui'
import { useAuth } from './AuthContext'

/**
 * Защита маршрутов /app/* (Этап 4, п.12).
 *
 * Не проверяет авторизацию через localStorage напрямую — опирается на
 * `isAuthenticated`/`isLoading` из AuthContext, которые, в свою очередь,
 * зеркалят реальную Supabase session (`supabase.auth.getSession()` +
 * `onAuthStateChange`). Пока начальное состояние сессии не определено,
 * показываем loading, а не редиректим — иначе возможно мигание
 * Login → App → Login при обновлении страницы.
 */
export function ProtectedRoute() {
  const { isAuthenticated, isLoading } = useAuth()
  const location = useLocation()

  if (isLoading) {
    return <LoadingState label="Проверяем вход…" className="min-h-screen" />
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace state={{ from: location }} />
  }

  return <Outlet />
}
