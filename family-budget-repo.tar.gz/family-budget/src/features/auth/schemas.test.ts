import { loginSchema, registerSchema, resetPasswordSchema } from './schemas'

/**
 * Этап 21 (security audit) — регресс-тест на верхнюю границу длины пароля.
 * До этого этапа passwordSchema не имела .max(), что позволяло отправить
 * произвольно длинную строку в форму регистрации/сброса пароля — не
 * уязвимость взлома аккаунта, а вектор бессмысленной траты ресурсов
 * bcrypt-хеширования на стороне Supabase Auth (GoTrue физически учитывает
 * только первые 72 байта пароля).
 */
describe('passwordSchema — верхняя граница длины (Этап 21)', () => {
  it('принимает пароль длиной ровно 72 символа', () => {
    const password = 'a'.repeat(72)
    const result = registerSchema.safeParse({
      fullName: 'Тест Тестов',
      email: 'test@example.com',
      password,
      confirmPassword: password,
    })
    expect(result.success).toBe(true)
  })

  it('отклоняет пароль длиннее 72 символов', () => {
    const password = 'a'.repeat(73)
    const result = registerSchema.safeParse({
      fullName: 'Тест Тестов',
      email: 'test@example.com',
      password,
      confirmPassword: password,
    })
    expect(result.success).toBe(false)
  })

  it('отклоняет экстремально длинный пароль (регресс на отсутствие верхней границы)', () => {
    const password = 'a'.repeat(10_000)
    const result = resetPasswordSchema.safeParse({ password, confirmPassword: password })
    expect(result.success).toBe(false)
  })

  it('всё ещё отклоняет пароль короче 8 символов (нижняя граница не затронута)', () => {
    const result = registerSchema.safeParse({
      fullName: 'Тест Тестов',
      email: 'test@example.com',
      password: '1234567',
      confirmPassword: '1234567',
    })
    expect(result.success).toBe(false)
  })

  it('loginSchema не проверяет длину пароля (форма входа — не создание пароля)', () => {
    const result = loginSchema.safeParse({ email: 'test@example.com', password: 'a'.repeat(200) })
    expect(result.success).toBe(true)
  })
})
