import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react'
import type { Session, User, AuthError } from '@supabase/supabase-js'
import { supabase } from '@/lib/supabase'
import { queryClient } from '@/lib/queryClient'
import type { Tables } from '@/types/database'

export type Profile = Tables<'users'>

interface AuthResult {
  error: AuthError | null
}

interface AuthContextValue {
  /** "Сырой" Supabase auth user — источник истины для id/email/metadata. */
  user: User | null
  session: Session | null
  /** Строка public.users, если она уже успела подгрузиться (может быть null даже у авторизованного user). */
  profile: Profile | null
  /**
   * true, пока не определено even первоначальное состояние сессии
   * (см. Этап 4, п.3 — нельзя допустить мигание Login → App → Login).
   */
  isLoading: boolean
  isAuthenticated: boolean
  signUp: (params: { fullName: string; email: string; password: string }) => Promise<AuthResult>
  signIn: (params: { email: string; password: string }) => Promise<AuthResult>
  signOut: () => Promise<void>
  resetPassword: (email: string) => Promise<AuthResult>
  updatePassword: (password: string) => Promise<AuthResult>
  refreshSession: () => Promise<AuthResult>
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined)

/**
 * Реальный AuthProvider на Supabase Auth (Этап 4).
 *
 * Supabase JS сам управляет хранением/обновлением токенов (localStorage под
 * капотом библиотеки, не наш собственный код) — здесь мы только подписываемся
 * на события через `onAuthStateChange` и зеркалим состояние в React. Никаких
 * собственных JWT, паролей или токенов этот провайдер не хранит и не создаёт.
 */
export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  // Первоначальная сессия + подписка на изменения (Этап 4, п.3).
  useEffect(() => {
    let mounted = true

    supabase.auth.getSession().then(({ data }) => {
      if (!mounted) return
      setSession(data.session)
      setIsLoading(false)
    })

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      if (!mounted) return
      setSession(nextSession)
      setIsLoading(false)
    })

    return () => {
      mounted = false
      subscription.unsubscribe()
    }
  }, [])

  const user = session?.user ?? null

  // Подгружаем public.users отдельно от auth-сессии — это обычная таблица
  // под RLS (users_select_self_or_family), а не часть Supabase Auth.
  // profile отдаём наружу только пока есть user (см. ниже), поэтому здесь
  // достаточно обновлять его асинхронно и не сбрасывать синхронно при выходе.
  useEffect(() => {
    if (!user) return

    let cancelled = false
    supabase
      .from('users')
      .select('*')
      .eq('id', user.id)
      .single()
      .then(({ data, error }) => {
        if (cancelled) return
        setProfile(error ? null : data)
      })

    return () => {
      cancelled = true
    }
  }, [user])

  const signUp = useCallback<AuthContextValue['signUp']>(async ({ fullName, email, password }) => {
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { full_name: fullName } },
    })
    return { error }
  }, [])

  const signIn = useCallback<AuthContextValue['signIn']>(async ({ email, password }) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    return { error }
  }, [])

  const signOut = useCallback(async () => {
    await supabase.auth.signOut()
    // Кэш React Query (семья, dashboard, ...) принадлежит вышедшему
    // пользователю — следующий вход не должен унаследовать чужие данные
    // из памяти (Этап 6, п.23: "при logout ... очищать соответствующий кэш").
    queryClient.clear()
  }, [])

  const resetPassword = useCallback<AuthContextValue['resetPassword']>(async (email) => {
    const redirectTo = `${window.location.origin}/reset-password`
    const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo })
    return { error }
  }, [])

  const updatePassword = useCallback<AuthContextValue['updatePassword']>(async (password) => {
    const { error } = await supabase.auth.updateUser({ password })
    return { error }
  }, [])

  const refreshSession = useCallback(async () => {
    const { data, error } = await supabase.auth.refreshSession()
    if (!error) setSession(data.session)
    return { error }
  }, [])

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      session,
      profile: user ? profile : null,
      isLoading,
      isAuthenticated: Boolean(session),
      signUp,
      signIn,
      signOut,
      resetPassword,
      updatePassword,
      refreshSession,
    }),
    [user, session, profile, isLoading, signUp, signIn, signOut, resetPassword, updatePassword, refreshSession],
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth должен использоваться внутри <AuthProvider>')
  }
  return context
}
