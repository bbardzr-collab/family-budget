import { z } from 'zod'

/**
 * Общие правила валидации для всех auth-форм (Этап 4, п.4).
 * Пароль намеренно не усложняем сверх минимума символов — ТЗ прямо просит
 * не усложнять требования без необходимости.
 */

const emailSchema = z.string().min(1, 'Укажите email').email('Некорректный email')
/**
 * Этап 21 (security audit, п.4/11) — верхняя граница 72 символа добавлена не
 * как усложнение требований к паролю, а как граница безопасности: Supabase
 * Auth (GoTrue) хеширует пароль через bcrypt, который физически учитывает
 * только первые 72 байта строки — всё, что длиннее, либо молча обрезается
 * при хешировании, либо (в зависимости от реализации) требует непропорционально
 * много ресурсов на хеширование произвольно длинной строки без какой-либо
 * выгоды для стойкости пароля. Без верхней границы клиент мог отправить
 * сколь угодно длинную строку (например, мегабайты) в форму регистрации/
 * сброса пароля — не уязвимость взлома аккаунта, а вектор траты ресурсов
 * сервера аутентификации на бессмысленно длинный ввод.
 */
const passwordSchema = z
  .string()
  .min(8, 'Минимум 8 символов')
  .max(72, 'Максимум 72 символа')
const fullNameSchema = z
  .string()
  .trim()
  .min(1, 'Укажите имя')
  .max(100, 'Слишком длинное имя (максимум 100 символов)')

export const registerSchema = z
  .object({
    fullName: fullNameSchema,
    email: emailSchema,
    password: passwordSchema,
    confirmPassword: z.string().min(1, 'Подтвердите пароль'),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: 'Пароли не совпадают',
    path: ['confirmPassword'],
  })

export type RegisterFormValues = z.infer<typeof registerSchema>

export const loginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1, 'Укажите пароль'),
})

export type LoginFormValues = z.infer<typeof loginSchema>

export const forgotPasswordSchema = z.object({
  email: emailSchema,
})

export type ForgotPasswordFormValues = z.infer<typeof forgotPasswordSchema>

export const resetPasswordSchema = z
  .object({
    password: passwordSchema,
    confirmPassword: z.string().min(1, 'Подтвердите пароль'),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: 'Пароли не совпадают',
    path: ['confirmPassword'],
  })

export type ResetPasswordFormValues = z.infer<typeof resetPasswordSchema>
