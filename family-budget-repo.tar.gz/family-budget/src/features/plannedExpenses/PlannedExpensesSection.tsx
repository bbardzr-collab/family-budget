import { createElement, useState } from 'react'
import { CalendarClock, CheckCircle2, ListChecks, MoreVertical, Pencil, Receipt, Trash2, XCircle } from 'lucide-react'
import { Badge, Card, CardContent, Dropdown, EmptyState, ErrorState, IconButton, Skeleton, Tabs, TabsList, TabsTrigger, Text } from '@/components/ui'
import { useToast } from '@/components/ui/Toast'
import { cn } from '@/utils/cn'
import { formatDate, toDateInputValue } from '@/utils/formatDate'
import { formatMoney } from '@/utils/formatMoney'
import { getCategoryIcon } from '@/features/categories/iconMap'
import { TransactionFormModal } from '@/features/transactions/TransactionFormModal'
import { PLANNED_EXPENSE_STATUS_BADGE_VARIANT, PLANNED_EXPENSE_STATUS_LABELS } from './labels'
import { isPlannedExpenseOverdue, sortPlannedExpenses } from './sort'
import { usePlannedExpenses, useMarkPlannedExpenseDone } from './hooks'
import { getPlannedExpenseErrorMessage } from './errors'
import { PlannedExpenseFormModal, type EditablePlannedExpense } from './PlannedExpenseFormModal'
import { DeletePlannedExpenseModal } from './DeletePlannedExpenseModal'
import { CancelPlannedExpenseModal } from './CancelPlannedExpenseModal'
import type { PlannedExpenseListItem, PlannedExpenseStatus } from './api'

type StatusFilter = 'all' | PlannedExpenseStatus

interface PlannedExpensesSectionProps {
  /** Управляется родителем (TransactionsPage) — единая кнопка "Добавить" в шапке страницы переключает поведение по активной вкладке. */
  createOpen: boolean
  onCreateClose: () => void
}

/**
 * Содержимое вкладки "План" на /app/transactions?section=plan (Этап 12).
 *
 * Планируемый расход НИКОГДА не влияет на баланс/фактические расходы/spent
 * бюджета (ТЗ, п.15-16) — это гарантируется структурно, не только по
 * соглашению: единственная точка, где из плана появляется запись в
 * transactions, — explicit-confirm форма ниже (handleAddActual →
 * TransactionFormModal с prefill), а create/update/markDone/cancel в
 * features/plannedExpenses/api.ts не содержат ни одного обращения к таблице
 * transactions или budgets.
 */
export function PlannedExpensesSection({ createOpen, onCreateClose }: PlannedExpensesSectionProps) {
  const { toast } = useToast()
  const { data: plannedExpenses, isLoading, isError, refetch } = usePlannedExpenses()
  const markDoneMutation = useMarkPlannedExpenseDone()

  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all')
  const [editingItem, setEditingItem] = useState<EditablePlannedExpense | null>(null)
  const [deletingItem, setDeletingItem] = useState<PlannedExpenseListItem | null>(null)
  const [cancellingItem, setCancellingItem] = useState<PlannedExpenseListItem | null>(null)
  const [addingActualFor, setAddingActualFor] = useState<PlannedExpenseListItem | null>(null)

  const allItems = plannedExpenses ?? []
  const sorted = sortPlannedExpenses(allItems)
  const filtered = statusFilter === 'all' ? sorted : sorted.filter((item) => item.status === statusFilter)
  const today = toDateInputValue()

  const showEmptyOverall = !isLoading && !isError && allItems.length === 0
  const showEmptyFiltered = !isLoading && !isError && !showEmptyOverall && filtered.length === 0

  async function handleMarkDone(item: PlannedExpenseListItem) {
    try {
      await markDoneMutation.mutateAsync(item.id)
      toast({ type: 'success', title: 'План отмечен как выполненный' })
    } catch (error) {
      toast({ type: 'error', title: getPlannedExpenseErrorMessage(error) })
    }
  }

  function handleSelect(item: PlannedExpenseListItem, value: string) {
    if (value === 'edit') {
      setEditingItem({
        id: item.id,
        title: item.title,
        amount: item.amount,
        plannedDate: item.plannedDate,
        categoryId: item.categoryId,
        userId: item.userId,
      })
    } else if (value === 'done') {
      void handleMarkDone(item)
    } else if (value === 'cancel') {
      setCancellingItem(item)
    } else if (value === 'add-actual') {
      setAddingActualFor(item)
    } else if (value === 'delete') {
      setDeletingItem(item)
    }
  }

  return (
    <div className="flex flex-col gap-6">
      <Tabs value={statusFilter} onValueChange={(value) => setStatusFilter(value as StatusFilter)}>
        <TabsList>
          <TabsTrigger value="all">Все</TabsTrigger>
          <TabsTrigger value="planned">Запланированные</TabsTrigger>
          <TabsTrigger value="done">Выполненные</TabsTrigger>
          <TabsTrigger value="cancelled">Отменённые</TabsTrigger>
        </TabsList>
      </Tabs>

      <Card>
        <CardContent className="pt-6">
          {isLoading && (
            <div className="flex flex-col gap-3" role="status" aria-label="Загружаем планы…">
              {[0, 1, 2].map((i) => (
                <Skeleton key={i} className="h-14 w-full" />
              ))}
            </div>
          )}

          {isError && <ErrorState title="Не удалось загрузить планы" onRetry={() => void refetch()} />}

          {showEmptyOverall && (
            <EmptyState
              icon={ListChecks}
              title="Планов пока нет"
              description="Запланируйте будущий расход, чтобы не забыть о важных покупках."
            />
          )}

          {showEmptyFiltered && <Text variant="secondary">Нет планов с этим статусом.</Text>}

          {!isLoading && !isError && filtered.length > 0 && (
            <ul className="flex flex-col divide-y divide-border">
              {filtered.map((item) => (
                <PlannedExpenseRow
                  key={item.id}
                  item={item}
                  overdue={isPlannedExpenseOverdue(item, today)}
                  onSelect={(value) => handleSelect(item, value)}
                />
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      <PlannedExpenseFormModal open={createOpen} onClose={onCreateClose} />
      <PlannedExpenseFormModal
        open={Boolean(editingItem)}
        plannedExpense={editingItem}
        onClose={() => setEditingItem(null)}
      />
      <DeletePlannedExpenseModal plannedExpense={deletingItem} onClose={() => setDeletingItem(null)} />
      <CancelPlannedExpenseModal plannedExpense={cancellingItem} onClose={() => setCancellingItem(null)} />

      {/*
        "Добавить фактический расход" (ТЗ, п.14) — открывает СУЩЕСТВУЮЩУЮ форму
        операции (TransactionFormModal) с предзаполнением, а не создаёт запись
        в transactions сама. Реальная транзакция появляется только когда
        пользователь сам нажимает "Добавить расход" внутри этой формы — то
        самое явное подтверждение, которого требует ТЗ.
      */}
      <TransactionFormModal
        open={Boolean(addingActualFor)}
        defaultType="expense"
        prefill={
          addingActualFor
            ? {
                amount: addingActualFor.amount.toFixed(2),
                categoryId: addingActualFor.categoryId,
                transactionDate: addingActualFor.plannedDate,
                comment: addingActualFor.title,
              }
            : null
        }
        onClose={() => setAddingActualFor(null)}
      />
    </div>
  )
}

const STATUS_ICON: Record<PlannedExpenseStatus, typeof CalendarClock> = {
  planned: CalendarClock,
  done: CheckCircle2,
  cancelled: XCircle,
}

function PlannedExpenseRow({
  item,
  overdue,
  onSelect,
}: {
  item: PlannedExpenseListItem
  overdue: boolean
  onSelect: (value: string) => void
}) {
  const StatusIcon = STATUS_ICON[item.status]
  const canAddActual = item.status === 'planned' || item.status === 'done'

  const dropdownItems = [
    { value: 'edit', label: 'Редактировать', icon: <Pencil /> },
    ...(item.status === 'planned' ? [{ value: 'done', label: 'Отметить «Выполнено»', icon: <CheckCircle2 /> }] : []),
    ...(item.status === 'planned' ? [{ value: 'cancel', label: 'Отменить план', icon: <XCircle /> }] : []),
    ...(canAddActual ? [{ value: 'add-actual', label: 'Добавить фактический расход', icon: <Receipt /> }] : []),
    { value: 'delete', label: 'Удалить план', icon: <Trash2 />, destructive: true },
  ]

  return (
    <li className={cn('flex items-center gap-3 py-3 first:pt-0 last:pb-0', item.status === 'cancelled' && 'opacity-70')}>
      <div
        className={cn(
          'flex size-9 shrink-0 items-center justify-center rounded-full',
          item.status === 'done' ? 'bg-success-soft text-success' : 'bg-muted text-muted-foreground',
        )}
      >
        <StatusIcon className="size-4" aria-hidden="true" />
      </div>

      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-1.5">
          <p className="truncate text-sm font-medium text-foreground">{item.title}</p>
          {overdue ? (
            <Badge variant="warning">Просрочено</Badge>
          ) : (
            <Badge variant={PLANNED_EXPENSE_STATUS_BADGE_VARIANT[item.status]}>
              {PLANNED_EXPENSE_STATUS_LABELS[item.status]}
            </Badge>
          )}
        </div>
        <p className="flex items-center gap-1 truncate text-xs text-muted-foreground">
          <span>{formatDate(item.plannedDate)}</span>
          {item.category && (
            <>
              <span aria-hidden="true">·</span>
              {createElement(getCategoryIcon(item.category.icon), { className: 'size-3 shrink-0', 'aria-hidden': true })}
              <span className="truncate">{item.category.name}</span>
            </>
          )}
        </p>
        {item.userName && <p className="truncate text-xs text-muted-foreground">Ответственный: {item.userName}</p>}
      </div>

      <span className="shrink-0 text-sm font-semibold tabular-nums text-foreground">{formatMoney(item.amount)}</span>

      <Dropdown
        trigger={<IconButton icon={MoreVertical} aria-label={`Действия с планом ${item.title}`} size="sm" />}
        items={dropdownItems}
        onSelect={onSelect}
      />
    </li>
  )
}
