import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useFamily } from '@/features/family/FamilyContext'
import { plannedExpensesKeys } from './queryKeys'
import {
  cancelPlannedExpense,
  createPlannedExpense,
  deletePlannedExpense,
  fetchPlannedExpenses,
  markPlannedExpenseDone,
  updatePlannedExpense,
  type CreatePlannedExpenseInput,
  type UpdatePlannedExpenseInput,
} from './api'

/**
 * Server state планируемых расходов — через TanStack Query (ТЗ, п.20), по
 * тому же принципу, что и features/goals/hooks.ts::useGoals. Ключ
 * параметризован familyId, поэтому переключение текущей семьи не отдаёт
 * устаревший кэш другой семьи.
 */
export function usePlannedExpenses() {
  const { currentFamily } = useFamily()
  const familyId = currentFamily?.id
  return useQuery({
    queryKey: plannedExpensesKeys.list(familyId),
    queryFn: () => fetchPlannedExpenses(familyId!),
    enabled: Boolean(familyId),
  })
}

/**
 * Инвалидация после любой мутации (ТЗ, п.20: "корректно инвалидировать
 * planned-expenses И dashboard"). Отдельного ключа для дашборда не
 * заводим — блок "Ближайшие планы" на HomePage читает те же данные через
 * usePlannedExpenses(), поэтому инвалидация plannedExpensesKeys.all
 * обновляет оба места одним и тем же кэшем (тот же принцип, что и
 * GoalsPreviewSection, разделяющий кэш с /app/goals через useGoals()).
 */
function invalidatePlannedExpenseQueries(queryClient: ReturnType<typeof useQueryClient>) {
  void queryClient.invalidateQueries({ queryKey: plannedExpensesKeys.all })
}

export function useCreatePlannedExpense() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (input: CreatePlannedExpenseInput) => createPlannedExpense(input),
    onSuccess: () => invalidatePlannedExpenseQueries(queryClient),
  })
}

export function useUpdatePlannedExpense() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (input: UpdatePlannedExpenseInput) => updatePlannedExpense(input),
    onSuccess: () => invalidatePlannedExpenseQueries(queryClient),
  })
}

export function useDeletePlannedExpense() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => deletePlannedExpense(id),
    onSuccess: () => invalidatePlannedExpenseQueries(queryClient),
  })
}

export function useMarkPlannedExpenseDone() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => markPlannedExpenseDone(id),
    onSuccess: () => invalidatePlannedExpenseQueries(queryClient),
  })
}

export function useCancelPlannedExpense() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => cancelPlannedExpense(id),
    onSuccess: () => invalidatePlannedExpenseQueries(queryClient),
  })
}
