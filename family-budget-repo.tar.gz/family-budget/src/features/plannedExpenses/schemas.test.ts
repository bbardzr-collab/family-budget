import { describe, expect, it } from 'vitest'
import { plannedExpenseFormSchema } from './schemas'

/**
 * Тесты валидации формы планируемого расхода (Этап 12, ТЗ п.6-7, 27 —
 * минимальный набор: создание — корректный план принят, отрицательная и
 * нулевая сумма запрещены, пустое название запрещено).
 */
describe('plannedExpenseFormSchema (Этап 12, п.6-7, 27)', () => {
  const base = {
    title: 'Купить холодильник',
    amount: '65000',
    plannedDate: '2026-09-25',
    categoryId: '',
    userId: '',
  }

  it('принимает корректный план без категории и ответственного', () => {
    expect(plannedExpenseFormSchema.safeParse(base).success).toBe(true)
  })

  it('принимает план с категорией и ответственным', () => {
    const result = plannedExpenseFormSchema.safeParse({ ...base, categoryId: 'cat-1', userId: 'user-1' })
    expect(result.success).toBe(true)
  })

  it('отклоняет пустое название', () => {
    const result = plannedExpenseFormSchema.safeParse({ ...base, title: '   ' })
    expect(result.success).toBe(false)
    if (!result.success) {
      expect(result.error.issues.some((i) => i.path.includes('title'))).toBe(true)
    }
  })

  it('отклоняет слишком длинное название (>100 символов)', () => {
    expect(plannedExpenseFormSchema.safeParse({ ...base, title: 'x'.repeat(101) }).success).toBe(false)
  })

  it('отклоняет нулевую и отрицательную сумму', () => {
    expect(plannedExpenseFormSchema.safeParse({ ...base, amount: '0' }).success).toBe(false)
    expect(plannedExpenseFormSchema.safeParse({ ...base, amount: '-100' }).success).toBe(false)
  })

  it('отклоняет пустую сумму', () => {
    expect(plannedExpenseFormSchema.safeParse({ ...base, amount: '' }).success).toBe(false)
  })

  it('отклоняет более 2 знаков после запятой', () => {
    expect(plannedExpenseFormSchema.safeParse({ ...base, amount: '1000.999' }).success).toBe(false)
  })

  it('нормализует запятую как десятичный разделитель и дополняет копейки', () => {
    const result = plannedExpenseFormSchema.safeParse({ ...base, amount: '1500,5' })
    expect(result.success).toBe(true)
    if (result.success) expect(result.data.amount).toBe('1500.50')
  })

  it('отклоняет сумму за пределами NUMERIC(14,2)', () => {
    expect(plannedExpenseFormSchema.safeParse({ ...base, amount: '1'.repeat(13) }).success).toBe(false)
  })

  it('принимает максимально допустимую сумму 999999999999.99 (Этап 20 — регресс-тест на границу NUMERIC(14,2))', () => {
    expect(plannedExpenseFormSchema.safeParse({ ...base, amount: '999999999999.99' }).success).toBe(true)
  })

  it('требует дату', () => {
    expect(plannedExpenseFormSchema.safeParse({ ...base, plannedDate: '' }).success).toBe(false)
  })

  it('категория и ответственный необязательны (нет ошибок при пустой строке-сентинеле)', () => {
    const result = plannedExpenseFormSchema.safeParse({ ...base, categoryId: '', userId: '' })
    expect(result.success).toBe(true)
  })
})
