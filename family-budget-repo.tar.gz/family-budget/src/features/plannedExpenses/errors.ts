/**
 * Перевод ошибок операций с планируемыми расходами в понятные человеку
 * сообщения (ТЗ, п.20) — по аналогии с features/goals/errors.ts. Ошибки
 * триггера planned_expenses_check_same_family (миграция 0028) приходят как
 * `raise exception '<CODE>: ...'`, остальное — стандартные коды
 * PostgREST/Postgres для прямых CRUD-операций.
 */

interface MatchableError {
  message?: string
  code?: string
}

export function getPlannedExpenseErrorMessage(error: unknown): string {
  if (!error) return 'Неизвестная ошибка. Попробуйте ещё раз.'

  if (error instanceof TypeError) {
    return 'Проблема с сетью. Проверьте подключение к интернету и попробуйте снова.'
  }

  const { message, code } = (error as MatchableError) ?? {}
  const text = (message ?? String(error)).toLowerCase()

  // Триггер planned_expenses_check_same_family (миграция 0028) — попытка
  // назначить ответственным участника другой семьи.
  if (text.includes('planned_expense_user_not_in_family')) {
    return 'Выбранный ответственный не состоит в этой семье.'
  }

  // Тот же триггер — попытка использовать категорию другой семьи.
  if (text.includes('planned_expense_category_not_in_family')) {
    return 'Выбранная категория недоступна для этой семьи.'
  }

  if (text.includes('no_family')) {
    return 'Сначала создайте семью или присоединитесь к ней.'
  }

  if (code === '23514' || text.includes('check constraint') || text.includes('violates check')) {
    return 'Некорректные данные плана — проверьте сумму и остальные поля.'
  }

  // RLS отклонила действие — попытка затронуть план другой семьи, или
  // недостаточно прав (CHILD пытается изменить чужой план и т.п.).
  if (text.includes('row-level security') || text.includes('policy')) {
    return 'Недостаточно прав для этого действия.'
  }

  if (code === 'PGRST116') {
    return 'План не найден или у вас нет прав на это действие.'
  }

  if (text.includes('fetch') || text.includes('network')) {
    return 'Проблема с сетью. Проверьте подключение к интернету и попробуйте снова.'
  }

  return 'Не получилось выполнить действие. Попробуйте ещё раз чуть позже.'
}
