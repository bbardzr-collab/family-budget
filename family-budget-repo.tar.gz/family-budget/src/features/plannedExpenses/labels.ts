import type { PlannedExpenseStatus } from './api'

/** Русские подписи статусов плана (ТЗ, п.4). */
export const PLANNED_EXPENSE_STATUS_LABELS: Record<PlannedExpenseStatus, string> = {
  planned: 'Запланировано',
  done: 'Выполнено',
  cancelled: 'Отменено',
}

/**
 * Варианты Badge для статусов (ТЗ, п.4: "не кричащее, спокойное" —
 * без danger/бросающихся в глаза цветов). planned — нейтральный default,
 * done — success (мягкий зелёный, как и в остальном проекте), cancelled —
 * приглушённый default, а не danger — отмена плана не является ошибкой.
 */
export const PLANNED_EXPENSE_STATUS_BADGE_VARIANT: Record<PlannedExpenseStatus, 'default' | 'success' | 'warning'> = {
  planned: 'default',
  done: 'success',
  cancelled: 'default',
}
