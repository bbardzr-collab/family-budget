import { useState } from 'react'
import { Button, Modal, Text } from '@/components/ui'
import { useToast } from '@/components/ui/Toast'
import { useCancelPlannedExpense } from './hooks'
import { getPlannedExpenseErrorMessage } from './errors'

interface CancelPlannedExpenseModalProps {
  plannedExpense: { id: string; title: string } | null
  onClose: () => void
}

/**
 * Подтверждение отмены плана (переводит planned → cancelled). В отличие от
 * удаления, запись остаётся в списке (вкладка "Отменённые") — подтверждение
 * запрашивается по тому же принципу, что и CancelGoalModal.tsx на Этапе 11,
 * т.к. это тоже необратимое (в рамках этого этапа) изменение статуса.
 */
export function CancelPlannedExpenseModal({ plannedExpense, onClose }: CancelPlannedExpenseModalProps) {
  const { toast } = useToast()
  const cancelMutation = useCancelPlannedExpense()
  const [error, setError] = useState<string | null>(null)

  async function handleConfirm() {
    if (!plannedExpense) return
    setError(null)
    try {
      await cancelMutation.mutateAsync(plannedExpense.id)
      toast({ type: 'success', title: 'План отменён' })
      onClose()
    } catch (err) {
      setError(getPlannedExpenseErrorMessage(err))
    }
  }

  function handleClose() {
    setError(null)
    onClose()
  }

  return (
    <Modal
      open={Boolean(plannedExpense)}
      onClose={handleClose}
      title="Отменить план?"
      footer={
        <>
          <Button variant="outline" onClick={handleClose}>
            Отмена
          </Button>
          <Button
            variant="destructive"
            onClick={() => void handleConfirm()}
            isLoading={cancelMutation.isPending}
            disabled={cancelMutation.isPending}
          >
            Отменить план
          </Button>
        </>
      }
    >
      <Text variant="secondary">
        {plannedExpense && `«${plannedExpense.title}» `}
        перейдёт в статус «Отменено» и больше не будет считаться активным. Запись останется в списке.
      </Text>
      {error && (
        <p role="alert" className="mt-3 text-sm text-destructive">
          {error}
        </p>
      )}
    </Modal>
  )
}
