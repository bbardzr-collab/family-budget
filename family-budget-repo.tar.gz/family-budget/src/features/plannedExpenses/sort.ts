import type { PlannedExpenseListItem } from './api'

/**
 * Сортировка списка планов (ТЗ, п.17: "по умолчанию — по дате, ближайшие
 * planned_date сверху"). planned_date у planned_expenses NOT NULL (в
 * отличие от goals.target_date), поэтому здесь нет ветки "без даты" —
 * только сравнение по planned_date, а при совпадении дат — по createdAt
 * для стабильного порядка.
 */
export function sortPlannedExpenses(items: PlannedExpenseListItem[]): PlannedExpenseListItem[] {
  return [...items].sort((a, b) => {
    const byDate = a.plannedDate.localeCompare(b.plannedDate)
    if (byDate !== 0) return byDate
    return a.createdAt.localeCompare(b.createdAt)
  })
}

/** Просрочен ли план (ТЗ, п.18): статус planned и planned_date раньше сегодня. Само по себе НЕ меняет статус. */
export function isPlannedExpenseOverdue(item: PlannedExpenseListItem, todayIsoDate: string): boolean {
  return item.status === 'planned' && item.plannedDate < todayIsoDate
}
