import { describe, expect, it } from 'vitest'
import { isPlannedExpenseOverdue, sortPlannedExpenses } from './sort'
import type { PlannedExpenseListItem } from './api'

function item(overrides: Partial<PlannedExpenseListItem> & Pick<PlannedExpenseListItem, 'id'>): PlannedExpenseListItem {
  return {
    title: 'План',
    amount: 1000,
    plannedDate: '2026-09-20',
    status: 'planned',
    userId: null,
    userName: null,
    categoryId: null,
    category: null,
    createdAt: '2026-09-01T00:00:00Z',
    ...overrides,
  }
}

describe('sortPlannedExpenses (ТЗ, п.17 — по умолчанию ближайшая дата сверху)', () => {
  it('сортирует по возрастанию planned_date', () => {
    const items = [
      item({ id: 'c', plannedDate: '2026-09-28' }),
      item({ id: 'a', plannedDate: '2026-09-20' }),
      item({ id: 'b', plannedDate: '2026-09-25' }),
    ]
    expect(sortPlannedExpenses(items).map((i) => i.id)).toEqual(['a', 'b', 'c'])
  })

  it('при совпадении дат — стабильно по createdAt', () => {
    const items = [
      item({ id: 'later', plannedDate: '2026-09-25', createdAt: '2026-09-05T00:00:00Z' }),
      item({ id: 'earlier', plannedDate: '2026-09-25', createdAt: '2026-09-01T00:00:00Z' }),
    ]
    expect(sortPlannedExpenses(items).map((i) => i.id)).toEqual(['earlier', 'later'])
  })

  it('не мутирует исходный массив', () => {
    const items = [item({ id: 'b', plannedDate: '2026-09-28' }), item({ id: 'a', plannedDate: '2026-09-20' })]
    const original = [...items]
    sortPlannedExpenses(items)
    expect(items).toEqual(original)
  })
})

describe('isPlannedExpenseOverdue (ТЗ, п.18)', () => {
  it('план со статусом planned и датой в прошлом — просрочен', () => {
    expect(isPlannedExpenseOverdue(item({ id: 'x', plannedDate: '2026-09-10', status: 'planned' }), '2026-09-21')).toBe(
      true,
    )
  })

  it('план с сегодняшней или будущей датой — не просрочен', () => {
    expect(isPlannedExpenseOverdue(item({ id: 'x', plannedDate: '2026-09-21', status: 'planned' }), '2026-09-21')).toBe(
      false,
    )
    expect(isPlannedExpenseOverdue(item({ id: 'x', plannedDate: '2026-09-25', status: 'planned' }), '2026-09-21')).toBe(
      false,
    )
  })

  it('выполненный или отменённый план из прошлого — НЕ считается просроченным (статус меняется только явным действием)', () => {
    expect(isPlannedExpenseOverdue(item({ id: 'x', plannedDate: '2026-09-01', status: 'done' }), '2026-09-21')).toBe(
      false,
    )
    expect(
      isPlannedExpenseOverdue(item({ id: 'x', plannedDate: '2026-09-01', status: 'cancelled' }), '2026-09-21'),
    ).toBe(false)
  })
})
