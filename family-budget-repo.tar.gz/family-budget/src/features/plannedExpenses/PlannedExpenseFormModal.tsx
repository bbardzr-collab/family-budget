import { createElement, useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { ChevronRight } from 'lucide-react'
import { Button, Input, Modal, Select } from '@/components/ui'
import { useToast } from '@/components/ui/Toast'
import { cn } from '@/utils/cn'
import { toDateInputValue } from '@/utils/formatDate'
import { useFamily } from '@/features/family/FamilyContext'
import { useFamilyMembers } from '@/features/family/hooks'
import { useCategories } from '@/features/categories/hooks'
import { getCategoryIcon } from '@/features/categories/iconMap'
import { CategoryPickerModal } from '@/features/categories/CategoryPickerModal'
import { plannedExpenseFormSchema, type PlannedExpenseFormValues } from './schemas'
import { useCreatePlannedExpense, useUpdatePlannedExpense } from './hooks'
import { getPlannedExpenseErrorMessage } from './errors'

/** Минимально необходимые для формы поля — общие для PlannedExpenseListItem. */
export interface EditablePlannedExpense {
  id: string
  title: string
  amount: number
  plannedDate: string
  categoryId: string | null
  userId: string | null
}

interface PlannedExpenseFormModalProps {
  open: boolean
  onClose: () => void
  /** Если передан — форма работает в режиме редактирования (ТЗ, п.9). */
  plannedExpense?: EditablePlannedExpense | null
}

function buildDefaultValues(item: EditablePlannedExpense | null | undefined): PlannedExpenseFormValues {
  if (item) {
    return {
      title: item.title,
      amount: String(item.amount),
      plannedDate: item.plannedDate,
      categoryId: item.categoryId ?? '',
      userId: item.userId ?? '',
    }
  }
  return { title: '', amount: '', plannedDate: toDateInputValue(), categoryId: '', userId: '' }
}

/**
 * Единая форма создания/редактирования планируемого расхода (ТЗ, п.6-9).
 * Категория — через существующий CategoryPickerModal (тот же UX, что и в
 * TransactionFormModal), только активные категории семьи (ТЗ, п.7).
 * Ответственный — Select с явным пунктом "Не назначен" (а не заблокированный
 * placeholder, как в Select по умолчанию) — оба состояния (назначен/не
 * назначен) должны быть одинаково доступны для выбора при редактировании.
 *
 * И категория, и ответственный формируются ТОЛЬКО из данных текущей семьи
 * (useCategories/useFamilyMembers оба уже завязаны на currentFamily) — форма
 * структурно не может предложить выбрать что-то из чужой семьи; сервер
 * (RLS + триггер planned_expenses_check_same_family, миграция 0028)
 * перепроверяет это независимо от того, что показывает форма (ТЗ, п.7:
 * "фронтенд не является границей безопасности").
 */
export function PlannedExpenseFormModal({ open, onClose, plannedExpense = null }: PlannedExpenseFormModalProps) {
  const { toast } = useToast()
  const { currentFamily } = useFamily()
  const { data: members } = useFamilyMembers(currentFamily?.id)
  const { data: categories } = useCategories()

  const isEdit = Boolean(plannedExpense)
  const createMutation = useCreatePlannedExpense()
  const updateMutation = useUpdatePlannedExpense()
  const isSubmittingMutation = createMutation.isPending || updateMutation.isPending
  const [formError, setFormError] = useState<string | null>(null)
  const [categoryPickerOpen, setCategoryPickerOpen] = useState(false)

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<PlannedExpenseFormValues>({
    resolver: zodResolver(plannedExpenseFormSchema),
    defaultValues: buildDefaultValues(plannedExpense),
  })

  // Modal не размонтируется между открытиями — пересинхронизируем форму при
  // каждом новом открытии (тот же паттерн, что и в GoalFormModal/
  // TransactionFormModal).
  useEffect(() => {
    if (open) {
      reset(buildDefaultValues(plannedExpense))
      setFormError(null)
    }
  }, [open, plannedExpense, reset])

  const categoryId = watch('categoryId')
  const selectedCategory = categories?.find((c) => c.id === categoryId) ?? null

  function handleClose() {
    setFormError(null)
    onClose()
  }

  const memberOptions = [
    { value: '', label: 'Не назначен' },
    ...(members ?? [])
      .filter((m) => m.status === 'active')
      .map((m) => ({ value: m.user_id, label: m.profile?.full_name ?? 'Без имени' })),
  ]

  const onSubmit = handleSubmit(async (values) => {
    setFormError(null)
    const categoryIdValue = values.categoryId || null
    const userIdValue = values.userId || null

    try {
      if (isEdit && plannedExpense) {
        await updateMutation.mutateAsync({
          id: plannedExpense.id,
          title: values.title,
          amount: values.amount,
          plannedDate: values.plannedDate,
          categoryId: categoryIdValue,
          userId: userIdValue,
        })
        toast({ type: 'success', title: 'План сохранён' })
      } else {
        if (!currentFamily?.id) throw new Error('NO_FAMILY')
        await createMutation.mutateAsync({
          familyId: currentFamily.id,
          title: values.title,
          amount: values.amount,
          plannedDate: values.plannedDate,
          categoryId: categoryIdValue,
          userId: userIdValue,
        })
        toast({ type: 'success', title: 'Расход запланирован' })
      }
      handleClose()
    } catch (error) {
      setFormError(getPlannedExpenseErrorMessage(error))
    }
  })

  const busy = isSubmitting || isSubmittingMutation

  return (
    <Modal open={open} onClose={handleClose} title={isEdit ? 'Редактировать план' : 'Запланировать расход'}>
      <form className="flex flex-col gap-4" onSubmit={onSubmit} noValidate>
        <Input
          label="Название"
          placeholder="Например, Купить холодильник"
          autoComplete="off"
          error={errors.title?.message}
          {...register('title')}
        />

        <Input
          label="Сумма"
          inputMode="decimal"
          placeholder="0"
          autoComplete="off"
          error={errors.amount?.message}
          {...register('amount')}
        />

        <Input label="Дата" type="date" error={errors.plannedDate?.message} {...register('plannedDate')} />

        <div className="flex flex-col gap-1.5">
          <span className="text-sm font-medium text-foreground">Категория</span>
          <button
            type="button"
            onClick={() => setCategoryPickerOpen(true)}
            className={cn(
              'flex h-11 items-center gap-2 rounded-md border border-input bg-card px-3 text-left text-base text-foreground transition-colors',
              'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
            )}
          >
            <span className="flex size-6 shrink-0 items-center justify-center rounded-full bg-muted text-muted-foreground">
              {createElement(getCategoryIcon(selectedCategory?.icon), { className: 'size-3.5', 'aria-hidden': true })}
            </span>
            <span className="min-w-0 flex-1 truncate">
              {selectedCategory ? selectedCategory.name : 'Без категории'}
            </span>
            <ChevronRight className="size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
          </button>
        </div>

        <Select
          label="Ответственный"
          helperText="Необязательно"
          options={memberOptions}
          error={errors.userId?.message}
          {...register('userId')}
        />

        {formError && (
          <p role="alert" className="text-sm text-destructive">
            {formError}
          </p>
        )}

        <Button type="submit" size="lg" isLoading={busy} disabled={busy}>
          {isEdit ? 'Сохранить' : 'Запланировать'}
        </Button>
      </form>

      <CategoryPickerModal
        open={categoryPickerOpen}
        onClose={() => setCategoryPickerOpen(false)}
        categories={categories ?? []}
        selectedCategoryId={categoryId || null}
        onSelect={(nextCategoryId) => setValue('categoryId', nextCategoryId ?? '', { shouldValidate: true })}
      />
    </Modal>
  )
}
