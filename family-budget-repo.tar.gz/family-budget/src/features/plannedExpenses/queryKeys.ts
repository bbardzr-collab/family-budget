/**
 * Единый источник ключей React Query для домена "планируемые расходы"
 * (Этап 12, п.20) — параметризован familyId по тому же принципу, что
 * budgetsKeys.summary(familyId, periodMonth), т.к. список зависит от
 * текущей семьи.
 */
export const plannedExpensesKeys = {
  all: ['planned-expenses'] as const,
  list: (familyId: string | undefined) => [...plannedExpensesKeys.all, 'list', familyId] as const,
}
