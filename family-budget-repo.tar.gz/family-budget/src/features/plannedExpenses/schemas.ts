import { z } from 'zod'

/**
 * Валидация формы планируемого расхода (Этап 12, п.6-7). Локальная копия
 * нормализации суммы — тот же паттерн самодостаточности фичи, что уже
 * применён в features/budgets/schemas.ts, features/transactions/schemas.ts
 * и features/goals/schemas.ts (никакого cross-feature импорта, никакого
 * умножения/деления на 100 и никакого parseFloat на промежуточном шаге —
 * только строковые операции, чтобы не словить типичные JS float-баги).
 */
function normalizeAmountString(value: string): string {
  const [intPart, decPart = ''] = value.split('.')
  const cents = decPart.padEnd(2, '0').slice(0, 2)
  return `${intPart}.${cents}`
}

// До 12 цифр целой части + опционально точка и 1-2 цифры дробной — ровно
// граница NUMERIC(14,2), тот же паттерн, что и в остальных денежных полях.
const AMOUNT_PATTERN = /^\d{1,12}(\.\d{1,2})?$/

export const plannedExpenseAmountSchema = z
  .string()
  .trim()
  .min(1, 'Введите сумму')
  .transform((value) => value.replace(',', '.'))
  .refine((value) => AMOUNT_PATTERN.test(value), {
    message: 'Введите сумму числом, например 15000 или 15000,50',
  })
  .refine((value) => !/^0+(\.0{1,2})?$/.test(value), {
    message: 'Сумма должна быть больше нуля',
  })
  .transform((value) => normalizeAmountString(value))

/**
 * Форма создания/редактирования планируемого расхода (ТЗ, п.6-7).
 * categoryId/userId — '' сентинел "не выбрано" (то же решение, что
 * categoryId в transactionFormSchema и ownerUserId в goalFormSchema) —
 * category_id/user_id в БД nullable именно для этого случая, отдельная
 * проверка "принадлежит текущей семье" (п.7) обеспечивается не здесь, а
 * тем, что опции селектов формируются только из категорий/участников
 * ТЕКУЩЕЙ семьи (см. PlannedExpenseFormModal.tsx), и продублирована на
 * сервере триггером planned_expenses_check_same_family (миграция 0028) —
 * фронтенд не является границей безопасности.
 */
export const plannedExpenseFormSchema = z.object({
  title: z
    .string()
    .trim()
    .min(1, 'Введите название')
    .max(100, 'Название слишком длинное — максимум 100 символов'),
  amount: plannedExpenseAmountSchema,
  plannedDate: z.string().min(1, 'Укажите дату'),
  categoryId: z.string().optional().or(z.literal('')),
  userId: z.string().optional().or(z.literal('')),
})

export type PlannedExpenseFormValues = z.infer<typeof plannedExpenseFormSchema>
