import { fireEvent, render, screen, within } from '@testing-library/react'
import { ToastProvider } from '@/components/ui/Toast'
import { PlannedExpensesSection } from './PlannedExpensesSection'
import type { PlannedExpenseListItem } from './api'

const {
  mockUsePlannedExpenses,
  mockCreateMutateAsync,
  mockUpdateMutateAsync,
  mockDeleteMutateAsync,
  mockMarkDoneMutateAsync,
  mockCancelMutateAsync,
  mockUseFamily,
  mockUseFamilyMembers,
  mockUseCategories,
  mockCreateTransactionMutateAsync,
} = vi.hoisted(() => ({
  mockUsePlannedExpenses: vi.fn(),
  mockCreateMutateAsync: vi.fn(),
  mockUpdateMutateAsync: vi.fn(),
  mockDeleteMutateAsync: vi.fn(),
  mockMarkDoneMutateAsync: vi.fn(),
  mockCancelMutateAsync: vi.fn(),
  mockUseFamily: vi.fn(),
  mockUseFamilyMembers: vi.fn(),
  mockUseCategories: vi.fn(),
  mockCreateTransactionMutateAsync: vi.fn(),
}))

vi.mock('./hooks', () => ({
  usePlannedExpenses: mockUsePlannedExpenses,
  useCreatePlannedExpense: () => ({ mutateAsync: mockCreateMutateAsync, isPending: false }),
  useUpdatePlannedExpense: () => ({ mutateAsync: mockUpdateMutateAsync, isPending: false }),
  useDeletePlannedExpense: () => ({ mutateAsync: mockDeleteMutateAsync, isPending: false }),
  useMarkPlannedExpenseDone: () => ({ mutateAsync: mockMarkDoneMutateAsync, isPending: false }),
  useCancelPlannedExpense: () => ({ mutateAsync: mockCancelMutateAsync, isPending: false }),
}))

vi.mock('@/features/family/FamilyContext', () => ({
  useFamily: mockUseFamily,
}))

vi.mock('@/features/family/hooks', () => ({
  useFamilyMembers: mockUseFamilyMembers,
}))

vi.mock('@/features/categories/hooks', () => ({
  useCategories: mockUseCategories,
}))

// TransactionFormModal (используется для "Добавить фактический расход",
// ТЗ п.14) — мокаем создание операции на той же границе, что и в
// HomePage.test.tsx/TransactionFormModal.test.tsx, чтобы проверить: открытие
// формы с prefill само по себе НЕ создаёт транзакцию.
vi.mock('@/features/transactions/hooks', () => ({
  useCreateTransaction: () => ({ mutateAsync: mockCreateTransactionMutateAsync, isPending: false }),
  useUpdateTransaction: () => ({ mutateAsync: vi.fn(), isPending: false }),
}))

const CATEGORIES = [
  { id: 'cat-1', name: 'Покупки', type: 'WANTS' as const, icon: 'shopping-cart', isActive: true, isCustom: false },
]

const MEMBERS = [{ user_id: 'user-1', status: 'active', profile: { id: 'user-1', full_name: 'Иван', avatar_url: null } }]

// Этап 21 (security audit) — тот же регресс-фикс на дату-хрупкость, что и в
// RecurringTransactionsSection.test.tsx: литерал '2026-09-25' был в будущем
// только на момент написания теста (Этап 12), к прогону на Этапе 21 уже стал
// прошлым и ломал ожидание статуса "Запланировано". Вычисляем дату на
// несколько лет вперёд от реального "сегодня", чтобы `npm run test` не
// зависел от даты запуска.
const FAR_FUTURE_DATE_OBJ = (() => {
  const d = new Date()
  d.setFullYear(d.getFullYear() + 5)
  return d
})()
// Собираем 'YYYY-MM-DD' и 'DD.MM.YYYY' из ОДНИХ И ТЕХ ЖЕ локальных
// компонентов даты (getDate/getMonth/getFullYear), а не через toISOString()
// (который переводит в UTC и мог бы на сутки разойтись с локальным
// календарным днём в зависимости от часового пояса/времени запуска теста).
const FAR_FUTURE_Y = FAR_FUTURE_DATE_OBJ.getFullYear()
const FAR_FUTURE_M = String(FAR_FUTURE_DATE_OBJ.getMonth() + 1).padStart(2, '0')
const FAR_FUTURE_D = String(FAR_FUTURE_DATE_OBJ.getDate()).padStart(2, '0')
const FAR_FUTURE_DATE = `${FAR_FUTURE_Y}-${FAR_FUTURE_M}-${FAR_FUTURE_D}`
// DD.MM.YYYY — тот же формат, что и formatDate() в самом компоненте.
const FAR_FUTURE_DATE_FORMATTED = `${FAR_FUTURE_D}.${FAR_FUTURE_M}.${FAR_FUTURE_Y}`

function makePlan(overrides: Partial<PlannedExpenseListItem> = {}): PlannedExpenseListItem {
  return {
    id: 'plan-1',
    title: 'Купить холодильник',
    amount: 65000,
    plannedDate: FAR_FUTURE_DATE,
    status: 'planned',
    userId: null,
    userName: null,
    categoryId: 'cat-1',
    category: { id: 'cat-1', name: 'Покупки', icon: 'shopping-cart', isActive: true },
    createdAt: '2026-09-01T00:00:00Z',
    ...overrides,
  }
}

function renderSection(props: Partial<React.ComponentProps<typeof PlannedExpensesSection>> = {}) {
  return render(
    <ToastProvider>
      <PlannedExpensesSection createOpen={false} onCreateClose={vi.fn()} {...props} />
    </ToastProvider>,
  )
}

describe('PlannedExpensesSection (Этап 12)', () => {
  beforeEach(() => {
    // Без vi.useFakeTimers() — как и GoalsPage.test.tsx, чьи диалоги/мутации
    // построены по тому же принципу (Dropdown → Modal → mutateAsync → toast):
    // fireEvent.click + await screen.findByText(...) сами по себе прекрасно
    // работают с реальными таймерами, а подмена системного времени здесь не
    // нужна — просроченность плана ниже проверяется через даты, заведомо
    // далёкие в прошлом/будущем от любого реального "сегодня".
    mockUseFamily.mockReturnValue({ currentFamily: { id: 'family-1' } })
    mockUseFamilyMembers.mockReturnValue({ data: MEMBERS, isLoading: false })
    mockUseCategories.mockReturnValue({ data: CATEGORIES, isLoading: false, isError: false })
    mockCreateMutateAsync.mockReset().mockResolvedValue({})
    mockUpdateMutateAsync.mockReset().mockResolvedValue({})
    mockDeleteMutateAsync.mockReset().mockResolvedValue(undefined)
    mockMarkDoneMutateAsync.mockReset().mockResolvedValue(undefined)
    mockCancelMutateAsync.mockReset().mockResolvedValue(undefined)
    mockCreateTransactionMutateAsync.mockReset().mockResolvedValue({})
  })

  it('пустое состояние: "Планов пока нет" (ТЗ, п.21)', () => {
    mockUsePlannedExpenses.mockReturnValue({ data: [], isLoading: false, isError: false, refetch: vi.fn() })

    renderSection()

    expect(screen.getByText('Планов пока нет')).toBeInTheDocument()
    expect(
      screen.getByText('Запланируйте будущий расход, чтобы не забыть о важных покупках.'),
    ).toBeInTheDocument()
  })

  it('показывает строку плана с названием/суммой/датой/категорией/статусом (пример ТЗ)', () => {
    mockUsePlannedExpenses.mockReturnValue({
      data: [makePlan()],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderSection()

    expect(screen.getByText('Купить холодильник')).toBeInTheDocument()
    expect(screen.getByText('65 000 ₽')).toBeInTheDocument()
    expect(screen.getByText(FAR_FUTURE_DATE_FORMATTED)).toBeInTheDocument()
    expect(screen.getByText('Покупки')).toBeInTheDocument()
    expect(screen.getByText('Запланировано')).toBeInTheDocument()
  })

  it('просроченный план (planned + дата в прошлом) показывает индикатор "Просрочено", статус НЕ меняется автоматически (ТЗ, п.18)', () => {
    mockUsePlannedExpenses.mockReturnValue({
      data: [makePlan({ id: 'plan-overdue', plannedDate: '2026-09-10', status: 'planned' })],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderSection()

    expect(screen.getByText('Просрочено')).toBeInTheDocument()
    expect(screen.queryByText('Запланировано')).not.toBeInTheDocument()
    expect(mockMarkDoneMutateAsync).not.toHaveBeenCalled()
    expect(mockCancelMutateAsync).not.toHaveBeenCalled()
  })

  it('фильтр по статусу показывает только выбранный статус', () => {
    mockUsePlannedExpenses.mockReturnValue({
      data: [
        makePlan({ id: 'p1', title: 'Запланирован', status: 'planned' }),
        makePlan({ id: 'p2', title: 'Выполнен', status: 'done' }),
        makePlan({ id: 'p3', title: 'Отменён', status: 'cancelled' }),
      ],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderSection()

    expect(screen.getByText('Запланирован')).toBeInTheDocument()
    expect(screen.getByText('Выполнен')).toBeInTheDocument()
    expect(screen.getByText('Отменён')).toBeInTheDocument()

    fireEvent.click(screen.getByRole('tab', { name: 'Выполненные' }))

    expect(screen.queryByText('Запланирован')).not.toBeInTheDocument()
    expect(screen.getByText('Выполнен')).toBeInTheDocument()
    expect(screen.queryByText('Отменён')).not.toBeInTheDocument()
  })

  it('"Отметить «Выполнено»" вызывает мутацию сразу, без диалога подтверждения', async () => {
    mockUsePlannedExpenses.mockReturnValue({
      data: [makePlan()],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderSection()

    fireEvent.click(screen.getByRole('button', { name: /Действия с планом/i }))
    fireEvent.click(screen.getByRole('menuitem', { name: 'Отметить «Выполнено»' }))

    expect(await screen.findByText('План отмечен как выполненный')).toBeInTheDocument()
    expect(mockMarkDoneMutateAsync).toHaveBeenCalledWith('plan-1')
  })

  it('"Отменить план" показывает диалог подтверждения и вызывает мутацию (planned → cancelled)', async () => {
    mockUsePlannedExpenses.mockReturnValue({
      data: [makePlan()],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderSection()

    fireEvent.click(screen.getByRole('button', { name: /Действия с планом/i }))
    fireEvent.click(screen.getByRole('menuitem', { name: 'Отменить план' }))

    const dialog = screen.getByRole('dialog', { name: 'Отменить план?' })
    fireEvent.click(within(dialog).getByRole('button', { name: 'Отменить план' }))

    expect(await screen.findByText('План отменён')).toBeInTheDocument()
    expect(mockCancelMutateAsync).toHaveBeenCalledWith('plan-1')
  })

  it('удаление плана требует подтверждения и вызывает мутацию (ТЗ, п.11)', async () => {
    mockUsePlannedExpenses.mockReturnValue({
      data: [makePlan()],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderSection()

    fireEvent.click(screen.getByRole('button', { name: /Действия с планом/i }))
    fireEvent.click(screen.getByRole('menuitem', { name: 'Удалить план' }))

    const dialog = screen.getByRole('dialog', { name: 'Удалить план?' })
    expect(dialog.textContent).toContain('«Купить холодильник»')
    fireEvent.click(within(dialog).getByRole('button', { name: 'Удалить' }))

    expect(await screen.findByText('План удалён')).toBeInTheDocument()
    expect(mockDeleteMutateAsync).toHaveBeenCalledWith('plan-1')
  })

  it('редактирование: форма предзаполнена, сабмит вызывает мутацию обновления', async () => {
    mockUsePlannedExpenses.mockReturnValue({
      data: [makePlan()],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderSection()

    fireEvent.click(screen.getByRole('button', { name: /Действия с планом/i }))
    fireEvent.click(screen.getByRole('menuitem', { name: 'Редактировать' }))

    const dialog = screen.getByRole('dialog', { name: 'Редактировать план' })
    expect(within(dialog).getByLabelText('Название')).toHaveValue('Купить холодильник')
    expect(within(dialog).getByLabelText('Сумма')).toHaveValue('65000')

    fireEvent.click(within(dialog).getByRole('button', { name: 'Сохранить' }))

    expect(await screen.findByText('План сохранён')).toBeInTheDocument()
    expect(mockUpdateMutateAsync).toHaveBeenCalledWith(
      expect.objectContaining({ id: 'plan-1', title: 'Купить холодильник' }),
    )
  })

  it('создание: пустое название и нулевая сумма отклоняются валидацией (ТЗ, п.27)', async () => {
    mockUsePlannedExpenses.mockReturnValue({ data: [], isLoading: false, isError: false, refetch: vi.fn() })

    renderSection({ createOpen: true })

    const dialog = screen.getByRole('dialog', { name: 'Запланировать расход' })
    fireEvent.change(within(dialog).getByLabelText('Сумма'), { target: { value: '0' } })
    fireEvent.click(within(dialog).getByRole('button', { name: 'Запланировать' }))

    expect(await within(dialog).findByText('Введите название')).toBeInTheDocument()
    expect(within(dialog).getByText('Сумма должна быть больше нуля')).toBeInTheDocument()
    expect(mockCreateMutateAsync).not.toHaveBeenCalled()
  })

  it('создание: корректные данные вызывают мутацию создания с familyId текущей семьи', async () => {
    mockUsePlannedExpenses.mockReturnValue({ data: [], isLoading: false, isError: false, refetch: vi.fn() })

    renderSection({ createOpen: true })

    const dialog = screen.getByRole('dialog', { name: 'Запланировать расход' })
    fireEvent.change(within(dialog).getByLabelText('Название'), { target: { value: 'Страховка' } })
    fireEvent.change(within(dialog).getByLabelText('Сумма'), { target: { value: '12000' } })
    fireEvent.change(within(dialog).getByLabelText('Дата'), { target: { value: '2026-09-28' } })
    fireEvent.click(within(dialog).getByRole('button', { name: 'Запланировать' }))

    expect(await screen.findByText('Расход запланирован')).toBeInTheDocument()
    expect(mockCreateMutateAsync).toHaveBeenCalledWith(
      expect.objectContaining({
        familyId: 'family-1',
        title: 'Страховка',
        amount: '12000.00',
        plannedDate: '2026-09-28',
        categoryId: null,
        userId: null,
      }),
    )
  })

  it('"Добавить фактический расход" открывает существующую форму операции с предзаполнением и НЕ создаёт транзакцию сама по себе (ТЗ, п.14)', async () => {
    mockUsePlannedExpenses.mockReturnValue({
      data: [makePlan()],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderSection()

    fireEvent.click(screen.getByRole('button', { name: /Действия с планом/i }))
    fireEvent.click(screen.getByRole('menuitem', { name: 'Добавить фактический расход' }))

    const dialog = screen.getByRole('dialog', { name: 'Добавить операцию' })
    // Открытие формы само по себе не создало запись — только предзаполнило.
    expect(mockCreateTransactionMutateAsync).not.toHaveBeenCalled()
    expect(within(dialog).getByLabelText('Сумма')).toHaveValue('65000.00')
    expect(within(dialog).getByLabelText('Комментарий')).toHaveValue('Купить холодильник')
    expect(within(dialog).getByRole('button', { name: /покупки/i })).toBeInTheDocument()

    // Явное подтверждение пользователя — вот единственный момент, когда
    // появляется запись в transactions.
    fireEvent.click(within(dialog).getByRole('button', { name: /добавить расход/i }))

    expect(await screen.findByText('Расход добавлен')).toBeInTheDocument()
    expect(mockCreateTransactionMutateAsync).toHaveBeenCalledWith(
      expect.objectContaining({ amount: '65000.00', categoryId: 'cat-1', comment: 'Купить холодильник' }),
    )
    // Статус плана не был затронут этим действием (никакой мутации над планом).
    expect(mockMarkDoneMutateAsync).not.toHaveBeenCalled()
  })

  it('"Добавить фактический расход" недоступно для отменённого плана', () => {
    mockUsePlannedExpenses.mockReturnValue({
      data: [makePlan({ status: 'cancelled' })],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderSection()

    fireEvent.click(screen.getByRole('button', { name: /Действия с планом/i }))
    expect(screen.queryByRole('menuitem', { name: 'Добавить фактический расход' })).not.toBeInTheDocument()
    expect(screen.queryByRole('menuitem', { name: 'Отметить «Выполнено»' })).not.toBeInTheDocument()
    expect(screen.queryByRole('menuitem', { name: 'Отменить план' })).not.toBeInTheDocument()
  })
})
