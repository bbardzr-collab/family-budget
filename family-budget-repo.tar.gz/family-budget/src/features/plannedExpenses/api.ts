import { supabase } from '@/lib/supabase'

/**
 * Тонкий слой доступа к данным планируемых расходов (Этап 12) — только
 * запросы, никакой бизнес-логики и никакого React, по аналогии с
 * features/transactions/api.ts и features/goals/api.ts.
 *
 * Таблица planned_expenses существует без изменений с Этапа 3 — здесь нет
 * ни одной новой RPC-функции: create/update/delete/markDone/cancel идут
 * напрямую через Supabase поверх RLS (миграции 0010 + 0028), тем же
 * принципом, что и transactions/categories/budgets (простые однотабличные
 * операции без производных агрегатов не нуждаются в отдельном RPC — граница
 * безопасности — RLS + триггер planned_expenses_check_same_family,
 * см. миграцию 0028).
 *
 * family_id/user_id ПРИХОДЯТ с клиента при создании (как и в transactions,
 * см. комментарий в features/transactions/api.ts) — это структурно
 * безопасно: RLS отклонит INSERT, если family_id не является семьёй
 * вызывающего (is_family_member) или user_id не проходит требования
 * planned_expenses_insert_family, а триггер дополнительно проверяет, что
 * назначенные user_id/category_id реально принадлежат той же семье.
 */

export type PlannedExpenseStatus = 'planned' | 'done' | 'cancelled'

export interface PlannedExpenseCategory {
  id: string
  name: string
  icon: string | null
  isActive: boolean
}

export interface PlannedExpenseListItem {
  id: string
  title: string
  amount: number
  plannedDate: string
  status: PlannedExpenseStatus
  userId: string | null
  /** Имя ответственного — null, если не назначен или профиль недоступен. */
  userName: string | null
  categoryId: string | null
  category: PlannedExpenseCategory | null
  createdAt: string
}

interface PlannedExpenseQueryRow {
  id: string
  title: string
  amount: number
  planned_date: string
  status: string
  user_id: string | null
  assignee: { id: string; full_name: string | null } | null
  category_id: string | null
  category: { id: string; name: string; icon: string | null; is_active: boolean } | null
  created_at: string
}

function mapRow(row: PlannedExpenseQueryRow): PlannedExpenseListItem {
  return {
    id: row.id,
    title: row.title,
    amount: row.amount,
    plannedDate: row.planned_date,
    status: row.status as PlannedExpenseStatus,
    userId: row.user_id,
    userName: row.assignee?.full_name ?? null,
    categoryId: row.category_id,
    category: row.category
      ? { id: row.category.id, name: row.category.name, icon: row.category.icon, isActive: row.category.is_active }
      : null,
    createdAt: row.created_at,
  }
}

// assignee:users(...) — то же имя-алиас embedded-связи, что и user:users(...)
// в features/transactions/api.ts, переименовано в assignee только чтобы не
// путать с полем user_id рядом; category — тот же паттерн, что и там же.
const SELECT_FIELDS =
  'id, title, amount, planned_date, status, user_id, assignee:users(id, full_name), category_id, category:categories(id, name, icon, is_active), created_at'

/** Полный список планируемых расходов семьи для /app/transactions (вкладка «План»). */
export async function fetchPlannedExpenses(familyId: string): Promise<PlannedExpenseListItem[]> {
  const { data, error } = await supabase
    .from('planned_expenses')
    .select(SELECT_FIELDS)
    .eq('family_id', familyId)
    .order('planned_date', { ascending: true })
    .order('created_at', { ascending: true })

  if (error) throw error
  return ((data ?? []) as unknown as PlannedExpenseQueryRow[]).map(mapRow)
}

export interface CreatePlannedExpenseInput {
  familyId: string
  title: string
  /** Нормализованная строка с ровно 2 знаками после точки, см. schemas.ts. */
  amount: string
  plannedDate: string
  categoryId: string | null
  userId: string | null
}

export async function createPlannedExpense(input: CreatePlannedExpenseInput): Promise<PlannedExpenseListItem> {
  const { data, error } = await supabase
    .from('planned_expenses')
    .insert({
      family_id: input.familyId,
      title: input.title,
      amount: input.amount as unknown as number,
      planned_date: input.plannedDate,
      category_id: input.categoryId,
      user_id: input.userId,
    })
    .select(SELECT_FIELDS)
    .single()

  if (error) throw error
  return mapRow(data as unknown as PlannedExpenseQueryRow)
}

export interface UpdatePlannedExpenseInput {
  id: string
  title: string
  amount: string
  plannedDate: string
  categoryId: string | null
  userId: string | null
}

export async function updatePlannedExpense(input: UpdatePlannedExpenseInput): Promise<PlannedExpenseListItem> {
  const { data, error } = await supabase
    .from('planned_expenses')
    .update({
      title: input.title,
      amount: input.amount as unknown as number,
      planned_date: input.plannedDate,
      category_id: input.categoryId,
      user_id: input.userId,
      // family_id здесь намеренно отсутствует — редактирование не может
      // сменить семью плана (тот же принцип, что и в updateTransaction).
    })
    .eq('id', input.id)
    .select(SELECT_FIELDS)
    .single()

  if (error) throw error
  return mapRow(data as unknown as PlannedExpenseQueryRow)
}

/**
 * Удаление плана (ТЗ, п.11) — planned_expenses не имеет ни одной FK-связи
 * с transactions/categories/budgets/goals в направлении "от них к плану",
 * поэтому удаление плана структурно не может затронуть ни одну из этих
 * таблиц (единственная связь — planned_expenses.category_id → categories,
 * которая ничего не удаляет при удалении плана в обратную сторону).
 */
export async function deletePlannedExpense(id: string): Promise<void> {
  const { error, count } = await supabase.from('planned_expenses').delete({ count: 'exact' }).eq('id', id)
  if (error) throw error
  if (!count) {
    throw { message: 'План не найден или у вас нет прав его удалить.', code: 'PGRST116' }
  }
}

/**
 * "Выполнено" (ТЗ, п.12) — переводит статус planned → done. НИКОГДА не
 * создаёт запись в transactions (это отдельное явное действие пользователя,
 * см. п.13 и PlannedExpensesSection.tsx) — здесь буквально нет ни одного
 * обращения к таблице transactions.
 */
export async function markPlannedExpenseDone(id: string): Promise<void> {
  const { data, error } = await supabase
    .from('planned_expenses')
    .update({ status: 'done' })
    .eq('id', id)
    .eq('status', 'planned')
    .select('id')
    .single()

  if (error) throw error
  if (!data) {
    throw { message: 'План не найден, уже не активен, или у вас нет прав его изменить.', code: 'PGRST116' }
  }
}

/** Отмена плана (ТЗ, п.4) — planned → cancelled. */
export async function cancelPlannedExpense(id: string): Promise<void> {
  const { data, error } = await supabase
    .from('planned_expenses')
    .update({ status: 'cancelled' })
    .eq('id', id)
    .eq('status', 'planned')
    .select('id')
    .single()

  if (error) throw error
  if (!data) {
    throw { message: 'План не найден, уже не активен, или у вас нет прав его отменить.', code: 'PGRST116' }
  }
}
