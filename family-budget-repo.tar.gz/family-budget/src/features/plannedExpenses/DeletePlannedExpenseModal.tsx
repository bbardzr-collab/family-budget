import { useState } from 'react'
import { Button, Modal, Text } from '@/components/ui'
import { useToast } from '@/components/ui/Toast'
import { formatMoney } from '@/utils/formatMoney'
import { useDeletePlannedExpense } from './hooks'
import { getPlannedExpenseErrorMessage } from './errors'

interface DeletePlannedExpenseModalProps {
  plannedExpense: { id: string; title: string; amount: number } | null
  onClose: () => void
}

/**
 * Подтверждение удаления плана (ТЗ, п.11: "перед удалением обязательно
 * требовать подтверждение"). Удаление planned_expenses структурно не может
 * затронуть transactions/categories/budgets/goals — см. комментарий над
 * deletePlannedExpense в api.ts.
 */
export function DeletePlannedExpenseModal({ plannedExpense, onClose }: DeletePlannedExpenseModalProps) {
  const { toast } = useToast()
  const deleteMutation = useDeletePlannedExpense()
  const [error, setError] = useState<string | null>(null)

  async function handleConfirm() {
    if (!plannedExpense) return
    setError(null)
    try {
      await deleteMutation.mutateAsync(plannedExpense.id)
      toast({ type: 'success', title: 'План удалён' })
      onClose()
    } catch (err) {
      setError(getPlannedExpenseErrorMessage(err))
    }
  }

  function handleClose() {
    setError(null)
    onClose()
  }

  return (
    <Modal
      open={Boolean(plannedExpense)}
      onClose={handleClose}
      title="Удалить план?"
      footer={
        <>
          <Button variant="outline" onClick={handleClose}>
            Отмена
          </Button>
          <Button
            variant="destructive"
            onClick={() => void handleConfirm()}
            isLoading={deleteMutation.isPending}
            disabled={deleteMutation.isPending}
          >
            Удалить
          </Button>
        </>
      }
    >
      <Text variant="secondary">
        {plannedExpense && `«${plannedExpense.title}» на сумму ${formatMoney(plannedExpense.amount)} `}
        будет удалён без возможности восстановления. На операции, категории и бюджет это не повлияет.
      </Text>
      {error && (
        <p role="alert" className="mt-3 text-sm text-destructive">
          {error}
        </p>
      )}
    </Modal>
  )
}
