import { useState } from 'react'
import { Button, Modal, Text } from '@/components/ui'
import { useToast } from '@/components/ui/Toast'
import { useDeleteBudget } from './hooks'
import { getBudgetErrorMessage } from './errors'
import type { BudgetInfo } from './api'

interface DeleteBudgetModalProps {
  budget: BudgetInfo | null
  /** "сентябрь 2026" (строчными буквами, см. period.ts::formatPeriodMonthLower) — для точного текста ТЗ, п.19. */
  periodMonthLabelLower: string
  onClose: () => void
}

/**
 * Подтверждение удаления бюджета месяца (ТЗ, п.19) — текст диалога подобран
 * дословно под требование ТЗ: "Удалить бюджет за сентябрь 2026? История
 * операций не будет удалена.". budget_categories удаляются каскадом на
 * уровне схемы (ON DELETE CASCADE), transactions/categories/users/family не
 * затрагиваются вообще (см. deleteBudget в api.ts).
 */
export function DeleteBudgetModal({ budget, periodMonthLabelLower, onClose }: DeleteBudgetModalProps) {
  const { toast } = useToast()
  const deleteBudgetMutation = useDeleteBudget()
  const [error, setError] = useState<string | null>(null)

  async function handleConfirm() {
    if (!budget) return
    setError(null)
    try {
      await deleteBudgetMutation.mutateAsync(budget.id)
      toast({ type: 'success', title: 'Бюджет удалён' })
      onClose()
    } catch (err) {
      setError(getBudgetErrorMessage(err))
    }
  }

  function handleClose() {
    setError(null)
    onClose()
  }

  return (
    <Modal
      open={Boolean(budget)}
      onClose={handleClose}
      title={`Удалить бюджет за ${periodMonthLabelLower}?`}
      footer={
        <>
          <Button variant="outline" onClick={handleClose}>
            Отмена
          </Button>
          <Button
            variant="destructive"
            onClick={() => void handleConfirm()}
            isLoading={deleteBudgetMutation.isPending}
            disabled={deleteBudgetMutation.isPending}
          >
            Удалить
          </Button>
        </>
      }
    >
      <Text variant="secondary">История операций не будет удалена.</Text>
      {error && (
        <p role="alert" className="mt-3 text-sm text-destructive">
          {error}
        </p>
      )}
    </Modal>
  )
}
