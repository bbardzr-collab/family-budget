import { keepPreviousData, useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useFamily } from '@/features/family/FamilyContext'
import { budgetsKeys } from './queryKeys'
import {
  addBudgetCategory,
  createBudget,
  deleteBudget,
  deleteBudgetCategory,
  fetchBudgetSummary,
  updateBudget,
  updateBudgetCategoryLimit,
  type AddBudgetCategoryInput,
  type CreateBudgetInput,
  type UpdateBudgetCategoryInput,
  type UpdateBudgetInput,
} from './api'

/**
 * Server state бюджета — через TanStack Query (ТЗ, п.24), по тому же
 * принципу, что и features/transactions/hooks.ts и features/categories/hooks.ts.
 *
 * `placeholderData: keepPreviousData` — переключение месяца (ТЗ, п.30) не
 * обнуляет экран в Skeleton целиком; предыдущие данные остаются видимыми,
 * пока не придёт ответ для нового периода (тот же приём, что и у
 * useTransactionsList/useTransactionsTotals на Этапе 9).
 */
export function useBudgetSummary(periodMonth: string) {
  const { currentFamily } = useFamily()
  return useQuery({
    queryKey: budgetsKeys.summary(currentFamily?.id, periodMonth),
    queryFn: () => fetchBudgetSummary(periodMonth),
    enabled: Boolean(currentFamily?.id),
    placeholderData: keepPreviousData,
  })
}

/**
 * Лимиты категорий текущего бюджета месяца — под именем, которое явно
 * называет ТЗ (п.24). Это НЕ отдельный сетевой запрос: категории уже
 * приходят вложенными в ответ get_monthly_budget_summary (см. api.ts), а
 * useQuery с тем же ключом переиспользует один и тот же кэш — второй
 * fetch не происходит. Адаптация имени под уже существующую архитектуру
 * прямо разрешена ТЗ (п.24).
 */
export function useBudgetCategories(periodMonth: string) {
  const query = useBudgetSummary(periodMonth)
  return { ...query, data: query.data?.categories }
}

function invalidateBudgetQueries(queryClient: ReturnType<typeof useQueryClient>) {
  void queryClient.invalidateQueries({ queryKey: budgetsKeys.all })
}

type CreateBudgetFormInput = Omit<CreateBudgetInput, 'familyId'>

export function useCreateBudget() {
  const queryClient = useQueryClient()
  const { currentFamily } = useFamily()

  return useMutation({
    mutationFn: (input: CreateBudgetFormInput) => {
      if (!currentFamily?.id) throw new Error('NO_FAMILY')
      return createBudget({ ...input, familyId: currentFamily.id })
    },
    onSuccess: () => invalidateBudgetQueries(queryClient),
  })
}

export function useUpdateBudget() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (input: UpdateBudgetInput) => updateBudget(input),
    onSuccess: () => invalidateBudgetQueries(queryClient),
  })
}

export function useDeleteBudget() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => deleteBudget(id),
    onSuccess: () => invalidateBudgetQueries(queryClient),
  })
}

export function useAddBudgetCategory() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (input: AddBudgetCategoryInput) => addBudgetCategory(input),
    onSuccess: () => invalidateBudgetQueries(queryClient),
  })
}

export function useUpdateBudgetCategory() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (input: UpdateBudgetCategoryInput) => updateBudgetCategoryLimit(input),
    onSuccess: () => invalidateBudgetQueries(queryClient),
  })
}

export function useDeleteBudgetCategory() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => deleteBudgetCategory(id),
    onSuccess: () => invalidateBudgetQueries(queryClient),
  })
}
