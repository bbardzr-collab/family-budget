import { addMonths, format, isValid, parse, startOfMonth, subMonths } from 'date-fns'
import { ru } from 'date-fns/locale'

/**
 * Работа с "месяцем бюджета" (Этап 10, п.3, 30-33) — period_month в БД
 * хранит первое число месяца (см. таблицу budgets), а URL использует более
 * короткий "yyyy-MM" (?month=2026-09, ТЗ п.33). Здесь — единственное место,
 * где эти два строковых формата конвертируются друг в друга и в Date, чтобы
 * не дублировать date-fns вызовы по всей странице (тот же принцип, что и
 * features/dashboard/period.ts на Этапе 6).
 */

const MONTH_PARAM_PATTERN = /^\d{4}-\d{2}$/

/** "2026-09-01" — значение для period_month/RPC-параметра p_period_month. */
export function toPeriodMonthValue(date: Date): string {
  return format(startOfMonth(date), 'yyyy-MM-dd')
}

/** "2026-09" — значение URL-параметра ?month=. */
export function toMonthParam(date: Date): string {
  return format(startOfMonth(date), 'yyyy-MM')
}

/**
 * URL-параметр → Date (первое число месяца). Мягкая валидация, тот же
 * принцип, что и useTransactionFilters (Этап 9) — некорректное/отсутствующее
 * значение тихо откатывается к текущему месяцу; это UI-состояние, а не
 * граница безопасности (ТЗ, п.33).
 */
export function parseMonthParam(param: string | null, fallback: Date = new Date()): Date {
  if (param && MONTH_PARAM_PATTERN.test(param)) {
    const parsed = parse(param, 'yyyy-MM', new Date())
    if (isValid(parsed)) return startOfMonth(parsed)
  }
  return startOfMonth(fallback)
}

export function previousMonth(date: Date): Date {
  return startOfMonth(subMonths(date, 1))
}

export function nextMonth(date: Date): Date {
  return startOfMonth(addMonths(date, 1))
}

/** Совпадают ли две даты по календарному месяцу (год+месяц), независимо от дня/времени. */
export function isSameMonthAs(a: Date, b: Date): boolean {
  return toMonthParam(a) === toMonthParam(b)
}

/**
 * "сентябрь 2026" — со строчной буквы, для текста подтверждения удаления
 * (ТЗ, п.19: "Удалить бюджет за сентябрь 2026?"). В отличие от
 * formatMonthYear() (utils/formatDate.ts), здесь буква НЕ капитализируется —
 * так требует дословный текст диалога из ТЗ. Название месяца в винительном
 * падеже ("за сентябрь") у date-fns ru-локали совпадает с отдельно стоящей
 * формой для всех русских названий месяцев (мужской неодушевлённый род).
 */
export function formatPeriodMonthLower(date: Date): string {
  return format(date, 'LLLL yyyy', { locale: ru })
}
