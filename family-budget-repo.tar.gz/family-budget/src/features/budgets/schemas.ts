import { z } from 'zod'

/**
 * Валидация денежных сумм для бюджета (Этап 10, п.4, 11, 27) — тот же
 * принцип, что в features/transactions/schemas.ts: нормализация ТОЛЬКО
 * строковыми операциями (split/padEnd), без умножения/деления на 100 и без
 * промежуточного parseFloat, чтобы не словить typичные JS float-баги при
 * работе с деньгами. Локальная копия, а не импорт из соседнего домена — тот
 * же принцип самодостаточности фичи, что уже применён в проекте
 * (features/categories/schemas.ts тоже не переиспользует amountInputSchema
 * transactions, хотя формально мог бы).
 *
 * Два разных правила минимума — ключевое отличие от transactions:
 *  - общий бюджет (`budgetTotalAmountSchema`) допускает 0 — совпадает с
 *    существующим CHECK total_amount >= 0 (миграция 0002, не менялась);
 *  - лимит категории (`budgetCategoryLimitSchema`) обязан быть строго
 *    больше нуля — совпадает с ужесточённым CHECK limit_amount > 0
 *    (миграция 0021): "категория без лимита" не может существовать как
 *    строка budget_categories вообще (ТЗ, п.11) — пользователь просто не
 *    добавляет категорию, если не хочет её контролировать.
 */
function normalizeAmountString(value: string): string {
  const [intPart, decPart = ''] = value.split('.')
  const cents = decPart.padEnd(2, '0').slice(0, 2)
  return `${intPart}.${cents}`
}

// До 12 цифр целой части + опционально точка и 1-2 цифры дробной — граница
// NUMERIC(14,2), тот же паттерн, что в transactions/schemas.ts.
const AMOUNT_PATTERN = /^\d{1,12}(\.\d{1,2})?$/

const baseAmountSchema = z
  .string()
  .trim()
  .min(1, 'Введите сумму')
  .transform((value) => value.replace(',', '.'))
  .refine((value) => AMOUNT_PATTERN.test(value), {
    message: 'Введите сумму числом, например 150000 или 1500,50',
  })

/** Общий бюджет семьи — 0 допустим (ТЗ, п.4; CHECK total_amount >= 0). */
export const budgetTotalAmountSchema = baseAmountSchema.transform((value) => normalizeAmountString(value))

/** Лимит категории — строго больше нуля (ТЗ, п.11, 27; CHECK limit_amount > 0). */
export const budgetCategoryLimitSchema = baseAmountSchema
  .refine((value) => !/^0+(\.0{1,2})?$/.test(value), {
    message: 'Лимит должен быть больше нуля',
  })
  .transform((value) => normalizeAmountString(value))

export const budgetFormSchema = z.object({
  totalAmount: budgetTotalAmountSchema,
})
export type BudgetFormValues = z.infer<typeof budgetFormSchema>

export const budgetCategoryFormSchema = z.object({
  categoryId: z.string().min(1, 'Выберите категорию'),
  limitAmount: budgetCategoryLimitSchema,
})
export type BudgetCategoryFormValues = z.infer<typeof budgetCategoryFormSchema>
