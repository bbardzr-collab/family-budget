import {
  formatPeriodMonthLower,
  isSameMonthAs,
  nextMonth,
  parseMonthParam,
  previousMonth,
  toMonthParam,
  toPeriodMonthValue,
} from './period'

describe('budgets/period — конвертация месяца (Этап 10, п.3, 30-33)', () => {
  it('toPeriodMonthValue приводит любой день месяца к первому числу ("yyyy-MM-dd")', () => {
    expect(toPeriodMonthValue(new Date(2026, 8, 18))).toBe('2026-09-01')
    expect(toPeriodMonthValue(new Date(2026, 8, 1))).toBe('2026-09-01')
    expect(toPeriodMonthValue(new Date(2026, 8, 30))).toBe('2026-09-01')
  })

  it('toMonthParam возвращает короткий формат для URL ("yyyy-MM")', () => {
    expect(toMonthParam(new Date(2026, 8, 18))).toBe('2026-09')
  })

  it('parseMonthParam разбирает валидный параметр в первое число месяца', () => {
    const result = parseMonthParam('2026-09')
    expect(toMonthParam(result)).toBe('2026-09')
    expect(result.getDate()).toBe(1)
  })

  it('parseMonthParam откатывается к текущему месяцу при null (мягкая валидация, не граница безопасности)', () => {
    const fallback = new Date(2026, 8, 18)
    const result = parseMonthParam(null, fallback)
    expect(toMonthParam(result)).toBe('2026-09')
  })

  it('parseMonthParam откатывается к текущему месяцу при некорректном значении', () => {
    const fallback = new Date(2026, 8, 18)
    expect(toMonthParam(parseMonthParam('не месяц', fallback))).toBe('2026-09')
    expect(toMonthParam(parseMonthParam('2026-13', fallback))).toBe('2026-09')
    expect(toMonthParam(parseMonthParam('', fallback))).toBe('2026-09')
  })

  it('previousMonth/nextMonth переходят на соседний календарный месяц', () => {
    const september = new Date(2026, 8, 18)
    expect(toMonthParam(previousMonth(september))).toBe('2026-08')
    expect(toMonthParam(nextMonth(september))).toBe('2026-10')
  })

  it('previousMonth/nextMonth корректно переходят через границу года', () => {
    const december = new Date(2026, 11, 5)
    expect(toMonthParam(nextMonth(december))).toBe('2027-01')

    const january = new Date(2026, 0, 5)
    expect(toMonthParam(previousMonth(january))).toBe('2025-12')
  })

  it('isSameMonthAs сравнивает только год и месяц, игнорируя день', () => {
    expect(isSameMonthAs(new Date(2026, 8, 1), new Date(2026, 8, 30))).toBe(true)
    expect(isSameMonthAs(new Date(2026, 8, 30), new Date(2026, 9, 1))).toBe(false)
  })

  it('formatPeriodMonthLower отдаёт название месяца со строчной буквы для текста подтверждения удаления (ТЗ, п.19)', () => {
    expect(formatPeriodMonthLower(new Date(2026, 8, 1))).toBe('сентябрь 2026')
  })
})
