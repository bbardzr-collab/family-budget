import { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { Button, Input, Modal, Text } from '@/components/ui'
import { useToast } from '@/components/ui/Toast'
import { budgetFormSchema, type BudgetFormValues } from './schemas'
import { useCreateBudget, useUpdateBudget } from './hooks'
import { getBudgetErrorMessage } from './errors'
import type { BudgetInfo } from './api'

interface BudgetFormModalProps {
  open: boolean
  onClose: () => void
  /** "yyyy-MM-dd" месяца, для которого создаётся бюджет (используется только при создании). */
  periodMonth: string
  /** "Сентябрь 2026" — только для отображения, месяц не редактируется (ТЗ, п.17). */
  periodMonthLabel: string
  /** Если передан — форма работает в режиме редактирования общего лимита (ТЗ, п.17). */
  budget: BudgetInfo | null
}

function buildDefaultValues(budget: BudgetInfo | null): BudgetFormValues {
  return { totalAmount: budget ? String(budget.totalAmount) : '' }
}

/**
 * Единая форма создания/редактирования бюджета месяца (ТЗ, п.4-5, 17).
 * Месяц выбирается заранее навигацией по странице (BudgetPage) — здесь
 * только показывается как неизменяемый текст, ни при создании, ни при
 * редактировании его нельзя сменить прямо из формы (иначе пришлось бы
 * различать "переместить бюджет в другой месяц" от "создать новый", что ТЗ
 * не требует).
 */
export function BudgetFormModal({ open, onClose, periodMonth, periodMonthLabel, budget }: BudgetFormModalProps) {
  const { toast } = useToast()
  const isEdit = Boolean(budget)
  const createBudgetMutation = useCreateBudget()
  const updateBudgetMutation = useUpdateBudget()
  const isSubmittingMutation = createBudgetMutation.isPending || updateBudgetMutation.isPending
  const [formError, setFormError] = useState<string | null>(null)

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<BudgetFormValues>({
    resolver: zodResolver(budgetFormSchema),
    defaultValues: buildDefaultValues(budget),
  })

  // Modal не размонтируется между открытиями — пересинхронизируем форму при
  // каждом новом открытии (тот же паттерн, что и в CategoryFormModal/
  // TransactionFormModal — RHF берёт defaultValues только один раз).
  //
  // formError здесь НЕ сбрасывается (react-hooks/set-state-in-effect не
  // разрешает setState синхронно внутри эффекта) — это и не нужно: Modal
  // (см. components/ui/Modal.tsx) вызывает переданный onClose при ЛЮБОМ
  // закрытии (крестик/клик по фону/Escape), а handleClose ниже уже обнуляет
  // formError на каждом закрытии, так что к следующему открытию оно и так null.
  useEffect(() => {
    if (open) {
      reset(buildDefaultValues(budget))
    }
  }, [open, budget, reset])

  function handleClose() {
    setFormError(null)
    onClose()
  }

  const onSubmit = handleSubmit(async (values) => {
    setFormError(null)
    try {
      if (isEdit && budget) {
        await updateBudgetMutation.mutateAsync({ id: budget.id, totalAmount: values.totalAmount })
        toast({ type: 'success', title: 'Бюджет обновлён' })
      } else {
        await createBudgetMutation.mutateAsync({ periodMonth, totalAmount: values.totalAmount })
        toast({ type: 'success', title: 'Бюджет создан' })
      }
      handleClose()
    } catch (error) {
      setFormError(getBudgetErrorMessage(error))
    }
  })

  const busy = isSubmitting || isSubmittingMutation

  return (
    <Modal open={open} onClose={handleClose} title={isEdit ? 'Редактировать бюджет' : 'Создать бюджет'}>
      <form className="flex flex-col gap-4" onSubmit={onSubmit} noValidate>
        <Text variant="secondary">Месяц: {periodMonthLabel}</Text>

        <Input
          label="Общий бюджет"
          placeholder="Например, 150000"
          inputMode="decimal"
          autoComplete="off"
          error={errors.totalAmount?.message}
          {...register('totalAmount')}
        />

        {formError && (
          <p role="alert" className="text-sm text-destructive">
            {formError}
          </p>
        )}

        <Button type="submit" size="lg" isLoading={busy} disabled={busy}>
          {isEdit ? 'Сохранить' : 'Создать бюджет'}
        </Button>
      </form>
    </Modal>
  )
}
