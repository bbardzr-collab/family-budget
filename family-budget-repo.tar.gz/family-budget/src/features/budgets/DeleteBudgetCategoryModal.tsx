import { useState } from 'react'
import { Button, Modal, Text } from '@/components/ui'
import { useToast } from '@/components/ui/Toast'
import { useDeleteBudgetCategory } from './hooks'
import { getBudgetErrorMessage } from './errors'
import type { BudgetSummaryCategory } from './api'

interface DeleteBudgetCategoryModalProps {
  category: BudgetSummaryCategory | null
  onClose: () => void
}

/**
 * Подтверждение удаления лимита категории из бюджета (ТЗ, п.24 требует
 * useDeleteBudgetCategory как отдельный хук). Удаляется только строка
 * budget_categories (сам лимит) — категория и операции по ней не
 * затрагиваются; если позже понадобится снова отслеживать эту категорию, её
 * можно будет добавить в бюджет заново.
 */
export function DeleteBudgetCategoryModal({ category, onClose }: DeleteBudgetCategoryModalProps) {
  const { toast } = useToast()
  const deleteBudgetCategoryMutation = useDeleteBudgetCategory()
  const [error, setError] = useState<string | null>(null)

  async function handleConfirm() {
    if (!category) return
    setError(null)
    try {
      await deleteBudgetCategoryMutation.mutateAsync(category.id)
      toast({ type: 'success', title: 'Категория удалена из бюджета' })
      onClose()
    } catch (err) {
      setError(getBudgetErrorMessage(err))
    }
  }

  function handleClose() {
    setError(null)
    onClose()
  }

  return (
    <Modal
      open={Boolean(category)}
      onClose={handleClose}
      title="Убрать категорию из бюджета?"
      footer={
        <>
          <Button variant="outline" onClick={handleClose}>
            Отмена
          </Button>
          <Button
            variant="destructive"
            onClick={() => void handleConfirm()}
            isLoading={deleteBudgetCategoryMutation.isPending}
            disabled={deleteBudgetCategoryMutation.isPending}
          >
            Удалить
          </Button>
        </>
      }
    >
      <Text variant="secondary">
        {category &&
          `Лимит по категории «${category.categoryName}» будет удалён. Операции по этой категории останутся без изменений.`}
      </Text>
      {error && (
        <p role="alert" className="mt-3 text-sm text-destructive">
          {error}
        </p>
      )}
    </Modal>
  )
}
