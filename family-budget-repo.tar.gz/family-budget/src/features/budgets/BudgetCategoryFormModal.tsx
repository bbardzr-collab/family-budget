import { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { Button, Input, Modal, Select, Text } from '@/components/ui'
import { useToast } from '@/components/ui/Toast'
import { budgetCategoryFormSchema, type BudgetCategoryFormValues } from './schemas'
import { useAddBudgetCategory, useUpdateBudgetCategory } from './hooks'
import { getBudgetErrorMessage } from './errors'
import type { CategoryListItem } from '@/features/categories/api'
import type { BudgetSummaryCategory } from './api'

interface BudgetCategoryFormModalProps {
  open: boolean
  onClose: () => void
  budgetId: string
  /** Все категории семьи (активные и отключённые) — фильтрация вариантов происходит внутри. */
  categories: CategoryListItem[]
  /** categoryId категорий, уже добавленных в этот бюджет — исключаются из списка выбора при добавлении. */
  existingCategoryIds: string[]
  /** Если передана — форма работает в режиме редактирования лимита (категория не меняется, ТЗ п.18). */
  editing: BudgetSummaryCategory | null
}

function buildDefaultValues(editing: BudgetSummaryCategory | null): BudgetCategoryFormValues {
  return {
    categoryId: editing?.categoryId ?? '',
    limitAmount: editing ? String(editing.limitAmount) : '',
  }
}

/**
 * Добавление категории в бюджет / изменение её лимита (ТЗ, п.10, 18).
 *
 * При добавлении показываются только АКТИВНЫЕ категории семьи, которых ещё
 * нет в этом бюджете (ТЗ, п.10, 12) — "не позволяй добавить одну и ту же
 * категорию дважды" реализовано здесь на уровне списка опций (не даём даже
 * выбрать дубликат), а на сервере — тем же UNIQUE(budget_id, category_id)
 * (миграция 0002, см. errors.ts на случай гонки).
 *
 * При редактировании категория фиксирована (показывается текстом, не
 * выбором) — меняется только лимит, category_id вообще не уходит в
 * updateBudgetCategoryLimit (см. api.ts).
 */
export function BudgetCategoryFormModal({
  open,
  onClose,
  budgetId,
  categories,
  existingCategoryIds,
  editing,
}: BudgetCategoryFormModalProps) {
  const { toast } = useToast()
  const isEdit = Boolean(editing)
  const addMutation = useAddBudgetCategory()
  const updateMutation = useUpdateBudgetCategory()
  const isSubmittingMutation = addMutation.isPending || updateMutation.isPending
  const [formError, setFormError] = useState<string | null>(null)

  // Только активные категории (ТЗ, п.12), которых ещё нет в этом бюджете
  // (ТЗ, п.10) — "не позволяй добавить одну и ту же категорию дважды"
  // реализовано здесь на уровне списка опций, а не только надеждой на
  // ошибку сервера при сабмите.
  const availableCategories = categories.filter((c) => c.isActive && !existingCategoryIds.includes(c.id))
  const options = availableCategories.map((c) => ({ value: c.id, label: c.name }))

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<BudgetCategoryFormValues>({
    resolver: zodResolver(budgetCategoryFormSchema),
    defaultValues: buildDefaultValues(editing),
  })

  // formError НЕ сбрасывается здесь напрямую (react-hooks/set-state-in-effect
  // запрещает setState синхронно внутри тела эффекта) — Modal вызывает
  // переданный onClose при любом закрытии (см. components/ui/Modal.tsx), а
  // handleClose ниже уже обнуляет formError на каждом закрытии, так что к
  // следующему открытию оно и так null (тот же приём, что и в BudgetFormModal.tsx).
  useEffect(() => {
    if (open) {
      reset(buildDefaultValues(editing))
    }
  }, [open, editing, reset])

  function handleClose() {
    setFormError(null)
    onClose()
  }

  const onSubmit = handleSubmit(async (values) => {
    setFormError(null)
    try {
      if (isEdit && editing) {
        await updateMutation.mutateAsync({ id: editing.id, limitAmount: values.limitAmount })
        toast({ type: 'success', title: 'Лимит обновлён' })
      } else {
        await addMutation.mutateAsync({
          budgetId,
          categoryId: values.categoryId,
          limitAmount: values.limitAmount,
        })
        toast({ type: 'success', title: 'Категория добавлена в бюджет' })
      }
      handleClose()
    } catch (error) {
      setFormError(getBudgetErrorMessage(error))
    }
  })

  const busy = isSubmitting || isSubmittingMutation
  const noOptions = !isEdit && options.length === 0

  return (
    <Modal open={open} onClose={handleClose} title={isEdit ? 'Изменить лимит' : 'Добавить категорию'}>
      <form className="flex flex-col gap-4" onSubmit={onSubmit} noValidate>
        {isEdit ? (
          <Text variant="secondary">Категория: {editing?.categoryName}</Text>
        ) : (
          <Select
            label="Категория"
            options={options}
            placeholder={noOptions ? 'Нет доступных категорий' : 'Выберите категорию'}
            disabled={noOptions}
            error={errors.categoryId?.message}
            {...register('categoryId')}
          />
        )}

        {noOptions && (
          <Text variant="secondary">
            Все активные категории семьи уже добавлены в этот бюджет, либо активных категорий пока нет.
          </Text>
        )}

        <Input
          label="Лимит"
          placeholder="Например, 30000"
          inputMode="decimal"
          autoComplete="off"
          error={errors.limitAmount?.message}
          {...register('limitAmount')}
        />

        {formError && (
          <p role="alert" className="text-sm text-destructive">
            {formError}
          </p>
        )}

        <Button type="submit" size="lg" isLoading={busy} disabled={busy || noOptions}>
          {isEdit ? 'Сохранить' : 'Добавить категорию'}
        </Button>
      </form>
    </Modal>
  )
}
