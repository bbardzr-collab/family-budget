/** Единый источник ключей React Query для домена "бюджет" (Этап 10, п.24). */
export const budgetsKeys = {
  all: ['budgets'] as const,
  summary: (familyId: string | undefined, periodMonth: string) =>
    [...budgetsKeys.all, 'summary', familyId, periodMonth] as const,
}
