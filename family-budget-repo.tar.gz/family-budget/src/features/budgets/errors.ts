/**
 * Перевод ошибок операций с бюджетом в понятные человеку сообщения (ТЗ,
 * п.20) — по аналогии с features/transactions/errors.ts и
 * features/categories/errors.ts: INSERT/UPDATE/DELETE идут напрямую через
 * Supabase PostgREST поверх RLS, поэтому текст ошибки — либо код Postgres,
 * либо текст "row-level security", либо PGRST116 от .single()/count.
 */

interface MatchableError {
  message?: string
  code?: string
}

export function getBudgetErrorMessage(error: unknown): string {
  if (!error) return 'Неизвестная ошибка. Попробуйте ещё раз.'

  if (error instanceof TypeError) {
    return 'Проблема с сетью. Проверьте подключение к интернету и попробуйте снова.'
  }

  const { message, code } = (error as MatchableError) ?? {}
  const text = (message ?? String(error)).toLowerCase()

  // UNIQUE(family_id, period_month) — миграция 0002, не менялась (ТЗ, п.5).
  if (text.includes('budgets_family_id_period_month')) {
    return 'Бюджет на этот месяц уже существует. Отредактируйте его вместо создания нового.'
  }

  // UNIQUE(budget_id, category_id) — миграция 0002, не менялась (ТЗ, п.10).
  if (text.includes('budget_categories_budget_id_category_id')) {
    return 'Эта категория уже добавлена в бюджет.'
  }

  if (code === '23505' || text.includes('duplicate key')) {
    return 'Такая запись уже существует.'
  }

  // CHECK limit_amount > 0 / total_amount >= 0 — на практике форма уже не
  // пропускает такое значение (schemas.ts), это защита на случай гонки/
  // прямого API-запроса в обход формы.
  if (code === '23514' || text.includes('check constraint') || text.includes('violates check')) {
    return 'Некорректная сумма.'
  }

  // RLS отклонила действие — CHILD пытается изменить бюджет (ТЗ, п.21) или
  // попытка изменить бюджет другой семьи.
  if (text.includes('row-level security') || text.includes('policy')) {
    return 'Недостаточно прав для этого действия.'
  }

  if (code === 'PGRST116') {
    return 'Запись не найдена или у вас нет прав её изменить.'
  }

  if (text.includes('fetch') || text.includes('network')) {
    return 'Проблема с сетью. Проверьте подключение к интернету и попробуйте снова.'
  }

  return 'Не получилось выполнить действие. Попробуйте ещё раз чуть позже.'
}
