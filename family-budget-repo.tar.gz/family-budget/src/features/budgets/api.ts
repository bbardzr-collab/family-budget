import { supabase } from '@/lib/supabase'
import type { CategoryType } from '@/features/categories/constants'

/**
 * Тонкий слой доступа к данным бюджета (Этап 10, п.24) — только запросы,
 * никакой бизнес-логики и никакого React, по аналогии с
 * features/transactions/api.ts и features/categories/api.ts.
 *
 * ─── Чтение: RPC get_monthly_budget_summary (миграция 0021) ───
 * Единый запрос на всю сводку месяца (бюджет + фактические расходы, общие и
 * по категориям) — считается в Postgres, без загрузки транзакций месяца на
 * клиент (ТЗ, п.13, 25-26). SECURITY INVOKER — RLS уже ограничивает данные
 * своей семьёй и (для CHILD) своими операциями, см. комментарий в миграции.
 *
 * ─── Запись: прямой Supabase CRUD, БЕЗ новых RPC (тот же принцип, что
 * Этапы 7-8) ───
 * INSERT/UPDATE/DELETE на budgets/budget_categories идут напрямую через
 * Supabase поверх RLS-политик budgets_insert_adult_admin/update/delete и
 * budget_categories_insert_adult_admin/update/delete (миграция 0021) — они
 * уже ограничивают запись только ADMIN/ADULT текущей семьи, поэтому здесь не
 * нужна отдельная проверка family_id/роли на клиенте (RLS — единственная
 * граница, ТЗ п.20-21).
 */

export interface BudgetInfo {
  id: string
  periodMonth: string
  totalAmount: number
}

export interface BudgetSummaryCategory {
  id: string
  categoryId: string
  categoryName: string
  categoryIcon: string | null
  categoryType: CategoryType
  limitAmount: number
  spentAmount: number
  remainingAmount: number
  /** null, только если бы limit был 0 — на практике недостижимо благодаря CHECK limit_amount > 0. */
  percent: number | null
  isActive: boolean
}

export interface BudgetSummary {
  /** null — бюджет на этот месяц ещё не создан (ТЗ, п.23, 29) — НЕ "бюджет с нулевыми полями". */
  budget: BudgetInfo | null
  totalSpent: number
  totalRemaining: number
  totalPercent: number | null
  categories: BudgetSummaryCategory[]
}

interface RawBudgetSummary {
  budget: { id: string; periodMonth: string; totalAmount: number } | null
  totalSpent: number
  totalRemaining: number
  totalPercent: number | null
  categories: Array<{
    id: string
    categoryId: string
    categoryName: string
    categoryIcon: string | null
    categoryType: string
    limitAmount: number
    spentAmount: number
    remainingAmount: number
    percent: number | null
    isActive: boolean
  }>
}

/**
 * Полная сводка бюджета указанного месяца. `periodMonth` — "yyyy-MM-dd"
 * (первое число месяца, см. features/budgets/period.ts::toPeriodMonthValue).
 * family_id НЕ передаётся — RPC сама определяет семью пользователя по
 * auth.uid() (см. миграцию 0021), как и get_dashboard_summary/get_transactions_*.
 */
export async function fetchBudgetSummary(periodMonth: string): Promise<BudgetSummary> {
  const { data, error } = await supabase.rpc('get_monthly_budget_summary', {
    p_period_month: periodMonth,
  })
  if (error) throw error

  const raw = (data ?? null) as unknown as RawBudgetSummary | null
  if (!raw || !raw.budget) {
    return { budget: null, totalSpent: 0, totalRemaining: 0, totalPercent: null, categories: [] }
  }

  return {
    budget: raw.budget,
    totalSpent: raw.totalSpent,
    totalRemaining: raw.totalRemaining,
    totalPercent: raw.totalPercent,
    categories: raw.categories.map((c) => ({
      id: c.id,
      categoryId: c.categoryId,
      categoryName: c.categoryName,
      categoryIcon: c.categoryIcon,
      categoryType: c.categoryType as CategoryType,
      limitAmount: c.limitAmount,
      spentAmount: c.spentAmount,
      remainingAmount: c.remainingAmount,
      percent: c.percent,
      isActive: c.isActive,
    })),
  }
}

export interface CreateBudgetInput {
  familyId: string
  /** "yyyy-MM-dd" — первое число месяца. */
  periodMonth: string
  /** Нормализованная строка с ровно 2 знаками после точки, см. schemas.ts. */
  totalAmount: string
}

/**
 * Создание бюджета месяца (ТЗ, п.4-5). UNIQUE(family_id, period_month) на
 * стороне БД (миграция 0002, не менялась) — единственный реальный источник
 * защиты "один бюджет на месяц" (ТЗ, п.5); клиент не проверяет дубликат
 * сам, а показывает пользователю уже существующий бюджет вместо формы
 * создания (см. BudgetPage.tsx), так что сюда попадает только осмысленный
 * запрос — но даже если бы гонка обошла эту проверку, Postgres всё равно
 * откажет вставке ошибкой 23505 (см. errors.ts).
 */
export async function createBudget(input: CreateBudgetInput): Promise<{ id: string }> {
  const { data, error } = await supabase
    .from('budgets')
    .insert({
      family_id: input.familyId,
      period_month: input.periodMonth,
      total_amount: input.totalAmount as unknown as number,
    })
    .select('id')
    .single()

  if (error) throw error
  return { id: data.id }
}

export interface UpdateBudgetInput {
  id: string
  totalAmount: string
}

/** Редактирование общего бюджета (ТЗ, п.17) — меняется только total_amount, period_month/family_id не передаются. */
export async function updateBudget(input: UpdateBudgetInput): Promise<void> {
  const { data, error } = await supabase
    .from('budgets')
    .update({ total_amount: input.totalAmount as unknown as number })
    .eq('id', input.id)
    .select('id')
    .single()

  if (error) throw error
  if (!data) throw { message: 'Бюджет не найден или у вас нет прав его изменить.', code: 'PGRST116' }
}

/**
 * Удаление бюджета (ТЗ, п.19) — budget_categories удаляются каскадом на
 * уровне схемы (ON DELETE CASCADE, миграция 0002, не менялась), transactions
 * НЕ затрагиваются вообще (у них нет FK на budgets) — история операций
 * сохраняется всегда, независимо от того, существует ли бюджет.
 */
export async function deleteBudget(id: string): Promise<void> {
  const { error, count } = await supabase.from('budgets').delete({ count: 'exact' }).eq('id', id)

  if (error) throw error
  if (!count) throw { message: 'Бюджет не найден или у вас нет прав его удалить.', code: 'PGRST116' }
}

export interface AddBudgetCategoryInput {
  budgetId: string
  categoryId: string
  /** Нормализованная строка, см. schemas.ts (budgetCategoryLimitSchema) — строго больше нуля. */
  limitAmount: string
}

/**
 * Добавление категории в бюджет (ТЗ, п.10). UNIQUE(budget_id, category_id)
 * на стороне БД (миграция 0002) — реальная защита от дублирования категории
 * в одном бюджете (см. errors.ts, код 23505).
 */
export async function addBudgetCategory(input: AddBudgetCategoryInput): Promise<{ id: string }> {
  const { data, error } = await supabase
    .from('budget_categories')
    .insert({
      budget_id: input.budgetId,
      category_id: input.categoryId,
      limit_amount: input.limitAmount as unknown as number,
    })
    .select('id')
    .single()

  if (error) throw error
  return { id: data.id }
}

export interface UpdateBudgetCategoryInput {
  id: string
  limitAmount: string
}

/** Изменение лимита категории (ТЗ, п.18) — category_id не передаётся, категория лимита не меняется. */
export async function updateBudgetCategoryLimit(input: UpdateBudgetCategoryInput): Promise<void> {
  const { data, error } = await supabase
    .from('budget_categories')
    .update({ limit_amount: input.limitAmount as unknown as number })
    .eq('id', input.id)
    .select('id')
    .single()

  if (error) throw error
  if (!data) {
    throw { message: 'Лимит категории не найден или у вас нет прав его изменить.', code: 'PGRST116' }
  }
}

/** Удаление лимита категории из бюджета — сама категория и операции не удаляются. */
export async function deleteBudgetCategory(id: string): Promise<void> {
  const { error, count } = await supabase.from('budget_categories').delete({ count: 'exact' }).eq('id', id)

  if (error) throw error
  if (!count) {
    throw { message: 'Лимит категории не найден или у вас нет прав его удалить.', code: 'PGRST116' }
  }
}
