import { budgetCategoryFormSchema, budgetFormSchema } from './schemas'

describe('budgetFormSchema — общий бюджет месяца (ТЗ, п.4)', () => {
  it('отклоняет пустую сумму', () => {
    const result = budgetFormSchema.safeParse({ totalAmount: '' })
    expect(result.success).toBe(false)
  })

  it('принимает 0 (CHECK total_amount >= 0, не менялся)', () => {
    const result = budgetFormSchema.safeParse({ totalAmount: '0' })
    expect(result.success).toBe(true)
    if (result.success) expect(result.data.totalAmount).toBe('0.00')
  })

  it('отклоняет отрицательную сумму', () => {
    const result = budgetFormSchema.safeParse({ totalAmount: '-100' })
    expect(result.success).toBe(false)
  })

  it('отклоняет нечисловой ввод', () => {
    const result = budgetFormSchema.safeParse({ totalAmount: 'abc' })
    expect(result.success).toBe(false)
  })

  it('отклоняет больше двух знаков после запятой', () => {
    const result = budgetFormSchema.safeParse({ totalAmount: '150000.999' })
    expect(result.success).toBe(false)
  })

  it('отклоняет сумму за пределами NUMERIC(14,2) (13 цифр в целой части)', () => {
    const result = budgetFormSchema.safeParse({ totalAmount: '1234567890123' })
    expect(result.success).toBe(false)
  })

  it('принимает максимально допустимую сумму 999999999999.99 (Этап 20 — регресс-тест на границу NUMERIC(14,2))', () => {
    const result = budgetFormSchema.safeParse({ totalAmount: '999999999999.99' })
    expect(result.success).toBe(true)
  })

  it('принимает целое число: "150000" → "150000.00"', () => {
    const result = budgetFormSchema.safeParse({ totalAmount: '150000' })
    expect(result.success).toBe(true)
    if (result.success) expect(result.data.totalAmount).toBe('150000.00')
  })

  it('принимает сумму с запятой: "150000,50" → "150000.50" (оба разделителя)', () => {
    const result = budgetFormSchema.safeParse({ totalAmount: '150000,50' })
    expect(result.success).toBe(true)
    if (result.success) expect(result.data.totalAmount).toBe('150000.50')
  })
})

describe('budgetCategoryFormSchema — лимит категории (ТЗ, п.11, 27)', () => {
  function baseValues(overrides: Partial<Record<string, unknown>> = {}) {
    return { categoryId: 'cat-1', limitAmount: '30000', ...overrides }
  }

  it('отклоняет отсутствие категории', () => {
    const result = budgetCategoryFormSchema.safeParse(baseValues({ categoryId: '' }))
    expect(result.success).toBe(false)
  })

  it('отклоняет нулевой лимит — "категория без лимита" не может существовать (ТЗ, п.11)', () => {
    const result = budgetCategoryFormSchema.safeParse(baseValues({ limitAmount: '0' }))
    expect(result.success).toBe(false)
  })

  it('отклоняет "0.00"', () => {
    const result = budgetCategoryFormSchema.safeParse(baseValues({ limitAmount: '0.00' }))
    expect(result.success).toBe(false)
  })

  it('отклоняет отрицательный лимит', () => {
    const result = budgetCategoryFormSchema.safeParse(baseValues({ limitAmount: '-500' }))
    expect(result.success).toBe(false)
  })

  it('отклоняет пустой лимит', () => {
    const result = budgetCategoryFormSchema.safeParse(baseValues({ limitAmount: '' }))
    expect(result.success).toBe(false)
  })

  it('принимает положительный лимит: "30000" → "30000.00"', () => {
    const result = budgetCategoryFormSchema.safeParse(baseValues({ limitAmount: '30000' }))
    expect(result.success).toBe(true)
    if (result.success) expect(result.data.limitAmount).toBe('30000.00')
  })

  it('принимает лимит с копейками: "30000,50" → "30000.50"', () => {
    const result = budgetCategoryFormSchema.safeParse(baseValues({ limitAmount: '30000,50' }))
    expect(result.success).toBe(true)
    if (result.success) expect(result.data.limitAmount).toBe('30000.50')
  })

  it('отклоняет больше двух знаков после запятой', () => {
    const result = budgetCategoryFormSchema.safeParse(baseValues({ limitAmount: '30000.999' }))
    expect(result.success).toBe(false)
  })
})
