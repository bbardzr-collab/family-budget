import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useFamily } from '@/features/family/FamilyContext'
import { categoriesKeys } from './queryKeys'
import {
  createCategory,
  deleteCategory,
  fetchCategories,
  fetchCategoryUsage,
  toggleCategoryActive,
  updateCategory,
  type CreateCategoryInput,
  type UpdateCategoryInput,
} from './api'

/**
 * Server state категорий — через TanStack Query (Этап 8, п.14-15, 25), по
 * тому же принципу, что и features/transactions/hooks.ts.
 *
 * В отличие от транзакций, мутации категорий инвалидируют только
 * categoriesKeys — сами транзакции (их список/дэшборд) от смены названия/
 * типа/статуса категории не меняются как server-state объекты: React Query
 * у useTransactions обновит вложенный category сам, как только рефетчнет
 * список (invalidate ниже это и делает не напрямую, а через тот факт, что
 * transactionsKeys не связаны с categoriesKeys никак специально —
 * достаточно, что TransactionsPage использует те же категории по ссылке
 * category_id и перечитает актуальные данные категории при следующем
 * fetchTransactions, т.к. эмбеддинг тянет их заново при каждом запросе).
 */
export function useCategories() {
  const { currentFamily } = useFamily()
  return useQuery({
    queryKey: categoriesKeys.list(currentFamily?.id),
    queryFn: () => fetchCategories(currentFamily!.id),
    enabled: Boolean(currentFamily?.id),
  })
}

export function useCategoryUsage(categoryId: string | undefined, enabled: boolean) {
  return useQuery({
    queryKey: categoriesKeys.usage(categoryId ?? ''),
    queryFn: () => fetchCategoryUsage(categoryId!),
    enabled: Boolean(categoryId) && enabled,
  })
}

type CreateCategoryFormInput = Omit<CreateCategoryInput, 'familyId'>

export function useCreateCategory() {
  const queryClient = useQueryClient()
  const { currentFamily } = useFamily()

  return useMutation({
    mutationFn: (input: CreateCategoryFormInput) => {
      if (!currentFamily?.id) throw new Error('NO_FAMILY')
      return createCategory({ ...input, familyId: currentFamily.id })
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: categoriesKeys.list(currentFamily?.id) })
    },
  })
}

export function useUpdateCategory() {
  const queryClient = useQueryClient()
  const { currentFamily } = useFamily()

  return useMutation({
    mutationFn: (input: UpdateCategoryInput) => updateCategory(input),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: categoriesKeys.list(currentFamily?.id) })
    },
  })
}

export function useToggleCategory() {
  const queryClient = useQueryClient()
  const { currentFamily } = useFamily()

  return useMutation({
    mutationFn: ({ id, isActive }: { id: string; isActive: boolean }) => toggleCategoryActive(id, isActive),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: categoriesKeys.list(currentFamily?.id) })
    },
  })
}

export function useDeleteCategory() {
  const queryClient = useQueryClient()
  const { currentFamily } = useFamily()

  return useMutation({
    mutationFn: (id: string) => deleteCategory(id),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: categoriesKeys.list(currentFamily?.id) })
    },
  })
}
