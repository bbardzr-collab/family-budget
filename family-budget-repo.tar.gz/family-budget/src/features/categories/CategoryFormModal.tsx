import { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { Button, Input, Modal, Select } from '@/components/ui'
import { useToast } from '@/components/ui/Toast'
import { cn } from '@/utils/cn'
import { CATEGORY_TYPE_LABELS, CATEGORY_TYPE_ORDER } from './constants'
import { CATEGORY_ICON_OPTIONS } from './iconMap'
import { categoryFormSchema, type CategoryFormValues } from './schemas'
import { useCreateCategory, useUpdateCategory } from './hooks'
import { getCategoryErrorMessage } from './errors'
import type { CategoryListItem } from './api'

interface CategoryFormModalProps {
  open: boolean
  onClose: () => void
  /** Если передана — форма работает в режиме редактирования (ТЗ, п.11), поля предзаполняются. */
  category?: CategoryListItem | null
}

const TYPE_OPTIONS = CATEGORY_TYPE_ORDER.map((type) => ({ value: type, label: CATEGORY_TYPE_LABELS[type] }))

function buildDefaultValues(category: CategoryListItem | null | undefined): CategoryFormValues {
  if (category) {
    return { name: category.name, type: category.type, icon: category.icon ?? '' }
  }
  return { name: '', type: 'OBLIGATORY', icon: '' }
}

/**
 * Единая форма создания/редактирования категории (Этап 8, п.9, 11).
 * Название нормализуется трим+сжатием по схеме (schemas.ts) — здесь только
 * UI. Системную категорию тоже можно открыть в этой форме (is_custom не
 * передаётся ни при создании явно — она всегда true, — ни при апдейте
 * вовсе, см. hooks.ts/api.ts), поэтому один и тот же компонент безопасно
 * работает и для custom, и для системных категорий.
 */
export function CategoryFormModal({ open, onClose, category = null }: CategoryFormModalProps) {
  const { toast } = useToast()
  const isEdit = Boolean(category)
  const createCategoryMutation = useCreateCategory()
  const updateCategoryMutation = useUpdateCategory()
  const isSubmittingMutation = createCategoryMutation.isPending || updateCategoryMutation.isPending
  const [formError, setFormError] = useState<string | null>(null)

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<CategoryFormValues>({
    resolver: zodResolver(categoryFormSchema),
    defaultValues: buildDefaultValues(category),
  })

  // Modal не размонтируется между открытиями — пересинхронизируем форму при
  // каждом новом открытии, как и в TransactionFormModal (тот же паттерн,
  // тот же комментарий про причину: RHF берёт defaultValues один раз).
  useEffect(() => {
    if (open) {
      reset(buildDefaultValues(category))
      setFormError(null)
    }
  }, [open, category, reset])

  const selectedIcon = watch('icon')

  function handleClose() {
    setFormError(null)
    onClose()
  }

  const onSubmit = handleSubmit(async (values) => {
    setFormError(null)
    try {
      if (isEdit && category) {
        await updateCategoryMutation.mutateAsync({
          id: category.id,
          name: values.name,
          type: values.type,
          icon: values.icon,
        })
        toast({ type: 'success', title: 'Категория сохранена' })
      } else {
        await createCategoryMutation.mutateAsync({
          name: values.name,
          type: values.type,
          icon: values.icon,
        })
        toast({ type: 'success', title: 'Категория добавлена' })
      }
      handleClose()
    } catch (error) {
      setFormError(getCategoryErrorMessage(error))
    }
  })

  const busy = isSubmitting || isSubmittingMutation

  return (
    <Modal open={open} onClose={handleClose} title={isEdit ? 'Изменить категорию' : 'Добавить категорию'}>
      <form className="flex flex-col gap-4" onSubmit={onSubmit} noValidate>
        <Input
          label="Название"
          placeholder="Например, Продукты"
          autoComplete="off"
          error={errors.name?.message}
          {...register('name')}
        />

        <Select
          label="Тип"
          options={TYPE_OPTIONS}
          error={errors.type?.message}
          {...register('type')}
        />

        <div className="flex flex-col gap-1.5">
          <span className="text-sm font-medium text-foreground">Иконка</span>
          <div
            className="grid grid-cols-6 gap-2 sm:grid-cols-8"
            role="radiogroup"
            aria-label="Иконка категории"
          >
            {CATEGORY_ICON_OPTIONS.map(({ value, icon: Icon, label }) => {
              const active = selectedIcon === value
              return (
                <button
                  key={value}
                  type="button"
                  role="radio"
                  aria-checked={active}
                  aria-label={label}
                  title={label}
                  onClick={() => setValue('icon', value, { shouldValidate: true })}
                  className={cn(
                    'flex size-10 items-center justify-center rounded-md border transition-colors',
                    'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background',
                    active
                      ? 'border-primary bg-primary-soft text-primary'
                      : 'border-border bg-card text-muted-foreground hover:bg-muted',
                  )}
                >
                  <Icon className="size-4" aria-hidden="true" />
                </button>
              )
            })}
          </div>
          {errors.icon?.message && <p className="text-sm text-destructive">{errors.icon.message}</p>}
        </div>

        {formError && (
          <p role="alert" className="text-sm text-destructive">
            {formError}
          </p>
        )}

        <Button type="submit" size="lg" isLoading={busy} disabled={busy}>
          {isEdit ? 'Сохранить' : 'Добавить категорию'}
        </Button>
      </form>
    </Modal>
  )
}
