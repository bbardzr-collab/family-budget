/**
 * Перевод ошибок операций с категориями в понятные человеку сообщения
 * (по аналогии с features/transactions/errors.ts) — INSERT/UPDATE/DELETE
 * идут напрямую через Supabase PostgREST поверх RLS, поэтому текст ошибки —
 * либо код Postgres, либо текст "row-level security", либо (для дубликата
 * названия/попытки удалить используемую категорию) конкретный код Postgres.
 */

interface MatchableError {
  message?: string
  code?: string
}

export function getCategoryErrorMessage(error: unknown): string {
  if (!error) return 'Неизвестная ошибка. Попробуйте ещё раз.'

  if (error instanceof TypeError) {
    return 'Проблема с сетью. Проверьте подключение к интернету и попробуйте снова.'
  }

  const { message, code } = (error as MatchableError) ?? {}
  const text = (message ?? String(error)).toLowerCase()

  // Уникальный индекс categories_family_id_normalized_name_key (миграция
  // 0017) — категория с таким названием (без учёта регистра/пробелов) уже
  // есть в этой семье (ТЗ, п.10).
  if (code === '23505' || text.includes('duplicate key') || text.includes('already exists')) {
    return 'Категория с таким названием уже есть в вашей семье.'
  }

  // FK transactions_category_id_fkey теперь ON DELETE RESTRICT (миграция
  // 0017) — попытка физически удалить категорию, на которую ссылаются
  // операции (ТЗ, п.13, 24). budget_categories/planned_expenses — тоже FK,
  // тот же код ошибки.
  if (code === '23503' || text.includes('foreign key') || text.includes('violates foreign key')) {
    return 'Эта категория уже используется в операциях — удалить её нельзя. Отключите категорию вместо удаления.'
  }

  // RLS отклонила действие (например, попытка физически удалить системную
  // категорию — categories_delete_adult_admin теперь требует is_custom=true).
  if (text.includes('row-level security') || text.includes('policy')) {
    return 'Недостаточно прав для этого действия.'
  }

  if (code === 'PGRST116') {
    return 'Категория не найдена или у вас нет прав её изменить.'
  }

  if (text.includes('fetch') || text.includes('network')) {
    return 'Проблема с сетью. Проверьте подключение к интернету и попробуйте снова.'
  }

  return 'Не получилось выполнить действие. Попробуйте ещё раз чуть позже.'
}
