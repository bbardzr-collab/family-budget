import { useState } from 'react'
import { Button, LoadingState, Modal, Text } from '@/components/ui'
import { useToast } from '@/components/ui/Toast'
import { useCategoryUsage, useDeleteCategory, useToggleCategory } from './hooks'
import { isCategoryUsed } from './api'
import { getCategoryErrorMessage } from './errors'
import type { CategoryListItem } from './api'

interface DeleteCategoryModalProps {
  category: CategoryListItem | null
  onClose: () => void
}

/**
 * "Безопасное удаление" категории (Этап 8, п.13) — единственная точка входа
 * для действия "Удалить" в UI. Перед показом кнопки удаления проверяет
 * использование категории в transactions/budget_categories/planned_expenses
 * (useCategoryUsage → fetchCategoryUsage). Если категория используется ИЛИ
 * является системной (is_custom=false) — предлагает "Отключить" вместо
 * физического удаления, как явно требует ТЗ.
 *
 * Это UX-слой поверх настоящей защиты на сервере (FK RESTRICT + RLS
 * is_custom=true, миграция 0017) — даже если бы эта проверка ошиблась или
 * устарела из-за гонки, DELETE всё равно был бы отклонён Postgres, а
 * getCategoryErrorMessage показал бы понятное сообщение вместо технической
 * ошибки (см. errors.ts).
 */
export function DeleteCategoryModal({ category, onClose }: DeleteCategoryModalProps) {
  const { toast } = useToast()
  const open = Boolean(category)
  const canPhysicallyDelete = Boolean(category?.isCustom)
  const usageQuery = useCategoryUsage(category?.id, open && canPhysicallyDelete)
  const deleteCategoryMutation = useDeleteCategory()
  const toggleCategoryMutation = useToggleCategory()
  const [error, setError] = useState<string | null>(null)

  const used = usageQuery.data ? isCategoryUsed(usageQuery.data) : false
  const offerDisableInstead = !canPhysicallyDelete || used

  function handleClose() {
    setError(null)
    onClose()
  }

  async function handleDelete() {
    if (!category) return
    setError(null)
    try {
      await deleteCategoryMutation.mutateAsync(category.id)
      toast({ type: 'success', title: 'Категория удалена' })
      onClose()
    } catch (err) {
      setError(getCategoryErrorMessage(err))
    }
  }

  async function handleDisable() {
    if (!category) return
    setError(null)
    try {
      await toggleCategoryMutation.mutateAsync({ id: category.id, isActive: false })
      toast({ type: 'success', title: 'Категория отключена' })
      onClose()
    } catch (err) {
      setError(getCategoryErrorMessage(err))
    }
  }

  const busy = deleteCategoryMutation.isPending || toggleCategoryMutation.isPending

  return (
    <Modal
      open={open}
      onClose={handleClose}
      title="Удалить категорию?"
      footer={
        <>
          <Button variant="outline" onClick={handleClose}>
            Отмена
          </Button>
          {!usageQuery.isLoading && offerDisableInstead && (
            <Button variant="destructive" onClick={() => void handleDisable()} isLoading={busy} disabled={busy}>
              Отключить
            </Button>
          )}
          {!usageQuery.isLoading && !offerDisableInstead && (
            <Button variant="destructive" onClick={() => void handleDelete()} isLoading={busy} disabled={busy}>
              Удалить
            </Button>
          )}
        </>
      }
    >
      {canPhysicallyDelete && usageQuery.isLoading && <LoadingState label="Проверяем использование категории…" />}

      {(!canPhysicallyDelete || !usageQuery.isLoading) && (
        <Text variant="secondary">
          {!canPhysicallyDelete &&
            `Категория «${category?.name}» — стандартная, её нельзя удалить физически. Вы можете отключить её — она перестанет предлагаться при выборе, но история операций сохранится.`}
          {canPhysicallyDelete &&
            used &&
            `Категория «${category?.name}» уже используется в операциях. Удалить её нельзя — это бы нарушило историю. Вы можете отключить её вместо удаления.`}
          {canPhysicallyDelete &&
            !used &&
            `Категория «${category?.name}» будет удалена без возможности восстановления. Она нигде не используется.`}
        </Text>
      )}

      {error && (
        <p role="alert" className="mt-3 text-sm text-destructive">
          {error}
        </p>
      )}
    </Modal>
  )
}
