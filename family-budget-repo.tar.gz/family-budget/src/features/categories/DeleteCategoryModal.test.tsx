import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { ToastProvider } from '@/components/ui/Toast'
import { DeleteCategoryModal } from './DeleteCategoryModal'
import type { CategoryListItem } from './api'

const { mockUseCategoryUsage, mockDeleteMutateAsync, mockToggleMutateAsync } = vi.hoisted(() => ({
  mockUseCategoryUsage: vi.fn(),
  mockDeleteMutateAsync: vi.fn(),
  mockToggleMutateAsync: vi.fn(),
}))

vi.mock('./hooks', () => ({
  useCategoryUsage: mockUseCategoryUsage,
  useDeleteCategory: () => ({ mutateAsync: mockDeleteMutateAsync, isPending: false }),
  useToggleCategory: () => ({ mutateAsync: mockToggleMutateAsync, isPending: false }),
}))

const CUSTOM_CATEGORY: CategoryListItem = {
  id: 'cat-custom',
  name: 'Хобби',
  type: 'WANTS',
  icon: 'palette',
  isActive: true,
  isCustom: true,
}

const SYSTEM_CATEGORY: CategoryListItem = {
  id: 'cat-system',
  name: 'Продукты',
  type: 'OBLIGATORY',
  icon: 'shopping-cart',
  isActive: true,
  isCustom: false,
}

describe('DeleteCategoryModal (Этап 8, п.13, 24, 30)', () => {
  beforeEach(() => {
    mockUseCategoryUsage.mockReset()
    mockDeleteMutateAsync.mockReset()
    mockToggleMutateAsync.mockReset()
    mockDeleteMutateAsync.mockResolvedValue(undefined)
    mockToggleMutateAsync.mockResolvedValue({})
  })

  it('системную категорию нельзя физически удалить — предлагает только "Отключить"', () => {
    mockUseCategoryUsage.mockReturnValue({ data: undefined, isLoading: false })

    render(
      <ToastProvider>
        <DeleteCategoryModal category={SYSTEM_CATEGORY} onClose={vi.fn()} />
      </ToastProvider>,
    )

    expect(screen.getByText(/стандартная, её нельзя удалить физически/)).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Отключить' })).toBeInTheDocument()
    expect(screen.queryByRole('button', { name: 'Удалить' })).not.toBeInTheDocument()
  })

  it('пользовательскую неиспользуемую категорию можно удалить физически', async () => {
    const user = userEvent.setup()
    mockUseCategoryUsage.mockReturnValue({
      data: { transactionsCount: 0, budgetCategoriesCount: 0, plannedExpensesCount: 0 },
      isLoading: false,
    })

    render(
      <ToastProvider>
        <DeleteCategoryModal category={CUSTOM_CATEGORY} onClose={vi.fn()} />
      </ToastProvider>,
    )

    expect(screen.getByText(/будет удалена без возможности восстановления/)).toBeInTheDocument()
    const deleteButton = screen.getByRole('button', { name: 'Удалить' })
    await user.click(deleteButton)

    await waitFor(() => expect(mockDeleteMutateAsync).toHaveBeenCalledWith('cat-custom'))
  })

  it('пользовательскую категорию, используемую в операциях, нельзя удалить — предлагает "Отключить" (защита истории, п.13, 24)', async () => {
    const user = userEvent.setup()
    mockUseCategoryUsage.mockReturnValue({
      data: { transactionsCount: 3, budgetCategoriesCount: 0, plannedExpensesCount: 0 },
      isLoading: false,
    })

    render(
      <ToastProvider>
        <DeleteCategoryModal category={CUSTOM_CATEGORY} onClose={vi.fn()} />
      </ToastProvider>,
    )

    expect(screen.getByText(/уже используется в операциях/)).toBeInTheDocument()
    expect(screen.queryByRole('button', { name: 'Удалить' })).not.toBeInTheDocument()

    await user.click(screen.getByRole('button', { name: 'Отключить' }))
    await waitFor(() => expect(mockToggleMutateAsync).toHaveBeenCalledWith({ id: 'cat-custom', isActive: false }))
  })
})
