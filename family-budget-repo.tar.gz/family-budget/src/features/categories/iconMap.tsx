import {
  Baby,
  Bus,
  Car,
  CreditCard,
  Dog,
  Dumbbell,
  Fuel,
  Gift,
  GraduationCap,
  Heart,
  HeartPulse,
  Home,
  HelpCircle,
  Landmark,
  Wallet,
  Music,
  MoreHorizontal,
  Palette,
  PartyPopper,
  PiggyBank,
  Plane,
  Plug,
  Shirt,
  ShieldCheck,
  ShoppingBag,
  ShoppingCart,
  Smartphone,
  Sparkles,
  TrendingUp,
  Utensils,
  Wifi,
  type LucideIcon,
} from 'lucide-react'

/**
 * Единая карта icon-name (строка из БД, `categories.icon`) → компонент
 * Lucide (Этап 8, п.8). В БД хранится только строка-идентификатор,
 * НИКОГДА не SVG/HTML — это и требование ТЗ, и просто безопаснее (нет
 * risk'а вставить произвольную разметку через "иконку").
 *
 * Неизвестное/отсутствующее значение → безопасный fallback (HelpCircle),
 * без падения приложения — используется и для NULL (у операций без
 * категории эта функция не вызывается вовсе, см. CategoryBadge), и для
 * кастомных категорий, если когда-то в БД окажется значение не из набора
 * ниже (например, после ручного изменения данных в Supabase Studio).
 */
export const CATEGORY_ICON_MAP: Record<string, LucideIcon> = {
  'shopping-cart': ShoppingCart,
  'shopping-bag': ShoppingBag,
  home: Home,
  plug: Plug,
  car: Car,
  bus: Bus,
  fuel: Fuel,
  'heart-pulse': HeartPulse,
  heart: Heart,
  'graduation-cap': GraduationCap,
  wifi: Wifi,
  smartphone: Smartphone,
  'credit-card': CreditCard,
  landmark: Landmark,
  wallet: Wallet,
  baby: Baby,
  dog: Dog,
  shirt: Shirt,
  'party-popper': PartyPopper,
  utensils: Utensils,
  plane: Plane,
  gift: Gift,
  sparkles: Sparkles,
  music: Music,
  dumbbell: Dumbbell,
  palette: Palette,
  'piggy-bank': PiggyBank,
  'trending-up': TrendingUp,
  'shield-check': ShieldCheck,
  'more-horizontal': MoreHorizontal,
}

/** Безопасный fallback для неизвестной/отсутствующей иконки. */
export const FALLBACK_CATEGORY_ICON: LucideIcon = HelpCircle

export function getCategoryIcon(icon: string | null | undefined): LucideIcon {
  if (!icon) return FALLBACK_CATEGORY_ICON
  return CATEGORY_ICON_MAP[icon] ?? FALLBACK_CATEGORY_ICON
}

/**
 * Набор иконок, предлагаемых пользователю при создании/редактировании
 * категории (Этап 8, п.9 — поле "Иконка" обязательно). Ограниченный
 * curated-список вместо произвольного текстового ввода — исключает и опечатки
 * (icon хранился бы валидным, но нерисуемым значением), и попытку вставить
 * произвольную строку в это поле.
 */
export const CATEGORY_ICON_OPTIONS: { value: string; icon: LucideIcon; label: string }[] = [
  { value: 'shopping-cart', icon: ShoppingCart, label: 'Тележка' },
  { value: 'shopping-bag', icon: ShoppingBag, label: 'Пакет' },
  { value: 'home', icon: Home, label: 'Дом' },
  { value: 'plug', icon: Plug, label: 'Коммунальные' },
  { value: 'car', icon: Car, label: 'Машина' },
  { value: 'bus', icon: Bus, label: 'Транспорт' },
  { value: 'fuel', icon: Fuel, label: 'Бензин' },
  { value: 'heart-pulse', icon: HeartPulse, label: 'Здоровье' },
  { value: 'heart', icon: Heart, label: 'Сердце' },
  { value: 'graduation-cap', icon: GraduationCap, label: 'Образование' },
  { value: 'wifi', icon: Wifi, label: 'Интернет' },
  { value: 'smartphone', icon: Smartphone, label: 'Телефон' },
  { value: 'credit-card', icon: CreditCard, label: 'Кредит' },
  { value: 'landmark', icon: Landmark, label: 'Банк' },
  { value: 'wallet', icon: Wallet, label: 'Кошелёк' },
  { value: 'baby', icon: Baby, label: 'Ребёнок' },
  { value: 'dog', icon: Dog, label: 'Питомец' },
  { value: 'shirt', icon: Shirt, label: 'Одежда' },
  { value: 'party-popper', icon: PartyPopper, label: 'Праздник' },
  { value: 'utensils', icon: Utensils, label: 'Кафе' },
  { value: 'plane', icon: Plane, label: 'Путешествия' },
  { value: 'gift', icon: Gift, label: 'Подарок' },
  { value: 'sparkles', icon: Sparkles, label: 'Красота' },
  { value: 'music', icon: Music, label: 'Музыка' },
  { value: 'dumbbell', icon: Dumbbell, label: 'Спорт' },
  { value: 'palette', icon: Palette, label: 'Хобби' },
  { value: 'piggy-bank', icon: PiggyBank, label: 'Накопления' },
  { value: 'trending-up', icon: TrendingUp, label: 'Инвестиции' },
  { value: 'shield-check', icon: ShieldCheck, label: 'Резерв' },
  { value: 'more-horizontal', icon: MoreHorizontal, label: 'Другое' },
]
