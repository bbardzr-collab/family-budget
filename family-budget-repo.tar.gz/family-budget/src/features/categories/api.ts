import { supabase } from '@/lib/supabase'
import type { Tables } from '@/types/database'
import type { CategoryType } from './constants'

/**
 * Тонкий слой доступа к данным категорий (Этап 8, п.14) — только запросы,
 * никакой бизнес-логики и никакого React, по аналогии с
 * features/transactions/api.ts и features/family/api.ts.
 *
 * ─── Архитектурное решение по INSERT/UPDATE/DELETE (по аналогии с Этапом 7) ───
 * Никаких новых SECURITY DEFINER RPC — операции идут напрямую через Supabase
 * поверх RLS-политик categories_insert_adult_admin / categories_update_adult_admin
 * / categories_delete_adult_admin (см. supabase/migrations/0010, ужесточено в
 * 0017_categories_hardening.sql). Family_id и is_custom НИКОГДА не приходят в
 * update-запросах с клиента (см. updateCategory/toggleCategory ниже) — RLS сама
 * решает, что вообще видно/доступно для изменения текущему пользователю.
 */

export type CategoryRow = Tables<'categories'>

export interface CategoryListItem {
  id: string
  name: string
  type: CategoryType
  icon: string | null
  isActive: boolean
  isCustom: boolean
}

function mapRow(row: {
  id: string
  name: string
  type: string
  icon: string | null
  is_active: boolean
  is_custom: boolean
}): CategoryListItem {
  return {
    id: row.id,
    name: row.name,
    type: row.type as CategoryType,
    icon: row.icon,
    isActive: row.is_active,
    isCustom: row.is_custom,
  }
}

const SELECT_FIELDS = 'id, name, type, icon, is_active, is_custom'

/** Все категории семьи (и активные, и отключённые) — список сортируется по названию внутри группы на клиенте (CategoriesPage/CategoryPickerModal). */
export async function fetchCategories(familyId: string): Promise<CategoryListItem[]> {
  const { data, error } = await supabase
    .from('categories')
    .select(SELECT_FIELDS)
    .eq('family_id', familyId)
    .order('name', { ascending: true })

  if (error) throw error
  return (data ?? []).map(mapRow)
}

export interface CreateCategoryInput {
  familyId: string
  name: string
  type: CategoryType
  icon: string
}

export async function createCategory(input: CreateCategoryInput): Promise<CategoryListItem> {
  const { data, error } = await supabase
    .from('categories')
    .insert({
      family_id: input.familyId,
      name: input.name,
      type: input.type,
      icon: input.icon,
      is_custom: true,
      is_active: true,
    })
    .select(SELECT_FIELDS)
    .single()

  if (error) throw error
  return mapRow(data)
}

export interface UpdateCategoryInput {
  id: string
  name: string
  type: CategoryType
  icon: string
}

/**
 * Редактирование (Этап 8, п.11) — только название/тип/иконка. is_custom и
 * family_id намеренно не передаются: is_custom не может измениться через
 * форму редактирования (системная категория не превращается в
 * пользовательскую и наоборот), а сменить семью категории вообще невозможно.
 * RLS (categories_update_adult_admin) не ограничивает UPDATE только
 * is_custom=true категориями — по ТЗ (п.11) системные категории можно
 * редактировать (название/тип/иконку), запрещено только менять их is_custom.
 */
export async function updateCategory(input: UpdateCategoryInput): Promise<CategoryListItem> {
  const { data, error } = await supabase
    .from('categories')
    .update({ name: input.name, type: input.type, icon: input.icon })
    .eq('id', input.id)
    .select(SELECT_FIELDS)
    .single()

  if (error) throw error
  return mapRow(data)
}

/** Включить/выключить категорию (Этап 8, п.12) — is_active, история операций не трогается. */
export async function toggleCategoryActive(id: string, isActive: boolean): Promise<CategoryListItem> {
  const { data, error } = await supabase
    .from('categories')
    .update({ is_active: isActive })
    .eq('id', id)
    .select(SELECT_FIELDS)
    .single()

  if (error) throw error
  return mapRow(data)
}

export interface CategoryUsage {
  transactionsCount: number
  budgetCategoriesCount: number
  plannedExpensesCount: number
}

export function isCategoryUsed(usage: CategoryUsage): boolean {
  return usage.transactionsCount > 0 || usage.budgetCategoriesCount > 0 || usage.plannedExpensesCount > 0
}

/**
 * UX-предпроверка перед показом кнопки "Удалить" (Этап 8, п.13) — считает
 * использование категории в трёх таблицах, как явно требует ТЗ. Это ТОЛЬКО
 * для того, чтобы не предлагать пользователю действие, которое всё равно
 * будет отклонено сервером — настоящая гарантия безопасности физического
 * удаления обеспечивается на сервере: FK transactions.category_id теперь
 * ON DELETE RESTRICT (миграция 0017) и budget_categories/planned_expenses
 * ссылаются на categories.id так же по FK, так что даже если бы этот
 * клиентский подсчёт был неточен или устарел (гонка между проверкой и
 * удалением), Postgres всё равно физически откажет в DELETE при наличии
 * ссылающихся строк — клиентская проверка не единственная линия защиты.
 */
export async function fetchCategoryUsage(categoryId: string): Promise<CategoryUsage> {
  const [transactions, budgetCategories, plannedExpenses] = await Promise.all([
    supabase.from('transactions').select('id', { count: 'exact', head: true }).eq('category_id', categoryId),
    supabase
      .from('budget_categories')
      .select('category_id', { count: 'exact', head: true })
      .eq('category_id', categoryId),
    supabase
      .from('planned_expenses')
      .select('id', { count: 'exact', head: true })
      .eq('category_id', categoryId),
  ])

  if (transactions.error) throw transactions.error
  if (budgetCategories.error) throw budgetCategories.error
  if (plannedExpenses.error) throw plannedExpenses.error

  return {
    transactionsCount: transactions.count ?? 0,
    budgetCategoriesCount: budgetCategories.count ?? 0,
    plannedExpensesCount: plannedExpenses.count ?? 0,
  }
}

/**
 * Физическое удаление (Этап 8, п.13) — доступно RLS только для is_custom=true
 * категорий (categories_delete_adult_admin, миграция 0017); если категория
 * всё же где-то используется, Postgres отклонит DELETE ошибкой
 * foreign_key_violation (23503) — см. getCategoryErrorMessage.
 */
export async function deleteCategory(id: string): Promise<void> {
  const { error, count } = await supabase.from('categories').delete({ count: 'exact' }).eq('id', id)

  if (error) throw error
  if (!count) {
    throw { message: 'Категория не найдена или у вас нет прав её удалить.', code: 'PGRST116' }
  }
}
