import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { ToastProvider } from '@/components/ui/Toast'
import { CategoryFormModal } from './CategoryFormModal'
import type { CategoryListItem } from './api'

const { mockCreateMutateAsync, mockUpdateMutateAsync } = vi.hoisted(() => ({
  mockCreateMutateAsync: vi.fn(),
  mockUpdateMutateAsync: vi.fn(),
}))

vi.mock('./hooks', () => ({
  useCreateCategory: () => ({ mutateAsync: mockCreateMutateAsync, isPending: false }),
  useUpdateCategory: () => ({ mutateAsync: mockUpdateMutateAsync, isPending: false }),
}))

function renderModal(props: Partial<React.ComponentProps<typeof CategoryFormModal>> = {}) {
  return render(
    <ToastProvider>
      <CategoryFormModal open onClose={vi.fn()} {...props} />
    </ToastProvider>,
  )
}

describe('CategoryFormModal (Этап 8, п.9-11, 30)', () => {
  beforeEach(() => {
    mockCreateMutateAsync.mockReset()
    mockUpdateMutateAsync.mockReset()
    mockCreateMutateAsync.mockResolvedValue({})
    mockUpdateMutateAsync.mockResolvedValue({})
  })

  it('показывает поля Название/Тип/Иконка с человеческими подписями типа, а не сырой enum', () => {
    renderModal()

    expect(screen.getByLabelText('Название')).toBeInTheDocument()
    expect(screen.getByLabelText('Тип')).toBeInTheDocument()
    expect(screen.getByText('Обязательное')).toBeInTheDocument()
    expect(screen.getByText('Желания')).toBeInTheDocument()
    expect(screen.getByText('Цели')).toBeInTheDocument()
    expect(screen.getByText('Другое')).toBeInTheDocument()
    expect(screen.queryByText('OBLIGATORY')).not.toBeInTheDocument()
    expect(screen.queryByText('WANTS')).not.toBeInTheDocument()
  })

  it('отклоняет пустое название при сабмите', async () => {
    const user = userEvent.setup()
    renderModal()

    await user.click(screen.getByRole('radio', { name: 'Тележка' }))
    await user.click(screen.getByRole('button', { name: /добавить категорию/i }))

    expect(await screen.findByText('Введите название категории')).toBeInTheDocument()
    expect(mockCreateMutateAsync).not.toHaveBeenCalled()
  })

  it('требует выбрать иконку', async () => {
    const user = userEvent.setup()
    renderModal()

    await user.type(screen.getByLabelText('Название'), 'Хобби')
    await user.click(screen.getByRole('button', { name: /добавить категорию/i }))

    expect(await screen.findByText('Выберите иконку')).toBeInTheDocument()
    expect(mockCreateMutateAsync).not.toHaveBeenCalled()
  })

  it('создание: заполненная форма вызывает мутацию создания с трим названием', async () => {
    const user = userEvent.setup()
    renderModal()

    await user.type(screen.getByLabelText('Название'), '  Хобби  ')
    await user.selectOptions(screen.getByLabelText('Тип'), 'WANTS')
    await user.click(screen.getByRole('radio', { name: 'Хобби' }))
    await user.click(screen.getByRole('button', { name: /добавить категорию/i }))

    expect(mockCreateMutateAsync).toHaveBeenCalledWith({ name: 'Хобби', type: 'WANTS', icon: 'palette' })
  })

  it('дубликат названия показывает понятную ошибку с сервера', async () => {
    const user = userEvent.setup()
    mockCreateMutateAsync.mockRejectedValueOnce({ code: '23505', message: 'duplicate key value' })
    renderModal()

    await user.type(screen.getByLabelText('Название'), 'Продукты')
    await user.click(screen.getByRole('radio', { name: 'Тележка' }))
    await user.click(screen.getByRole('button', { name: /добавить категорию/i }))

    expect(await screen.findByText('Категория с таким названием уже есть в вашей семье.')).toBeInTheDocument()
  })

  it('редактирование: форма предзаполнена данными категории, сабмит вызывает мутацию обновления', async () => {
    const user = userEvent.setup()
    const category: CategoryListItem = {
      id: 'cat-1',
      name: 'Продукты',
      type: 'OBLIGATORY',
      icon: 'shopping-cart',
      isActive: true,
      isCustom: false,
    }

    renderModal({ category })

    expect(screen.getByLabelText('Название')).toHaveValue('Продукты')
    expect(screen.getByRole('button', { name: /сохранить/i })).toBeInTheDocument()

    await user.clear(screen.getByLabelText('Название'))
    await user.type(screen.getByLabelText('Название'), 'Продукты и напитки')
    await user.click(screen.getByRole('button', { name: /сохранить/i }))

    expect(mockUpdateMutateAsync).toHaveBeenCalledWith({
      id: 'cat-1',
      name: 'Продукты и напитки',
      type: 'OBLIGATORY',
      icon: 'shopping-cart',
    })
  })
})
