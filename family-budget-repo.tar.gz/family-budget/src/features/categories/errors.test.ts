import { getCategoryErrorMessage } from './errors'

/**
 * Этап 20 — до этого этапа `categories/errors.ts` не имел собственного
 * теста и был покрыт только косвенно (через один сценарий в
 * CategoryFormModal.test.tsx) — регресс-тест на все ветки маппинга.
 */
describe('getCategoryErrorMessage (Этап 8 — регресс-тест Этапа 20)', () => {
  it('дубликат названия (23505) -> понятное сообщение (ТЗ, п.10 — case-insensitive)', () => {
    expect(getCategoryErrorMessage({ code: '23505', message: 'duplicate key value' })).toBe(
      'Категория с таким названием уже есть в вашей семье.',
    )
  })

  it('дубликат по тексту сообщения (без code) -> то же сообщение', () => {
    expect(getCategoryErrorMessage({ message: 'category already exists' })).toBe(
      'Категория с таким названием уже есть в вашей семье.',
    )
  })

  it('категория используется в операциях (23503, FK RESTRICT) -> понятное сообщение', () => {
    expect(getCategoryErrorMessage({ code: '23503', message: 'violates foreign key constraint' })).toBe(
      'Эта категория уже используется в операциях — удалить её нельзя. Отключите категорию вместо удаления.',
    )
  })

  it('RLS/policy отклонила действие -> "недостаточно прав"', () => {
    expect(
      getCategoryErrorMessage({ message: 'new row violates row-level security policy for table "categories"' }),
    ).toBe('Недостаточно прав для этого действия.')
  })

  it('PGRST116 (не найдена / нет прав) -> понятное сообщение', () => {
    expect(getCategoryErrorMessage({ code: 'PGRST116', message: 'no rows' })).toBe(
      'Категория не найдена или у вас нет прав её изменить.',
    )
  })

  it('сетевая ошибка по тексту -> сообщение про сеть', () => {
    expect(getCategoryErrorMessage({ message: 'network request failed' })).toBe(
      'Проблема с сетью. Проверьте подключение к интернету и попробуйте снова.',
    )
  })

  it('сетевая ошибка (TypeError) -> сообщение про сеть', () => {
    expect(getCategoryErrorMessage(new TypeError('Failed to fetch'))).toBe(
      'Проблема с сетью. Проверьте подключение к интернету и попробуйте снова.',
    )
  })

  it('неизвестная ошибка -> общий fallback, без раскрытия технических деталей', () => {
    expect(getCategoryErrorMessage({ message: 'some_unmapped_postgres_error' })).toBe(
      'Не получилось выполнить действие. Попробуйте ещё раз чуть позже.',
    )
  })

  it('пустая ошибка -> общий fallback без падения', () => {
    expect(getCategoryErrorMessage(undefined)).toBe('Неизвестная ошибка. Попробуйте ещё раз.')
  })
})
