import { z } from 'zod'
import { CATEGORY_ICON_MAP } from './iconMap'
import { CATEGORY_NAME_MAX_LENGTH, CATEGORY_TYPES } from './constants'

/**
 * Форма создания/редактирования категории (Этап 8, п.9-10).
 *
 * Нормализация названия — обрезка пробелов по краям здесь же, в схеме (а не
 * только в БД), чтобы "  Продукты  " и "Продукты" считались одинаковыми уже
 * на клиенте, до похода в сеть — но именно БД-индекс
 * categories_family_id_normalized_name_key (см. миграцию 0017) является
 * настоящей гарантией уникальности, а не эта схема (сообщение об ошибке
 * дубликата всё равно приходит с сервера, см. errors.ts).
 */
export const categoryFormSchema = z.object({
  name: z
    .string()
    .trim()
    .min(1, 'Введите название категории')
    .max(CATEGORY_NAME_MAX_LENGTH, `Название слишком длинное — максимум ${CATEGORY_NAME_MAX_LENGTH} символов`),
  type: z.enum(CATEGORY_TYPES),
  icon: z
    .string()
    .min(1, 'Выберите иконку')
    .refine((value) => value in CATEGORY_ICON_MAP, { message: 'Выберите иконку из списка' }),
})

export type CategoryFormValues = z.infer<typeof categoryFormSchema>
