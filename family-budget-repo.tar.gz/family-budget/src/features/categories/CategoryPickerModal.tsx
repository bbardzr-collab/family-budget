import { createElement } from 'react'
import { Ban, Check } from 'lucide-react'
import { Badge, Modal } from '@/components/ui'
import { cn } from '@/utils/cn'
import { CATEGORY_TYPE_LABELS, CATEGORY_TYPE_ORDER } from './constants'
import { getCategoryIcon } from './iconMap'
import type { CategoryListItem } from './api'

interface CategoryPickerModalProps {
  open: boolean
  onClose: () => void
  categories: CategoryListItem[]
  selectedCategoryId: string | null
  onSelect: (categoryId: string | null) => void
}

/**
 * Модальный выбор категории для расхода (Этап 8, п.16-19) — переиспользуемый
 * компонент, отдельный от Dropdown/Select: ни один из них не поддерживает
 * группировку по типу с иконками (см. исследование перед реализацией —
 * Dropdown.tsx плоский, нативный <select> не рисует иконки в <option>).
 *
 * Показывает только активные категории (is_active=true), сгруппированные по
 * типу (п.17). Исключение — п.19: если у редактируемой операции уже стоит
 * category_id ОТКЛЮЧЁННОЙ категории, она всё равно показывается — отдельно,
 * сверху, с меткой "Выключена" — чтобы форма нормально открывалась и не
 * "теряла" текущий выбор, но явно сигнализировала, что стоит выбрать другую.
 */
export function CategoryPickerModal({
  open,
  onClose,
  categories,
  selectedCategoryId,
  onSelect,
}: CategoryPickerModalProps) {
  const selectedInactive = categories.find((c) => c.id === selectedCategoryId && !c.isActive) ?? null
  const activeByType = CATEGORY_TYPE_ORDER.map((type) => ({
    type,
    items: categories.filter((c) => c.type === type && c.isActive),
  })).filter((group) => group.items.length > 0)

  function handleSelect(categoryId: string | null) {
    onSelect(categoryId)
    onClose()
  }

  return (
    <Modal open={open} onClose={onClose} title="Категория">
      <div className="flex flex-col gap-4">
        <button
          type="button"
          onClick={() => handleSelect(null)}
          className={cn(
            'flex items-center gap-3 rounded-md border p-3 text-left text-sm font-medium transition-colors',
            'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
            selectedCategoryId === null
              ? 'border-primary bg-primary-soft text-primary'
              : 'border-border bg-card text-foreground hover:bg-muted',
          )}
        >
          <span className="flex size-8 shrink-0 items-center justify-center rounded-full bg-muted text-muted-foreground">
            <Ban className="size-4" aria-hidden="true" />
          </span>
          Без категории
          {selectedCategoryId === null && <Check className="ml-auto size-4" aria-hidden="true" />}
        </button>

        {selectedInactive && (
          <div className="flex flex-col gap-2">
            <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Текущая категория</p>
            <CategoryRow
              category={selectedInactive}
              active
              disabledLabel="Выключена"
              onClick={() => handleSelect(selectedInactive.id)}
            />
          </div>
        )}

        {activeByType.map((group) => (
          <div key={group.type} className="flex flex-col gap-2">
            <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              {CATEGORY_TYPE_LABELS[group.type]}
            </p>
            <div className="flex flex-col gap-1.5">
              {group.items.map((item) => (
                <CategoryRow
                  key={item.id}
                  category={item}
                  active={item.id === selectedCategoryId}
                  onClick={() => handleSelect(item.id)}
                />
              ))}
            </div>
          </div>
        ))}

        {activeByType.length === 0 && !selectedInactive && (
          <p className="py-6 text-center text-sm text-muted-foreground">
            В семье пока нет активных категорий. Добавьте категорию в разделе «Категории».
          </p>
        )}
      </div>
    </Modal>
  )
}

function CategoryRow({
  category,
  active,
  disabledLabel,
  onClick,
}: {
  category: CategoryListItem
  active: boolean
  disabledLabel?: string
  onClick: () => void
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'flex items-center gap-3 rounded-md border p-3 text-left text-sm font-medium transition-colors',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
        active ? 'border-primary bg-primary-soft text-primary' : 'border-border bg-card text-foreground hover:bg-muted',
      )}
    >
      <span className="flex size-8 shrink-0 items-center justify-center rounded-full bg-muted text-muted-foreground">
        {/* createElement, а не JSX-тег <Icon/> — компонент иконки выбирается
            динамически по строке из БД (getCategoryIcon), а React Compiler
            (react-hooks/static-components) запрещает использовать в JSX как
            тег переменную с компонентом, "созданным" во время рендера. */}
        {createElement(getCategoryIcon(category.icon), { className: 'size-4', 'aria-hidden': true })}
      </span>
      <span className="min-w-0 flex-1 truncate">{category.name}</span>
      {disabledLabel && (
        <Badge variant="default" className="shrink-0">
          {disabledLabel}
        </Badge>
      )}
      {active && <Check className="ml-auto size-4 shrink-0" aria-hidden="true" />}
    </button>
  )
}
