/**
 * Единый источник ключей React Query для домена "категории" (Этап 8, п.15) —
 * тот же паттерн, что и familyKeys/transactionsKeys/dashboardKeys.
 */
export const categoriesKeys = {
  all: ['categories'] as const,
  list: (familyId: string | undefined) => [...categoriesKeys.all, 'list', familyId] as const,
  usage: (categoryId: string) => [...categoriesKeys.all, 'usage', categoryId] as const,
}
