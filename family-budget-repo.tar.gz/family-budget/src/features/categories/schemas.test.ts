import { categoryFormSchema } from './schemas'

function baseValues(overrides: Partial<Record<string, unknown>> = {}) {
  return {
    name: 'Продукты',
    type: 'OBLIGATORY',
    icon: 'shopping-cart',
    ...overrides,
  }
}

describe('categoryFormSchema — название (Этап 8, п.10, 30)', () => {
  it('отклоняет пустое название', () => {
    const result = categoryFormSchema.safeParse(baseValues({ name: '' }))
    expect(result.success).toBe(false)
  })

  it('отклоняет название из одних пробелов', () => {
    const result = categoryFormSchema.safeParse(baseValues({ name: '   ' }))
    expect(result.success).toBe(false)
  })

  it('отклоняет слишком длинное название (>100 символов)', () => {
    const result = categoryFormSchema.safeParse(baseValues({ name: 'а'.repeat(101) }))
    expect(result.success).toBe(false)
  })

  it('принимает название ровно 100 символов', () => {
    const result = categoryFormSchema.safeParse(baseValues({ name: 'а'.repeat(100) }))
    expect(result.success).toBe(true)
  })

  it('обрезает пробелы по краям: "  Продукты  " → "Продукты"', () => {
    const result = categoryFormSchema.safeParse(baseValues({ name: '  Продукты  ' }))
    expect(result.success).toBe(true)
    if (result.success) expect(result.data.name).toBe('Продукты')
  })

  it('принимает корректное название', () => {
    const result = categoryFormSchema.safeParse(baseValues({ name: 'Хобби' }))
    expect(result.success).toBe(true)
  })
})

describe('categoryFormSchema — тип (Этап 8, п.5, 30)', () => {
  it.each(['OBLIGATORY', 'WANTS', 'GOALS', 'OTHER'])('принимает тип %s', (type) => {
    const result = categoryFormSchema.safeParse(baseValues({ type }))
    expect(result.success).toBe(true)
  })

  it('отклоняет неизвестный тип', () => {
    const result = categoryFormSchema.safeParse(baseValues({ type: 'UNKNOWN' }))
    expect(result.success).toBe(false)
  })
})

describe('categoryFormSchema — иконка (Этап 8, п.9)', () => {
  it('отклоняет пустую иконку (обязательное поле)', () => {
    const result = categoryFormSchema.safeParse(baseValues({ icon: '' }))
    expect(result.success).toBe(false)
  })

  it('отклоняет иконку не из известного набора', () => {
    const result = categoryFormSchema.safeParse(baseValues({ icon: 'not-a-real-icon' }))
    expect(result.success).toBe(false)
  })

  it('принимает известную иконку', () => {
    const result = categoryFormSchema.safeParse(baseValues({ icon: 'home' }))
    expect(result.success).toBe(true)
  })
})
