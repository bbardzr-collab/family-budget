/**
 * UI-метки для технического enum `categories.type` (Этап 8, п.5) — сырое
 * значение из БД (OBLIGATORY/WANTS/GOALS/OTHER) нигде не должно попадать на
 * экран, только эти подписи.
 *
 * Порядок CATEGORY_TYPE_ORDER одновременно задаёт порядок отображения групп
 * на /app/categories и в CategoryPickerModal (Этап 8, п.7, 17) — от
 * обязательных трат к прочим, интуитивно понятный пользователю.
 */
export const CATEGORY_TYPES = ['OBLIGATORY', 'WANTS', 'GOALS', 'OTHER'] as const
export type CategoryType = (typeof CATEGORY_TYPES)[number]

export const CATEGORY_TYPE_LABELS: Record<CategoryType, string> = {
  OBLIGATORY: 'Обязательное',
  WANTS: 'Желания',
  GOALS: 'Цели',
  OTHER: 'Другое',
}

export const CATEGORY_TYPE_ORDER: CategoryType[] = ['OBLIGATORY', 'WANTS', 'GOALS', 'OTHER']

/** Максимальная длина названия категории (Этап 8, п.10) — та же граница, что и у названия семьи (Этап 5). */
export const CATEGORY_NAME_MAX_LENGTH = 100
