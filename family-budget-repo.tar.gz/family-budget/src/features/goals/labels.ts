/** Человекочитаемые подписи для goal_type/status (ТЗ, Этап 11, п.6-7). */

export type GoalType = 'personal' | 'family'
export type GoalStatus = 'active' | 'completed' | 'cancelled'

const GOAL_TYPE_LABELS: Record<GoalType, string> = {
  personal: 'Личная',
  family: 'Семейная',
}

export function goalTypeLabel(goalType: string): string {
  return GOAL_TYPE_LABELS[goalType as GoalType] ?? goalType
}

const GOAL_STATUS_LABELS: Record<GoalStatus, string> = {
  active: 'Активная',
  completed: 'Выполнена',
  cancelled: 'Отменена',
}

export function goalStatusLabel(status: string): string {
  return GOAL_STATUS_LABELS[status as GoalStatus] ?? status
}
