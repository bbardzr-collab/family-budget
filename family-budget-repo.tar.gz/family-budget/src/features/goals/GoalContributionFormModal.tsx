import { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { Button, Input, Modal, Textarea } from '@/components/ui'
import { useToast } from '@/components/ui/Toast'
import { toDateInputValue } from '@/utils/formatDate'
import { goalContributionFormSchema, type GoalContributionFormValues } from './schemas'
import { useAddGoalContribution } from './hooks'
import { getGoalErrorMessage } from './errors'

interface GoalContributionFormModalProps {
  open: boolean
  onClose: () => void
  goalId: string | null
  goalTitle: string
  /** Вызывается после успешного взноса; goalCompleted=true, если ИМЕННО этот взнос завершил цель (ТЗ, п.18). */
  onCompleted?: (goalCompleted: boolean) => void
}

function buildDefaultValues(): GoalContributionFormValues {
  return { amount: '', comment: '', contributedAt: toDateInputValue() }
}

/**
 * Форма "Внести в цель" (ТЗ, п.12-13). Дата по умолчанию — сегодня.
 * user_id НЕ является полем формы вообще — определяется сервером внутри
 * RPC add_goal_contribution (auth.uid()), поэтому здесь просто нет способа
 * его подделать.
 *
 * formError НЕ сбрасывается внутри useEffect (react-hooks/set-state-in-effect
 * запрещает setState синхронно в теле эффекта, и здесь нет watch() из
 * react-hook-form, который снял бы эту проверку, как в GoalFormModal) —
 * Modal вызывает onClose при любом закрытии, а handleClose ниже уже
 * обнуляет formError на каждом закрытии (тот же приём, что в
 * BudgetCategoryFormModal.tsx).
 */
export function GoalContributionFormModal({
  open,
  onClose,
  goalId,
  goalTitle,
  onCompleted,
}: GoalContributionFormModalProps) {
  const { toast } = useToast()
  const addContributionMutation = useAddGoalContribution()
  const [formError, setFormError] = useState<string | null>(null)

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<GoalContributionFormValues>({
    resolver: zodResolver(goalContributionFormSchema),
    defaultValues: buildDefaultValues(),
  })

  useEffect(() => {
    if (open) {
      reset(buildDefaultValues())
    }
  }, [open, reset])

  function handleClose() {
    setFormError(null)
    onClose()
  }

  const onSubmit = handleSubmit(async (values) => {
    if (!goalId) return
    setFormError(null)
    let result
    try {
      result = await addContributionMutation.mutateAsync({
        goalId,
        amount: values.amount,
        comment: values.comment?.trim() || null,
        contributedAt: values.contributedAt,
      })
    } catch (error) {
      // GOAL_NOT_ACTIVE может произойти, только если цель успела завершиться/
      // отмениться, пока форма была открыта (гонка) — RPC отклоняет попытку,
      // ошибка показывается как обычная, отдельного случая не требуется.
      setFormError(getGoalErrorMessage(error))
      return
    }
    // Автозавершение (ТЗ, п.18) уже произошло на сервере триггером к моменту
    // ответа RPC (см. миграцию 0027) — goalCompleted просто сообщает об этом,
    // без отдельного запроса статуса цели.
    toast({ type: 'success', title: result.goalCompleted ? 'Цель достигнута!' : 'Взнос добавлен' })
    handleClose()
    onCompleted?.(result.goalCompleted)
  })

  const busy = isSubmitting || addContributionMutation.isPending

  return (
    <Modal open={open} onClose={handleClose} title="Внести в цель">
      <form className="flex flex-col gap-4" onSubmit={onSubmit} noValidate>
        <p className="text-sm text-muted-foreground">Цель: {goalTitle}</p>

        <Input
          label="Сумма"
          placeholder="Например, 10000"
          inputMode="decimal"
          autoComplete="off"
          error={errors.amount?.message}
          {...register('amount')}
        />

        <Input
          label="Дата"
          type="date"
          error={errors.contributedAt?.message}
          {...register('contributedAt')}
        />

        <Textarea
          label="Комментарий"
          placeholder="Необязательно"
          error={errors.comment?.message}
          {...register('comment')}
        />

        {formError && (
          <p role="alert" className="text-sm text-destructive">
            {formError}
          </p>
        )}

        <Button type="submit" size="lg" isLoading={busy} disabled={busy}>
          Внести
        </Button>
      </form>
    </Modal>
  )
}
