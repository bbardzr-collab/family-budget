/**
 * Перевод ошибок операций с целями в понятные человеку сообщения (ТЗ, п.20,
 * 39) — по аналогии с features/budgets/errors.ts. Часть ошибок приходит как
 * `raise exception '<CODE>: ...'` из RPC/триггеров (миграции 0024-0026),
 * остальное — стандартные коды PostgREST/Postgres для прямых CRUD-операций.
 */

interface MatchableError {
  message?: string
  code?: string
}

export function getGoalErrorMessage(error: unknown): string {
  if (!error) return 'Неизвестная ошибка. Попробуйте ещё раз.'

  if (error instanceof TypeError) {
    return 'Проблема с сетью. Проверьте подключение к интернету и попробуйте снова.'
  }

  const { message, code } = (error as MatchableError) ?? {}
  const text = (message ?? String(error)).toLowerCase()

  // Триггер goals_check_owner_in_family (миграция 0025) — попытка назначить
  // владельцем личной цели участника другой семьи.
  if (text.includes('goal_owner_not_in_family')) {
    return 'Выбранный владелец не состоит в этой семье.'
  }

  // RPC add_goal_contribution (миграция 0026) — цель уже completed/cancelled.
  if (text.includes('goal_not_active')) {
    return 'В эту цель больше нельзя вносить взносы — она завершена или отменена.'
  }

  if (text.includes('goal_not_found')) {
    return 'Цель не найдена или у вас нет к ней доступа.'
  }

  if (text.includes('no_family')) {
    return 'Сначала создайте семью или присоединитесь к ней.'
  }

  // CHECK goals_owner_matches_type — personal без owner или family с owner.
  if (text.includes('goals_owner_matches_type')) {
    return 'Для личной цели нужно выбрать владельца, для семейной — владелец не указывается.'
  }

  if (code === '23514' || text.includes('check constraint') || text.includes('violates check')) {
    return 'Некорректные данные цели.'
  }

  // RLS отклонила действие — CHILD пытается создать/изменить семейную цель
  // (ТЗ, п.26), или попытка затронуть цель другой семьи.
  if (text.includes('row-level security') || text.includes('policy')) {
    return 'Недостаточно прав для этого действия.'
  }

  if (code === 'PGRST116') {
    return 'Запись не найдена или у вас нет прав на это действие.'
  }

  if (text.includes('fetch') || text.includes('network')) {
    return 'Проблема с сетью. Проверьте подключение к интернету и попробуйте снова.'
  }

  return 'Не получилось выполнить действие. Попробуйте ещё раз чуть позже.'
}
