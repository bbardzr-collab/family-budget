import { useState } from 'react'
import { Button, Modal, Text } from '@/components/ui'
import { useToast } from '@/components/ui/Toast'
import { useCancelGoal } from './hooks'
import { getGoalErrorMessage } from './errors'

interface CancelGoalModalProps {
  goal: { id: string; title: string } | null
  onClose: () => void
}

/**
 * Подтверждение отмены цели (ТЗ, п.22) — в отличие от удаления, история
 * взносов ПОЛНОСТЬЮ сохраняется и остаётся доступна для просмотра, а сама
 * цель просто переходит в status='cancelled' (RLS запрещает пополнять
 * cancelled-цель, см. миграцию 0024).
 */
export function CancelGoalModal({ goal, onClose }: CancelGoalModalProps) {
  const { toast } = useToast()
  const cancelGoalMutation = useCancelGoal()
  const [error, setError] = useState<string | null>(null)

  async function handleConfirm() {
    if (!goal) return
    setError(null)
    try {
      await cancelGoalMutation.mutateAsync(goal.id)
      toast({ type: 'success', title: 'Цель отменена' })
      onClose()
    } catch (err) {
      setError(getGoalErrorMessage(err))
    }
  }

  function handleClose() {
    setError(null)
    onClose()
  }

  return (
    <Modal
      open={Boolean(goal)}
      onClose={handleClose}
      title="Отменить цель?"
      footer={
        <>
          <Button variant="outline" onClick={handleClose}>
            Отмена
          </Button>
          <Button
            variant="destructive"
            onClick={() => void handleConfirm()}
            isLoading={cancelGoalMutation.isPending}
            disabled={cancelGoalMutation.isPending}
          >
            Отменить цель
          </Button>
        </>
      }
    >
      <Text variant="secondary">
        {goal && `«${goal.title}» `}
        станет недоступна для новых взносов. История уже внесённых взносов сохранится, и цель можно будет
        возобновить позже.
      </Text>
      {error && (
        <p role="alert" className="mt-3 text-sm text-destructive">
          {error}
        </p>
      )}
    </Modal>
  )
}
