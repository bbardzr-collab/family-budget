import { describe, expect, it } from 'vitest'
import { goalContributionFormSchema, goalFormSchema } from './schemas'

describe('goalFormSchema (Этап 11, п.10, 37)', () => {
  const base = {
    title: 'Отпуск',
    goalType: 'family' as const,
    ownerUserId: '',
    targetAmount: '250000',
    targetDate: '',
    icon: 'plane',
  }

  it('принимает корректную семейную цель без владельца', () => {
    const result = goalFormSchema.safeParse(base)
    expect(result.success).toBe(true)
  })

  it('отклоняет пустое название', () => {
    const result = goalFormSchema.safeParse({ ...base, title: '   ' })
    expect(result.success).toBe(false)
  })

  it('отклоняет личную цель без владельца (ТЗ, п.8)', () => {
    const result = goalFormSchema.safeParse({ ...base, goalType: 'personal', ownerUserId: '' })
    expect(result.success).toBe(false)
    if (!result.success) {
      expect(result.error.issues.some((i) => i.path.includes('ownerUserId'))).toBe(true)
    }
  })

  it('принимает личную цель с владельцем', () => {
    const result = goalFormSchema.safeParse({ ...base, goalType: 'personal', ownerUserId: 'user-1' })
    expect(result.success).toBe(true)
  })

  it('отклоняет нулевую и отрицательную целевую сумму', () => {
    expect(goalFormSchema.safeParse({ ...base, targetAmount: '0' }).success).toBe(false)
    expect(goalFormSchema.safeParse({ ...base, targetAmount: '-100' }).success).toBe(false)
  })

  it('отклоняет более 2 знаков после запятой', () => {
    expect(goalFormSchema.safeParse({ ...base, targetAmount: '1000.999' }).success).toBe(false)
  })

  it('нормализует запятую как десятичный разделитель', () => {
    const result = goalFormSchema.safeParse({ ...base, targetAmount: '1500,50' })
    expect(result.success).toBe(true)
    if (result.success) expect(result.data.targetAmount).toBe('1500.50')
  })

  it('отклоняет сумму за пределами NUMERIC(14,2)', () => {
    expect(goalFormSchema.safeParse({ ...base, targetAmount: '1'.repeat(13) }).success).toBe(false)
  })

  it('принимает максимально допустимую сумму 999999999999.99 (Этап 20 — регресс-тест на границу NUMERIC(14,2))', () => {
    expect(goalFormSchema.safeParse({ ...base, targetAmount: '999999999999.99' }).success).toBe(true)
  })

  it('отклоняет некорректную дату достижения', () => {
    expect(goalFormSchema.safeParse({ ...base, targetDate: 'не дата' }).success).toBe(false)
  })

  it('допускает отсутствие даты достижения (необязательное поле)', () => {
    expect(goalFormSchema.safeParse({ ...base, targetDate: '' }).success).toBe(true)
  })

  it('требует выбор иконки', () => {
    expect(goalFormSchema.safeParse({ ...base, icon: '' }).success).toBe(false)
  })
})

describe('goalContributionFormSchema (Этап 11, п.13, 37)', () => {
  const base = { amount: '10000', comment: '', contributedAt: '2026-09-18' }

  it('принимает корректный взнос', () => {
    expect(goalContributionFormSchema.safeParse(base).success).toBe(true)
  })

  it('отклоняет нулевую и отрицательную сумму взноса', () => {
    expect(goalContributionFormSchema.safeParse({ ...base, amount: '0' }).success).toBe(false)
    expect(goalContributionFormSchema.safeParse({ ...base, amount: '-1' }).success).toBe(false)
  })

  it('требует дату', () => {
    expect(goalContributionFormSchema.safeParse({ ...base, contributedAt: '' }).success).toBe(false)
  })

  it('нормализует запятую в сумме', () => {
    const result = goalContributionFormSchema.safeParse({ ...base, amount: '1500,50' })
    expect(result.success).toBe(true)
    if (result.success) expect(result.data.amount).toBe('1500.50')
  })

  it('допускает пустой комментарий, отклоняет слишком длинный', () => {
    expect(goalContributionFormSchema.safeParse({ ...base, comment: '' }).success).toBe(true)
    expect(goalContributionFormSchema.safeParse({ ...base, comment: 'x'.repeat(501) }).success).toBe(false)
  })
})
