import { supabase } from '@/lib/supabase'

/**
 * Тонкий слой доступа к данным целей (Этап 11) — только запросы, никакой
 * бизнес-логики и никакого React, по аналогии с features/budgets/api.ts.
 *
 * ─── Чтение: RPC get_goals_list / get_goal_summary (миграция 0026) ───
 * Агрегация (SUM взносов, остаток, %) считается в Postgres — на клиент не
 * загружается список всех contributions ради подсчёта суммы (ТЗ, п.15, 28).
 * current_amount НЕ хранится нигде на клиенте как отдельное поле состояния —
 * оно каждый раз приходит пересчитанным с сервера как contributedAmount.
 *
 * ─── Запись ───
 * create_goal / add_goal_contribution — RPC (ТЗ, п.27: "особенно" для этих
 * двух операций), family_id/user_id определяются сервером по auth.uid(),
 * никогда не передаются с фронта. update/cancel/resume/delete — прямой
 * Supabase CRUD поверх RLS (goals_update_owner_or_admin/delete_owner_or_admin,
 * миграция 0024) — тот же принцип, что и в budgets/transactions: простые
 * однотабличные операции не нуждаются в отдельном RPC, RLS уже достаточная
 * граница.
 */

export type GoalType = 'personal' | 'family'
export type GoalStatus = 'active' | 'completed' | 'cancelled'

export interface GoalListItem {
  id: string
  goalType: GoalType
  ownerUserId: string | null
  ownerName: string | null
  title: string
  icon: string | null
  targetAmount: number
  targetDate: string | null
  status: GoalStatus
  /** Реальная сумма взносов, БЕЗ ограничения сверху (ТЗ, п.16-17). */
  contributedAmount: number
  /** max(target - contributed, 0) — никогда не отрицательный (ТЗ, п.16). */
  remainingAmount: number
  /** min(contributed/target*100, 100) — округлено до 1 знака на сервере. */
  percent: number
  createdAt: string
}

export interface GoalContributionItem {
  id: string
  amount: number
  comment: string | null
  contributedAt: string
  userId: string
  userName: string | null
}

export interface GoalDetail {
  id: string
  familyId: string
  goalType: GoalType
  ownerUserId: string | null
  ownerName: string | null
  title: string
  icon: string | null
  targetAmount: number
  targetDate: string | null
  status: GoalStatus
  createdAt: string
}

export interface GoalSummary {
  goal: GoalDetail
  contributedAmount: number
  remainingAmount: number
  percent: number
  contributions: GoalContributionItem[]
}

/** Список целей семьи с агрегатом — для /app/goals и превью на Dashboard (ТЗ, п.28-29, 31). */
export async function fetchGoalsList(): Promise<GoalListItem[]> {
  const { data, error } = await supabase.rpc('get_goals_list')
  if (error) throw error
  return (data ?? []) as unknown as GoalListItem[]
}

/** Полная сводка одной цели + история взносов. null — цель не найдена/недоступна. */
export async function fetchGoalSummary(goalId: string): Promise<GoalSummary | null> {
  const { data, error } = await supabase.rpc('get_goal_summary', { p_goal_id: goalId })
  if (error) throw error
  return (data ?? null) as unknown as GoalSummary | null
}

export interface CreateGoalInput {
  goalType: GoalType
  /** null для family; для personal — id владельца (по умолчанию сам создающий, см. RPC). */
  ownerUserId: string | null
  title: string
  icon: string
  /** Нормализованная строка с ровно 2 знаками после точки, см. schemas.ts. */
  targetAmount: string
  /** "yyyy-MM-dd" или null. */
  targetDate: string | null
}

/** Создание цели (ТЗ, п.9) — family_id определяется сервером внутри RPC, не передаётся отсюда. */
export async function createGoal(input: CreateGoalInput): Promise<{ id: string }> {
  const { data, error } = await supabase.rpc('create_goal', {
    p_goal_type: input.goalType,
    // p_owner_user_id/p_target_date реально nullable в самой Postgres-функции
    // (см. миграцию 0026) — сгенерированный тип Database['Functions'] просто
    // не отражает nullability параметров, поэтому здесь явный каст, а не
    // ошибка в API.
    p_owner_user_id: input.ownerUserId as unknown as string,
    p_title: input.title,
    p_icon: input.icon,
    p_target_amount: input.targetAmount as unknown as number,
    p_target_date: input.targetDate as unknown as string,
  })
  if (error) throw error
  return { id: data as unknown as string }
}

export interface UpdateGoalInput {
  id: string
  goalType: GoalType
  ownerUserId: string | null
  title: string
  icon: string
  targetAmount: string
  targetDate: string | null
}

/**
 * Редактирование цели (ТЗ, п.20) — можно менять всё, включая тип. При смене
 * family -> personal owner_user_id обязателен (проверяется формой, см.
 * GoalFormModal, и CHECK goals_owner_matches_type на уровне БД); при смене
 * personal -> family owner_user_id отправляется null.
 */
export async function updateGoal(input: UpdateGoalInput): Promise<void> {
  const { data, error } = await supabase
    .from('goals')
    .update({
      goal_type: input.goalType,
      owner_user_id: input.ownerUserId,
      title: input.title,
      icon: input.icon,
      target_amount: input.targetAmount as unknown as number,
      target_date: input.targetDate,
    })
    .eq('id', input.id)
    .select('id')
    .single()

  if (error) throw error
  if (!data) throw { message: 'Цель не найдена или у вас нет прав её изменить.', code: 'PGRST116' }
}

/** Удаление цели (ТЗ, п.21) — goal_contributions удаляются каскадом на уровне схемы (ON DELETE CASCADE). */
export async function deleteGoal(id: string): Promise<void> {
  const { error, count } = await supabase.from('goals').delete({ count: 'exact' }).eq('id', id)
  if (error) throw error
  if (!count) throw { message: 'Цель не найдена или у вас нет прав её удалить.', code: 'PGRST116' }
}

/** Отмена цели (ТЗ, п.22) — история взносов сохраняется, пополнение становится недоступно (RLS). */
export async function cancelGoal(id: string): Promise<void> {
  const { data, error } = await supabase
    .from('goals')
    .update({ status: 'cancelled' })
    .eq('id', id)
    .eq('status', 'active')
    .select('id')
    .single()

  if (error) throw error
  if (!data) {
    throw { message: 'Цель не найдена, уже не активна, или у вас нет прав её отменить.', code: 'PGRST116' }
  }
}

/** Возобновление отменённой цели (ТЗ, п.23). */
export async function resumeGoal(id: string): Promise<void> {
  const { data, error } = await supabase
    .from('goals')
    .update({ status: 'active' })
    .eq('id', id)
    .eq('status', 'cancelled')
    .select('id')
    .single()

  if (error) throw error
  if (!data) {
    throw { message: 'Цель не найдена, не отменена, или у вас нет прав её возобновить.', code: 'PGRST116' }
  }
}

export interface AddGoalContributionInput {
  goalId: string
  /** Нормализованная строка, см. schemas.ts. */
  amount: string
  comment: string | null
  /** "yyyy-MM-dd". */
  contributedAt: string
}

export interface AddGoalContributionResult {
  id: string
  /** true, если ИМЕННО этот взнос перевёл цель в completed (ТЗ, п.18) — см. миграцию 0027. */
  goalCompleted: boolean
}

/** Взнос в цель (ТЗ, п.12-13) — user_id определяется сервером (auth.uid()) внутри RPC, никогда с фронта. */
export async function addGoalContribution(input: AddGoalContributionInput): Promise<AddGoalContributionResult> {
  const { data, error } = await supabase.rpc('add_goal_contribution', {
    p_goal_id: input.goalId,
    p_amount: input.amount as unknown as number,
    // p_comment реально nullable в Postgres-функции — см. комментарий в createGoal выше.
    p_comment: input.comment as unknown as string,
    p_contributed_at: input.contributedAt,
  })
  if (error) throw error
  const result = data as unknown as { id: string; goalCompleted: boolean }
  return { id: result.id, goalCompleted: result.goalCompleted }
}
