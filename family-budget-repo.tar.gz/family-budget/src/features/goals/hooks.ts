import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useFamily } from '@/features/family/FamilyContext'
import { goalsKeys } from './queryKeys'
import {
  addGoalContribution,
  cancelGoal,
  createGoal,
  deleteGoal,
  fetchGoalSummary,
  fetchGoalsList,
  resumeGoal,
  updateGoal,
  type AddGoalContributionInput,
  type CreateGoalInput,
  type UpdateGoalInput,
} from './api'

/**
 * Server state целей — через TanStack Query (ТЗ, п.35), по тому же
 * принципу, что и features/budgets/hooks.ts.
 */
export function useGoals() {
  const { currentFamily } = useFamily()
  return useQuery({
    queryKey: goalsKeys.list(),
    queryFn: fetchGoalsList,
    enabled: Boolean(currentFamily?.id),
  })
}

export function useGoal(goalId: string | undefined) {
  return useQuery({
    queryKey: goalsKeys.detail(goalId ?? ''),
    queryFn: () => fetchGoalSummary(goalId!),
    enabled: Boolean(goalId),
  })
}

function invalidateGoalQueries(queryClient: ReturnType<typeof useQueryClient>, goalId?: string) {
  void queryClient.invalidateQueries({ queryKey: goalsKeys.all })
  if (goalId) {
    void queryClient.invalidateQueries({ queryKey: goalsKeys.detail(goalId) })
  }
}

export function useCreateGoal() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (input: CreateGoalInput) => createGoal(input),
    onSuccess: () => invalidateGoalQueries(queryClient),
  })
}

export function useUpdateGoal() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (input: UpdateGoalInput) => updateGoal(input),
    onSuccess: (_data, variables) => invalidateGoalQueries(queryClient, variables.id),
  })
}

export function useDeleteGoal() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => deleteGoal(id),
    onSuccess: () => invalidateGoalQueries(queryClient),
  })
}

export function useCancelGoal() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => cancelGoal(id),
    onSuccess: (_data, id) => invalidateGoalQueries(queryClient, id),
  })
}

export function useResumeGoal() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => resumeGoal(id),
    onSuccess: (_data, id) => invalidateGoalQueries(queryClient, id),
  })
}

/**
 * Взнос в цель (ТЗ, п.12-13, 19) — принципиально НЕ трогает
 * features/transactions/queryKeys (budgetsKeys уже инвалидируются
 * отдельно в transactions/hooks.ts при мутации транзакций, но пополнение
 * цели транзакцией не является, см. api.ts).
 */
export function useAddGoalContribution() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (input: AddGoalContributionInput) => addGoalContribution(input),
    onSuccess: (_data, variables) => invalidateGoalQueries(queryClient, variables.goalId),
  })
}
