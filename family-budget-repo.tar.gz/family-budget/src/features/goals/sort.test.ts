import { sortActiveGoals } from './sort'
import type { GoalListItem } from './api'

function makeGoal(overrides: Partial<GoalListItem>): GoalListItem {
  return {
    id: 'g1',
    familyId: 'f1',
    goalType: 'personal',
    ownerUserId: 'u1',
    ownerName: 'Test',
    title: 'Goal',
    icon: 'target',
    targetAmount: 1000,
    targetDate: null,
    status: 'active',
    contributedAmount: 0,
    remainingAmount: 1000,
    percent: 0,
    createdAt: '2026-01-01T00:00:00Z',
    updatedAt: '2026-01-01T00:00:00Z',
    ...overrides,
  } as GoalListItem
}

/**
 * Этап 20 — единственный sort/status-файл в проекте без собственного теста
 * (в отличие от аналогичных plannedExpenses/sort.ts и
 * recurringTransactions/status.ts), несмотря на такую же 4-ветвевую логику.
 */
describe('sortActiveGoals (ТЗ Этапа 11, п.32 — регресс-тест Этапа 20)', () => {
  it('обе цели с датой — сортирует по возрастанию target_date', () => {
    const a = makeGoal({ id: 'a', targetDate: '2026-12-01' })
    const b = makeGoal({ id: 'b', targetDate: '2026-06-01' })
    expect(sortActiveGoals([a, b]).map((g) => g.id)).toEqual(['b', 'a'])
  })

  it('цель с датой всегда раньше цели без даты', () => {
    const withDate = makeGoal({ id: 'with-date', targetDate: '2027-01-01' })
    const noDate = makeGoal({ id: 'no-date', targetDate: null, createdAt: '2020-01-01T00:00:00Z' })
    expect(sortActiveGoals([noDate, withDate]).map((g) => g.id)).toEqual(['with-date', 'no-date'])
  })

  it('обе цели без даты — сортирует по возрастанию createdAt (стабильный порядок)', () => {
    const older = makeGoal({ id: 'older', targetDate: null, createdAt: '2026-01-01T00:00:00Z' })
    const newer = makeGoal({ id: 'newer', targetDate: null, createdAt: '2026-06-01T00:00:00Z' })
    expect(sortActiveGoals([newer, older]).map((g) => g.id)).toEqual(['older', 'newer'])
  })

  it('не мутирует исходный массив', () => {
    const goals = [makeGoal({ id: 'a', targetDate: '2026-02-01' }), makeGoal({ id: 'b', targetDate: '2026-01-01' })]
    const original = [...goals]
    sortActiveGoals(goals)
    expect(goals).toEqual(original)
  })
})
