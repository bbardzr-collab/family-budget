import { z } from 'zod'

/**
 * Валидация формы цели и формы взноса (Этап 11, п.10, 37). Локальная копия
 * нормализации суммы — тот же принцип самодостаточности фичи, что уже
 * применён в features/budgets/schemas.ts и features/transactions/schemas.ts
 * (никакого умножения/деления на 100 и никакого parseFloat на промежуточном
 * шаге — только строковые операции, чтобы не словить JS float-баги).
 */
function normalizeAmountString(value: string): string {
  const [intPart, decPart = ''] = value.split('.')
  const cents = decPart.padEnd(2, '0').slice(0, 2)
  return `${intPart}.${cents}`
}

// До 12 цифр целой части + опционально точка и 1-2 цифры дробной — граница
// NUMERIC(14,2), тот же паттерн, что и в остальных денежных полях проекта.
const AMOUNT_PATTERN = /^\d{1,12}(\.\d{1,2})?$/

const baseAmountSchema = z
  .string()
  .trim()
  .min(1, 'Введите сумму')
  .transform((value) => value.replace(',', '.'))
  .refine((value) => AMOUNT_PATTERN.test(value), {
    message: 'Введите сумму числом, например 150000 или 1500,50',
  })

/** Целевая сумма/сумма взноса — строго больше нуля (ТЗ, п.4, 10, 13; CHECK target_amount/amount > 0). */
const positiveAmountSchema = baseAmountSchema
  .refine((value) => !/^0+(\.0{1,2})?$/.test(value), {
    message: 'Сумма должна быть больше нуля',
  })
  .transform((value) => normalizeAmountString(value))

export const GOAL_TYPES = ['personal', 'family'] as const
export type GoalTypeValue = (typeof GOAL_TYPES)[number]

const goalTitleSchema = z
  .string()
  .trim()
  .min(1, 'Введите название цели')
  .max(100, 'Название слишком длинное — максимум 100 символов')

/** Необязательная дата — если указана, должна быть валидной (ТЗ, п.10). */
const optionalDateSchema = z
  .string()
  .optional()
  .or(z.literal(''))
  .refine((value) => !value || !Number.isNaN(new Date(value).getTime()), {
    message: 'Некорректная дата',
  })

/**
 * Форма создания/редактирования цели. ownerUserId обязателен только для
 * personal (ТЗ, п.8-9) — проверяется через superRefine, а не отдельной
 * веткой схемы, чтобы одна и та же форма (с переключателем типа) не теряла
 * состояние при переключении goalType туда-обратно.
 */
export const goalFormSchema = z
  .object({
    title: goalTitleSchema,
    goalType: z.enum(GOAL_TYPES),
    ownerUserId: z.string().optional().or(z.literal('')),
    targetAmount: positiveAmountSchema,
    targetDate: optionalDateSchema,
    icon: z.string().min(1, 'Выберите иконку'),
  })
  .superRefine((values, ctx) => {
    if (values.goalType === 'personal' && !values.ownerUserId) {
      ctx.addIssue({
        code: 'custom',
        path: ['ownerUserId'],
        message: 'Выберите владельца личной цели',
      })
    }
  })

export type GoalFormValues = z.infer<typeof goalFormSchema>

/** Форма взноса в цель (ТЗ, п.12-13). */
export const goalContributionFormSchema = z.object({
  amount: positiveAmountSchema,
  comment: z
    .string()
    .trim()
    .max(500, 'Комментарий слишком длинный — максимум 500 символов')
    .optional()
    .or(z.literal('')),
  contributedAt: z.string().min(1, 'Укажите дату'),
})
export type GoalContributionFormValues = z.infer<typeof goalContributionFormSchema>
