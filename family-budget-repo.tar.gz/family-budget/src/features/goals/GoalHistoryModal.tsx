import { Amount, EmptyState, ErrorState, Modal, Skeleton, Text } from '@/components/ui'
import { formatDate } from '@/utils/formatDate'
import { useGoal } from './hooks'

interface GoalHistoryModalProps {
  goalId: string | null
  goalTitle: string
  onClose: () => void
}

/**
 * История взносов цели (ТЗ, п.14) — дата, сумма, пользователь, комментарий
 * (если есть). contributedAt приходит из get_goal_summary уже
 * отсортированным по убыванию даты (см. миграцию 0026, ORDER BY внутри
 * jsonb_agg) — сортировка не дублируется на клиенте.
 */
export function GoalHistoryModal({ goalId, goalTitle, onClose }: GoalHistoryModalProps) {
  const { data: summary, isLoading, isError, refetch } = useGoal(goalId ?? undefined)
  const contributions = summary?.contributions ?? []

  return (
    <Modal open={Boolean(goalId)} onClose={onClose} title="История накоплений">
      <div className="flex flex-col gap-4">
        <Text variant="secondary">Цель: {goalTitle}</Text>

        {isLoading && (
          <div className="flex flex-col gap-3" role="status" aria-label="Загружаем историю…">
            {[0, 1, 2].map((i) => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        )}

        {!isLoading && isError && (
          <ErrorState title="Не удалось загрузить историю" onRetry={() => void refetch()} />
        )}

        {!isLoading && !isError && contributions.length === 0 && (
          <EmptyState title="Взносов пока нет" description="Первый взнос появится здесь сразу после добавления." />
        )}

        {!isLoading && !isError && contributions.length > 0 && (
          <ul className="flex flex-col divide-y divide-border">
            {contributions.map((contribution) => (
              <li key={contribution.id} className="flex flex-col gap-1 py-3 first:pt-0 last:pb-0">
                <div className="flex items-center justify-between gap-3">
                  <span className="text-sm text-muted-foreground">{formatDate(contribution.contributedAt)}</span>
                  <Amount value={contribution.amount} size="sm" tone="success" showSign />
                </div>
                <span className="text-sm font-medium text-foreground">
                  {contribution.userName ?? 'Участник семьи'}
                </span>
                {contribution.comment && (
                  <p className="text-sm text-muted-foreground">{contribution.comment}</p>
                )}
              </li>
            ))}
          </ul>
        )}
      </div>
    </Modal>
  )
}
