/** Единый источник ключей React Query для домена "цели" (Этап 11, п.35). */
export const goalsKeys = {
  all: ['goals'] as const,
  list: () => [...goalsKeys.all, 'list'] as const,
  detail: (goalId: string) => [...goalsKeys.all, 'detail', goalId] as const,
}
