import { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { Button, Input, Modal, Select, Text } from '@/components/ui'
import { useToast } from '@/components/ui/Toast'
import { cn } from '@/utils/cn'
import { useAuth } from '@/features/auth/AuthContext'
import { useFamily } from '@/features/family/FamilyContext'
import { useFamilyMembers } from '@/features/family/hooks'
import { GOAL_ICON_OPTIONS, DEFAULT_GOAL_ICON } from './iconMap'
import { goalFormSchema, GOAL_TYPES, type GoalFormValues } from './schemas'
import { useCreateGoal, useUpdateGoal } from './hooks'
import { getGoalErrorMessage } from './errors'
import type { GoalType } from './api'

/** Минимально необходимые для формы поля — общие для GoalListItem и GoalDetail. */
export interface EditableGoal {
  id: string
  goalType: GoalType
  ownerUserId: string | null
  title: string
  icon: string | null
  targetAmount: number
  targetDate: string | null
}

interface GoalFormModalProps {
  open: boolean
  onClose: () => void
  /** Если передана — форма работает в режиме редактирования (ТЗ, п.20). */
  goal?: EditableGoal | null
}

const GOAL_TYPE_LABELS: Record<GoalType, string> = { family: 'Семейная', personal: 'Личная' }

function buildDefaultValues(goal: EditableGoal | null | undefined): GoalFormValues {
  if (goal) {
    return {
      title: goal.title,
      goalType: goal.goalType,
      ownerUserId: goal.ownerUserId ?? '',
      targetAmount: String(goal.targetAmount),
      targetDate: goal.targetDate ?? '',
      icon: goal.icon ?? DEFAULT_GOAL_ICON,
    }
  }
  return {
    title: '',
    goalType: 'family',
    ownerUserId: '',
    targetAmount: '',
    targetDate: '',
    icon: DEFAULT_GOAL_ICON,
  }
}

/**
 * Единая форма создания/редактирования цели (ТЗ, п.9, 20).
 *
 * Владелец личной цели (ТЗ, п.8): ADMIN/ADULT могут выбрать ЛЮБОГО активного
 * участника семьи (например, "Велосипед ребёнку" создаёт родитель) — RLS
 * (goals_insert_own_or_family/update_owner_or_admin, миграция 0024) и
 * триггер (goals_check_owner_in_family, миграция 0025) перепроверяют это на
 * сервере независимо от того, что показывает форма. CHILD видит только
 * своё имя как владельца (может создавать/редактировать только свою
 * личную цель — тот же принцип "UI отражает права, но не является их
 * источником").
 */
export function GoalFormModal({ open, onClose, goal = null }: GoalFormModalProps) {
  const { toast } = useToast()
  const { profile, user } = useAuth()
  const { currentFamily, isAdmin, isAdult } = useFamily()
  const { data: members } = useFamilyMembers(currentFamily?.id)
  const canPickOwner = isAdmin || isAdult

  const isEdit = Boolean(goal)
  const createGoalMutation = useCreateGoal()
  const updateGoalMutation = useUpdateGoal()
  const isSubmittingMutation = createGoalMutation.isPending || updateGoalMutation.isPending
  const [formError, setFormError] = useState<string | null>(null)

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<GoalFormValues>({
    resolver: zodResolver(goalFormSchema),
    defaultValues: buildDefaultValues(goal),
  })

  // Modal не размонтируется между открытиями — пересинхронизируем форму при
  // каждом новом открытии (тот же паттерн, что и в CategoryFormModal/
  // TransactionFormModal — оба используют watch() ниже, поэтому React
  // Compiler пропускает полную компиляцию компонента и setFormError(null)
  // внутри эффекта здесь безопасен, как и там).
  useEffect(() => {
    if (open) {
      reset(buildDefaultValues(goal))
      setFormError(null)
    }
  }, [open, goal, reset])

  const goalType = watch('goalType')
  const selectedIcon = watch('icon')

  function handleTypeChange(nextType: GoalType) {
    setValue('goalType', nextType, { shouldValidate: true })
    if (nextType === 'family') {
      setValue('ownerUserId', '', { shouldValidate: true })
    } else if (nextType === 'personal' && !watch('ownerUserId')) {
      // По умолчанию предлагаем самого создающего — и ADMIN/ADULT, и CHILD
      // (ТЗ, п.9: "выбрать владельца" — логичный default, а не пустой выбор).
      setValue('ownerUserId', user?.id ?? '', { shouldValidate: true })
    }
  }

  function handleClose() {
    setFormError(null)
    onClose()
  }

  const memberOptions = (members ?? [])
    .filter((m) => m.status === 'active')
    .map((m) => ({ value: m.user_id, label: m.profile?.full_name ?? 'Без имени' }))

  const onSubmit = handleSubmit(async (values) => {
    setFormError(null)
    const ownerUserId = values.goalType === 'personal' ? values.ownerUserId || null : null
    const targetDate = values.targetDate || null

    try {
      if (isEdit && goal) {
        await updateGoalMutation.mutateAsync({
          id: goal.id,
          goalType: values.goalType,
          ownerUserId,
          title: values.title,
          icon: values.icon,
          targetAmount: values.targetAmount,
          targetDate,
        })
        toast({ type: 'success', title: 'Цель сохранена' })
      } else {
        await createGoalMutation.mutateAsync({
          goalType: values.goalType,
          ownerUserId,
          title: values.title,
          icon: values.icon,
          targetAmount: values.targetAmount,
          targetDate,
        })
        toast({ type: 'success', title: 'Цель создана' })
      }
      handleClose()
    } catch (error) {
      setFormError(getGoalErrorMessage(error))
    }
  })

  const busy = isSubmitting || isSubmittingMutation

  return (
    <Modal open={open} onClose={handleClose} title={isEdit ? 'Редактировать цель' : 'Новая финансовая цель'}>
      <form className="flex flex-col gap-4" onSubmit={onSubmit} noValidate>
        <Input
          label="Название"
          placeholder="Например, Отпуск"
          autoComplete="off"
          error={errors.title?.message}
          {...register('title')}
        />

        <div className="grid grid-cols-2 gap-2" role="group" aria-label="Тип цели">
          {GOAL_TYPES.map((value) => (
            <button
              key={value}
              type="button"
              aria-pressed={goalType === value}
              onClick={() => handleTypeChange(value)}
              className={cn(
                'flex h-11 items-center justify-center gap-2 rounded-md border text-sm font-medium transition-colors',
                'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background',
                goalType === value
                  ? 'border-primary bg-primary-soft text-primary'
                  : 'border-border bg-card text-muted-foreground hover:bg-muted',
              )}
            >
              {GOAL_TYPE_LABELS[value]}
            </button>
          ))}
        </div>

        {goalType === 'personal' && canPickOwner && (
          <Select
            label="Владелец"
            options={memberOptions}
            placeholder="Выберите владельца"
            error={errors.ownerUserId?.message}
            {...register('ownerUserId')}
          />
        )}

        {goalType === 'personal' && !canPickOwner && (
          <div className="flex flex-col gap-1.5">
            <span className="text-sm font-medium text-foreground">Владелец</span>
            <Text variant="secondary">{profile?.full_name ?? 'Вы'} (только вы можете быть владельцем)</Text>
          </div>
        )}

        <Input
          label="Целевая сумма"
          placeholder="Например, 250000"
          inputMode="decimal"
          autoComplete="off"
          error={errors.targetAmount?.message}
          {...register('targetAmount')}
        />

        <Input
          label="Дата достижения"
          type="date"
          helperText="Необязательно"
          error={errors.targetDate?.message}
          {...register('targetDate')}
        />

        <div className="flex flex-col gap-1.5">
          <span className="text-sm font-medium text-foreground">Иконка</span>
          <div className="grid grid-cols-6 gap-2 sm:grid-cols-7" role="radiogroup" aria-label="Иконка цели">
            {GOAL_ICON_OPTIONS.map(({ value, icon: Icon, label }) => {
              const active = selectedIcon === value
              return (
                <button
                  key={value}
                  type="button"
                  role="radio"
                  aria-checked={active}
                  aria-label={label}
                  title={label}
                  onClick={() => setValue('icon', value, { shouldValidate: true })}
                  className={cn(
                    'flex size-10 items-center justify-center rounded-md border transition-colors',
                    'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background',
                    active
                      ? 'border-primary bg-primary-soft text-primary'
                      : 'border-border bg-card text-muted-foreground hover:bg-muted',
                  )}
                >
                  <Icon className="size-4" aria-hidden="true" />
                </button>
              )
            })}
          </div>
          {errors.icon?.message && <p className="text-sm text-destructive">{errors.icon.message}</p>}
        </div>

        {formError && (
          <p role="alert" className="text-sm text-destructive">
            {formError}
          </p>
        )}

        <Button type="submit" size="lg" isLoading={busy} disabled={busy}>
          {isEdit ? 'Сохранить' : 'Создать цель'}
        </Button>
      </form>
    </Modal>
  )
}
