import { useState } from 'react'
import { Button, Modal, Text } from '@/components/ui'
import { useToast } from '@/components/ui/Toast'
import { useDeleteGoal } from './hooks'
import { getGoalErrorMessage } from './errors'

interface DeleteGoalModalProps {
  goal: { id: string; title: string } | null
  onClose: () => void
}

/**
 * Подтверждение удаления цели (ТЗ, п.21) — точный текст из ТЗ:
 * "Удалить цель? История взносов также будет удалена." goal_contributions
 * удаляются каскадом на уровне схемы (ON DELETE CASCADE) — transactions
 * семьи это удаление никак не затрагивает (у goals/goal_contributions нет
 * FK на transactions вообще, см. STAGE11_REPORT.md).
 */
export function DeleteGoalModal({ goal, onClose }: DeleteGoalModalProps) {
  const { toast } = useToast()
  const deleteGoalMutation = useDeleteGoal()
  const [error, setError] = useState<string | null>(null)

  async function handleConfirm() {
    if (!goal) return
    setError(null)
    try {
      await deleteGoalMutation.mutateAsync(goal.id)
      toast({ type: 'success', title: 'Цель удалена' })
      onClose()
    } catch (err) {
      setError(getGoalErrorMessage(err))
    }
  }

  function handleClose() {
    setError(null)
    onClose()
  }

  return (
    <Modal
      open={Boolean(goal)}
      onClose={handleClose}
      title="Удалить цель?"
      footer={
        <>
          <Button variant="outline" onClick={handleClose}>
            Отмена
          </Button>
          <Button
            variant="destructive"
            onClick={() => void handleConfirm()}
            isLoading={deleteGoalMutation.isPending}
            disabled={deleteGoalMutation.isPending}
          >
            Удалить
          </Button>
        </>
      }
    >
      <Text variant="secondary">
        {goal && `«${goal.title}». `}
        История взносов также будет удалена.
      </Text>
      {error && (
        <p role="alert" className="mt-3 text-sm text-destructive">
          {error}
        </p>
      )}
    </Modal>
  )
}
