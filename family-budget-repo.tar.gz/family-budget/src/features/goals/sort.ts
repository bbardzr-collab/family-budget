import type { GoalListItem } from './api'

/**
 * Сортировка активных целей (ТЗ, п.32): сначала цели с ближайшей
 * target_date (по возрастанию), затем цели без даты — среди них по дате
 * создания (стабильный порядок по createdAt, а не случайный порядок ответа
 * сервера).
 */
export function sortActiveGoals(goals: GoalListItem[]): GoalListItem[] {
  return [...goals].sort((a, b) => {
    if (a.targetDate && b.targetDate) {
      return a.targetDate.localeCompare(b.targetDate)
    }
    if (a.targetDate && !b.targetDate) return -1
    if (!a.targetDate && b.targetDate) return 1
    return a.createdAt.localeCompare(b.createdAt)
  })
}
