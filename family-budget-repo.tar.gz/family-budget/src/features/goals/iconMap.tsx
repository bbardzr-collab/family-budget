import {
  Bike,
  Car,
  Gift,
  GraduationCap,
  Heart,
  HelpCircle,
  Home,
  Palette,
  PiggyBank,
  Plane,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Target,
  Wallet,
  type LucideIcon,
} from 'lucide-react'

/**
 * Карта icon-name (строка из БД, `goals.icon`) → компонент Lucide (ТЗ, п.11).
 * Тот же принцип, что и features/categories/iconMap.tsx: в БД хранится
 * только строка-идентификатор, никогда не SVG/HTML. Список — примеры из ТЗ
 * (plane/car/home/smartphone/piggy-bank/gift/wallet/graduation-cap) плюс
 * несколько дополнительных под частые сценарии целей (велосипед, хобби,
 * резерв/подушка безопасности, мечта).
 */
export const GOAL_ICON_MAP: Record<string, LucideIcon> = {
  plane: Plane,
  car: Car,
  home: Home,
  smartphone: Smartphone,
  'piggy-bank': PiggyBank,
  gift: Gift,
  wallet: Wallet,
  'graduation-cap': GraduationCap,
  bike: Bike,
  heart: Heart,
  'shield-check': ShieldCheck,
  palette: Palette,
  sparkles: Sparkles,
  target: Target,
}

/** Безопасный fallback для неизвестной/отсутствующей иконки. */
export const FALLBACK_GOAL_ICON: LucideIcon = HelpCircle

export function getGoalIcon(icon: string | null | undefined): LucideIcon {
  if (!icon) return FALLBACK_GOAL_ICON
  return GOAL_ICON_MAP[icon] ?? FALLBACK_GOAL_ICON
}

/** Набор иконок, предлагаемых пользователю при создании/редактировании цели (ТЗ, п.9 — "Иконка: обязательно/имеет default"). */
export const GOAL_ICON_OPTIONS: { value: string; icon: LucideIcon; label: string }[] = [
  { value: 'target', icon: Target, label: 'Цель' },
  { value: 'plane', icon: Plane, label: 'Путешествия' },
  { value: 'car', icon: Car, label: 'Машина' },
  { value: 'home', icon: Home, label: 'Дом/ремонт' },
  { value: 'smartphone', icon: Smartphone, label: 'Техника' },
  { value: 'piggy-bank', icon: PiggyBank, label: 'Накопления' },
  { value: 'gift', icon: Gift, label: 'Подарок' },
  { value: 'wallet', icon: Wallet, label: 'Кошелёк' },
  { value: 'graduation-cap', icon: GraduationCap, label: 'Образование' },
  { value: 'bike', icon: Bike, label: 'Велосипед' },
  { value: 'shield-check', icon: ShieldCheck, label: 'Подушка безопасности' },
  { value: 'heart', icon: Heart, label: 'Мечта' },
  { value: 'palette', icon: Palette, label: 'Хобби' },
  { value: 'sparkles', icon: Sparkles, label: 'Особое' },
]

/** default для новой цели, если пользователь ничего не выбрал (ТЗ, п.9). */
export const DEFAULT_GOAL_ICON = 'target'
