import { supabase } from '@/lib/supabase'

/**
 * Тонкий слой доступа к данным Dashboard (Этап 6, п.7, 14) — только запросы,
 * без бизнес-логики и без React, по аналогии с features/family/api.ts.
 */

export interface DashboardSummary {
  income: number
  expenses: number
  balance: number
  periodStart: string
  periodEnd: string
}

/**
 * Сводка за период — считается в Postgres через SQL aggregate
 * (get_dashboard_summary, SECURITY INVOKER, см. миграцию 0015), а не
 * загрузкой всех transactions на фронтенд (ТЗ, п.7, 26). family_id не
 * передаётся — функция сама определяет семью пользователя по auth.uid().
 */
export async function fetchDashboardSummary(
  periodStart: string,
  periodEnd: string,
): Promise<DashboardSummary> {
  const { data, error } = await supabase.rpc('get_dashboard_summary', {
    p_period_start: periodStart,
    p_period_end: periodEnd,
  })
  if (error) throw error

  const row = data?.[0]
  if (!row) {
    return { income: 0, expenses: 0, balance: 0, periodStart, periodEnd }
  }
  return {
    income: row.income,
    expenses: row.expenses,
    balance: row.balance,
    periodStart: row.period_start,
    periodEnd: row.period_end,
  }
}

export interface RecentTransaction {
  id: string
  type: string
  amount: number
  transactionDate: string
  comment: string | null
}

/**
 * Последние N операций семьи — только нужные поля (без category_id/
 * income_source/family_id/user_id, которые здесь не отображаются), лимит и
 * сортировка на стороне БД (ТЗ, п.14, 26). family_id берётся из
 * FamilyContext на уровне хука и используется только как фильтр конкретной
 * семьи — фактическая защита от чужих данных обеспечивается RLS
 * (transactions_select_role_aware), а не этим фильтром.
 */
export async function fetchRecentTransactions(
  familyId: string,
  limit = 8,
): Promise<RecentTransaction[]> {
  const { data, error } = await supabase
    .from('transactions')
    .select('id, type, amount, transaction_date, comment')
    .eq('family_id', familyId)
    .order('transaction_date', { ascending: false })
    .order('created_at', { ascending: false })
    .limit(limit)

  if (error) throw error
  return (data ?? []).map((row) => ({
    id: row.id,
    type: row.type,
    amount: row.amount,
    transactionDate: row.transaction_date,
    comment: row.comment,
  }))
}
