import { endOfMonth, startOfMonth, format } from 'date-fns'

export interface MonthRange {
  /** yyyy-MM-dd, для передачи в RPC/запросы (date-параметры) */
  start: string
  end: string
  startDate: Date
  endDate: Date
}

/**
 * Текущий месяц приложения — первый и последний день (Этап 6, п.6).
 * Единая точка правды: все запросы Dashboard берут диапазон отсюда,
 * а не считают его каждый в своём месте.
 */
export function getCurrentMonthRange(referenceDate: Date = new Date()): MonthRange {
  const startDate = startOfMonth(referenceDate)
  const endDate = endOfMonth(referenceDate)
  return {
    start: format(startDate, 'yyyy-MM-dd'),
    end: format(endDate, 'yyyy-MM-dd'),
    startDate,
    endDate,
  }
}
