import { ArrowDownCircle, ArrowUpCircle, CalendarClock, Target } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'

export interface QuickActionItem {
  key: 'expense' | 'income' | 'goal' | 'plan'
  label: string
  icon: LucideIcon
  /** На каком этапе появится реальная логика — показывается в подсказке (Этап 6, п.16-17). */
  stageHint: string
}

/**
 * Единый источник правды для "быстрых действий" (Этап 6, п.16-17) —
 * используется и блоком Quick Actions на Dashboard, и меню Floating Action
 * Button в AppLayout, чтобы не дублировать список/подписи/иконки в двух
 * местах. Бизнес-логика этих действий на этом этапе НЕ реализуется.
 */
export const QUICK_ACTIONS: QuickActionItem[] = [
  { key: 'expense', label: 'Расход', icon: ArrowDownCircle, stageHint: 'Этап 7' },
  { key: 'income', label: 'Доход', icon: ArrowUpCircle, stageHint: 'Этап 7' },
  { key: 'goal', label: 'Цель', icon: Target, stageHint: 'Этап 11' },
  { key: 'plan', label: 'План', icon: CalendarClock, stageHint: 'Этапы 12–13' },
]
