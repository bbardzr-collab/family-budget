/** Единый источник ключей React Query для домена "dashboard" (Этап 6, п.23). */
export const dashboardKeys = {
  all: ['dashboard'] as const,
  summary: (familyId: string | undefined, periodStart: string, periodEnd: string) =>
    [...dashboardKeys.all, 'summary', familyId, periodStart, periodEnd] as const,
  recentTransactions: (familyId: string | undefined, limit: number) =>
    [...dashboardKeys.all, 'recent-transactions', familyId, limit] as const,
}
