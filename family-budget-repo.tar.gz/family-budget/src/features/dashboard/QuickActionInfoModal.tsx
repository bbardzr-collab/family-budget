import { Button, Modal, Text } from '@/components/ui'
import type { QuickActionItem } from './quickActions'

/**
 * Общая модалка "скоро появится" для Quick Actions на Dashboard и для меню
 * Floating Action Button в AppLayout (Этап 6, п.16-17) — один и тот же
 * компонент в обоих местах, чтобы не дублировать текст/разметку.
 */
export function QuickActionInfoModal({
  action,
  onClose,
}: {
  action: QuickActionItem | null
  onClose: () => void
}) {
  return (
    <Modal
      open={Boolean(action)}
      onClose={onClose}
      title={action ? action.label : ''}
      description={action ? `Добавление появится на ${action.stageHint}.` : undefined}
      footer={
        <Button variant="primary" onClick={onClose}>
          Понятно
        </Button>
      }
    >
      <Text variant="secondary">
        Пока это только визуальная заготовка — бизнес-логика появится на следующих этапах.
      </Text>
    </Modal>
  )
}
