/**
 * Приветствие Dashboard с учётом времени суток (Этап 6, п.3). Намеренно
 * простое — без сложной персонализации, ровно 3 состояния по ТЗ.
 */
export function getTimeGreeting(date: Date = new Date()): string {
  const hour = date.getHours()
  if (hour >= 6 && hour < 12) return 'Доброе утро'
  if (hour >= 12 && hour < 18) return 'Добрый день'
  return 'Добрый вечер'
}

/** Имя берём из public.users.full_name (передаётся вызывающим кодом), не user_metadata. */
export function getGreeting(fullName: string | null | undefined, date: Date = new Date()): string {
  const base = getTimeGreeting(date)
  return fullName ? `${base}, ${fullName}!` : `${base}!`
}
