import { useQuery } from '@tanstack/react-query'
import { useFamily } from '@/features/family/FamilyContext'
import { dashboardKeys } from './queryKeys'
import { fetchDashboardSummary, fetchRecentTransactions } from './api'
import { getCurrentMonthRange } from './period'

/**
 * Server state Dashboard — через TanStack Query (ТЗ, п.23, 34), по тому же
 * принципу, что и features/family/hooks.ts. Ключи параметризованы
 * currentFamily.id, поэтому при смене семьи (в 1.0 — только с "нет семьи" на
 * "есть семья", family switcher не предусмотрен) старые данные другой семьи
 * просто не подходят ни под один активный ключ — отдельная ручная очистка
 * кэша не нужна. На logout весь кэш чистится в AuthContext.signOut
 * (queryClient.clear()).
 */
export function useDashboardSummary() {
  const { currentFamily } = useFamily()
  const { start, end } = getCurrentMonthRange()

  return useQuery({
    queryKey: dashboardKeys.summary(currentFamily?.id, start, end),
    queryFn: () => fetchDashboardSummary(start, end),
    enabled: Boolean(currentFamily?.id),
  })
}

export function useRecentTransactions(limit = 8) {
  const { currentFamily } = useFamily()

  return useQuery({
    queryKey: dashboardKeys.recentTransactions(currentFamily?.id, limit),
    queryFn: () => fetchRecentTransactions(currentFamily!.id, limit),
    enabled: Boolean(currentFamily?.id),
  })
}
