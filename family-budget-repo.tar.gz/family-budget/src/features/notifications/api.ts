import { supabase } from '@/lib/supabase'

/**
 * Тонкий слой доступа к данным уведомлений (Этап 17) — только запросы, без
 * бизнес-логики, по аналогии с features/goals/api.ts и
 * features/plannedExpenses/api.ts.
 *
 * ─── Чтение: обычный Supabase REST, НЕ RPC ───
 * fetchNotifications/fetchUnreadNotificationsCount читают notifications
 * напрямую через .from() — RLS notifications_select_own (`user_id =
 * auth.uid()`, существует с Этапа 3, не менялась) уже гарантирует "только
 * свои уведомления", отдельная агрегация/бизнес-логика тут не нужна (тот же
 * принцип, что у planned_expenses на Этапе 12 — простой однотабличный
 * фильтр не оправдывает RPC, см. комментарий в миграции 0033).
 *
 * ─── Запись: RPC (ТЗ, п.5, императивно "Создать") ───
 * mark_notification_read/mark_all_notifications_read/delete_notification —
 * SECURITY INVOKER RPC (миграция 0033); реальная граница по-прежнему RLS
 * (notifications_update_own/delete_own), RPC — явная именованная точка входа
 * с понятными кодами ошибок (NOTIFICATION_NOT_FOUND и т.п.), см. errors.ts.
 */

export type NotificationType = 'payment_due' | 'budget_exceeded' | 'limit_reached' | 'goal_achieved' | 'family_invite'

export interface NotificationPayload {
  recurring_transaction_id?: string
  planned_expense_id?: string
  transaction_id?: string
  budget_id?: string
  category_id?: string
  goal_id?: string
  invitation_id?: string
}

export interface NotificationItem {
  id: string
  type: NotificationType
  title: string
  message: string
  payload: NotificationPayload | null
  isRead: boolean
  createdAt: string
}

interface NotificationRow {
  id: string
  type: string
  title: string
  message: string
  payload: unknown
  is_read: boolean
  created_at: string
}

function mapNotification(row: NotificationRow): NotificationItem {
  return {
    id: row.id,
    type: row.type as NotificationType,
    title: row.title,
    message: row.message,
    payload: (row.payload as NotificationPayload | null) ?? null,
    isRead: row.is_read,
    createdAt: row.created_at,
  }
}

export interface FetchNotificationsOptions {
  /** Только непрочитанные (вкладка "Непрочитанные" на /app/notifications). */
  unreadOnly?: boolean
  /** Ограничение количества (bell-дропдаун — последние несколько). */
  limit?: number
}

/** Список уведомлений текущего пользователя, от новых к старым. */
export async function fetchNotifications(options: FetchNotificationsOptions = {}): Promise<NotificationItem[]> {
  let query = supabase
    .from('notifications')
    .select('id, type, title, message, payload, is_read, created_at')
    .order('created_at', { ascending: false })

  if (options.unreadOnly) {
    query = query.eq('is_read', false)
  }
  if (options.limit) {
    query = query.limit(options.limit)
  }

  const { data, error } = await query
  if (error) throw error
  return (data ?? []).map(mapNotification)
}

/** Количество непрочитанных — отдельный лёгкий запрос (head+count, без загрузки строк) для бейджа колокольчика. */
export async function fetchUnreadNotificationsCount(): Promise<number> {
  const { count, error } = await supabase
    .from('notifications')
    .select('id', { count: 'exact', head: true })
    .eq('is_read', false)
  if (error) throw error
  return count ?? 0
}

/** Отметить одно уведомление прочитанным. NOTIFICATION_NOT_FOUND — если id чужой (см. errors.ts). */
export async function markNotificationRead(id: string): Promise<void> {
  const { error } = await supabase.rpc('mark_notification_read', { p_notification_id: id })
  if (error) throw error
}

/** Отметить прочитанными все непрочитанные уведомления текущего пользователя. Возвращает количество изменённых строк. */
export async function markAllNotificationsRead(): Promise<number> {
  const { data, error } = await supabase.rpc('mark_all_notifications_read')
  if (error) throw error
  return (data as unknown as number) ?? 0
}

/** Удалить одно уведомление. NOTIFICATION_NOT_FOUND — если id чужой. */
export async function deleteNotification(id: string): Promise<void> {
  const { error } = await supabase.rpc('delete_notification', { p_notification_id: id })
  if (error) throw error
}

// ─────────────────────── Настройки уведомлений (ТЗ, п.19) ───────────────────────

export type NotificationPrefs = Record<NotificationType, boolean>

export const DEFAULT_NOTIFICATION_PREFS: NotificationPrefs = {
  payment_due: true,
  budget_exceeded: true,
  limit_reached: true,
  goal_achieved: true,
  family_invite: true,
}

/**
 * user_settings.notification_prefs — та же таблица/колонка, что и остальные
 * персональные настройки (ТЗ, п.3: не заводить отдельную таблицу). RLS
 * user_settings_select_own (Этап 3, не менялась) уже ограничивает чтение
 * собственной строкой.
 */
export async function fetchNotificationPrefs(): Promise<NotificationPrefs> {
  const { data, error } = await supabase.from('user_settings').select('notification_prefs').maybeSingle()
  if (error) throw error
  const prefs = (data?.notification_prefs as Partial<NotificationPrefs> | null) ?? null
  // Отсутствующие ключи трактуются как "включено" — тот же безопасный
  // дефолт, что и на сервере в create_notification() (миграция 0033).
  return { ...DEFAULT_NOTIFICATION_PREFS, ...prefs }
}

/**
 * Обновление настроек — прямой UPDATE, не RPC (единственная строка,
 * RLS user_settings_update_own уже полностью достаточна, тот же принцип,
 * что у fetchNotifications выше). userId нужен только как явный предикат
 * запроса (аналог .eq('id', ...) у других однотабличных мутаций проекта) —
 * не граница безопасности, ей остаётся RLS.
 */
export async function updateNotificationPrefs(userId: string, prefs: NotificationPrefs): Promise<void> {
  const { error } = await supabase.from('user_settings').update({ notification_prefs: prefs }).eq('user_id', userId)
  if (error) throw error
}
