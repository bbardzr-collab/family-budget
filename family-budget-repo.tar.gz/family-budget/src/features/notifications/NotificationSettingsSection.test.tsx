import { fireEvent, render, screen } from '@testing-library/react'
import { ToastProvider } from '@/components/ui/Toast'
import { NotificationSettingsSection } from './NotificationSettingsSection'
import { DEFAULT_NOTIFICATION_PREFS } from './api'

const { mockUseNotificationPrefs, mockUpdatePrefsMutateAsync } = vi.hoisted(() => ({
  mockUseNotificationPrefs: vi.fn(),
  mockUpdatePrefsMutateAsync: vi.fn(),
}))

vi.mock('./hooks', () => ({
  useNotificationPrefs: mockUseNotificationPrefs,
  useUpdateNotificationPrefs: () => ({ mutateAsync: mockUpdatePrefsMutateAsync, isPending: false }),
}))

function renderSection() {
  return render(
    <ToastProvider>
      <NotificationSettingsSection />
    </ToastProvider>,
  )
}

describe('NotificationSettingsSection (Этап 17, п.19)', () => {
  beforeEach(() => {
    mockUpdatePrefsMutateAsync.mockReset().mockResolvedValue(undefined)
  })

  it('во время загрузки показывает skeleton', () => {
    mockUseNotificationPrefs.mockReturnValue({ data: undefined, isLoading: true, isError: false, refetch: vi.fn() })

    renderSection()

    expect(screen.getByRole('status', { name: /загружаем настройки уведомлений/i })).toBeInTheDocument()
  })

  it('ошибка загрузки показывает ErrorState с кнопкой "Повторить"', () => {
    const refetch = vi.fn()
    mockUseNotificationPrefs.mockReturnValue({ data: undefined, isLoading: false, isError: true, refetch })

    renderSection()

    expect(screen.getByText('Не удалось загрузить настройки уведомлений')).toBeInTheDocument()
    fireEvent.click(screen.getByRole('button', { name: 'Повторить' }))
    expect(refetch).toHaveBeenCalled()
  })

  it('показывает все 5 переключателей в порядке ТЗ, п.19, включённые по умолчанию', () => {
    mockUseNotificationPrefs.mockReturnValue({
      data: DEFAULT_NOTIFICATION_PREFS,
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderSection()

    const switches = screen.getAllByRole('switch')
    expect(switches).toHaveLength(5)
    expect(switches.map((el) => el.getAttribute('aria-checked'))).toEqual(['true', 'true', 'true', 'true', 'true'])

    // Доступное имя переключателя — это label целиком (заголовок +
    // описание, оба внутри одного <label>), поэтому матчим по подстроке.
    expect(screen.getByRole('switch', { name: /Напоминания о платежах/ })).toBeInTheDocument()
    expect(screen.getByRole('switch', { name: /^Превышение бюджета/ })).toBeInTheDocument()
    expect(screen.getByRole('switch', { name: /Лимиты категорий/ })).toBeInTheDocument()
    expect(screen.getByRole('switch', { name: /Достижение целей/ })).toBeInTheDocument()
    expect(screen.getByRole('switch', { name: /Приглашения в семью/ })).toBeInTheDocument()
  })

  it('выключение переключателя вызывает сохранение с изменённым только этим полем набором настроек', async () => {
    mockUseNotificationPrefs.mockReturnValue({
      data: DEFAULT_NOTIFICATION_PREFS,
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderSection()
    fireEvent.click(screen.getByRole('switch', { name: /Лимиты категорий/ }))

    expect(mockUpdatePrefsMutateAsync).toHaveBeenCalledWith({
      ...DEFAULT_NOTIFICATION_PREFS,
      limit_reached: false,
    })
  })

  it('ошибка сохранения показывает toast, не ломая страницу', async () => {
    mockUpdatePrefsMutateAsync.mockRejectedValueOnce({ message: 'NOT_AUTHENTICATED' })
    mockUseNotificationPrefs.mockReturnValue({
      data: DEFAULT_NOTIFICATION_PREFS,
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderSection()
    fireEvent.click(screen.getByRole('switch', { name: /Достижение целей/ }))

    expect(await screen.findByText('Сессия истекла. Войдите заново.')).toBeInTheDocument()
  })
})
