import { getNotificationErrorMessage } from './errors'

/**
 * Этап 17, п.30 — коды ошибок RPC миграции 0033
 * (NOTIFICATION_NOT_FOUND/NOT_AUTHENTICATED), по аналогии с
 * features/family/errors.test.ts.
 */
describe('getNotificationErrorMessage (Этап 17)', () => {
  it('NOTIFICATION_NOT_FOUND (чужой/несуществующий id) -> понятное сообщение', () => {
    expect(getNotificationErrorMessage({ message: 'NOTIFICATION_NOT_FOUND' })).toBe(
      'Уведомление не найдено или недоступно.',
    )
  })

  it('NOT_AUTHENTICATED -> сообщение про истёкшую сессию', () => {
    expect(getNotificationErrorMessage({ message: 'NOT_AUTHENTICATED' })).toBe('Сессия истекла. Войдите заново.')
  })

  it('ошибка RLS/policy по подстроке -> "недостаточно прав"', () => {
    expect(
      getNotificationErrorMessage({ message: 'new row violates row-level security policy for table "notifications"' }),
    ).toBe('Недостаточно прав для этого действия.')
  })

  it('PGRST116 -> понятное сообщение', () => {
    expect(getNotificationErrorMessage({ code: 'PGRST116', message: 'no rows' })).toBe(
      'Уведомление не найдено или у вас нет прав на это действие.',
    )
  })

  it('неизвестная ошибка -> общий fallback', () => {
    expect(getNotificationErrorMessage({ message: 'something_unexpected' })).toBe(
      'Не получилось выполнить действие. Попробуйте ещё раз чуть позже.',
    )
  })

  it('сетевая ошибка (TypeError) -> сообщение про сеть', () => {
    expect(getNotificationErrorMessage(new TypeError('Failed to fetch'))).toBe(
      'Проблема с сетью. Проверьте подключение к интернету и попробуйте снова.',
    )
  })

  it('пустая ошибка -> общий fallback без падения', () => {
    expect(getNotificationErrorMessage(undefined)).toBe('Неизвестная ошибка. Попробуйте ещё раз.')
  })
})
