import { Bell } from 'lucide-react'
import { Card, CardContent, ErrorState, SectionTitle, Skeleton, Switch } from '@/components/ui'
import { useToast } from '@/components/ui/Toast'
import { useNotificationPrefs, useUpdateNotificationPrefs } from './hooks'
import { getNotificationErrorMessage } from './errors'
import { NOTIFICATION_TYPE_DESCRIPTIONS, NOTIFICATION_TYPE_LABELS, NOTIFICATION_TYPE_ORDER } from './labels'
import type { NotificationType } from './api'

/**
 * Блок настроек уведомлений (ТЗ, Этап 17, п.19) — 5 переключателей,
 * сохраняются в user_settings.notification_prefs (useUpdateNotificationPrefs,
 * оптимистичное обновление). Порядок и подписи — из labels.ts, единый
 * источник правды с самими уведомлениями.
 */
export function NotificationSettingsSection() {
  const { toast } = useToast()
  const { data: prefs, isLoading, isError, refetch } = useNotificationPrefs()
  const updatePrefs = useUpdateNotificationPrefs()

  async function handleToggle(type: NotificationType, checked: boolean) {
    if (!prefs) return
    try {
      await updatePrefs.mutateAsync({ ...prefs, [type]: checked })
    } catch (error) {
      toast({ type: 'error', title: getNotificationErrorMessage(error) })
    }
  }

  return (
    <Card>
      <CardContent className="flex flex-col gap-3 pt-6">
        <div className="flex items-center gap-2">
          <Bell className="size-5 text-muted-foreground" aria-hidden="true" />
          <SectionTitle>Уведомления</SectionTitle>
        </div>

        {isLoading && (
          <div className="flex flex-col gap-3" role="status" aria-label="Загружаем настройки уведомлений…">
            {NOTIFICATION_TYPE_ORDER.map((type) => (
              <Skeleton key={type} className="h-10 w-full" />
            ))}
          </div>
        )}

        {isError && <ErrorState title="Не удалось загрузить настройки уведомлений" onRetry={() => void refetch()} />}

        {!isLoading && !isError && prefs && (
          <div className="flex flex-col divide-y divide-border">
            {NOTIFICATION_TYPE_ORDER.map((type) => (
              <Switch
                key={type}
                label={NOTIFICATION_TYPE_LABELS[type]}
                description={NOTIFICATION_TYPE_DESCRIPTIONS[type]}
                checked={prefs[type]}
                onCheckedChange={(checked) => void handleToggle(type, checked)}
                disabled={updatePrefs.isPending}
              />
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
