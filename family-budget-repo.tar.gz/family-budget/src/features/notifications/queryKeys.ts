/**
 * Единый источник ключей React Query для домена "уведомления" (Этап 17,
 * п.22) — ключи ровно те, что перечислило ТЗ: ['notifications'],
 * ['notifications', 'unread-count']. Список параметризован фильтром
 * (unreadOnly/limit) — bell-дропдаун (limit: 5, все статусы) и страница
 * /app/notifications (без лимита, unreadOnly зависит от активной вкладки)
 * используют один и тот же ключ-фабрику, поэтому у них разный кэш-слот и
 * они не путают друг друга при инвалидации.
 */
export const notificationsKeys = {
  all: ['notifications'] as const,
  list: (params: { unreadOnly?: boolean; limit?: number } = {}) =>
    [...notificationsKeys.all, 'list', params] as const,
  unreadCount: () => [...notificationsKeys.all, 'unread-count'] as const,
}

/** Настройки уведомлений (user_settings.notification_prefs) — отдельное дерево ключей. */
export const notificationPrefsKeys = {
  all: ['notification-prefs'] as const,
}
