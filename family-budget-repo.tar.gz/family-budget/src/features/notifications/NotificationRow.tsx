import { createElement } from 'react'
import { Link } from 'react-router-dom'
import { Trash2 } from 'lucide-react'
import { IconButton } from '@/components/ui'
import { cn } from '@/utils/cn'
import { formatRelativeDateTime } from '@/utils/formatDate'
import { NOTIFICATION_TYPE_ICONS } from './iconMap'
import { getNotificationTarget } from './links'
import type { NotificationItem } from './api'

interface NotificationRowProps {
  item: NotificationItem
  onOpen: (item: NotificationItem) => void
  onDelete?: (item: NotificationItem) => void
  /** Компактная версия — bell-дропдаун (без кнопки удаления). */
  compact?: boolean
}

/**
 * Одна строка уведомления — переиспользуется и в bell-дропдауне (ТЗ, п.10),
 * и на /app/notifications (ТЗ, п.6). Непрочитанное визуально отличается
 * (точка-индикатор + чуть более насыщенный фон) — не только цветом текста,
 * чтобы состояние читалось и без восприятия цвета (тот же принцип
 * доступности, что и у Badge/Switch в остальном проекте).
 */
export function NotificationRow({ item, onOpen, onDelete, compact }: NotificationRowProps) {
  const Icon = NOTIFICATION_TYPE_ICONS[item.type]
  const target = getNotificationTarget(item)

  return (
    <li className={cn('relative rounded-md', !item.isRead && 'bg-muted/60')}>
      <Link
        to={target}
        onClick={() => onOpen(item)}
        className={cn(
          'flex w-full items-start gap-3 rounded-md px-3 py-3 text-left transition-colors hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-inset',
          // pr-14 — резервирует место под абсолютно спозиционированную кнопку
          // удаления (44×44, absolute right-2 top-2), чтобы truncate у
          // заголовка не считал доступную ширину строки без учёта кнопки и не
          // визуально наезжал на неё текстом (Этап 19, п.36 — кнопка выросла
          // с 36 до 44px).
          compact ? 'py-2.5' : 'py-3 pr-14',
        )}
      >
        <span
          className={cn(
            'mt-0.5 flex size-9 shrink-0 items-center justify-center rounded-full',
            item.isRead ? 'bg-muted text-muted-foreground' : 'bg-primary-soft text-primary',
          )}
        >
          {createElement(Icon, { className: 'size-4', 'aria-hidden': true })}
        </span>

        <span className="min-w-0 flex-1">
          <span className="flex items-center gap-1.5">
            {!item.isRead && (
              <span className="size-1.5 shrink-0 rounded-full bg-primary" aria-hidden="true" />
            )}
            <span className={cn('truncate text-sm', item.isRead ? 'font-medium text-foreground' : 'font-semibold text-foreground')}>
              {item.title}
            </span>
          </span>
          <span className={cn('mt-0.5 block text-sm text-muted-foreground', compact ? 'line-clamp-1' : 'line-clamp-2')}>
            {item.message}
          </span>
          <span className="mt-1 block text-xs text-muted-foreground">{formatRelativeDateTime(item.createdAt)}</span>
        </span>
      </Link>

      {!compact && onDelete && (
        <IconButton
          icon={Trash2}
          aria-label={`Удалить уведомление «${item.title}»`}
          size="sm"
          variant="ghost"
          className="absolute right-2 top-2"
          onClick={() => onDelete(item)}
        />
      )}
    </li>
  )
}
