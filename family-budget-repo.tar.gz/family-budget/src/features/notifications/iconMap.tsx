import { Bell, CalendarClock, PartyPopper, TrendingUp, UserPlus, Wallet } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import type { NotificationType } from './api'

/**
 * Карта type → иконка Lucide. Тип уведомления — фиксированный union из 5
 * значений (CHECK-констрейнт notifications_type_check, Этап 3), а не
 * произвольная строка из БД, но выбор компонента всё равно происходит по
 * значению переменной во время рендера — тот же класс паттерна, что и
 * features/goals/iconMap.tsx/features/categories/iconMap.tsx, поэтому в JSX
 * используется createElement(NOTIFICATION_TYPE_ICONS[type], props), а не
 * <Icon /> напрямую (react-hooks/static-components, см. architecture-v1.md).
 */
export const NOTIFICATION_TYPE_ICONS: Record<NotificationType, LucideIcon> = {
  payment_due: CalendarClock,
  budget_exceeded: Wallet,
  limit_reached: TrendingUp,
  goal_achieved: PartyPopper,
  family_invite: UserPlus,
}

export const NOTIFICATION_FALLBACK_ICON: LucideIcon = Bell
