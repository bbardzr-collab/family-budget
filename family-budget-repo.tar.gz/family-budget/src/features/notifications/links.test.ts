import { getNotificationTarget } from './links'

/** Этап 17, п.11 — переход по клику ведёт в существующий раздел для каждого типа. */
describe('getNotificationTarget (Этап 17)', () => {
  it('payment_due -> раздел планов на странице операций', () => {
    expect(getNotificationTarget({ type: 'payment_due' })).toBe('/app/transactions?section=plan')
  })

  it('budget_exceeded -> страница бюджета', () => {
    expect(getNotificationTarget({ type: 'budget_exceeded' })).toBe('/app/budget')
  })

  it('limit_reached -> страница бюджета', () => {
    expect(getNotificationTarget({ type: 'limit_reached' })).toBe('/app/budget')
  })

  it('goal_achieved -> страница целей', () => {
    expect(getNotificationTarget({ type: 'goal_achieved' })).toBe('/app/goals')
  })

  it('family_invite -> страница семьи', () => {
    expect(getNotificationTarget({ type: 'family_invite' })).toBe('/app/family')
  })
})
