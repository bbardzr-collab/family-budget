/**
 * Перевод ошибок операций с уведомлениями в понятные человеку сообщения —
 * по аналогии с features/plannedExpenses/errors.ts. Коды NOT_AUTHENTICATED/
 * NOTIFICATION_NOT_FOUND приходят как `raise exception '<CODE>'` из RPC
 * миграции 0033.
 */

interface MatchableError {
  message?: string
  code?: string
}

export function getNotificationErrorMessage(error: unknown): string {
  if (!error) return 'Неизвестная ошибка. Попробуйте ещё раз.'

  if (error instanceof TypeError) {
    return 'Проблема с сетью. Проверьте подключение к интернету и попробуйте снова.'
  }

  const { message, code } = (error as MatchableError) ?? {}
  const text = (message ?? String(error)).toLowerCase()

  // mark_notification_read/delete_notification (миграция 0033) — id чужой
  // или уже не существует; RLS отфильтровала строку ещё до RETURNING.
  if (text.includes('notification_not_found')) {
    return 'Уведомление не найдено или недоступно.'
  }

  if (text.includes('not_authenticated')) {
    return 'Сессия истекла. Войдите заново.'
  }

  if (text.includes('row-level security') || text.includes('policy')) {
    return 'Недостаточно прав для этого действия.'
  }

  if (code === 'PGRST116') {
    return 'Уведомление не найдено или у вас нет прав на это действие.'
  }

  if (text.includes('fetch') || text.includes('network')) {
    return 'Проблема с сетью. Проверьте подключение к интернету и попробуйте снова.'
  }

  return 'Не получилось выполнить действие. Попробуйте ещё раз чуть позже.'
}
