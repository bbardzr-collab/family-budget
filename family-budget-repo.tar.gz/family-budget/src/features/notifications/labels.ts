import type { NotificationType } from './api'

/** Подписи типов уведомлений — для настроек (ТЗ, п.19) и, при необходимости, отладки. */
export const NOTIFICATION_TYPE_LABELS: Record<NotificationType, string> = {
  payment_due: 'Напоминания о платежах',
  budget_exceeded: 'Превышение бюджета',
  limit_reached: 'Лимиты категорий',
  goal_achieved: 'Достижение целей',
  family_invite: 'Приглашения в семью',
}

/** Короткие описания под каждым переключателем настроек. */
export const NOTIFICATION_TYPE_DESCRIPTIONS: Record<NotificationType, string> = {
  payment_due: 'Когда наступает срок регулярного платежа, за который отвечаете вы',
  budget_exceeded: 'Когда расходы семьи превышают месячный бюджет',
  limit_reached: 'Когда расходы по категории приближаются к лимиту или превышают его',
  goal_achieved: 'Когда финансовая цель достигнута',
  family_invite: 'О приглашениях в семью',
}

/** Порядок отображения в настройках — совпадает с порядком из ТЗ, п.19. */
export const NOTIFICATION_TYPE_ORDER: NotificationType[] = [
  'payment_due',
  'budget_exceeded',
  'limit_reached',
  'goal_achieved',
  'family_invite',
]
