import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useAuth } from '@/features/auth/AuthContext'
import { notificationPrefsKeys, notificationsKeys } from './queryKeys'
import {
  deleteNotification,
  fetchNotificationPrefs,
  fetchNotifications,
  fetchUnreadNotificationsCount,
  markAllNotificationsRead,
  markNotificationRead,
  updateNotificationPrefs,
  type FetchNotificationsOptions,
  type NotificationItem,
  type NotificationPrefs,
} from './api'

/** Список уведомлений (страница /app/notifications и bell-дропдаун — разные наборы параметров, разные слоты кэша). */
export function useNotifications(options: FetchNotificationsOptions = {}) {
  return useQuery({
    queryKey: notificationsKeys.list(options),
    queryFn: () => fetchNotifications(options),
  })
}

/**
 * Счётчик непрочитанных для бейджа колокольчика (ТЗ, п.9) — реальные данные
 * Supabase, лёгкий head+count запрос. Умеренный polling (ТЗ, п.23:
 * "если это действительно необходимо" — 30 с, не чаще) держит бейдж свежим,
 * даже если событие (например, budget_exceeded от другого члена семьи)
 * создалось не в результате действия самого пользователя на этой вкладке, и
 * поэтому не может быть подхвачено обычной инвалидацией мутации.
 */
export function useUnreadNotificationsCount() {
  return useQuery({
    queryKey: notificationsKeys.unreadCount(),
    queryFn: fetchUnreadNotificationsCount,
    refetchInterval: 30_000,
    refetchOnWindowFocus: true,
  })
}

function invalidateNotificationQueries(queryClient: ReturnType<typeof useQueryClient>) {
  void queryClient.invalidateQueries({ queryKey: notificationsKeys.all })
}

/**
 * Отметить одно уведомление прочитанным — optimistic update и в списках, и
 * в счётчике (ТЗ, п.7: "использовать optimistic update там, где это
 * безопасно"). Безопасно здесь, потому что откат при ошибке тривиален
 * (просто восстановить снимок), а RPC на сервере в любом случае — финальный
 * источник истины после инвалидации в onSettled.
 */
export function useMarkNotificationRead() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => markNotificationRead(id),
    onMutate: async (id: string) => {
      await queryClient.cancelQueries({ queryKey: notificationsKeys.all })
      const previousLists = queryClient.getQueriesData<NotificationItem[]>({
        queryKey: notificationsKeys.all,
      })
      const previousCount = queryClient.getQueryData<number>(notificationsKeys.unreadCount())
      let wasUnread = false

      previousLists.forEach(([key, data]) => {
        if (!data) return
        // Ключ счётчика ['notifications','unread-count'] тоже подпадает под
        // getQueriesData(all) — данные там number, а не массив, поэтому
        // безопасно пропускаем нечисловые/немассивные значения.
        if (!Array.isArray(data)) return
        const next = data.map((item) => {
          if (item.id === id && !item.isRead) {
            wasUnread = true
            return { ...item, isRead: true }
          }
          return item
        })
        queryClient.setQueryData(key, next)
      })

      if (wasUnread && typeof previousCount === 'number') {
        queryClient.setQueryData(notificationsKeys.unreadCount(), Math.max(0, previousCount - 1))
      }

      return { previousLists, previousCount }
    },
    onError: (_error, _id, context) => {
      context?.previousLists.forEach(([key, data]) => {
        queryClient.setQueryData(key, data)
      })
      if (context && typeof context.previousCount === 'number') {
        queryClient.setQueryData(notificationsKeys.unreadCount(), context.previousCount)
      }
    },
    onSettled: () => invalidateNotificationQueries(queryClient),
  })
}

/** "Прочитать все" (ТЗ, п.8) — optimistic: все видимые уведомления помечаются прочитанными, счётчик обнуляется. */
export function useMarkAllNotificationsRead() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: () => markAllNotificationsRead(),
    onMutate: async () => {
      await queryClient.cancelQueries({ queryKey: notificationsKeys.all })
      const previousLists = queryClient.getQueriesData<NotificationItem[]>({
        queryKey: notificationsKeys.all,
      })
      const previousCount = queryClient.getQueryData<number>(notificationsKeys.unreadCount())

      previousLists.forEach(([key, data]) => {
        if (!Array.isArray(data)) return
        queryClient.setQueryData(
          key,
          data.map((item) => ({ ...item, isRead: true })),
        )
      })
      queryClient.setQueryData(notificationsKeys.unreadCount(), 0)

      return { previousLists, previousCount }
    },
    onError: (_error, _vars, context) => {
      context?.previousLists.forEach(([key, data]) => {
        queryClient.setQueryData(key, data)
      })
      if (context && typeof context.previousCount === 'number') {
        queryClient.setQueryData(notificationsKeys.unreadCount(), context.previousCount)
      }
    },
    onSettled: () => invalidateNotificationQueries(queryClient),
  })
}

export function useDeleteNotification() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => deleteNotification(id),
    onSuccess: () => invalidateNotificationQueries(queryClient),
  })
}

// ─────────────────────── Настройки уведомлений ───────────────────────

export function useNotificationPrefs() {
  return useQuery({
    queryKey: notificationPrefsKeys.all,
    queryFn: fetchNotificationPrefs,
  })
}

export function useUpdateNotificationPrefs() {
  const { user } = useAuth()
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (prefs: NotificationPrefs) => {
      if (!user) throw new Error('NOT_AUTHENTICATED')
      return updateNotificationPrefs(user.id, prefs)
    },
    onMutate: async (prefs: NotificationPrefs) => {
      await queryClient.cancelQueries({ queryKey: notificationPrefsKeys.all })
      const previous = queryClient.getQueryData<NotificationPrefs>(notificationPrefsKeys.all)
      queryClient.setQueryData(notificationPrefsKeys.all, prefs)
      return { previous }
    },
    onError: (_error, _prefs, context) => {
      if (context?.previous) {
        queryClient.setQueryData(notificationPrefsKeys.all, context.previous)
      }
    },
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: notificationPrefsKeys.all })
    },
  })
}
