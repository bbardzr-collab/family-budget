import type { NotificationItem } from './api'

/**
 * Переход по клику на уведомление (ТЗ, п.11: "по возможности открыть
 * соответствующий раздел") — используется во вкладке /app/notifications и в
 * bell-дропдауне. Ведёт на уже существующий раздел, а не на несуществующую
 * "деталь одной операции" — ни у planned_expenses, ни у budget_categories в
 * проекте нет собственного постраничного маршрута (см. architecture-v1.md).
 */
export function getNotificationTarget(item: Pick<NotificationItem, 'type'>): string {
  switch (item.type) {
    case 'payment_due':
      return '/app/transactions?section=plan'
    case 'budget_exceeded':
    case 'limit_reached':
      return '/app/budget'
    case 'goal_achieved':
      return '/app/goals'
    case 'family_invite':
      return '/app/family'
    default:
      return '/app/notifications'
  }
}
