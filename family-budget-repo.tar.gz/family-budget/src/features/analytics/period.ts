import {
  differenceInCalendarDays,
  endOfMonth,
  endOfWeek,
  endOfYear,
  startOfMonth,
  startOfWeek,
  startOfYear,
  subDays,
  subMonths,
  subWeeks,
  subYears,
} from 'date-fns'
import { ru } from 'date-fns/locale'
import { toDateInputValue } from '@/utils/formatDate'

/**
 * Период аналитики (Этап 14, п.2, 15-16) — отдельный, аналитический набор
 * пресетов, а не переиспользование features/transactions/filters.ts.
 *
 * Причина: пресеты Этапа 9 (today/week/month/lastMonth/year/custom) не
 * покрывают явно требуемые здесь last3Months/last6Months/lastYear, а менять
 * PeriodPreset Этапа 9 ради этого значило бы трогать код журнала операций без
 * необходимости (принцип проекта "не переписывать лишнее"). Конвенции те же:
 * date-fns, toDateInputValue(), НИКОГДА `.toISOString()`/`new Date("yyyy-MM-
 * dd")` для чистой работы со строкой даты (та же причина, что и в
 * features/recurringTransactions/api.ts — сдвиг на день из-за таймзоны).
 */

export const ANALYTICS_PERIOD_PRESETS = [
  'today',
  'week',
  'month',
  'lastMonth',
  'last3Months',
  'last6Months',
  'year',
  'lastYear',
  'custom',
] as const
export type AnalyticsPeriodPreset = (typeof ANALYTICS_PERIOD_PRESETS)[number]

export const ANALYTICS_PERIOD_LABELS: Record<AnalyticsPeriodPreset, string> = {
  today: 'Сегодня',
  week: 'Эта неделя',
  month: 'Этот месяц',
  lastMonth: 'Прошлый месяц',
  last3Months: 'Последние 3 месяца',
  last6Months: 'Последние 6 месяцев',
  year: 'Этот год',
  lastYear: 'Прошлый год',
  custom: 'Произвольный период',
}

/** UI-состояние выбора периода — то, что хранится в URL/состоянии страницы. */
export interface AnalyticsPeriodState {
  preset: AnalyticsPeriodPreset
  /** Значимы только при preset === 'custom'. */
  customFrom: string
  customTo: string
}

export const DEFAULT_ANALYTICS_PERIOD: AnalyticsPeriodState = {
  preset: 'month',
  customFrom: '',
  customTo: '',
}

export interface ResolvedAnalyticsRange {
  /** "yyyy-MM-dd" — включительно, локальный календарный день пользователя. */
  dateFrom: string
  dateTo: string
}

/** Разрешённый период — то, что реально уходит в RPC/query key (ТЗ, п.23). */
export interface AnalyticsPeriod extends ResolvedAnalyticsRange {
  preset: AnalyticsPeriodPreset
}

/**
 * "yyyy-MM-dd" -> локальная полночь этого дня. Компонентный конструктор
 * `new Date(year, monthIndex, day)` всегда трактует значения как локальное
 * время — в отличие от `new Date("yyyy-MM-dd")` (парсится как UTC-полночь и
 * может "уехать" на день назад при выводе в часовых поясах западнее UTC).
 */
export function parseDateInputValue(value: string): Date {
  const parts = value.split('-')
  const year = Number(parts[0])
  const month = Number(parts[1])
  const day = Number(parts[2])
  return new Date(year, month - 1, day)
}

function resolveCalendarRange(preset: Exclude<AnalyticsPeriodPreset, 'custom'>, now: Date): ResolvedAnalyticsRange {
  switch (preset) {
    case 'today': {
      const today = toDateInputValue(now)
      return { dateFrom: today, dateTo: today }
    }
    case 'week':
      return {
        dateFrom: toDateInputValue(startOfWeek(now, { weekStartsOn: 1, locale: ru })),
        dateTo: toDateInputValue(endOfWeek(now, { weekStartsOn: 1, locale: ru })),
      }
    case 'month':
      return { dateFrom: toDateInputValue(startOfMonth(now)), dateTo: toDateInputValue(endOfMonth(now)) }
    case 'lastMonth': {
      const month = subMonths(now, 1)
      return { dateFrom: toDateInputValue(startOfMonth(month)), dateTo: toDateInputValue(endOfMonth(month)) }
    }
    // Текущий месяц + два предыдущих = 3 календарных месяца целиком
    // (аналогично last6Months) — так период всегда состоит из полных
    // месяцев, что даёт чистые границы для месячной агрегации в графике.
    case 'last3Months':
      return {
        dateFrom: toDateInputValue(startOfMonth(subMonths(now, 2))),
        dateTo: toDateInputValue(endOfMonth(now)),
      }
    case 'last6Months':
      return {
        dateFrom: toDateInputValue(startOfMonth(subMonths(now, 5))),
        dateTo: toDateInputValue(endOfMonth(now)),
      }
    case 'year':
      return { dateFrom: toDateInputValue(startOfYear(now)), dateTo: toDateInputValue(endOfYear(now)) }
    case 'lastYear': {
      const year = subYears(now, 1)
      return { dateFrom: toDateInputValue(startOfYear(year)), dateTo: toDateInputValue(endOfYear(year)) }
    }
  }
}

/** UI-состояние периода -> конкретные даты (ТЗ, п.2) — всегда КОНКРЕТНЫЕ даты. */
export function resolveAnalyticsPeriod(state: AnalyticsPeriodState, now: Date = new Date()): AnalyticsPeriod {
  if (state.preset === 'custom') {
    return {
      preset: 'custom',
      // Пока пользователь не выбрал обе границы — безопасный дефолт (начало
      // месяца/сегодня), чтобы запрос никогда не улетал без диапазона (тот
      // же принцип, что и resolveDateRange() в features/transactions/filters.ts).
      dateFrom: state.customFrom || toDateInputValue(startOfMonth(now)),
      dateTo: state.customTo || toDateInputValue(now),
    }
  }
  return { preset: state.preset, ...resolveCalendarRange(state.preset, now) }
}

/**
 * Предыдущий период для сравнения "период к периоду" (ТЗ, п.15-16).
 *
 * Для календарно-выровненных пресетов — естественный предыдущий период
 * (вчера/прошлая неделя/прошлый календарный месяц/прошлый год), а НЕ
 * скользящий сдвиг на количество дней текущего периода: например, для
 * "Этот месяц" в сентябре (30 дней) сдвиг на 30 дней назад от 1 сентября дал
 * бы 2 августа, а не 1 августа — то есть не "прошлый календарный месяц".
 *
 * Для 'custom' (и, как следствие, любого периода без единственного
 * "календарного предшественника") — скользящий период ровно той же длины,
 * непосредственно предшествующий текущему.
 */
export function resolvePreviousAnalyticsPeriod(
  period: AnalyticsPeriod,
  now: Date = new Date(),
): ResolvedAnalyticsRange {
  switch (period.preset) {
    case 'today': {
      const yesterday = toDateInputValue(subDays(now, 1))
      return { dateFrom: yesterday, dateTo: yesterday }
    }
    case 'week': {
      const anchor = subWeeks(now, 1)
      return {
        dateFrom: toDateInputValue(startOfWeek(anchor, { weekStartsOn: 1, locale: ru })),
        dateTo: toDateInputValue(endOfWeek(anchor, { weekStartsOn: 1, locale: ru })),
      }
    }
    case 'month': {
      const month = subMonths(now, 1)
      return { dateFrom: toDateInputValue(startOfMonth(month)), dateTo: toDateInputValue(endOfMonth(month)) }
    }
    case 'lastMonth': {
      const month = subMonths(now, 2)
      return { dateFrom: toDateInputValue(startOfMonth(month)), dateTo: toDateInputValue(endOfMonth(month)) }
    }
    case 'last3Months':
      return {
        dateFrom: toDateInputValue(startOfMonth(subMonths(now, 5))),
        dateTo: toDateInputValue(endOfMonth(subMonths(now, 3))),
      }
    case 'last6Months':
      return {
        dateFrom: toDateInputValue(startOfMonth(subMonths(now, 11))),
        dateTo: toDateInputValue(endOfMonth(subMonths(now, 6))),
      }
    case 'year': {
      const year = subYears(now, 1)
      return { dateFrom: toDateInputValue(startOfYear(year)), dateTo: toDateInputValue(endOfYear(year)) }
    }
    case 'lastYear': {
      const year = subYears(now, 2)
      return { dateFrom: toDateInputValue(startOfYear(year)), dateTo: toDateInputValue(endOfYear(year)) }
    }
    case 'custom': {
      const from = parseDateInputValue(period.dateFrom)
      const to = parseDateInputValue(period.dateTo)
      const lengthDays = differenceInCalendarDays(to, from) + 1
      const prevTo = subDays(from, 1)
      const prevFrom = subDays(prevTo, lengthDays - 1)
      return { dateFrom: toDateInputValue(prevFrom), dateTo: toDateInputValue(prevTo) }
    }
  }
}

/** Период ≤31 дня — фронтенд-эквивалент условия гранулярности на сервере (ТЗ, п.8), для UI-подписей/форматирования оси. */
export function isShortAnalyticsPeriod(period: ResolvedAnalyticsRange): boolean {
  const from = parseDateInputValue(period.dateFrom)
  const to = parseDateInputValue(period.dateTo)
  return differenceInCalendarDays(to, from) + 1 <= 31
}
