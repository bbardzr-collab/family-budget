import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { formatMoney } from '@/utils/formatMoney'
import { CATEGORY_TYPE_LABELS, CATEGORY_TYPE_ORDER, type CategoryType } from '@/features/categories/constants'
import type { AnalyticsByTypeStat, AnalyticsCategoryTypeGroup } from './api'

/**
 * График "Структура расходов" по типу категории (ТЗ, п.11-12) — второй из
 * двух обязательных графиков Этапа 14. ВАЖНО: `type` здесь — значения
 * `categories.type` (OBLIGATORY/WANTS/GOALS/OTHER + синтетический
 * UNCATEGORIZED), НЕ связано с таблицей `goals` (Этап 11) — "Цели" тут
 * означает категорию с типом GOALS, а не финансовую цель накопления.
 *
 * Горизонтальный BarChart в ОДНОМ оттенке (--color-primary), а не Pie/Donut
 * и не многоцветная категориальная палитра — сознательный выбор (см. api.ts
 * этого модуля): так график читаем на мобильном без риска нечитаемых долек
 * (ТЗ, п.12: "если Pie плохо смотрится на мобильном — BarChart или список").
 * Порядок баров ФИКСИРОВАН (CATEGORY_TYPE_ORDER + UNCATEGORIZED последним) и
 * не зависит от суммы — иначе бары "прыгали" бы местами при смене периода.
 */

const TYPE_ORDER: AnalyticsCategoryTypeGroup[] = [...CATEGORY_TYPE_ORDER, 'UNCATEGORIZED']

function typeLabel(type: AnalyticsCategoryTypeGroup): string {
  return type === 'UNCATEGORIZED' ? 'Без категории' : CATEGORY_TYPE_LABELS[type as CategoryType]
}

const compactAmount = new Intl.NumberFormat('ru-RU', { notation: 'compact' })

export interface AnalyticsStructureChartProps {
  byType: AnalyticsByTypeStat[]
}

export function AnalyticsStructureChart({ byType }: AnalyticsStructureChartProps) {
  const byTypeMap = new Map(byType.map((t) => [t.type, t]))
  const data = TYPE_ORDER.map((type) => ({
    type,
    label: typeLabel(type),
    amount: byTypeMap.get(type)?.amount ?? 0,
    percent: byTypeMap.get(type)?.percent ?? 0,
  }))

  return (
    <div role="img" aria-label="Структура расходов по типу категории (обязательное, желания, цели, другое, без категории)">
      <ResponsiveContainer width="100%" height={200}>
        <BarChart data={data} layout="vertical" margin={{ top: 4, right: 24, left: 0, bottom: 4 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" horizontal={false} />
          <XAxis
            type="number"
            tick={{ fill: 'var(--color-muted-foreground)', fontSize: 12 }}
            axisLine={false}
            tickLine={false}
            tickFormatter={(value: number) => compactAmount.format(value)}
          />
          <YAxis
            type="category"
            dataKey="label"
            tick={{ fill: 'var(--color-foreground)', fontSize: 12 }}
            axisLine={false}
            tickLine={false}
            width={90}
          />
          <Tooltip
            formatter={(value) => [formatMoney(Number(value)), 'Сумма']}
            contentStyle={{
              backgroundColor: 'var(--color-card)',
              borderColor: 'var(--color-border)',
              borderRadius: 8,
              fontSize: 13,
            }}
          />
          <Bar dataKey="amount" fill="var(--color-primary)" radius={[0, 4, 4, 0]} maxBarSize={22} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}
