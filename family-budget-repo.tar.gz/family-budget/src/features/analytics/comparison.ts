import type { AnalyticsSummary } from './api'

/**
 * Сравнение "период к периоду" (ТЗ, п.15-16) — чистая функция, без React и
 * без запросов (используется хуком useAnalyticsComparison, см. hooks.ts).
 *
 * Принципиально: разница считается только как объективное число/процент, без
 * оценочных суждений ("Расходы изменились на +8,2%" — можно; "Вы стали лучше
 * управлять деньгами" — нельзя, ТЗ п.16) — это исполняется на уровне UI
 * (AnalyticsPage.tsx), а не здесь, но само значение не должно провоцировать
 * оценку (например, не помечается цветом "хорошо/плохо" на уровне данных).
 */

export interface AnalyticsComparisonValue {
  current: number
  previous: number
  difference: number
  /**
   * Изменение в процентах. null, если previous === 0 — делить не на что, а
   * не Infinity/NaN (ТЗ, п.16: "показывать «—» или «Нет данных для
   * сравнения»", ни в коем случае не ∞%).
   */
  percentageChange: number | null
}

export function calculateComparisonValue(current: number, previous: number): AnalyticsComparisonValue {
  return {
    current,
    previous,
    difference: current - previous,
    percentageChange: previous === 0 ? null : ((current - previous) / previous) * 100,
  }
}

export interface AnalyticsComparison {
  income: AnalyticsComparisonValue
  expenses: AnalyticsComparisonValue
  balance: AnalyticsComparisonValue
  transactionCount: AnalyticsComparisonValue
}

/** Сводки текущего и предыдущего периода (fetchAnalyticsSummary) -> сравнение по всем метрикам. */
export function buildAnalyticsComparison(current: AnalyticsSummary, previous: AnalyticsSummary): AnalyticsComparison {
  return {
    income: calculateComparisonValue(current.income, previous.income),
    expenses: calculateComparisonValue(current.expenses, previous.expenses),
    balance: calculateComparisonValue(current.balance, previous.balance),
    transactionCount: calculateComparisonValue(current.transactionCount, previous.transactionCount),
  }
}

const PERCENT_FORMATTER = new Intl.NumberFormat('ru-RU', {
  minimumFractionDigits: 1,
  maximumFractionDigits: 1,
  signDisplay: 'exceptZero',
})

/** "+8,2%" / "−3,5%" / "0,0%" / "—" (когда сравнивать не с чем — previous === 0). */
export function formatPercentageChange(value: number | null): string {
  if (value === null) return '—'
  return `${PERCENT_FORMATTER.format(value)}%`
}
