import { format } from 'date-fns'
import { ru } from 'date-fns/locale'
import { Area, AreaChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { formatMoney } from '@/utils/formatMoney'
import type { AnalyticsGranularity, AnalyticsTimeseriesPoint } from './api'
import { parseDateInputValue } from './period'

/**
 * График "Доходы/расходы по времени" (ТЗ, п.7-8, dataviz skill) — первый из
 * двух обязательных графиков Этапа 14.
 *
 * Цвета — существующие токены дизайн-системы (index.css), НЕ новая палитра:
 * доходы = --color-success (зелёный), расходы = --color-primary (фирменный
 * фиолетовый). Сознательно НЕ --color-danger для расходов — ТЗ явно требует
 * не намекать на оценочное суждение о тратах (п.16), а красный для "расход"
 * — самый частый способ такой намёк создать непреднамеренно.
 *
 * points уже зон-заполнены (zero-filled) на сервере (миграция 0030) — график
 * всегда рисует непрерывную линию без "прыжков" через пустые дни/месяцы, и
 * ровно нулевой график для периода без единой операции — это настоящие
 * данные (не фейковый демо-график, ТЗ п.33).
 */

export interface AnalyticsDynamicsChartProps {
  points: AnalyticsTimeseriesPoint[]
  granularity: AnalyticsGranularity
}

function bucketLabel(bucket: string, granularity: AnalyticsGranularity): string {
  const date = parseDateInputValue(bucket)
  return granularity === 'day' ? format(date, 'd MMM', { locale: ru }) : format(date, 'LLL yy', { locale: ru })
}

const compactAmount = new Intl.NumberFormat('ru-RU', { notation: 'compact' })

export function AnalyticsDynamicsChart({ points, granularity }: AnalyticsDynamicsChartProps) {
  const data = points.map((p) => ({ ...p, label: bucketLabel(p.bucket, granularity) }))

  return (
    <div
      role="img"
      aria-label={`График динамики доходов и расходов по ${granularity === 'day' ? 'дням' : 'месяцам'} за выбранный период`}
    >
      <ResponsiveContainer width="100%" height={260}>
        <AreaChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" vertical={false} />
          <XAxis
            dataKey="label"
            tick={{ fill: 'var(--color-muted-foreground)', fontSize: 12 }}
            axisLine={{ stroke: 'var(--color-border)' }}
            tickLine={false}
            interval="preserveStartEnd"
            minTickGap={24}
          />
          <YAxis
            tick={{ fill: 'var(--color-muted-foreground)', fontSize: 12 }}
            axisLine={false}
            tickLine={false}
            width={48}
            tickFormatter={(value: number) => compactAmount.format(value)}
          />
          <Tooltip
            formatter={(value, name) => [formatMoney(Number(value)), String(name)]}
            contentStyle={{
              backgroundColor: 'var(--color-card)',
              borderColor: 'var(--color-border)',
              borderRadius: 8,
              fontSize: 13,
            }}
          />
          <Legend
            formatter={(value: string) => <span className="text-sm text-muted-foreground">{value}</span>}
          />
          <Area
            type="monotone"
            dataKey="income"
            name="Доходы"
            stroke="var(--color-success)"
            fill="var(--color-success)"
            fillOpacity={0.12}
            strokeWidth={2}
          />
          <Area
            type="monotone"
            dataKey="expenses"
            name="Расходы"
            stroke="var(--color-primary)"
            fill="var(--color-primary)"
            fillOpacity={0.12}
            strokeWidth={2}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  )
}
