import { Button, Input, Select, type SelectOption } from '@/components/ui'
import { formatDate } from '@/utils/formatDate'
import {
  ANALYTICS_PERIOD_LABELS,
  ANALYTICS_PERIOD_PRESETS,
  type AnalyticsPeriod,
  type AnalyticsPeriodPreset,
  type AnalyticsPeriodState,
} from './period'

/**
 * Быстрые кнопки + полный Select (ТЗ, п.2) — тот же приём, что и
 * TransactionFiltersPanel (Этап 9): кнопки покрывают самые частые пресеты,
 * Select — оставшиеся (включая "Произвольный период"), чтобы не городить
 * 9 кнопок в ряд на мобильном экране.
 */
const QUICK_ANALYTICS_PERIODS: readonly AnalyticsPeriodPreset[] = ['month', 'lastMonth', 'last3Months', 'year']

const PERIOD_OPTIONS: SelectOption[] = ANALYTICS_PERIOD_PRESETS.map((preset) => ({
  value: preset,
  label: ANALYTICS_PERIOD_LABELS[preset],
}))

export interface AnalyticsPeriodSelectorProps {
  state: AnalyticsPeriodState
  resolved: AnalyticsPeriod
  onChangePreset: (preset: AnalyticsPeriodPreset) => void
  onChangeCustomRange: (from: string, to: string) => void
}

export function AnalyticsPeriodSelector({
  state,
  resolved,
  onChangePreset,
  onChangeCustomRange,
}: AnalyticsPeriodSelectorProps) {
  return (
    <div className="flex flex-col gap-2">
      <div className="flex flex-wrap items-center gap-2" role="group" aria-label="Быстрый выбор периода аналитики">
        {QUICK_ANALYTICS_PERIODS.map((preset) => (
          <Button
            key={preset}
            type="button"
            variant={state.preset === preset ? 'primary' : 'outline'}
            size="sm"
            aria-pressed={state.preset === preset}
            onClick={() => onChangePreset(preset)}
          >
            {ANALYTICS_PERIOD_LABELS[preset]}
          </Button>
        ))}
        <div className="w-48">
          <Select
            aria-label="Период аналитики"
            options={PERIOD_OPTIONS}
            value={state.preset}
            onChange={(event) => onChangePreset(event.target.value as AnalyticsPeriodPreset)}
          />
        </div>
      </div>

      {state.preset === 'custom' && (
        <div className="grid grid-cols-2 gap-3 sm:max-w-sm">
          <Input
            label="С"
            type="date"
            value={resolved.dateFrom}
            onChange={(event) => onChangeCustomRange(event.target.value, resolved.dateTo)}
          />
          <Input
            label="По"
            type="date"
            value={resolved.dateTo}
            onChange={(event) => onChangeCustomRange(resolved.dateFrom, event.target.value)}
          />
        </div>
      )}

      <p className="text-xs text-muted-foreground">
        {formatDate(resolved.dateFrom)} – {formatDate(resolved.dateTo)}
      </p>
    </div>
  )
}
