import { buildAnalyticsComparison, calculateComparisonValue, formatPercentageChange } from './comparison'
import type { AnalyticsSummary } from './api'

describe('calculateComparisonValue (Этап 14, п.16, ТЗ п.39 "Дельта"/"Деление на ноль")', () => {
  it('считает current/previous/difference/percentageChange для обычного роста', () => {
    expect(calculateComparisonValue(150000, 140000)).toEqual({
      current: 150000,
      previous: 140000,
      difference: 10000,
      percentageChange: expect.closeTo(7.142857, 5),
    })
  })

  it('считает отрицательное изменение (снижение)', () => {
    const result = calculateComparisonValue(93500, 98000)
    expect(result.difference).toBe(-4500)
    expect(result.percentageChange).toBeCloseTo(-4.591837, 5)
  })

  it('previous === 0 — НЕ делит на ноль: percentageChange строго null, а не Infinity/NaN', () => {
    const result = calculateComparisonValue(47, 0)
    expect(result.percentageChange).toBeNull()
    expect(Number.isFinite(result.percentageChange as unknown as number)).toBe(false)
    expect(result.difference).toBe(47)
  })

  it('current === previous === 0 — тоже null, а не NaN (0/0)', () => {
    const result = calculateComparisonValue(0, 0)
    expect(result.percentageChange).toBeNull()
    expect(result.difference).toBe(0)
  })
})

describe('buildAnalyticsComparison', () => {
  it('строит сравнение по всем 4 метрикам сводки одним вызовом', () => {
    const current: AnalyticsSummary = { income: 150000, expenses: 93500, balance: 56500, transactionCount: 47 }
    const previous: AnalyticsSummary = { income: 140000, expenses: 98000, balance: 42000, transactionCount: 0 }

    const comparison = buildAnalyticsComparison(current, previous)

    expect(comparison.income.difference).toBe(10000)
    expect(comparison.expenses.difference).toBe(-4500)
    expect(comparison.balance.difference).toBe(14500)
    expect(comparison.transactionCount.percentageChange).toBeNull()
  })
})

describe('formatPercentageChange (ТЗ, п.16 — только объективное изменение, никогда ∞%)', () => {
  it('null → тире, а не "∞%"/"Infinity%"', () => {
    expect(formatPercentageChange(null)).toBe('—')
  })

  it('положительное значение — со знаком "+"', () => {
    expect(formatPercentageChange(7.1)).toBe('+7,1%')
  })

  it('отрицательное значение — со знаком минус', () => {
    const formatted = formatPercentageChange(-4.6)
    expect(formatted.endsWith('4,6%')).toBe(true)
    expect(formatted.startsWith('+')).toBe(false)
  })

  it('ровно 0 — тоже со знаком (signDisplay: exceptZero не прячет знак у не-нуля, а 0 — единственное исключение)', () => {
    expect(formatPercentageChange(0)).toBe('0,0%')
  })
})
