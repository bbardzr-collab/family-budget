import {
  isShortAnalyticsPeriod,
  resolveAnalyticsPeriod,
  resolvePreviousAnalyticsPeriod,
  type AnalyticsPeriodState,
} from './period'

function state(overrides: Partial<AnalyticsPeriodState> = {}): AnalyticsPeriodState {
  return { preset: 'month', customFrom: '', customTo: '', ...overrides }
}

// "Сейчас" зафиксировано в среду, 16 сентября 2026 — та же опорная дата, что
// и в features/transactions/filters.test.ts (Этап 9), чтобы границы недели/
// месяца были уже проверены и сверены вручную там же.
const NOW = new Date(2026, 8, 16)

describe('resolveAnalyticsPeriod (Этап 14, п.2, ТЗ п.39 "Периоды")', () => {
  it('"Сегодня"', () => {
    expect(resolveAnalyticsPeriod(state({ preset: 'today' }), NOW)).toEqual({
      preset: 'today',
      dateFrom: '2026-09-16',
      dateTo: '2026-09-16',
    })
  })

  it('"Эта неделя" — понедельник-воскресенье', () => {
    expect(resolveAnalyticsPeriod(state({ preset: 'week' }), NOW)).toEqual({
      preset: 'week',
      dateFrom: '2026-09-14',
      dateTo: '2026-09-20',
    })
  })

  it('"Этот месяц"', () => {
    expect(resolveAnalyticsPeriod(state({ preset: 'month' }), NOW)).toEqual({
      preset: 'month',
      dateFrom: '2026-09-01',
      dateTo: '2026-09-30',
    })
  })

  it('"Прошлый месяц"', () => {
    expect(resolveAnalyticsPeriod(state({ preset: 'lastMonth' }), NOW)).toEqual({
      preset: 'lastMonth',
      dateFrom: '2026-08-01',
      dateTo: '2026-08-31',
    })
  })

  it('"Последние 3 месяца" — текущий месяц + два предыдущих целиком', () => {
    expect(resolveAnalyticsPeriod(state({ preset: 'last3Months' }), NOW)).toEqual({
      preset: 'last3Months',
      dateFrom: '2026-07-01',
      dateTo: '2026-09-30',
    })
  })

  it('"Последние 6 месяцев"', () => {
    expect(resolveAnalyticsPeriod(state({ preset: 'last6Months' }), NOW)).toEqual({
      preset: 'last6Months',
      dateFrom: '2026-04-01',
      dateTo: '2026-09-30',
    })
  })

  it('"Этот год"', () => {
    expect(resolveAnalyticsPeriod(state({ preset: 'year' }), NOW)).toEqual({
      preset: 'year',
      dateFrom: '2026-01-01',
      dateTo: '2026-12-31',
    })
  })

  it('"Прошлый год"', () => {
    expect(resolveAnalyticsPeriod(state({ preset: 'lastYear' }), NOW)).toEqual({
      preset: 'lastYear',
      dateFrom: '2025-01-01',
      dateTo: '2025-12-31',
    })
  })

  it('"Произвольный период" — использует ровно указанные даты', () => {
    expect(
      resolveAnalyticsPeriod(state({ preset: 'custom', customFrom: '2026-09-01', customTo: '2026-09-15' }), NOW),
    ).toEqual({ preset: 'custom', dateFrom: '2026-09-01', dateTo: '2026-09-15' })
  })

  it('"Произвольный период" без выбранных границ — безопасный дефолт, а не null/пустая строка', () => {
    const period = resolveAnalyticsPeriod(state({ preset: 'custom' }), NOW)
    expect(period.dateFrom).toBe('2026-09-01')
    expect(period.dateTo).toBe('2026-09-16')
  })
})

describe('resolvePreviousAnalyticsPeriod (Этап 14, п.15-16, ТЗ п.39 "Сравнение")', () => {
  it('"Сегодня" → вчера', () => {
    const period = resolveAnalyticsPeriod(state({ preset: 'today' }), NOW)
    expect(resolvePreviousAnalyticsPeriod(period, NOW)).toEqual({ dateFrom: '2026-09-15', dateTo: '2026-09-15' })
  })

  it('"Эта неделя" → предыдущая календарная неделя (не скользящий сдвиг на 7 дней от произвольной точки)', () => {
    const period = resolveAnalyticsPeriod(state({ preset: 'week' }), NOW)
    expect(resolvePreviousAnalyticsPeriod(period, NOW)).toEqual({ dateFrom: '2026-09-07', dateTo: '2026-09-13' })
  })

  it('"Этот месяц" → прошлый календарный МЕСЯЦ, а не сдвиг на 30 дней (30 дней от 1 сентября — это 2, а не 1 августа)', () => {
    const period = resolveAnalyticsPeriod(state({ preset: 'month' }), NOW)
    expect(resolvePreviousAnalyticsPeriod(period, NOW)).toEqual({ dateFrom: '2026-08-01', dateTo: '2026-08-31' })
  })

  it('"Прошлый месяц" → месяц перед ним', () => {
    const period = resolveAnalyticsPeriod(state({ preset: 'lastMonth' }), NOW)
    expect(resolvePreviousAnalyticsPeriod(period, NOW)).toEqual({ dateFrom: '2026-07-01', dateTo: '2026-07-31' })
  })

  it('"Последние 3 месяца" → предыдущие 3 календарных месяца тем же блоком', () => {
    const period = resolveAnalyticsPeriod(state({ preset: 'last3Months' }), NOW)
    expect(resolvePreviousAnalyticsPeriod(period, NOW)).toEqual({ dateFrom: '2026-04-01', dateTo: '2026-06-30' })
  })

  it('"Последние 6 месяцев" → предыдущий 6-месячный блок', () => {
    const period = resolveAnalyticsPeriod(state({ preset: 'last6Months' }), NOW)
    expect(resolvePreviousAnalyticsPeriod(period, NOW)).toEqual({ dateFrom: '2025-10-01', dateTo: '2026-03-31' })
  })

  it('"Этот год" → прошлый календарный год', () => {
    const period = resolveAnalyticsPeriod(state({ preset: 'year' }), NOW)
    expect(resolvePreviousAnalyticsPeriod(period, NOW)).toEqual({ dateFrom: '2025-01-01', dateTo: '2025-12-31' })
  })

  it('"Прошлый год" → год перед ним', () => {
    const period = resolveAnalyticsPeriod(state({ preset: 'lastYear' }), NOW)
    expect(resolvePreviousAnalyticsPeriod(period, NOW)).toEqual({ dateFrom: '2024-01-01', dateTo: '2024-12-31' })
  })

  it('"Произвольный период" → скользящий период РОВНО той же длины непосредственно перед текущим', () => {
    const period = resolveAnalyticsPeriod(
      state({ preset: 'custom', customFrom: '2026-09-01', customTo: '2026-09-15' }),
      NOW,
    )
    // 15 дней (01.09-15.09 включительно) → предыдущие 15 дней: 17.08-31.08.
    expect(resolvePreviousAnalyticsPeriod(period, NOW)).toEqual({ dateFrom: '2026-08-17', dateTo: '2026-08-31' })
  })
})

describe('isShortAnalyticsPeriod (ТЗ, п.8 — граница адаптивной агрегации на фронтенде)', () => {
  it('31 день включительно — короткий период (дневная гранулярность)', () => {
    expect(isShortAnalyticsPeriod({ dateFrom: '2026-01-01', dateTo: '2026-01-31' })).toBe(true)
  })

  it('32 дня — уже длинный период (месячная гранулярность)', () => {
    expect(isShortAnalyticsPeriod({ dateFrom: '2026-01-01', dateTo: '2026-02-01' })).toBe(false)
  })
})
