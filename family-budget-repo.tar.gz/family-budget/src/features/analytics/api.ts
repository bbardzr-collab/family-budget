import { supabase } from '@/lib/supabase'
import type { CategoryType } from '@/features/categories/constants'

/**
 * Тонкий слой доступа к данным аналитики (Этап 14, п.5-9, 13-14, 24-27) —
 * только запросы, никакой бизнес-логики и никакого React, по аналогии с
 * features/budgets/api.ts и features/goals/api.ts.
 *
 * Все суммы считаются в Postgres (SUM/COUNT/GROUP BY внутри RPC, миграция
 * 0030) — на фронтенд никогда не загружаются списки transactions ради
 * подсчёта итогов (ТЗ, п.4, 24, 26). Все четыре RPC — SECURITY INVOKER, семья
 * определяется внутри функции через family_members+auth.uid() — family_id
 * НЕ передаётся ни одним из параметров ниже (ТЗ, п.5, 26).
 *
 * Источник данных — исключительно `transactions` (ТЗ, п.1): ни одна из этих
 * функций не обращается к planned_expenses/recurring_transactions. Блоки
 * "Запланировано" и "Цели" на странице аналитики читают существующие
 * usePlannedExpenses()/useGoals() (Этапы 12/11) напрямую, без обёртки здесь —
 * это справочные, а не агрегируемые данные (см. AnalyticsPage.tsx).
 */

export interface AnalyticsSummary {
  income: number
  expenses: number
  balance: number
  transactionCount: number
}

/** Сводка доходов/расходов/баланса/количества операций за период (ТЗ, п.3, 6). */
export async function fetchAnalyticsSummary(dateFrom: string, dateTo: string): Promise<AnalyticsSummary> {
  const { data, error } = await supabase.rpc('get_analytics_summary', {
    p_date_from: dateFrom,
    p_date_to: dateTo,
  })
  if (error) throw error

  const row = data?.[0]
  if (!row) return { income: 0, expenses: 0, balance: 0, transactionCount: 0 }
  return {
    income: row.income,
    expenses: row.expenses,
    balance: row.balance,
    transactionCount: row.transaction_count,
  }
}

export type AnalyticsGranularity = 'day' | 'month'

export interface AnalyticsTimeseriesPoint {
  /** "yyyy-MM-dd" — начало дня/месяца-бакета. */
  bucket: string
  income: number
  expenses: number
}

export interface AnalyticsTimeseries {
  /** Решается на сервере (ТЗ, п.8) — период <=31 дня -> 'day', иначе -> 'month'. */
  granularity: AnalyticsGranularity
  points: AnalyticsTimeseriesPoint[]
}

interface RawTimeseries {
  granularity: AnalyticsGranularity
  points: Array<{ bucket: string; income: number; expenses: number }>
}

/** Динамика доходов/расходов по времени, с адаптивной агрегацией (ТЗ, п.7-8). */
export async function fetchAnalyticsTimeseries(dateFrom: string, dateTo: string): Promise<AnalyticsTimeseries> {
  const { data, error } = await supabase.rpc('get_analytics_timeseries', {
    p_date_from: dateFrom,
    p_date_to: dateTo,
  })
  if (error) throw error

  const raw = (data ?? null) as unknown as RawTimeseries | null
  if (!raw) return { granularity: 'day', points: [] }
  return {
    granularity: raw.granularity,
    points: raw.points.map((p) => ({ bucket: p.bucket, income: p.income, expenses: p.expenses })),
  }
}

/** UNCATEGORIZED — псевдо-тип для расходов без категории (ТЗ, п.10-11) — не путать со значениями categories.type. */
export type AnalyticsCategoryTypeGroup = CategoryType | 'UNCATEGORIZED'

export interface AnalyticsCategoryStat {
  /** null — расходы без категории (ТЗ, п.10). */
  categoryId: string | null
  categoryName: string
  categoryIcon: string | null
  /** null для группы "Без категории". */
  categoryType: CategoryType | null
  amount: number
  /** 0, если totalExpense === 0 (ТЗ, п.9). */
  percent: number
}

export interface AnalyticsByTypeStat {
  type: AnalyticsCategoryTypeGroup
  amount: number
  percent: number
}

export interface AnalyticsCategories {
  totalExpense: number
  /** Уже отсортировано по убыванию amount — TOP-5 (ТЗ, п.13) это categories.slice(0, 5). */
  categories: AnalyticsCategoryStat[]
  /** Структура расходов по типу категории (ТЗ, п.11) — та же выборка, второй разрез. */
  byType: AnalyticsByTypeStat[]
}

interface RawCategories {
  totalExpense: number
  categories: Array<{
    categoryId: string | null
    categoryName: string
    categoryIcon: string | null
    categoryType: string | null
    amount: number
    percent: number
  }>
  byType: Array<{ type: string; amount: number; percent: number }>
}

/** Расходы по категориям + структура расходов по типу (ТЗ, п.9-13). */
export async function fetchAnalyticsCategories(dateFrom: string, dateTo: string): Promise<AnalyticsCategories> {
  const { data, error } = await supabase.rpc('get_analytics_categories', {
    p_date_from: dateFrom,
    p_date_to: dateTo,
  })
  if (error) throw error

  const raw = (data ?? null) as unknown as RawCategories | null
  if (!raw) return { totalExpense: 0, categories: [], byType: [] }
  return {
    totalExpense: raw.totalExpense,
    categories: raw.categories.map((c) => ({
      categoryId: c.categoryId,
      categoryName: c.categoryName,
      categoryIcon: c.categoryIcon,
      categoryType: c.categoryType as CategoryType | null,
      amount: c.amount,
      percent: c.percent,
    })),
    byType: raw.byType.map((t) => ({
      type: t.type as AnalyticsCategoryTypeGroup,
      amount: t.amount,
      percent: t.percent,
    })),
  }
}

export interface AnalyticsIncomeSourceStat {
  /** null — доход без указанного источника (ТЗ, п.14). */
  incomeSource: string | null
  amount: number
  percent: number
}

export interface AnalyticsIncomeSources {
  totalIncome: number
  sources: AnalyticsIncomeSourceStat[]
}

interface RawIncomeSources {
  totalIncome: number
  sources: Array<{ incomeSource: string | null; amount: number; percent: number }>
}

/** Доходы по источникам (ТЗ, п.14). */
export async function fetchAnalyticsIncomeSources(dateFrom: string, dateTo: string): Promise<AnalyticsIncomeSources> {
  const { data, error } = await supabase.rpc('get_analytics_income_sources', {
    p_date_from: dateFrom,
    p_date_to: dateTo,
  })
  if (error) throw error

  const raw = (data ?? null) as unknown as RawIncomeSources | null
  if (!raw) return { totalIncome: 0, sources: [] }
  return {
    totalIncome: raw.totalIncome,
    sources: raw.sources.map((s) => ({ incomeSource: s.incomeSource, amount: s.amount, percent: s.percent })),
  }
}
