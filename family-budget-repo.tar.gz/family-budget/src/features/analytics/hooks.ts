import { keepPreviousData, useQueries, useQuery } from '@tanstack/react-query'
import { useFamily } from '@/features/family/FamilyContext'
import { buildAnalyticsComparison, type AnalyticsComparison } from './comparison'
import { resolvePreviousAnalyticsPeriod, type AnalyticsPeriod } from './period'
import { analyticsKeys } from './queryKeys'
import {
  fetchAnalyticsCategories,
  fetchAnalyticsIncomeSources,
  fetchAnalyticsSummary,
  fetchAnalyticsTimeseries,
} from './api'

/**
 * Server state аналитики (ТЗ, п.20-23) — TanStack Query, по тому же принципу,
 * что и features/budgets/hooks.ts и features/goals/hooks.ts.
 *
 * Бюджет/цели/запланированные расходы намеренно НЕ дублируются отдельными
 * хуками здесь — AnalyticsPage.tsx напрямую использует уже существующие
 * useBudgetSummary() (Этап 10), useGoals() (Этап 11), usePlannedExpenses()
 * (Этап 12) — ровно как задокументировано в api.ts этого модуля (ТЗ, п.19-21:
 * переиспользовать существующие механизмы, не создавать новых).
 *
 * Аналитика read-only (ТЗ, п.24) — поэтому здесь только useQuery/useQueries,
 * ни одной useMutation.
 */

export function useAnalyticsSummary(period: AnalyticsPeriod) {
  const { currentFamily } = useFamily()
  return useQuery({
    queryKey: analyticsKeys.summary(period.dateFrom, period.dateTo),
    queryFn: () => fetchAnalyticsSummary(period.dateFrom, period.dateTo),
    enabled: Boolean(currentFamily?.id),
    placeholderData: keepPreviousData,
  })
}

export function useAnalyticsTimeseries(period: AnalyticsPeriod) {
  const { currentFamily } = useFamily()
  return useQuery({
    queryKey: analyticsKeys.timeseries(period.dateFrom, period.dateTo),
    queryFn: () => fetchAnalyticsTimeseries(period.dateFrom, period.dateTo),
    enabled: Boolean(currentFamily?.id),
    placeholderData: keepPreviousData,
  })
}

export function useAnalyticsCategories(period: AnalyticsPeriod) {
  const { currentFamily } = useFamily()
  return useQuery({
    queryKey: analyticsKeys.categories(period.dateFrom, period.dateTo),
    queryFn: () => fetchAnalyticsCategories(period.dateFrom, period.dateTo),
    enabled: Boolean(currentFamily?.id),
    placeholderData: keepPreviousData,
  })
}

export function useAnalyticsIncomeSources(period: AnalyticsPeriod) {
  const { currentFamily } = useFamily()
  return useQuery({
    queryKey: analyticsKeys.incomeSources(period.dateFrom, period.dateTo),
    queryFn: () => fetchAnalyticsIncomeSources(period.dateFrom, period.dateTo),
    enabled: Boolean(currentFamily?.id),
    placeholderData: keepPreviousData,
  })
}

export interface UseAnalyticsComparisonResult {
  data: AnalyticsComparison | undefined
  isLoading: boolean
  isError: boolean
  refetch: () => void
}

/**
 * Сравнение "период к периоду" (ТЗ, п.15-16, 22) — комбинирует ДВА вызова
 * get_analytics_summary (текущий период + предыдущий, см. period.ts) в одном
 * хуке через useQueries, вместо отдельной RPC под сравнение — ТЗ явно
 * разрешает комбинировать существующие агрегаты, если это разумно (п.6, 22).
 *
 * queryKey текущего периода здесь совпадает с ключом useAnalyticsSummary() —
 * если обе карточки используются на одной странице одновременно (как в
 * AnalyticsPage), React Query раздаёт один и тот же кэш и не делает второй
 * сетевой запрос для того же диапазона дат.
 */
export function useAnalyticsComparison(
  period: AnalyticsPeriod,
  now: Date = new Date(),
): UseAnalyticsComparisonResult {
  const { currentFamily } = useFamily()
  const previous = resolvePreviousAnalyticsPeriod(period, now)

  const [currentQuery, previousQuery] = useQueries({
    queries: [
      {
        queryKey: analyticsKeys.summary(period.dateFrom, period.dateTo),
        queryFn: () => fetchAnalyticsSummary(period.dateFrom, period.dateTo),
        enabled: Boolean(currentFamily?.id),
      },
      {
        queryKey: analyticsKeys.summary(previous.dateFrom, previous.dateTo),
        queryFn: () => fetchAnalyticsSummary(previous.dateFrom, previous.dateTo),
        enabled: Boolean(currentFamily?.id),
      },
    ],
  })

  return {
    data:
      currentQuery.data && previousQuery.data
        ? buildAnalyticsComparison(currentQuery.data, previousQuery.data)
        : undefined,
    isLoading: currentQuery.isLoading || previousQuery.isLoading,
    isError: currentQuery.isError || previousQuery.isError,
    refetch: () => {
      void currentQuery.refetch()
      void previousQuery.refetch()
    },
  }
}
