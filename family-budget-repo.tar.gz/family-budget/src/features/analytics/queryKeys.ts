/**
 * Единый источник ключей React Query для домена "аналитика" (Этап 14, п.23).
 *
 * По аналогии с budgetsKeys/goalsKeys — familyId не входит в ключ: family_id
 * никогда не передаётся с фронтенда (см. api.ts), а инвалидация запросов
 * происходит в рамках текущей залогиненной семьи. Сводка/динамика/категории/
 * источники дохода зависят только от выбранного периода (dateFrom/dateTo).
 */
export const analyticsKeys = {
  all: ['analytics'] as const,
  summary: (dateFrom: string, dateTo: string) => [...analyticsKeys.all, 'summary', dateFrom, dateTo] as const,
  timeseries: (dateFrom: string, dateTo: string) => [...analyticsKeys.all, 'timeseries', dateFrom, dateTo] as const,
  categories: (dateFrom: string, dateTo: string) => [...analyticsKeys.all, 'categories', dateFrom, dateTo] as const,
  incomeSources: (dateFrom: string, dateTo: string) =>
    [...analyticsKeys.all, 'income-sources', dateFrom, dateTo] as const,
}
