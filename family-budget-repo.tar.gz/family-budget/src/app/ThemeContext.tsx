import { createContext, useContext, useMemo, useState, type ReactNode } from 'react'

export type Theme = 'light' | 'dark'

interface ThemeContextValue {
  theme: Theme
  setTheme: (theme: Theme) => void
}

const ThemeContext = createContext<ThemeContextValue | undefined>(undefined)

/**
 * Заглушка ThemeProvider (Этап 1).
 *
 * Тёмная тема запланирована в архитектуре (см. ТЗ, п.30), но не входит
 * в MVP — сейчас provider всегда отдаёт светлую тему. Компонент уже
 * подключён на уровне приложения, чтобы в будущем достаточно было
 * реализовать переключение и persist без изменения дерева провайдеров.
 */
export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState<Theme>('light')

  const value = useMemo(() => ({ theme, setTheme }), [theme])

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>
}

export function useTheme(): ThemeContextValue {
  const context = useContext(ThemeContext)
  if (!context) {
    throw new Error('useTheme должен использоваться внутри <ThemeProvider>')
  }
  return context
}
