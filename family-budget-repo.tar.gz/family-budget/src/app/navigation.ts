import { BarChart3, Home, Receipt, Target, Users } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'

export interface NavItem {
  to: string
  label: string
  icon: LucideIcon
  /** Точное совпадение пути (для главной страницы раздела /app) */
  end?: boolean
}

/**
 * Единый источник правды для навигации авторизованной части приложения.
 * Используется и BottomNav (мобильные устройства), и Sidebar (desktop) —
 * набор маршрутов один и тот же, отличается только форма отображения.
 */
export const NAV_ITEMS: NavItem[] = [
  { to: '/app', label: 'Главная', icon: Home, end: true },
  { to: '/app/transactions', label: 'Операции', icon: Receipt },
  { to: '/app/goals', label: 'Цели', icon: Target },
  { to: '/app/analytics', label: 'Аналитика', icon: BarChart3 },
  { to: '/app/family', label: 'Семья', icon: Users },
]

/** Заголовки страниц, не входящих в NAV_ITEMS (используются в Header) */
const EXTRA_PAGE_TITLES: Record<string, string> = {
  '/app/settings': 'Настройки',
  '/app/categories': 'Категории',
  '/app/budget': 'Бюджет',
  '/app/notifications': 'Уведомления',
}

/** Возвращает заголовок текущей страницы для Header по её пути. */
export function getPageTitle(pathname: string): string {
  const navMatch = NAV_ITEMS.find((item) =>
    item.end ? pathname === item.to : pathname.startsWith(item.to),
  )
  if (navMatch) return navMatch.label
  return EXTRA_PAGE_TITLES[pathname] ?? 'Семейный бюджет'
}
