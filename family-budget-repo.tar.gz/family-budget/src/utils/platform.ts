/**
 * Платформенные проверки для PWA (Этап 18).
 *
 * Чистые функции без побочных эффектов и без React — читают глобальные
 * `window`/`navigator` каждый вызов, поэтому легко тестируются подменой
 * этих глобальных объектов в unit-тестах, а хуки (useIsStandalone и т.п.)
 * оборачивают их в React-состояние там, где это нужно.
 */

/**
 * iOS/iPadOS-детект — нужен только для одного решения: показывать ли
 * пользователю инструкцию "Поделиться → На экран Домой" вместо кнопки
 * установки (п.21), т.к. Safari на iOS/iPadOS не поддерживает
 * `beforeinstallprompt` в принципе.
 *
 * iPadOS 13+ представляется в UA как обычный Mac Safari — единственный
 * надёжный без серверных API признак различить их на клиенте — это
 * multi-touch (у настоящих Mac его нет). Это эвристика, а не гарантия;
 * см. известные ограничения в отчёте по Этапу 18.
 */
export function isIOSDevice(): boolean {
  if (typeof navigator === 'undefined') return false

  const userAgent = navigator.userAgent
  const isClassicIOS = /iPad|iPhone|iPod/.test(userAgent)
  const isIPadOSMasqueradingAsMac = navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1

  return isClassicIOS || isIPadOSMasqueradingAsMac
}

/**
 * true, если приложение уже открыто как установленное PWA (standalone) —
 * т.е. повторно предлагать установку не нужно (п.22).
 *
 * Два независимых признака объединены через "или": стандартный
 * `display-mode: standalone` (Chromium/Android/десктоп) и нестандартный
 * `navigator.standalone` (Safari/iOS, `display-mode` там не поддерживается).
 */
export function isStandaloneDisplay(): boolean {
  if (typeof window === 'undefined') return false

  const iosNavigatorStandalone = (window.navigator as Navigator & { standalone?: boolean }).standalone
  const matchesStandaloneMediaQuery = window.matchMedia?.('(display-mode: standalone)').matches === true

  return matchesStandaloneMediaQuery || iosNavigatorStandalone === true
}
