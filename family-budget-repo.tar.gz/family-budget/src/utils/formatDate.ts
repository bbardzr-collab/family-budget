import { format, isToday, isYesterday } from 'date-fns'
import { ru } from 'date-fns/locale'

/**
 * Форматирует дату в привычном для пользователя виде: "14.09.2026".
 */
export function formatDate(date: Date | string): string {
  const value = typeof date === 'string' ? new Date(date) : date
  return format(value, 'dd.MM.yyyy', { locale: ru })
}

/** "14 сентября 2026" — для заголовков и карточек */
export function formatDateLong(date: Date | string): string {
  const value = typeof date === 'string' ? new Date(date) : date
  return format(value, 'd MMMM yyyy', { locale: ru })
}

/**
 * "Сентябрь 2026" — заголовок периода Dashboard (Этап 6, п.32). date-fns в
 * ru-локали отдаёт название месяца в отдельно стоящей форме с маленькой
 * буквы ("сентябрь"), поэтому первая буква капитализируется здесь, а не
 * захардкожена вручную по месяцам.
 */
export function formatMonthYear(date: Date | string): string {
  const value = typeof date === 'string' ? new Date(date) : date
  const formatted = format(value, 'LLLL yyyy', { locale: ru })
  return formatted.charAt(0).toUpperCase() + formatted.slice(1)
}

/**
 * "2026-09-18" — значение для <input type="date">/для отправки в Postgres
 * (колонка `date`). Отдельно от formatDate() (та отдаёт ДД.ММ.ГГГГ для
 * отображения) — два разных потребителя, два разных формата (Этап 7, п.5).
 */
export function toDateInputValue(date: Date = new Date()): string {
  return format(date, 'yyyy-MM-dd')
}

/**
 * "Сегодня, 08:30" / "Вчера, 14:02" / "14.09.2026, 09:15" — относительная
 * подпись времени для центра уведомлений (Этап 17, п.6: "Сегодня, 08:30").
 * Старше вчерашнего дня — полная дата, чтобы не путать пользователя.
 */
export function formatRelativeDateTime(date: Date | string): string {
  const value = typeof date === 'string' ? new Date(date) : date
  const time = format(value, 'HH:mm', { locale: ru })
  if (isToday(value)) return `Сегодня, ${time}`
  if (isYesterday(value)) return `Вчера, ${time}`
  return `${formatDate(value)}, ${time}`
}
