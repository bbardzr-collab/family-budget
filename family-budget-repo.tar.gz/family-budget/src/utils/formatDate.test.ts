import { formatDate, formatDateLong, formatMonthYear, formatRelativeDateTime, toDateInputValue } from './formatDate'

/**
 * Этап 20 — `formatDate.ts` не имел собственного теста, несмотря на то что
 * `formatRelativeDateTime` (сегодня/вчера/иначе) — самая заметная строка
 * текста в центре уведомлений (Этап 17, п.6).
 */
describe('formatDate.ts (регресс-тест Этапа 20)', () => {
  it('formatDate — ДД.ММ.ГГГГ', () => {
    expect(formatDate('2026-09-14T10:00:00Z')).toBe('14.09.2026')
  })

  it('formatDateLong — "D месяц ГГГГ"', () => {
    expect(formatDateLong('2026-09-14T10:00:00Z')).toBe('14 сентября 2026')
  })

  it('formatMonthYear — капитализирует первую букву названия месяца', () => {
    expect(formatMonthYear('2026-09-14T10:00:00Z')).toBe('Сентябрь 2026')
  })

  it('toDateInputValue — ГГГГ-ММ-ДД для <input type="date">', () => {
    expect(toDateInputValue(new Date(2026, 8, 14))).toBe('2026-09-14')
  })

  describe('formatRelativeDateTime', () => {
    beforeEach(() => {
      vi.useFakeTimers()
      vi.setSystemTime(new Date('2026-09-14T15:00:00'))
    })

    afterEach(() => {
      vi.useRealTimers()
    })

    it('сегодняшняя дата -> "Сегодня, HH:mm"', () => {
      expect(formatRelativeDateTime(new Date('2026-09-14T08:30:00'))).toBe('Сегодня, 08:30')
    })

    it('вчерашняя дата -> "Вчера, HH:mm"', () => {
      expect(formatRelativeDateTime(new Date('2026-09-13T14:02:00'))).toBe('Вчера, 14:02')
    })

    it('дата раньше вчера -> полная дата с временем, не относительная подпись', () => {
      expect(formatRelativeDateTime(new Date('2026-09-01T09:15:00'))).toBe('01.09.2026, 09:15')
    })
  })
})
