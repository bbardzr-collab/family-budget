import { formatMoney } from './formatMoney'

/**
 * Intl.NumberFormat в ru-RU локали разделяет разряды/сумму-и-валюту
 * неразрывными пробелами (код 0x00A0 и узким неразрывным пробелом 0x202F),
 * а не обычным пробелом — визуально неотличимо, но строковое сравнение
 * ломается. Нормализуем перед сравнением через явные коды символов (а не
 * литералы в исходнике — ловится eslint no-irregular-whitespace), а не
 * подгоняем ожидания под конкретные невидимые символы.
 */
const NBSP = String.fromCharCode(0x00a0)
const NARROW_NBSP = String.fromCharCode(0x202f)

function normalizeSpaces(value: string): string {
  return value.split(NBSP).join(' ').split(NARROW_NBSP).join(' ')
}

describe('formatMoney (Этап 6, п.9, 36.8)', () => {
  it('форматирует целую сумму без копеек: 1250 → "1 250 ₽"', () => {
    expect(normalizeSpaces(formatMoney(1250))).toBe('1 250 ₽')
  })

  it('показывает копейки только когда они есть: 125000.5 → "125 000,50 ₽"', () => {
    expect(normalizeSpaces(formatMoney(125000.5))).toBe('125 000,50 ₽')
  })

  it('ноль форматируется как "0 ₽"', () => {
    expect(normalizeSpaces(formatMoney(0))).toBe('0 ₽')
  })

  it('отрицательная сумма показывает знак минус и полное число (п.11)', () => {
    const result = normalizeSpaces(formatMoney(-12500))
    expect(result).toMatch(/^[-−]/)
    expect(result).toContain('12 500')
    expect(result).toContain('₽')
  })

  // Этап 20 — набор граничных денежных значений из чек-листа полного
  // тестирования: каждое значение проверяется на отсутствие float-артефактов
  // (0.30000000000000004 и подобных) и на правильную видимость копеек.
  it.each([
    [0.01, '0,01 ₽'],
    [0.1, '0,10 ₽'],
    [1.99, '1,99 ₽'],
    [10.01, '10,01 ₽'],
    [100.5, '100,50 ₽'],
    [999.99, '999,99 ₽'],
    [1000.0, '1 000 ₽'],
    [99999999.99, '99 999 999,99 ₽'],
  ])('%s → "%s" без float-артефактов', (amount, expected) => {
    const result = normalizeSpaces(formatMoney(amount))
    expect(result).toBe(expected)
    // Явная проверка, что в строке нет "хвоста" вроде 0.30000000000000004.
    expect(result).not.toMatch(/\d{3,}$/)
  })

  it('верхняя граница NUMERIC(14,2) форматируется без потери точности', () => {
    expect(normalizeSpaces(formatMoney(999999999999.99))).toBe('999 999 999 999,99 ₽')
  })

  // Этап 22 (production readiness) — защита от нефинитных значений: ни один
  // известный путь сегодня не передаёт сюда NaN/Infinity, но формат не должен
  // молча показать пользователю "NaN ₽"/"∞ ₽", если такой путь появится.
  it.each([
    [NaN, '— ₽'],
    [Infinity, '— ₽'],
    [-Infinity, '— ₽'],
  ])('нефинитное значение %s форматируется как "%s", а не как мусор', (amount, expected) => {
    expect(formatMoney(amount)).toBe(expected)
  })
})
