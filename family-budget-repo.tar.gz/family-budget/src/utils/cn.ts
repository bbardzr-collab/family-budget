export type ClassValue = string | false | null | undefined

/**
 * Маленькая утилита для условного объединения классов Tailwind.
 * Отдельной библиотеки (clsx) не подключаем — задача тривиальная.
 */
export function cn(...classes: ClassValue[]): string {
  return classes.filter(Boolean).join(' ')
}
