import { isIOSDevice, isStandaloneDisplay } from './platform'

const IPHONE_UA =
  'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1'
const IPADOS_MASQUERADING_UA =
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15'
const ANDROID_UA = 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0 Mobile Safari/537.36'
const DESKTOP_MAC_UA =
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0 Safari/537.36'

/**
 * `navigator` в jsdom определяет userAgent/platform/maxTouchPoints как
 * геттеры на прототипе, а не как собственные перечисляемые свойства —
 * `{...navigator}` их не скопирует. Поэтому здесь — явный литерал с
 * безопасными значениями по умолчанию, а не попытка "склонировать" реальный
 * navigator.
 */
function mockNavigator(overrides: { userAgent?: string; platform?: string; maxTouchPoints?: number; standalone?: boolean }) {
  vi.stubGlobal('navigator', {
    userAgent: '',
    platform: '',
    maxTouchPoints: 0,
    ...overrides,
  })
}

describe('isIOSDevice (Этап 18, п.21)', () => {
  afterEach(() => {
    vi.unstubAllGlobals()
  })

  it('распознаёт iPhone по User-Agent', () => {
    mockNavigator({ userAgent: IPHONE_UA, platform: 'iPhone', maxTouchPoints: 5 })
    expect(isIOSDevice()).toBe(true)
  })

  it('распознаёт iPadOS 13+, маскирующийся под Mac (по multi-touch)', () => {
    mockNavigator({ userAgent: IPADOS_MASQUERADING_UA, platform: 'MacIntel', maxTouchPoints: 5 })
    expect(isIOSDevice()).toBe(true)
  })

  it('не считает настоящий десктопный Mac (без multi-touch) iOS-устройством', () => {
    mockNavigator({ userAgent: DESKTOP_MAC_UA, platform: 'MacIntel', maxTouchPoints: 0 })
    expect(isIOSDevice()).toBe(false)
  })

  it('не считает Android-устройство iOS-устройством', () => {
    mockNavigator({ userAgent: ANDROID_UA, platform: 'Linux armv81', maxTouchPoints: 5 })
    expect(isIOSDevice()).toBe(false)
  })
})

describe('isStandaloneDisplay (Этап 18, п.22)', () => {
  afterEach(() => {
    vi.unstubAllGlobals()
  })

  it('true, если matchMedia(display-mode: standalone) совпадает', () => {
    vi.stubGlobal('matchMedia', (query: string) => ({ matches: query.includes('standalone') }) as MediaQueryList)
    expect(isStandaloneDisplay()).toBe(true)
  })

  it('true, если navigator.standalone === true (iOS Safari)', () => {
    vi.stubGlobal('matchMedia', (() => ({ matches: false })) as unknown as typeof window.matchMedia)
    mockNavigator({ standalone: true })
    expect(isStandaloneDisplay()).toBe(true)
  })

  it('false в обычном браузерном режиме', () => {
    vi.stubGlobal('matchMedia', (() => ({ matches: false })) as unknown as typeof window.matchMedia)
    mockNavigator({ standalone: false })
    expect(isStandaloneDisplay()).toBe(false)
  })
})
