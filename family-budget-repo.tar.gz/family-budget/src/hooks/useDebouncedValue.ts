import { useEffect, useState } from 'react'

/**
 * Небольшой переиспользуемый хук debounce (Этап 9, п.6) — значение
 * обновляется не на каждый ввод символа, а спустя `delayMs` тишины.
 * Используется для поля поиска операций, чтобы не слать запрос в Supabase
 * на каждое нажатие клавиши.
 */
export function useDebouncedValue<T>(value: T, delayMs: number): T {
  const [debounced, setDebounced] = useState(value)

  useEffect(() => {
    const timer = setTimeout(() => setDebounced(value), delayMs)
    return () => clearTimeout(timer)
  }, [value, delayMs])

  return debounced
}
