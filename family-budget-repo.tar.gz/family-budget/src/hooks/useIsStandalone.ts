import { useEffect, useState } from 'react'
import { isStandaloneDisplay } from '@/utils/platform'

/**
 * Определяет, открыто ли приложение как установленное PWA (standalone) —
 * Этап 18, п.22. Используется, чтобы не предлагать установку повторно
 * (InstallPWAButton) пользователю, который уже установил приложение.
 *
 * Подписывается на изменение `(display-mode: standalone)` — на десктопе
 * это событие в теории может смениться без перезагрузки страницы (окно
 * перетащили в/из режима приложения); для iOS Safari (`navigator.standalone`)
 * такого события нет в принципе, поэтому там значение фиксируется один раз
 * при монтировании — соответствует реальным возможностям платформы.
 */
export function useIsStandalone(): boolean {
  const [isStandalone, setIsStandalone] = useState(isStandaloneDisplay)

  useEffect(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return

    const mediaQuery = window.matchMedia('(display-mode: standalone)')
    function handleChange() {
      setIsStandalone(isStandaloneDisplay())
    }

    mediaQuery.addEventListener('change', handleChange)
    return () => mediaQuery.removeEventListener('change', handleChange)
  }, [])

  return isStandalone
}
