import { useEffect, useState } from 'react'

/**
 * Отслеживает состояние подключения к интернету (Этап 18, п.14) через
 * `navigator.onLine` + события `online`/`offline`.
 *
 * Возвращает только булево состояние — вся UX-логика (баннер, безопасный
 * точечный refetch при восстановлении связи) намеренно живёт в
 * компонентах/хуках, которые этот хук используют (см. OfflineBanner), а не
 * здесь: хук отвечает только за факт наличия сети.
 */
export function useOnlineStatus(): boolean {
  const [isOnline, setIsOnline] = useState(() => (typeof navigator === 'undefined' ? true : navigator.onLine))

  useEffect(() => {
    function handleOnline() {
      setIsOnline(true)
    }
    function handleOffline() {
      setIsOnline(false)
    }

    window.addEventListener('online', handleOnline)
    window.addEventListener('offline', handleOffline)

    return () => {
      window.removeEventListener('online', handleOnline)
      window.removeEventListener('offline', handleOffline)
    }
  }, [])

  return isOnline
}
