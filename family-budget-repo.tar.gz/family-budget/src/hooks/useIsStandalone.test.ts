import { act, renderHook } from '@testing-library/react'
import { useIsStandalone } from './useIsStandalone'

interface MutableMediaQueryListMock {
  matches: boolean
  addEventListener: (type: string, listener: (event: Partial<MediaQueryListEvent>) => void) => void
  removeEventListener: ReturnType<typeof vi.fn>
}

function createMediaQueryListMock(initialMatches: boolean) {
  const listeners: Array<(event: Partial<MediaQueryListEvent>) => void> = []
  const list: MutableMediaQueryListMock = {
    matches: initialMatches,
    addEventListener: (_type, listener) => {
      listeners.push(listener)
    },
    removeEventListener: vi.fn(),
  }
  return {
    list,
    // matchMedia() должен вернуть DOM-совместимый MediaQueryList — приведение
    // типа только здесь, в точке передачи моку, чтобы сам `list` в тесте
    // оставался с изменяемым `matches` (реальный MediaQueryList.matches —
    // readonly).
    asMediaQueryList: () => list as unknown as MediaQueryList,
    emitChange(matches: boolean) {
      listeners.forEach((listener) => listener({ matches }))
    },
  }
}

describe('useIsStandalone (Этап 18, п.22)', () => {
  afterEach(() => {
    vi.unstubAllGlobals()
  })

  it('false в обычном браузерном режиме', () => {
    const { asMediaQueryList } = createMediaQueryListMock(false)
    vi.stubGlobal('matchMedia', vi.fn().mockReturnValue(asMediaQueryList()))
    vi.stubGlobal('navigator', { standalone: false })

    const { result } = renderHook(() => useIsStandalone())
    expect(result.current).toBe(false)
  })

  it('true, если (display-mode: standalone) уже совпадает при монтировании', () => {
    const { asMediaQueryList } = createMediaQueryListMock(true)
    vi.stubGlobal('matchMedia', vi.fn().mockReturnValue(asMediaQueryList()))
    vi.stubGlobal('navigator', { standalone: false })

    const { result } = renderHook(() => useIsStandalone())
    expect(result.current).toBe(true)
  })

  it('обновляется при событии change у matchMedia', () => {
    const { list, asMediaQueryList, emitChange } = createMediaQueryListMock(false)
    vi.stubGlobal('matchMedia', vi.fn().mockReturnValue(asMediaQueryList()))
    vi.stubGlobal('navigator', { standalone: false })

    const { result } = renderHook(() => useIsStandalone())
    expect(result.current).toBe(false)

    act(() => {
      list.matches = true
      emitChange(true)
    })

    expect(result.current).toBe(true)
  })

  it('отписывается от change при unmount', () => {
    const { list, asMediaQueryList } = createMediaQueryListMock(false)
    vi.stubGlobal('matchMedia', vi.fn().mockReturnValue(asMediaQueryList()))
    vi.stubGlobal('navigator', { standalone: false })

    const { unmount } = renderHook(() => useIsStandalone())
    unmount()

    expect(list.removeEventListener).toHaveBeenCalledWith('change', expect.any(Function))
  })
})
