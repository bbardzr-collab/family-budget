import { render, screen } from '@testing-library/react'
import { ProgressBar } from './ProgressBar'

/**
 * Этап 20 — `ProgressBar` не имел собственного unit-теста несмотря на
 * реальную ветвящуюся логику (guard на max<=0, пороги warning/danger),
 * используемую и бюджетом, и целями (ТЗ, п.16 — "не агрессивный дизайн").
 */
describe('ProgressBar (регресс-тест Этапа 20)', () => {
  it('max <= 0 не делит на ноль — ratio считается 0, а не NaN/Infinity', () => {
    render(<ProgressBar value={100} max={0} />)
    const bar = screen.getByRole('progressbar')
    expect(bar).toHaveAttribute('aria-valuenow', '0')
  })

  it('обычный прогресс (< 80%) — базовый цвет, без warning/danger классов', () => {
    render(<ProgressBar value={50} max={100} />)
    const bar = screen.getByRole('progressbar')
    expect(bar).toHaveAttribute('aria-valuenow', '50')
    expect(bar.firstElementChild).toHaveClass('bg-primary')
    expect(bar.firstElementChild).not.toHaveClass('bg-warning')
    expect(bar.firstElementChild).not.toHaveClass('bg-danger')
  })

  it('ровно на пороге warning (80%) — warning-цвет (>= включительно)', () => {
    render(<ProgressBar value={80} max={100} />)
    expect(screen.getByRole('progressbar').firstElementChild).toHaveClass('bg-warning')
  })

  it('чуть ниже порога warning (79%) — ещё не warning', () => {
    render(<ProgressBar value={79} max={100} />)
    expect(screen.getByRole('progressbar').firstElementChild).toHaveClass('bg-primary')
  })

  it('ровно 100% — всё ещё warning, не danger (строго > 100 для danger)', () => {
    render(<ProgressBar value={100} max={100} />)
    expect(screen.getByRole('progressbar').firstElementChild).toHaveClass('bg-warning')
  })

  it('превышение 100% — danger-цвет, а ширина полосы не превышает 100%', () => {
    render(<ProgressBar value={150} max={100} />)
    const bar = screen.getByRole('progressbar')
    expect(bar.firstElementChild).toHaveClass('bg-danger')
    expect(bar.firstElementChild).toHaveStyle({ width: '100%' })
  })

  it('процент отображения не улетает в бесконечность при экстремальном превышении — капается на 999', () => {
    render(<ProgressBar value={1_000_000} max={1} />)
    expect(screen.getByRole('progressbar')).toHaveAttribute('aria-valuenow', '999')
  })

  it('кастомный warningThreshold применяется вместо дефолтного 0.8', () => {
    render(<ProgressBar value={50} max={100} warningThreshold={0.4} />)
    expect(screen.getByRole('progressbar').firstElementChild).toHaveClass('bg-warning')
  })
})
