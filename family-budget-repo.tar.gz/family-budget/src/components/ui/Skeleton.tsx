import type { HTMLAttributes } from 'react'
import { cn } from '@/utils/cn'

/** Плейсхолдер загрузки контента (в отличие от LoadingState — для точечных блоков внутри уже видимого макета). */
export function Skeleton({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      aria-hidden="true"
      className={cn('animate-pulse rounded-md bg-muted', className)}
      {...props}
    />
  )
}
