import { forwardRef, useId, type TextareaHTMLAttributes } from 'react'
import { cn } from '@/utils/cn'

export interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string
  error?: string
  helperText?: string
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(function Textarea(
  { className, label, error, helperText, id, required, rows = 3, ...props },
  ref,
) {
  const generatedId = useId()
  const textareaId = id ?? generatedId

  return (
    <div className="flex flex-col gap-1.5">
      {label && (
        <label htmlFor={textareaId} className="text-sm font-medium text-foreground">
          {label}
          {required && (
            <span className="ml-0.5 text-danger" aria-hidden="true">
              *
            </span>
          )}
        </label>
      )}
      <textarea
        ref={ref}
        id={textareaId}
        required={required}
        rows={rows}
        aria-invalid={Boolean(error)}
        aria-describedby={
          error ? `${textareaId}-error` : helperText ? `${textareaId}-hint` : undefined
        }
        className={cn(
          'w-full resize-y rounded-md border bg-card px-3 py-2 text-base text-foreground placeholder:text-muted-foreground',
          'focus:outline-none focus-visible:ring-2 focus-visible:ring-ring',
          'disabled:cursor-not-allowed disabled:bg-muted disabled:text-muted-foreground',
          error ? 'border-destructive' : 'border-input',
          className,
        )}
        {...props}
      />
      {error && (
        <p id={`${textareaId}-error`} className="text-sm text-destructive">
          {error}
        </p>
      )}
      {!error && helperText && (
        <p id={`${textareaId}-hint`} className="text-sm text-muted-foreground">
          {helperText}
        </p>
      )}
    </div>
  )
})
