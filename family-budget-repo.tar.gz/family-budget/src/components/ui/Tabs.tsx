import {
  createContext,
  useCallback,
  useContext,
  useId,
  useMemo,
  useState,
  type KeyboardEvent,
  type ReactNode,
} from 'react'
import { cn } from '@/utils/cn'

interface TabsContextValue {
  value: string
  setValue: (value: string) => void
  baseId: string
}

const TabsContext = createContext<TabsContextValue | undefined>(undefined)

export interface TabsProps {
  /** Значение по умолчанию (неконтролируемый режим) */
  defaultValue?: string
  /** Текущее значение (контролируемый режим) */
  value?: string
  onValueChange?: (value: string) => void
  children: ReactNode
  className?: string
}

/**
 * Простой переиспользуемый Tabs без внешних зависимостей.
 * Понадобится для «Факт / План» в операциях, для фильтров и аналитики.
 *
 *   <Tabs defaultValue="fact">
 *     <TabsList>
 *       <TabsTrigger value="fact">Факт</TabsTrigger>
 *       <TabsTrigger value="plan">План</TabsTrigger>
 *     </TabsList>
 *     <TabsContent value="fact">…</TabsContent>
 *     <TabsContent value="plan">…</TabsContent>
 *   </Tabs>
 */
export function Tabs({ defaultValue, value, onValueChange, children, className }: TabsProps) {
  const [internalValue, setInternalValue] = useState(defaultValue ?? '')
  const baseId = useId()

  const isControlled = value !== undefined
  const currentValue = isControlled ? value : internalValue

  const setValue = useCallback(
    (next: string) => {
      if (!isControlled) setInternalValue(next)
      onValueChange?.(next)
    },
    [isControlled, onValueChange],
  )

  const contextValue = useMemo(
    () => ({ value: currentValue, setValue, baseId }),
    [currentValue, setValue, baseId],
  )

  return (
    <TabsContext.Provider value={contextValue}>
      <div className={className}>{children}</div>
    </TabsContext.Provider>
  )
}

function useTabsContext() {
  const context = useContext(TabsContext)
  if (!context) throw new Error('Компоненты Tabs.* должны использоваться внутри <Tabs>')
  return context
}

export function TabsList({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div
      role="tablist"
      // max-w-full + overflow-x-auto — с 4+ пунктами (например, фильтр
      // Активные/Выполненные/Отменённые/Все на /app/goals) строка табов
      // шире узких вьюпортов (320-390px) и без этого раздвигала всю
      // страницу в горизонтальный скролл вместо переноса. Затрагивает все
      // использования Tabs — для 2-3 коротких пунктов, которые и так
      // умещаются, поведение не меняется (Этап 19, п.36).
      className={cn('inline-flex max-w-full items-center gap-1 overflow-x-auto rounded-md bg-muted p-1', className)}
    >
      {children}
    </div>
  )
}

export interface TabsTriggerProps {
  value: string
  children: ReactNode
  className?: string
}

export function TabsTrigger({ value, children, className }: TabsTriggerProps) {
  const { value: activeValue, setValue, baseId } = useTabsContext()
  const isActive = activeValue === value
  const tabId = `${baseId}-tab-${value}`
  const panelId = `${baseId}-panel-${value}`

  function handleKeyDown(event: KeyboardEvent<HTMLButtonElement>) {
    const list = event.currentTarget.parentElement
    if (!list) return
    const tabs = Array.from(list.querySelectorAll<HTMLButtonElement>('[role="tab"]'))
    const currentIndex = tabs.indexOf(event.currentTarget)

    if (event.key === 'ArrowRight' || event.key === 'ArrowLeft') {
      event.preventDefault()
      const delta = event.key === 'ArrowRight' ? 1 : -1
      const nextIndex = (currentIndex + delta + tabs.length) % tabs.length
      tabs[nextIndex]?.focus()
      tabs[nextIndex]?.click()
    } else if (event.key === 'Home') {
      event.preventDefault()
      tabs[0]?.focus()
      tabs[0]?.click()
    } else if (event.key === 'End') {
      event.preventDefault()
      tabs[tabs.length - 1]?.focus()
      tabs[tabs.length - 1]?.click()
    }
  }

  return (
    <button
      type="button"
      role="tab"
      id={tabId}
      aria-selected={isActive}
      aria-controls={panelId}
      tabIndex={isActive ? 0 : -1}
      onClick={() => setValue(value)}
      onKeyDown={handleKeyDown}
      className={cn(
        'rounded-md px-3.5 py-2 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
        isActive
          ? 'bg-card text-foreground shadow-card'
          : 'text-muted-foreground hover:text-foreground',
        className,
      )}
    >
      {children}
    </button>
  )
}

export interface TabsContentProps {
  value: string
  children: ReactNode
  className?: string
}

export function TabsContent({ value, children, className }: TabsContentProps) {
  const { value: activeValue, baseId } = useTabsContext()
  if (activeValue !== value) return null

  return (
    <div
      role="tabpanel"
      id={`${baseId}-panel-${value}`}
      aria-labelledby={`${baseId}-tab-${value}`}
      className={cn('mt-3', className)}
    >
      {children}
    </div>
  )
}
