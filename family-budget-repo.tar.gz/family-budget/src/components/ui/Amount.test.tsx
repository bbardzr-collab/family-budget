import { render, screen } from '@testing-library/react'
import { Amount } from './Amount'

/**
 * Этап 20 — `Amount` не имел собственного unit-теста, несмотря на реальную
 * ветвящуюся логику tone="auto" (знак суммы -> цвет), используемую по всему
 * приложению для отображения денег.
 */
describe('Amount (регресс-тест Этапа 20)', () => {
  it('tone="auto" + отрицательная сумма -> danger', () => {
    render(<Amount value={-100} tone="auto" />)
    expect(screen.getByText(/100/)).toHaveClass('text-danger')
  })

  it('tone="auto" + положительная сумма -> success', () => {
    render(<Amount value={100} tone="auto" />)
    expect(screen.getByText(/100/)).toHaveClass('text-success')
  })

  it('tone="auto" + ноль -> neutral (не success и не danger)', () => {
    render(<Amount value={0} tone="auto" />)
    const el = screen.getByText('0 ₽')
    expect(el).toHaveClass('text-foreground')
    expect(el).not.toHaveClass('text-success')
    expect(el).not.toHaveClass('text-danger')
  })

  it('явный tone игнорирует знак суммы', () => {
    render(<Amount value={-100} tone="success" />)
    expect(screen.getByText(/100/)).toHaveClass('text-success')
  })

  it('showSign добавляет "+" только для положительной суммы', () => {
    const { rerender } = render(<Amount value={100} showSign tone="neutral" />)
    expect(screen.getByText('+100 ₽')).toBeInTheDocument()

    rerender(<Amount value={-100} showSign tone="neutral" />)
    expect(screen.queryByText(/^\+/)).not.toBeInTheDocument()

    rerender(<Amount value={0} showSign tone="neutral" />)
    expect(screen.queryByText(/^\+/)).not.toBeInTheDocument()
  })
})
