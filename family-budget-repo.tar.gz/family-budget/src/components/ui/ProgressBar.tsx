import { cn } from '@/utils/cn'

export interface ProgressBarProps {
  value: number
  max: number
  className?: string
  /** Порог (0-1), после которого полоса становится "warning" (по умолчанию 0.8, см. ТЗ п.16) */
  warningThreshold?: number
  label?: string
}

/**
 * Прогресс-бар бюджета/цели. Цвет меняется мягко: обычный -> warning (>=80%) -> danger (>100%).
 * Без агрессивных цветов (см. ТЗ п.16 — "не используй агрессивный дизайн").
 */
export function ProgressBar({
  value,
  max,
  className,
  warningThreshold = 0.8,
  label,
}: ProgressBarProps) {
  const ratio = max > 0 ? value / max : 0
  const percent = Math.min(Math.round(ratio * 100), 999)
  const widthPercent = Math.min(ratio, 1) * 100

  const barColor = ratio > 1 ? 'bg-danger' : ratio >= warningThreshold ? 'bg-warning' : 'bg-primary'

  return (
    <div className={cn('flex flex-col gap-1.5', className)}>
      <div
        role="progressbar"
        aria-valuenow={percent}
        aria-valuemin={0}
        aria-valuemax={100}
        className="h-2.5 w-full overflow-hidden rounded-full bg-muted"
      >
        <div
          className={cn('h-full rounded-full transition-all', barColor)}
          style={{ width: `${widthPercent}%` }}
        />
      </div>
      {label && <p className="text-sm text-muted-foreground">{label}</p>}
    </div>
  )
}
