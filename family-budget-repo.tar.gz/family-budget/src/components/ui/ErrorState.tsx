import { AlertTriangle } from 'lucide-react'
import type { ReactNode } from 'react'
import { cn } from '@/utils/cn'
import { Button } from './Button'

export interface ErrorStateProps {
  title?: string
  description?: string
  onRetry?: () => void
  action?: ReactNode
  className?: string
}

/**
 * Понятное пользователю сообщение об ошибке — без технических деталей
 * и stack trace (см. ТЗ, п.39).
 */
export function ErrorState({
  title = 'Что-то пошло не так',
  description = 'Попробуйте ещё раз. Если ошибка повторится, вернитесь чуть позже.',
  onRetry,
  action,
  className,
}: ErrorStateProps) {
  return (
    <div className={cn('flex flex-col items-center gap-3 py-12 text-center', className)}>
      <div className="flex size-12 items-center justify-center rounded-full bg-danger-soft">
        <AlertTriangle className="size-6 text-danger" aria-hidden="true" />
      </div>
      <div className="flex flex-col gap-1">
        <p className="font-medium text-foreground">{title}</p>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
      {action ??
        (onRetry && (
          <Button variant="secondary" size="sm" onClick={onRetry}>
            Повторить
          </Button>
        ))}
    </div>
  )
}
