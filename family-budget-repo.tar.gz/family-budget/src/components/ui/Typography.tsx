import type { ElementType, HTMLAttributes } from 'react'
import { cn } from '@/utils/cn'

/**
 * Единая типографическая шкала приложения (см. Этап 2, п.3).
 * Все страницы должны использовать эти компоненты вместо собственных
 * заголовков/текста, чтобы иерархия оставалась одинаковой везде.
 */

export function PageTitle({ className, ...props }: HTMLAttributes<HTMLHeadingElement>) {
  return (
    <h1
      className={cn('text-2xl font-semibold tracking-tight text-foreground sm:text-3xl', className)}
      {...props}
    />
  )
}

export function SectionTitle({ className, ...props }: HTMLAttributes<HTMLHeadingElement>) {
  return <h2 className={cn('text-lg font-semibold text-foreground', className)} {...props} />
}

export type TextVariant = 'body' | 'secondary' | 'small' | 'caption'

export interface TextProps extends HTMLAttributes<HTMLParagraphElement> {
  variant?: TextVariant
  as?: ElementType
}

const TEXT_VARIANT_CLASSES: Record<TextVariant, string> = {
  body: 'text-base text-foreground',
  secondary: 'text-sm text-muted-foreground',
  small: 'text-xs text-muted-foreground',
  caption: 'text-xs uppercase tracking-wide text-muted-foreground',
}

/** Универсальный текстовый компонент: `<Text variant="secondary">…</Text>` */
export function Text({ className, variant = 'body', as: Component = 'p', ...props }: TextProps) {
  return <Component className={cn(TEXT_VARIANT_CLASSES[variant], className)} {...props} />
}
