import { forwardRef, type ButtonHTMLAttributes } from 'react'
import type { LucideIcon } from 'lucide-react'
import { cn } from '@/utils/cn'
import type { ButtonVariant } from './Button'

export type IconButtonSize = 'sm' | 'md' | 'lg'

export interface IconButtonProps extends Omit<
  ButtonHTMLAttributes<HTMLButtonElement>,
  'aria-label'
> {
  icon: LucideIcon
  /** Обязателен — кнопка состоит только из иконки, aria-label заменяет ей подпись/tooltip. */
  'aria-label': string
  variant?: Extract<ButtonVariant, 'ghost' | 'outline' | 'primary'>
  size?: IconButtonSize
}

const SIZE_CLASSES: Record<IconButtonSize, string> = {
  // 44×44 — минимальная зона касания (Этап 19, п.36). Иконка внутри
  // остаётся визуально компактной (size-4), увеличена только площадь
  // самой кнопки — так `sm` не выглядит крупнее по контуру иконки, но
  // проходит по touch-target, оставаясь меньше `md` по размеру иконки.
  sm: 'size-11 [&>svg]:size-4',
  md: 'size-11 [&>svg]:size-5',
  lg: 'size-14 [&>svg]:size-6',
}

const VARIANT_CLASSES: Record<'ghost' | 'outline' | 'primary', string> = {
  ghost: 'bg-transparent text-muted-foreground hover:bg-muted hover:text-foreground',
  outline: 'border border-border bg-card text-foreground hover:bg-muted',
  primary: 'bg-primary text-primary-foreground hover:bg-primary-hover',
}

/** Кнопка-иконка (без подписи). aria-label обязателен на уровне типов. */
export const IconButton = forwardRef<HTMLButtonElement, IconButtonProps>(function IconButton(
  { icon: Icon, variant = 'ghost', size = 'md', className, disabled, ...props },
  ref,
) {
  return (
    <button
      ref={ref}
      type="button"
      disabled={disabled}
      className={cn(
        'inline-flex shrink-0 items-center justify-center rounded-md transition-colors',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background',
        'disabled:cursor-not-allowed disabled:opacity-50',
        SIZE_CLASSES[size],
        VARIANT_CLASSES[variant],
        className,
      )}
      {...props}
    >
      <Icon aria-hidden="true" />
    </button>
  )
})
