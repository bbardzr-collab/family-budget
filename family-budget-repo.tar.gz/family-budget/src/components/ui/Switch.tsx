import { forwardRef, useId } from 'react'
import { cn } from '@/utils/cn'

export interface SwitchProps {
  checked: boolean
  onCheckedChange: (checked: boolean) => void
  label?: string
  description?: string
  disabled?: boolean
  id?: string
  className?: string
}

/**
 * Переключатель (role="switch"). Понадобится для настроек приватности
 * (Этап 16) и уведомлений (Этап 17) — состояние ВСЕГДА дублируется
 * положением + подписью, не только цветом.
 */
export const Switch = forwardRef<HTMLButtonElement, SwitchProps>(function Switch(
  { checked, onCheckedChange, label, description, disabled, id, className },
  ref,
) {
  const generatedId = useId()
  const switchId = id ?? generatedId

  const control = (
    <button
      ref={ref}
      type="button"
      role="switch"
      id={switchId}
      aria-checked={checked}
      disabled={disabled}
      onClick={() => onCheckedChange(!checked)}
      className={cn(
        'relative inline-flex h-7 w-12 shrink-0 items-center rounded-full transition-colors',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background',
        'disabled:cursor-not-allowed disabled:opacity-50',
        checked ? 'bg-primary' : 'bg-muted',
        className,
      )}
    >
      <span
        className={cn(
          'inline-block size-5 translate-x-1 rounded-full bg-card shadow-card transition-transform',
          checked && 'translate-x-6',
        )}
      />
    </button>
  )

  if (!label && !description) return control

  return (
    <div className="flex items-center justify-between gap-4 py-1.5">
      <label htmlFor={switchId} className="flex flex-col">
        {label && <span className="text-sm font-medium text-foreground">{label}</span>}
        {description && <span className="text-sm text-muted-foreground">{description}</span>}
      </label>
      {control}
    </div>
  )
})
