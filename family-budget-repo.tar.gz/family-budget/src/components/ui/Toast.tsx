import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react'
import { createPortal } from 'react-dom'
import { CheckCircle2, AlertTriangle, Info, XCircle, X } from 'lucide-react'
import { cn } from '@/utils/cn'

export type ToastType = 'success' | 'error' | 'warning' | 'info'

export interface ToastOptions {
  title: string
  description?: string
  type?: ToastType
  /** мс до автоматического закрытия, 0 — не закрывать автоматически */
  duration?: number
}

interface ToastItem extends Required<Omit<ToastOptions, 'description'>> {
  id: string
  description?: string
}

interface ToastContextValue {
  toast: (options: ToastOptions) => void
}

const ToastContext = createContext<ToastContextValue | undefined>(undefined)

const TYPE_CONFIG: Record<ToastType, { icon: typeof CheckCircle2; className: string }> = {
  success: { icon: CheckCircle2, className: 'text-success' },
  error: { icon: XCircle, className: 'text-destructive' },
  warning: { icon: AlertTriangle, className: 'text-warning' },
  info: { icon: Info, className: 'text-primary' },
}

/**
 * Простой Toast-механизм без внешних сервисов.
 * Использование в любом компоненте: const { toast } = useToast();
 * toast({ type: 'success', title: 'Расход добавлен' })
 */
export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([])

  const dismiss = useCallback((id: string) => {
    setItems((current) => current.filter((item) => item.id !== id))
  }, [])

  const toast = useCallback(
    ({ title, description, type = 'info', duration = 4000 }: ToastOptions) => {
      const id = crypto.randomUUID()
      setItems((current) => [...current, { id, title, description, type, duration }])

      if (duration > 0) {
        setTimeout(() => dismiss(id), duration)
      }
    },
    [dismiss],
  )

  const value = useMemo(() => ({ toast }), [toast])

  return (
    <ToastContext.Provider value={value}>
      {children}
      {createPortal(
        <div
          className="fixed inset-x-0 bottom-20 z-[100] flex flex-col items-center gap-2 px-4 sm:bottom-4 sm:items-end sm:right-4 sm:left-auto"
          role="region"
          aria-label="Уведомления"
        >
          {items.map((item) => {
            const { icon: Icon, className } = TYPE_CONFIG[item.type]
            return (
              <div
                key={item.id}
                role={item.type === 'error' ? 'alert' : 'status'}
                aria-live={item.type === 'error' ? 'assertive' : 'polite'}
                className="flex w-full max-w-sm items-start gap-3 rounded-md border border-border bg-card p-4 shadow-elevated sm:w-96"
              >
                <Icon className={cn('mt-0.5 size-5 shrink-0', className)} aria-hidden="true" />
                <div className="flex-1">
                  <p className="text-sm font-medium text-foreground">{item.title}</p>
                  {item.description && (
                    <p className="mt-0.5 text-sm text-muted-foreground">{item.description}</p>
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => dismiss(item.id)}
                  aria-label="Закрыть уведомление"
                  className="shrink-0 rounded-full p-1 text-muted-foreground hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  <X className="size-4" aria-hidden="true" />
                </button>
              </div>
            )
          })}
        </div>,
        document.body,
      )}
    </ToastContext.Provider>
  )
}

export function useToast(): ToastContextValue {
  const context = useContext(ToastContext)
  if (!context) {
    throw new Error('useToast должен использоваться внутри <ToastProvider>')
  }
  return context
}
