import { forwardRef, useId, type InputHTMLAttributes, type ReactNode } from 'react'
import { cn } from '@/utils/cn'

export interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string
  /** Пояснительный текст под полем (не показывается вместе с error) */
  helperText?: string
  error?: string
  leftIcon?: ReactNode
  /** Декоративная иконка справа (не кликабельна) */
  rightIcon?: ReactNode
  /** Интерактивный элемент справа (например, кнопка "показать пароль") — в отличие от rightIcon, кликабелен */
  rightElement?: ReactNode
}

export const Input = forwardRef<HTMLInputElement, InputProps>(function Input(
  { className, label, error, helperText, leftIcon, rightIcon, rightElement, id, required, ...props },
  ref,
) {
  const generatedId = useId()
  const inputId = id ?? generatedId

  return (
    <div className="flex flex-col gap-1.5">
      {label && (
        <label htmlFor={inputId} className="text-sm font-medium text-foreground">
          {label}
          {required && (
            <span className="ml-0.5 text-danger" aria-hidden="true">
              *
            </span>
          )}
        </label>
      )}
      <div className="relative flex items-center">
        {leftIcon && (
          <span className="pointer-events-none absolute left-3 flex text-muted-foreground [&>svg]:size-4">
            {leftIcon}
          </span>
        )}
        <input
          ref={ref}
          id={inputId}
          required={required}
          aria-invalid={Boolean(error)}
          aria-describedby={error ? `${inputId}-error` : helperText ? `${inputId}-hint` : undefined}
          className={cn(
            'h-11 w-full rounded-md border bg-card px-3 text-base text-foreground placeholder:text-muted-foreground',
            'focus:outline-none focus-visible:ring-2 focus-visible:ring-ring',
            'disabled:cursor-not-allowed disabled:bg-muted disabled:text-muted-foreground',
            error ? 'border-destructive' : 'border-input',
            leftIcon ? 'pl-9' : undefined,
            rightIcon || rightElement ? 'pr-9' : undefined,
            className,
          )}
          {...props}
        />
        {rightIcon && (
          <span className="pointer-events-none absolute right-3 flex text-muted-foreground [&>svg]:size-4">
            {rightIcon}
          </span>
        )}
        {rightElement && (
          <span className="absolute right-1.5 flex text-muted-foreground [&>svg]:size-4">
            {rightElement}
          </span>
        )}
      </div>
      {error && (
        <p id={`${inputId}-error`} className="text-sm text-destructive">
          {error}
        </p>
      )}
      {!error && helperText && (
        <p id={`${inputId}-hint`} className="text-sm text-muted-foreground">
          {helperText}
        </p>
      )}
    </div>
  )
})
