import type { HTMLAttributes } from 'react'
import { formatMoney } from '@/utils/formatMoney'
import { cn } from '@/utils/cn'

export type AmountSize = 'sm' | 'md' | 'lg' | 'xl'
/** 'auto' — цвет по знаку суммы (доход зелёный, расход обычный текст) */
export type AmountTone = 'auto' | 'neutral' | 'success' | 'danger'

export interface AmountProps extends Omit<HTMLAttributes<HTMLSpanElement>, 'children'> {
  value: number
  size?: AmountSize
  tone?: AmountTone
  /** Показывать явный знак "+" перед положительной суммой (для доходов в списках) */
  showSign?: boolean
  currency?: string
}

const SIZE_CLASSES: Record<AmountSize, string> = {
  sm: 'text-sm font-medium',
  md: 'text-base font-semibold',
  lg: 'text-2xl font-semibold tracking-tight',
  xl: 'text-3xl font-semibold tracking-tight sm:text-4xl',
}

const TONE_CLASSES: Record<Exclude<AmountTone, 'auto'>, string> = {
  neutral: 'text-foreground',
  success: 'text-success',
  danger: 'text-danger',
}

/**
 * Денежная сумма — главный визуальный элемент экрана (см. ТЗ, п.11:
 * "крупные суммы"), а не обычный текст. Всегда использует российский
 * формат через formatMoney() и моноширинные цифры (tabular-nums),
 * чтобы суммы в списках были ровными.
 */
export function Amount({
  value,
  size = 'md',
  tone = 'neutral',
  showSign = false,
  currency = 'RUB',
  className,
  ...props
}: AmountProps) {
  const resolvedTone: Exclude<AmountTone, 'auto'> =
    tone === 'auto' ? (value < 0 ? 'danger' : value > 0 ? 'success' : 'neutral') : tone

  const sign = showSign && value > 0 ? '+' : ''

  return (
    <span
      className={cn('tabular-nums', SIZE_CLASSES[size], TONE_CLASSES[resolvedTone], className)}
      {...props}
    >
      {sign}
      {formatMoney(value, currency)}
    </span>
  )
}
