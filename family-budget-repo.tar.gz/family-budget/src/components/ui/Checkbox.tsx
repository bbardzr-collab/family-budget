import { forwardRef, useId, type InputHTMLAttributes } from 'react'
import { Check } from 'lucide-react'
import { cn } from '@/utils/cn'

export interface CheckboxProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> {
  label?: string
  description?: string
}

/**
 * Чекбокс с увеличенной зоной нажатия (весь label кликабелен) —
 * понадобится, например, для настроек приватности CHILD (Этап 16).
 */
export const Checkbox = forwardRef<HTMLInputElement, CheckboxProps>(function Checkbox(
  { className, label, description, id, ...props },
  ref,
) {
  const generatedId = useId()
  const checkboxId = id ?? generatedId

  return (
    <label
      htmlFor={checkboxId}
      className={cn(
        'flex cursor-pointer items-start gap-3 rounded-md py-1.5',
        props.disabled && 'cursor-not-allowed opacity-50',
      )}
    >
      <span className="relative mt-0.5 inline-flex size-5 shrink-0 items-center justify-center">
        <input
          ref={ref}
          type="checkbox"
          id={checkboxId}
          className={cn(
            'peer size-5 shrink-0 cursor-pointer appearance-none rounded-sm border border-input bg-card',
            'checked:border-primary checked:bg-primary',
            'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background',
            'disabled:cursor-not-allowed',
            className,
          )}
          {...props}
        />
        <Check
          className="pointer-events-none absolute size-3.5 text-primary-foreground opacity-0 peer-checked:opacity-100"
          aria-hidden="true"
        />
      </span>
      {(label || description) && (
        <span className="flex flex-col">
          {label && <span className="text-sm font-medium text-foreground">{label}</span>}
          {description && <span className="text-sm text-muted-foreground">{description}</span>}
        </span>
      )}
    </label>
  )
})
