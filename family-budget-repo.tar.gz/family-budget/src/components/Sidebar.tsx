import { NavLink } from 'react-router-dom'
import { LogOut, Settings, Wallet } from 'lucide-react'
import { NAV_ITEMS } from '@/app/navigation'
import { Avatar, IconButton } from '@/components/ui'
import { useAuth } from '@/features/auth/AuthContext'
import { cn } from '@/utils/cn'

/**
 * Боковая навигация для планшета/desktop.
 * Использует тот же NAV_ITEMS и те же маршруты, что и BottomNav —
 * никакой отдельной "десктопной" логики маршрутизации нет.
 */
export function Sidebar() {
  const { profile, user, signOut } = useAuth()
  const displayName = profile?.full_name ?? (user?.user_metadata?.full_name as string | undefined) ?? user?.email ?? ''

  return (
    <aside
      aria-label="Основная навигация"
      className="sticky top-0 hidden h-screen w-60 shrink-0 flex-col border-r border-border bg-card p-4 md:flex"
    >
      <div className="mb-6 flex items-center gap-2 px-2">
        <div className="flex size-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
          <Wallet className="size-4" aria-hidden="true" />
        </div>
        <span className="font-semibold text-foreground">Семейный бюджет</span>
      </div>

      <nav className="flex flex-1 flex-col gap-1">
        {NAV_ITEMS.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            className={({ isActive }) =>
              cn(
                'flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium transition-colors',
                isActive
                  ? 'bg-accent text-accent-foreground'
                  : 'text-muted-foreground hover:bg-muted hover:text-foreground',
              )
            }
          >
            <item.icon className="size-5" aria-hidden="true" />
            {item.label}
          </NavLink>
        ))}
      </nav>

      <NavLink
        to="/app/settings"
        className={({ isActive }) =>
          cn(
            'mb-2 flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium transition-colors',
            isActive
              ? 'bg-accent text-accent-foreground'
              : 'text-muted-foreground hover:bg-muted hover:text-foreground',
          )
        }
      >
        <Settings className="size-5" aria-hidden="true" />
        Настройки
      </NavLink>

      <div className="flex items-center gap-2 rounded-md border border-border p-2.5">
        <NavLink to="/app/settings" className="flex min-w-0 flex-1 items-center gap-3">
          <Avatar name={displayName || 'Пользователь'} size="sm" />
          <div className="min-w-0">
            <p className="truncate text-sm font-medium text-foreground">{displayName}</p>
            <p className="truncate text-xs text-muted-foreground">{user?.email}</p>
          </div>
        </NavLink>
        <IconButton
          icon={LogOut}
          aria-label="Выйти"
          variant="ghost"
          size="sm"
          onClick={() => void signOut()}
        />
      </div>
    </aside>
  )
}
