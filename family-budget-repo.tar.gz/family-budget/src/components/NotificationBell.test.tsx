import { fireEvent, render, screen } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { NotificationBell } from './NotificationBell'
import type { NotificationItem } from '@/features/notifications/api'

const { mockUseUnreadNotificationsCount, mockUseNotifications, mockMarkReadMutate } = vi.hoisted(() => ({
  mockUseUnreadNotificationsCount: vi.fn(),
  mockUseNotifications: vi.fn(),
  mockMarkReadMutate: vi.fn(),
}))

vi.mock('@/features/notifications/hooks', () => ({
  useUnreadNotificationsCount: mockUseUnreadNotificationsCount,
  useNotifications: mockUseNotifications,
  useMarkNotificationRead: () => ({ mutate: mockMarkReadMutate }),
}))

function makeItem(overrides: Partial<NotificationItem> = {}): NotificationItem {
  return {
    id: 'notif-1',
    type: 'goal_achieved',
    title: 'Цель достигнута',
    message: 'Цель «Новый автомобиль» достигнута.',
    payload: { goal_id: 'goal-1' },
    isRead: false,
    createdAt: new Date().toISOString(),
    ...overrides,
  }
}

function renderBell() {
  return render(
    <MemoryRouter>
      <NotificationBell />
    </MemoryRouter>,
  )
}

describe('NotificationBell (Этап 17, п.9-10)', () => {
  beforeEach(() => {
    mockMarkReadMutate.mockReset()
    mockUseNotifications.mockReturnValue({ data: [], isLoading: false, isError: false, refetch: vi.fn() })
  })

  it('без непрочитанных — просто колокольчик, без бейджа', () => {
    mockUseUnreadNotificationsCount.mockReturnValue({ data: 0 })

    renderBell()

    expect(screen.getByRole('button', { name: 'Уведомления' })).toBeInTheDocument()
  })

  it('с непрочитанными — бейдж с реальным числом из Supabase (например "3")', () => {
    mockUseUnreadNotificationsCount.mockReturnValue({ data: 3 })

    renderBell()

    expect(screen.getByText('3')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Уведомления, непрочитанных: 3' })).toBeInTheDocument()
  })

  it('больше 99 непрочитанных — бейдж показывает "99+"', () => {
    mockUseUnreadNotificationsCount.mockReturnValue({ data: 150 })

    renderBell()

    expect(screen.getByText('99+')).toBeInTheDocument()
  })

  it('клик открывает попап со списком последних уведомлений и ссылкой на полный список', () => {
    mockUseUnreadNotificationsCount.mockReturnValue({ data: 1 })
    mockUseNotifications.mockReturnValue({
      data: [makeItem()],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderBell()
    fireEvent.click(screen.getByRole('button', { name: /Уведомления/ }))

    expect(screen.getByRole('menu', { name: 'Уведомления' })).toBeInTheDocument()
    expect(screen.getByText('Цель достигнута')).toBeInTheDocument()
    expect(screen.getByRole('link', { name: 'Посмотреть все уведомления' })).toHaveAttribute(
      'href',
      '/app/notifications',
    )
  })

  it('пустой попап: "Новых уведомлений пока нет" (ТЗ, п.20)', () => {
    mockUseUnreadNotificationsCount.mockReturnValue({ data: 0 })
    mockUseNotifications.mockReturnValue({ data: [], isLoading: false, isError: false, refetch: vi.fn() })

    renderBell()
    fireEvent.click(screen.getByRole('button', { name: /Уведомления/ }))

    expect(screen.getByText('Новых уведомлений пока нет')).toBeInTheDocument()
  })

  it('состояние загрузки попапа — skeleton, не пустой экран (ТЗ, п.21)', () => {
    mockUseUnreadNotificationsCount.mockReturnValue({ data: 0 })
    mockUseNotifications.mockReturnValue({ data: undefined, isLoading: true, isError: false, refetch: vi.fn() })

    renderBell()
    fireEvent.click(screen.getByRole('button', { name: /Уведомления/ }))

    expect(screen.getByRole('status', { name: /загружаем уведомления/i })).toBeInTheDocument()
  })

  it('ошибка загрузки попапа — сообщение и кнопка "Повторить"', () => {
    const refetch = vi.fn()
    mockUseUnreadNotificationsCount.mockReturnValue({ data: 0 })
    mockUseNotifications.mockReturnValue({ data: undefined, isLoading: false, isError: true, refetch })

    renderBell()
    fireEvent.click(screen.getByRole('button', { name: /Уведомления/ }))
    fireEvent.click(screen.getByRole('button', { name: 'Повторить' }))

    expect(refetch).toHaveBeenCalled()
  })

  it('клик по уведомлению помечает его прочитанным и закрывает попап', () => {
    mockUseUnreadNotificationsCount.mockReturnValue({ data: 1 })
    mockUseNotifications.mockReturnValue({
      data: [makeItem({ id: 'notif-bell', isRead: false })],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderBell()
    fireEvent.click(screen.getByRole('button', { name: /Уведомления/ }))
    fireEvent.click(screen.getByText('Цель достигнута'))

    expect(mockMarkReadMutate).toHaveBeenCalledWith('notif-bell')
    expect(screen.queryByRole('menu', { name: 'Уведомления' })).not.toBeInTheDocument()
  })

  it('клик вне попапа закрывает его', () => {
    mockUseUnreadNotificationsCount.mockReturnValue({ data: 0 })

    renderBell()
    fireEvent.click(screen.getByRole('button', { name: /Уведомления/ }))
    expect(screen.getByRole('menu', { name: 'Уведомления' })).toBeInTheDocument()

    fireEvent.mouseDown(document.body)

    expect(screen.queryByRole('menu', { name: 'Уведомления' })).not.toBeInTheDocument()
  })

  it('Escape закрывает попап', () => {
    mockUseUnreadNotificationsCount.mockReturnValue({ data: 0 })

    renderBell()
    fireEvent.click(screen.getByRole('button', { name: /Уведомления/ }))
    fireEvent.keyDown(document, { key: 'Escape' })

    expect(screen.queryByRole('menu', { name: 'Уведомления' })).not.toBeInTheDocument()
  })
})
