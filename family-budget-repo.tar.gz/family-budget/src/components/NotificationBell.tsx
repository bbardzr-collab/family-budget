import { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { Bell } from 'lucide-react'
import { Skeleton } from '@/components/ui'
import { cn } from '@/utils/cn'
import { NotificationRow } from '@/features/notifications/NotificationRow'
import { useMarkNotificationRead, useNotifications, useUnreadNotificationsCount } from '@/features/notifications/hooks'
import type { NotificationItem } from '@/features/notifications/api'

const DROPDOWN_LIMIT = 5

/**
 * Колокольчик уведомлений в Header (ТЗ, п.9-10) — реальный счётчик
 * непрочитанных из Supabase (useUnreadNotificationsCount) и небольшой
 * попап с последними DROPDOWN_LIMIT уведомлениями. Собственная простая
 * реализация попапа (не components/ui/Dropdown — тот рассчитан на плоский
 * список пунктов меню, а здесь нужен кастомный контент: иконка/заголовок/
 * сообщение/время на строку) — тот же click-outside/Escape паттерн, что и
 * в Dropdown.tsx.
 */
export function NotificationBell() {
  const [open, setOpen] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)

  const { data: unreadCount } = useUnreadNotificationsCount()
  const { data: items, isLoading, isError, refetch } = useNotifications({ limit: DROPDOWN_LIMIT })
  const markRead = useMarkNotificationRead()

  useEffect(() => {
    if (!open) return

    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setOpen(false)
      }
    }
    function handleEscape(event: KeyboardEvent) {
      if (event.key === 'Escape') setOpen(false)
    }

    document.addEventListener('mousedown', handleClickOutside)
    document.addEventListener('keydown', handleEscape)
    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
      document.removeEventListener('keydown', handleEscape)
    }
  }, [open])

  function handleOpenItem(item: NotificationItem) {
    if (!item.isRead) markRead.mutate(item.id)
    setOpen(false)
  }

  const badgeLabel = unreadCount && unreadCount > 0 ? (unreadCount > 99 ? '99+' : String(unreadCount)) : null

  return (
    <div ref={containerRef} className="relative">
      <button
        type="button"
        onClick={() => setOpen((value) => !value)}
        aria-label={badgeLabel ? `Уведомления, непрочитанных: ${badgeLabel}` : 'Уведомления'}
        aria-expanded={open}
        aria-haspopup="true"
        className={cn(
          'relative inline-flex size-11 shrink-0 items-center justify-center rounded-md text-muted-foreground transition-colors',
          'hover:bg-muted hover:text-foreground',
          'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background',
        )}
      >
        <Bell className="size-5" aria-hidden="true" />
        {badgeLabel && (
          <span
            className="absolute right-1.5 top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-danger px-1 text-[10px] font-semibold leading-none text-danger-foreground"
            aria-hidden="true"
          >
            {badgeLabel}
          </span>
        )}
      </button>

      {open && (
        <div
          role="menu"
          aria-label="Уведомления"
          className="absolute right-0 z-40 mt-2 w-[calc(100vw-2rem)] max-w-sm rounded-md border border-border bg-card p-2 shadow-elevated sm:w-96"
        >
          <p className="px-2 py-1.5 text-sm font-semibold text-foreground">Уведомления</p>

          {isLoading && (
            <div className="flex flex-col gap-2 p-2" role="status" aria-label="Загружаем уведомления…">
              {[0, 1, 2].map((i) => (
                <Skeleton key={i} className="h-14 w-full" />
              ))}
            </div>
          )}

          {isError && (
            <div className="flex flex-col items-center gap-2 px-2 py-6 text-center">
              <p className="text-sm text-muted-foreground">Не удалось загрузить уведомления</p>
              <button
                type="button"
                onClick={() => void refetch()}
                className="text-sm font-medium text-primary hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                Повторить
              </button>
            </div>
          )}

          {!isLoading && !isError && items && items.length === 0 && (
            <p className="px-2 py-6 text-center text-sm text-muted-foreground">Новых уведомлений пока нет</p>
          )}

          {!isLoading && !isError && items && items.length > 0 && (
            <ul className="flex max-h-[60vh] flex-col gap-0.5 overflow-y-auto">
              {items.map((item) => (
                <NotificationRow key={item.id} item={item} onOpen={handleOpenItem} compact />
              ))}
            </ul>
          )}

          <div className="mt-1 border-t border-border pt-1">
            <Link
              to="/app/notifications"
              onClick={() => setOpen(false)}
              className="block rounded-md px-2 py-2 text-center text-sm font-medium text-primary hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              Посмотреть все уведомления
            </Link>
          </div>
        </div>
      )}
    </div>
  )
}
