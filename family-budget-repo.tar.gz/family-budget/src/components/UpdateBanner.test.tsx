import { fireEvent, render, screen } from '@testing-library/react'
import { UpdateBanner } from './UpdateBanner'

const { mockUseRegisterSW, mockUpdateServiceWorker } = vi.hoisted(() => ({
  mockUseRegisterSW: vi.fn(),
  mockUpdateServiceWorker: vi.fn(),
}))

vi.mock('virtual:pwa-register/react', () => ({
  useRegisterSW: mockUseRegisterSW,
}))

describe('UpdateBanner (Этап 18, п.23-26)', () => {
  beforeEach(() => {
    mockUpdateServiceWorker.mockReset().mockResolvedValue(undefined)
  })

  it('ничего не показывает, пока новой версии не найдено', () => {
    mockUseRegisterSW.mockReturnValue({
      needRefresh: [false, vi.fn()],
      offlineReady: [false, vi.fn()],
      updateServiceWorker: mockUpdateServiceWorker,
    })

    render(<UpdateBanner />)

    expect(screen.queryByRole('status')).not.toBeInTheDocument()
  })

  it('показывает баннер "Доступна новая версия" с кнопкой "Обновить", когда needRefresh === true', () => {
    mockUseRegisterSW.mockReturnValue({
      needRefresh: [true, vi.fn()],
      offlineReady: [false, vi.fn()],
      updateServiceWorker: mockUpdateServiceWorker,
    })

    render(<UpdateBanner />)

    expect(screen.getByText(/доступна новая версия/i)).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Обновить' })).toBeInTheDocument()
  })

  it('вызывает updateServiceWorker только по клику — не автоматически', () => {
    mockUseRegisterSW.mockReturnValue({
      needRefresh: [true, vi.fn()],
      offlineReady: [false, vi.fn()],
      updateServiceWorker: mockUpdateServiceWorker,
    })

    render(<UpdateBanner />)

    expect(mockUpdateServiceWorker).not.toHaveBeenCalled()
    fireEvent.click(screen.getByRole('button', { name: 'Обновить' }))
    expect(mockUpdateServiceWorker).toHaveBeenCalledTimes(1)
  })

  it('регистрирует periodic-update проверку через onRegisteredSW, не форсируя reload', () => {
    let capturedOptions: { onRegisteredSW?: (url: string, reg: unknown) => void } = {}
    mockUseRegisterSW.mockImplementation((options) => {
      capturedOptions = options
      return {
        needRefresh: [false, vi.fn()],
        offlineReady: [false, vi.fn()],
        updateServiceWorker: mockUpdateServiceWorker,
      }
    })

    render(<UpdateBanner />)

    const fakeRegistration = { update: vi.fn() }
    const setIntervalSpy = vi.spyOn(window, 'setInterval')
    capturedOptions.onRegisteredSW?.('/sw.js', fakeRegistration)

    expect(setIntervalSpy).toHaveBeenCalledWith(expect.any(Function), 60 * 60 * 1000)
    setIntervalSpy.mockRestore()
  })
})
