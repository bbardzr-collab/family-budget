import { useEffect, useState } from 'react'
import { Download, Share } from 'lucide-react'
import { Button, Card, CardContent, Modal, SectionTitle } from '@/components/ui'
import { useIsStandalone } from '@/hooks/useIsStandalone'
import { isIOSDevice } from '@/utils/platform'

/** Нестандартное, но широко используемое Chromium-событие — типов у DOM lib для него нет. */
interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>
}

/**
 * Кнопка установки PWA (Этап 18, п.19-22).
 *
 * Три взаимоисключающих состояния:
 *  - приложение уже установлено (standalone, см. useIsStandalone) — компонент
 *    ничего не рендерит: повторно предлагать установку не нужно (п.22);
 *  - Chromium/Android с поддержкой `beforeinstallprompt` — кнопка запускает
 *    нативный prompt установки;
 *  - iOS/iPadOS Safari — `beforeinstallprompt` там не существует в принципе
 *    (п.21), поэтому кнопка вместо prompt открывает модалку с текстовой
 *    инструкцией "Поделиться → На экран Домой → Добавить".
 * На остальных платформах (десктопный Safari/Firefox без поддержки
 * установки) — компонент ничего не рендерит: событие не придёт и
 * isIOS === false, п.19 явно запрещает показывать кнопку там, где установка
 * не поддерживается.
 */
export function InstallPWAButton() {
  const isStandalone = useIsStandalone()
  const isIOS = isIOSDevice()
  const [installEvent, setInstallEvent] = useState<BeforeInstallPromptEvent | null>(null)
  const [iosModalOpen, setIosModalOpen] = useState(false)

  useEffect(() => {
    function handleBeforeInstallPrompt(event: Event) {
      event.preventDefault()
      setInstallEvent(event as BeforeInstallPromptEvent)
    }
    function handleAppInstalled() {
      setInstallEvent(null)
    }

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt)
    window.addEventListener('appinstalled', handleAppInstalled)

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt)
      window.removeEventListener('appinstalled', handleAppInstalled)
    }
  }, [])

  if (isStandalone) return null
  if (!installEvent && !isIOS) return null

  async function handleInstallClick() {
    if (isIOS) {
      setIosModalOpen(true)
      return
    }
    if (!installEvent) return

    await installEvent.prompt()
    // Результат (accepted/dismissed) намеренно не влияет на дальнейшую
    // логику по-разному — сам браузер обновит UI (appinstalled сработает
    // при accepted). Prompt одноразовый в любом случае — событие придёт
    // заново только при следующей загрузке страницы.
    await installEvent.userChoice
    setInstallEvent(null)
  }

  return (
    <Card>
      <CardContent className="flex flex-col gap-3 pt-6">
        <div className="flex items-center gap-2">
          <Download className="size-5 text-muted-foreground" aria-hidden="true" />
          <SectionTitle>Установка приложения</SectionTitle>
        </div>
        <p className="text-sm text-muted-foreground">
          Установите «Семейный бюджет» на устройство — быстрый доступ с домашнего экрана, без
          адресной строки браузера.
        </p>
        <Button
          type="button"
          variant="secondary"
          onClick={() => void handleInstallClick()}
          className="self-start"
        >
          <Download className="size-4" aria-hidden="true" />
          Установить приложение
        </Button>
      </CardContent>

      <Modal open={iosModalOpen} onClose={() => setIosModalOpen(false)} title="Установка на iPhone/iPad">
        <ol className="flex flex-col gap-4 text-sm text-foreground">
          <li className="flex items-center gap-3">
            <span className="flex size-7 shrink-0 items-center justify-center rounded-full bg-muted text-xs font-semibold">
              1
            </span>
            <span className="flex items-center gap-1.5">
              Нажмите «Поделиться» <Share className="size-4 shrink-0" aria-hidden="true" />
            </span>
          </li>
          <li className="flex items-center gap-3">
            <span className="flex size-7 shrink-0 items-center justify-center rounded-full bg-muted text-xs font-semibold">
              2
            </span>
            Выберите «На экран Домой»
          </li>
          <li className="flex items-center gap-3">
            <span className="flex size-7 shrink-0 items-center justify-center rounded-full bg-muted text-xs font-semibold">
              3
            </span>
            Нажмите «Добавить»
          </li>
        </ol>
      </Modal>
    </Card>
  )
}
