import { useEffect, useState } from 'react'
import { checkSupabaseConnection } from '@/lib/supabase'
import { Badge } from '@/components/ui'

type Status = 'checking' | 'connected' | 'error'

/**
 * ВРЕМЕННЫЙ dev-only индикатор подключения к Supabase (Этап 3, п.35).
 * Показывает только "Connected / Not connected" — никаких секретов, URL или
 * ключей на экран не выводится. Рендерится только в dev-сборке
 * (import.meta.env.DEV) — в production build отсутствует, см. использование
 * в SettingsPage.
 */
export function SupabaseStatus() {
  const [status, setStatus] = useState<Status>('checking')

  useEffect(() => {
    let cancelled = false
    checkSupabaseConnection()
      .then((ok) => {
        if (!cancelled) setStatus(ok ? 'connected' : 'error')
      })
      .catch(() => {
        if (!cancelled) setStatus('error')
      })
    return () => {
      cancelled = true
    }
  }, [])

  return (
    <div className="flex items-center gap-2 rounded-md border border-dashed border-border p-3 text-sm text-muted-foreground">
      <span>Supabase connection (dev-only):</span>
      {status === 'checking' && <Badge>Проверка…</Badge>}
      {status === 'connected' && <Badge variant="success">Connected</Badge>}
      {status === 'error' && <Badge variant="danger">Not connected</Badge>}
    </div>
  )
}
