import { act, fireEvent, render, screen, waitFor } from '@testing-library/react'
import { InstallPWAButton } from './InstallPWAButton'

const { mockUseIsStandalone, mockIsIOSDevice } = vi.hoisted(() => ({
  mockUseIsStandalone: vi.fn(),
  mockIsIOSDevice: vi.fn(),
}))

vi.mock('@/hooks/useIsStandalone', () => ({
  useIsStandalone: mockUseIsStandalone,
}))

vi.mock('@/utils/platform', () => ({
  isIOSDevice: mockIsIOSDevice,
}))

function dispatchBeforeInstallPrompt(overrides: Partial<{ prompt: () => Promise<void>; userChoice: Promise<unknown> }> = {}) {
  const event = new Event('beforeinstallprompt', { cancelable: true }) as Event & {
    prompt: () => Promise<void>
    userChoice: Promise<{ outcome: string; platform: string }>
  }
  event.prompt = overrides.prompt ?? vi.fn().mockResolvedValue(undefined)
  event.userChoice = (overrides.userChoice as Promise<{ outcome: string; platform: string }>) ??
    Promise.resolve({ outcome: 'accepted', platform: 'web' })
  window.dispatchEvent(event)
  return event
}

describe('InstallPWAButton (Этап 18, п.19-22)', () => {
  beforeEach(() => {
    mockUseIsStandalone.mockReset().mockReturnValue(false)
    mockIsIOSDevice.mockReset().mockReturnValue(false)
  })

  it('не рендерит ничего, если приложение уже установлено (standalone)', () => {
    mockUseIsStandalone.mockReturnValue(true)
    const { container } = render(<InstallPWAButton />)
    expect(container).toBeEmptyDOMElement()
  })

  it('не рендерит ничего на платформе без поддержки установки (не iOS, beforeinstallprompt не пришёл)', () => {
    const { container } = render(<InstallPWAButton />)
    expect(container).toBeEmptyDOMElement()
  })

  it('показывает кнопку после beforeinstallprompt и запускает нативный prompt по клику', async () => {
    render(<InstallPWAButton />)
    expect(screen.queryByRole('button', { name: /установить приложение/i })).not.toBeInTheDocument()

    const promptSpy = vi.fn().mockResolvedValue(undefined)
    act(() => {
      dispatchBeforeInstallPrompt({ prompt: promptSpy })
    })

    const button = await screen.findByRole('button', { name: /установить приложение/i })
    fireEvent.click(button)

    await waitFor(() => expect(promptSpy).toHaveBeenCalledTimes(1))
  })

  it('preventDefault() вызывается для beforeinstallprompt (не даём браузеру показать свой мини-баннер)', () => {
    render(<InstallPWAButton />)
    const event = new Event('beforeinstallprompt', { cancelable: true }) as Event & {
      prompt: () => Promise<void>
      userChoice: Promise<unknown>
    }
    event.prompt = vi.fn().mockResolvedValue(undefined)
    event.userChoice = Promise.resolve({ outcome: 'accepted', platform: 'web' })
    const preventDefaultSpy = vi.spyOn(event, 'preventDefault')

    act(() => {
      window.dispatchEvent(event)
    })

    expect(preventDefaultSpy).toHaveBeenCalled()
  })

  it('скрывает кнопку после события appinstalled', async () => {
    render(<InstallPWAButton />)
    act(() => {
      dispatchBeforeInstallPrompt()
    })
    await screen.findByRole('button', { name: /установить приложение/i })

    act(() => {
      window.dispatchEvent(new Event('appinstalled'))
    })

    expect(screen.queryByRole('button', { name: /установить приложение/i })).not.toBeInTheDocument()
  })

  it('на iOS показывает кнопку сразу (без beforeinstallprompt) и по клику открывает инструкцию, а не нативный prompt', async () => {
    mockIsIOSDevice.mockReturnValue(true)
    render(<InstallPWAButton />)

    const button = await screen.findByRole('button', { name: /установить приложение/i })
    fireEvent.click(button)

    expect(await screen.findByRole('dialog', { name: /установка на iphone\/ipad/i })).toBeInTheDocument()
    expect(screen.getByText(/поделиться/i)).toBeInTheDocument()
    expect(screen.getByText(/на экран домой/i)).toBeInTheDocument()
    expect(screen.getByText(/добавить/i)).toBeInTheDocument()
  })
})
