import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { AppErrorBoundary } from './AppErrorBoundary'

function Bomb(): never {
  throw new Error('boom')
}

describe('AppErrorBoundary (Этап 20, п.46-47 — не должно быть белого экрана)', () => {
  // React логирует ошибку в консоль само по себе при перехвате error boundary —
  // подавляем шум в выводе теста, не сам факт логирования (мы отдельно
  // проверяем, что console.error реально вызывается, см. ниже).
  let consoleErrorSpy: ReturnType<typeof vi.spyOn>

  beforeEach(() => {
    consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {})
  })

  afterEach(() => {
    consoleErrorSpy.mockRestore()
  })

  it('рендерит children как есть, когда ошибки нет', () => {
    render(
      <AppErrorBoundary>
        <p>Обычный контент</p>
      </AppErrorBoundary>,
    )
    expect(screen.getByText('Обычный контент')).toBeInTheDocument()
  })

  it('перехватывает ошибку рендера дочернего компонента и показывает понятный fallback вместо белого экрана', () => {
    render(
      <AppErrorBoundary>
        <Bomb />
      </AppErrorBoundary>,
    )

    expect(screen.getByText('Что-то пошло не так')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Обновить страницу' })).toBeInTheDocument()
    // Технические детали (сообщение исключения/stack) не должны попасть в DOM.
    expect(screen.queryByText(/boom/i)).not.toBeInTheDocument()
  })

  it('логирует ошибку в консоль, а не молчит', () => {
    render(
      <AppErrorBoundary>
        <Bomb />
      </AppErrorBoundary>,
    )
    expect(consoleErrorSpy).toHaveBeenCalled()
  })

  it('кнопка "Обновить страницу" вызывает перезагрузку', async () => {
    const reloadSpy = vi.fn()
    const originalLocation = window.location
    Object.defineProperty(window, 'location', {
      configurable: true,
      value: { ...originalLocation, reload: reloadSpy },
    })

    const user = userEvent.setup()
    render(
      <AppErrorBoundary>
        <Bomb />
      </AppErrorBoundary>,
    )
    await user.click(screen.getByRole('button', { name: 'Обновить страницу' }))

    expect(reloadSpy).toHaveBeenCalledTimes(1)

    Object.defineProperty(window, 'location', { configurable: true, value: originalLocation })
  })
})
