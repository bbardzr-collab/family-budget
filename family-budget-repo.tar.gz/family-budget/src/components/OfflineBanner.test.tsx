import { act, render, screen } from '@testing-library/react'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { OfflineBanner } from './OfflineBanner'

const { mockUseOnlineStatus } = vi.hoisted(() => ({
  mockUseOnlineStatus: vi.fn(),
}))

vi.mock('@/hooks/useOnlineStatus', () => ({
  useOnlineStatus: mockUseOnlineStatus,
}))

function renderBanner(queryClient: QueryClient) {
  return render(
    <QueryClientProvider client={queryClient}>
      <OfflineBanner />
    </QueryClientProvider>,
  )
}

describe('OfflineBanner (Этап 18, п.14-16)', () => {
  let queryClient: QueryClient

  beforeEach(() => {
    queryClient = new QueryClient()
    vi.useFakeTimers()
  })

  afterEach(() => {
    vi.useRealTimers()
  })

  it('ничего не показывает, пока соединение есть и не терялось', () => {
    mockUseOnlineStatus.mockReturnValue(true)
    renderBanner(queryClient)

    expect(screen.queryByRole('status')).not.toBeInTheDocument()
  })

  it('показывает постоянный баннер "Нет подключения" без технических деталей, пока офлайн', () => {
    mockUseOnlineStatus.mockReturnValue(false)
    renderBanner(queryClient)

    const banner = screen.getByRole('status')
    expect(banner).toHaveTextContent('Нет подключения к интернету')
    expect(banner).not.toHaveTextContent(/failed to fetch/i)
    expect(banner).not.toHaveTextContent(/err_network/i)
  })

  it('при восстановлении связи показывает "Соединение восстановлено" и точечно инвалидирует 5 доменов из ТЗ, затем скрывается', () => {
    mockUseOnlineStatus.mockReturnValue(false)
    const { rerender } = renderBanner(queryClient)
    expect(screen.getByText(/нет подключения/i)).toBeInTheDocument()

    const invalidateSpy = vi.spyOn(queryClient, 'invalidateQueries')
    mockUseOnlineStatus.mockReturnValue(true)
    rerender(
      <QueryClientProvider client={queryClient}>
        <OfflineBanner />
      </QueryClientProvider>,
    )

    expect(screen.getByText('Соединение восстановлено')).toBeInTheDocument()

    const invalidatedRoots = invalidateSpy.mock.calls.map(([arg]) => (arg as { queryKey: unknown[] }).queryKey[0])
    expect(invalidatedRoots).toEqual(
      expect.arrayContaining(['dashboard', 'transactions', 'budgets', 'goals', 'notifications']),
    )
    // Ровно эти пять доменов — не "инвалидировать вообще всё" (п.16 запрещает
    // бесконтрольный refetch всего приложения).
    expect(invalidateSpy).toHaveBeenCalledTimes(5)

    act(() => {
      vi.advanceTimersByTime(4000)
    })
    expect(screen.queryByRole('status')).not.toBeInTheDocument()
  })

  it('не показывает "восстановлено" при первом монтировании уже онлайн (не было разрыва)', () => {
    mockUseOnlineStatus.mockReturnValue(true)
    renderBanner(queryClient)

    expect(screen.queryByText('Соединение восстановлено')).not.toBeInTheDocument()
  })
})
