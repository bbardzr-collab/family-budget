import type { LucideIcon } from 'lucide-react'
import { Badge, Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui'

export interface StagePlaceholderProps {
  icon: LucideIcon
  title: string
  description: string
  stage: string
}

/**
 * Временная страница-заглушка для раздела, который будет реализован
 * на одном из следующих этапов. Показывает, что роутинг, layout и
 * навигация для этого раздела уже работают.
 */
export function StagePlaceholder({ icon: Icon, title, description, stage }: StagePlaceholderProps) {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-start gap-3">
          <div className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-primary-soft text-primary">
            <Icon className="size-5" aria-hidden="true" />
          </div>
          <div>
            <CardTitle>{title}</CardTitle>
            <CardDescription>{description}</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Badge>Появится на: {stage}</Badge>
      </CardContent>
    </Card>
  )
}
