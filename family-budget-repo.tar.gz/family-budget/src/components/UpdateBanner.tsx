import { RefreshCw } from 'lucide-react'
import { useRegisterSW } from 'virtual:pwa-register/react'
import { Button } from '@/components/ui'

/** Раз в час — открытая вкладка может жить долго, не полагаемся только на переоткрытие (п.26). */
const UPDATE_CHECK_INTERVAL_MS = 60 * 60 * 1000

/**
 * Баннер "доступна новая версия" (Этап 18, п.23-26).
 *
 * `registerType: 'prompt'` в vite.config.ts (изменено с исходного
 * 'autoUpdate') — намеренно и является той самой "эквивалентной безопасной
 * схемой", которую явно допускает ТЗ п.9: при 'autoUpdate' сам Service
 * Worker вызывает self.skipWaiting()/clientsClaim() сразу после установки,
 * без стадии ожидания — новый SW получает контроль без какого-либо
 * действия пользователя, что противоречит п.24 ("пользователь должен сам
 * нажать Обновить", "не делать принудительный reload"). 'prompt' —
 * официально документированная схема vite-plugin-pwa именно для ручного
 * подтверждения обновления через `updateServiceWorker()`.
 *
 * updateServiceWorker() вызывается ТОЛЬКО по клику на кнопку — никогда
 * автоматически, поэтому ввод в форме (расход/доход/цель/бюджет и т.п.)
 * никогда не будет прерван неожиданной перезагрузкой (п.24).
 */
export function UpdateBanner() {
  const {
    needRefresh: [needRefresh],
    updateServiceWorker,
  } = useRegisterSW({
    onRegisteredSW(_swUrl, registration) {
      if (!registration) return
      setInterval(() => {
        void registration.update()
      }, UPDATE_CHECK_INTERVAL_MS)
    },
    onRegisterError(error) {
      console.error('Не удалось зарегистрировать Service Worker:', error)
    },
  })

  if (!needRefresh) return null

  return (
    <div
      role="status"
      aria-live="polite"
      // Текст — text-foreground, не text-primary (см. тот же разбор
      // контраста в OfflineBanner.tsx) — семантический цвет несёт только
      // иконка, как в Toast.tsx.
      className="flex flex-wrap items-center justify-center gap-3 bg-primary-soft px-4 py-2 text-center text-sm text-foreground"
    >
      <RefreshCw className="size-4 shrink-0 text-primary" aria-hidden="true" />
      <span>
        <span className="font-medium">Доступна новая версия.</span> Обновите приложение, чтобы получить
        последние изменения.
      </span>
      <Button size="sm" variant="primary" onClick={() => void updateServiceWorker(true)}>
        Обновить
      </Button>
    </div>
  )
}
