import { Component, type ErrorInfo, type ReactNode } from 'react'
import { Button, ErrorState } from '@/components/ui'

interface AppErrorBoundaryProps {
  children: ReactNode
}

interface AppErrorBoundaryState {
  hasError: boolean
}

/**
 * Последний рубеж на случай непойманного исключения при рендере (Этап 20,
 * п.46-47 — "не должно быть белого экрана"). До этого этапа в приложении не
 * было НИ ОДНОГО React error boundary — падение любого компонента при
 * рендере (не только сетевая/Supabase-ошибка, которые уже обрабатываются
 * через errors.ts/toast в каждой фиче) полностью размонтировало дерево React
 * и оставляло белый экран без какого-либо пути восстановления.
 *
 * Переиспользует уже существующий ErrorState (тот же компонент, что и
 * сетевые ошибки в каждой фиче) — без технических деталей/stack trace в UI
 * (ТЗ, п.46), кнопка ведёт на обычную перезагрузку страницы, а не пытается
 * "самовосстановить" сломанное дерево компонентов (после реального краша
 * рендера это ненадёжно).
 */
export class AppErrorBoundary extends Component<AppErrorBoundaryProps, AppErrorBoundaryState> {
  state: AppErrorBoundaryState = { hasError: false }

  static getDerivedStateFromError(): AppErrorBoundaryState {
    return { hasError: true }
  }

  componentDidCatch(error: unknown, errorInfo: ErrorInfo): void {
    // Только консоль — не в DOM (ТЗ, п.46: "не показывать пользователю raw
    // stack trace, если это не dev mode").
    console.error('Необработанная ошибка рендера:', error, errorInfo)
  }

  render(): ReactNode {
    if (this.state.hasError) {
      return (
        <div className="flex min-h-screen items-center justify-center px-4">
          <ErrorState
            title="Что-то пошло не так"
            description="Приложение столкнулось с непредвиденной ошибкой. Обновите страницу — обычно это помогает."
            action={
              <Button size="sm" onClick={() => window.location.reload()}>
                Обновить страницу
              </Button>
            }
          />
        </div>
      )
    }

    return this.props.children
  }
}
