import { useEffect, useState } from 'react'
import { Wifi, WifiOff } from 'lucide-react'
import { useQueryClient } from '@tanstack/react-query'
import { useOnlineStatus } from '@/hooks/useOnlineStatus'
import { dashboardKeys } from '@/features/dashboard/queryKeys'
import { transactionsKeys } from '@/features/transactions/queryKeys'
import { budgetsKeys } from '@/features/budgets/queryKeys'
import { goalsKeys } from '@/features/goals/queryKeys'
import { notificationsKeys } from '@/features/notifications/queryKeys'
import { cn } from '@/utils/cn'

const RECONNECTED_VISIBLE_MS = 4000

type BannerStatus = 'hidden' | 'offline' | 'reconnected'

/**
 * Индикатор состояния сети (Этап 18, п.14-16).
 *
 * Смонтирован один раз в App.tsx, а не внутри AppLayout — соединение может
 * пропасть и на экране входа/лендинга, не только внутри /app, поэтому
 * баннер должен быть виден на всех маршрутах.
 *
 * Пока офлайн — показывает постоянный баннер (текст — ровно тот, что
 * требует ТЗ п.13, чтобы вместо технической ошибки вроде "Failed to fetch"
 * пользователь видел понятное объяснение). При восстановлении связи —
 * короткое "Соединение восстановлено" на несколько секунд и точечная
 * инвалидация ровно тех пяти доменов, что перечислены в ТЗ п.16
 * (dashboard/transactions/budgets/goals/notifications) через уже
 * существующие ключи React Query каждого домена — НЕ
 * queryClient.invalidateQueries() без фильтра (п.16 прямо запрещает
 * "бесконтрольный refetch всего приложения").
 *
 * Офлайн-очередь операций (создание расходов/доходов без сети) сознательно
 * не реализована — вне рамок Этапа 18 (см. ТЗ п.17).
 */
export function OfflineBanner() {
  const isOnline = useOnlineStatus()
  const [prevIsOnline, setPrevIsOnline] = useState(isOnline)
  const [status, setStatus] = useState<BannerStatus>(isOnline ? 'hidden' : 'offline')
  const queryClient = useQueryClient()

  // Реакция на изменение isOnline — не Effect, а "adjusting state during
  // rendering" (официально рекомендованный React-паттерн для случая "проп
  // изменился — синхронно подстроить состояние", см.
  // https://react.dev/learn/you-might-not-need-an-effect#adjusting-some-state-when-a-prop-changes).
  // Здесь нет никакого внешнего события, кроме самого изменения isOnline —
  // делать это Effect'ом означало бы лишний, ничем не оправданный
  // промежуточный рендер с устаревшим status. Побочные эффекты, которые
  // ДЕЙСТВИТЕЛЬНО должны быть в Effect (точечная инвалидация запросов и
  // таймер авто-скрытия) — ниже, отдельно, реагируют на сам status.
  if (isOnline !== prevIsOnline) {
    setPrevIsOnline(isOnline)
    setStatus(isOnline ? 'reconnected' : 'offline')
  }

  useEffect(() => {
    if (status !== 'reconnected') return

    void queryClient.invalidateQueries({ queryKey: dashboardKeys.all })
    void queryClient.invalidateQueries({ queryKey: transactionsKeys.all })
    void queryClient.invalidateQueries({ queryKey: budgetsKeys.all })
    void queryClient.invalidateQueries({ queryKey: goalsKeys.all })
    void queryClient.invalidateQueries({ queryKey: notificationsKeys.all })

    const timeout = setTimeout(() => {
      setStatus('hidden')
    }, RECONNECTED_VISIBLE_MS)

    return () => clearTimeout(timeout)
  }, [status, queryClient])

  if (status === 'hidden') return null

  const isOffline = status === 'offline'

  return (
    <div
      role="status"
      aria-live="polite"
      className={cn(
        // Текст — text-foreground (обычный, тёмный), а не тонированный
        // text-warning/text-success: у text-warning/text-success на своём
        // -soft фоне контраст ~2.5:1/~3.1:1 — ниже WCAG AA (4.5:1) для
        // обычного текста (та же характеристика есть у Badge/чипов в
        // остальном приложении, где это лейбл рядом с суммой, а не блок для
        // чтения). Семантический цвет здесь несёт только иконка — ровно тот
        // же приём, что уже использует Toast.tsx (иконка цветная, текст —
        // foreground/muted-foreground), поэтому это не новый визуальный
        // стиль, а переиспользование существующего паттерна (Этап 18, п.32).
        'flex items-center justify-center gap-2 px-4 py-2 text-center text-sm font-medium text-foreground',
        isOffline ? 'bg-warning-soft' : 'bg-success-soft',
      )}
    >
      {isOffline ? (
        <>
          <WifiOff className="size-4 shrink-0 text-warning" aria-hidden="true" />
          <span>
            Нет подключения к интернету. Некоторые данные могут быть временно недоступны. После
            восстановления соединения попробуйте ещё раз.
          </span>
        </>
      ) : (
        <>
          <Wifi className="size-4 shrink-0 text-success" aria-hidden="true" />
          <span>Соединение восстановлено</span>
        </>
      )}
    </div>
  )
}
