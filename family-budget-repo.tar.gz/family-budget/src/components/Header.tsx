import { Link, useLocation } from 'react-router-dom'
import { Avatar } from '@/components/ui'
import { NotificationBell } from '@/components/NotificationBell'
import { getPageTitle } from '@/app/navigation'
import { useAuth } from '@/features/auth/AuthContext'

/**
 * Верхняя шапка авторизованной части приложения: заголовок текущей
 * страницы слева, уведомления и аватар пользователя справа.
 * Данные пользователя — реальные, из AuthContext (Этап 4).
 */
export function Header() {
  const location = useLocation()
  const title = getPageTitle(location.pathname)
  const { profile, user } = useAuth()
  const displayName =
    profile?.full_name ?? (user?.user_metadata?.full_name as string | undefined) ?? user?.email ?? 'Пользователь'

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-border bg-card/80 px-4 backdrop-blur sm:px-6">
      <h1 className="text-lg font-semibold text-foreground">{title}</h1>

      <div className="flex items-center gap-1.5">
        <NotificationBell />
        <Link to="/app/settings" aria-label={`Профиль: ${displayName}`}>
          <Avatar name={displayName} size="sm" />
        </Link>
      </div>
    </header>
  )
}
