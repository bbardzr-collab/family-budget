import { NavLink } from 'react-router-dom'
import { NAV_ITEMS } from '@/app/navigation'
import { cn } from '@/utils/cn'

/**
 * Нижняя навигация для мобильных устройств.
 * Пять разделов, крупные зоны нажатия — удобно для большого пальца (ТЗ, п.28).
 * Скрыта на desktop (см. Sidebar).
 */
export function BottomNav() {
  return (
    <nav
      aria-label="Основная навигация"
      className="fixed inset-x-0 bottom-0 z-40 flex border-t border-border bg-card pb-[env(safe-area-inset-bottom)] md:hidden"
    >
      {NAV_ITEMS.map((item) => (
        <NavLink
          key={item.to}
          to={item.to}
          end={item.end}
          className={({ isActive }) =>
            cn(
              'flex min-h-14 flex-1 flex-col items-center justify-center gap-0.5 py-2 text-xs font-medium',
              isActive ? 'text-primary' : 'text-muted-foreground',
            )
          }
        >
          <item.icon className="size-5" aria-hidden="true" />
          {item.label}
        </NavLink>
      ))}
    </nav>
  )
}
