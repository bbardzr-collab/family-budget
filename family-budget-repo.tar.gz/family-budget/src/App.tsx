import { AppRoutes } from '@/app/routes'
import { OfflineBanner } from '@/components/OfflineBanner'
import { UpdateBanner } from '@/components/UpdateBanner'
import { AppErrorBoundary } from '@/components/AppErrorBoundary'

/**
 * OfflineBanner/UpdateBanner смонтированы здесь, а не внутри AppLayout —
 * они должны быть видны на ЛЮБОМ маршруте (лендинг, /login, /app/...), а не
 * только в авторизованной части (Этап 18, п.15).
 *
 * AppErrorBoundary оборачивает только AppRoutes, не баннеры — сбой рендера
 * внутри самих баннеров не должен закрывать собой всё приложение сильнее,
 * чем сбой в самих страницах, но баннеры продолжают быть видны даже на
 * экране ошибки (тот же принцип, что и у их размещения выше — Этап 20,
 * п.46-47: единый последний рубеж на случай непойманного исключения рендера).
 */
function App() {
  return (
    <>
      <OfflineBanner />
      <UpdateBanner />
      <AppErrorBoundary>
        <AppRoutes />
      </AppErrorBoundary>
    </>
  )
}

export default App
