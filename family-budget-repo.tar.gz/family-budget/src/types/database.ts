export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: '14.5'
  }
  public: {
    Tables: {
      budget_categories: {
        Row: {
          budget_id: string
          category_id: string
          created_at: string
          id: string
          limit_amount: number
        }
        Insert: {
          budget_id: string
          category_id: string
          created_at?: string
          id?: string
          limit_amount: number
        }
        Update: {
          budget_id?: string
          category_id?: string
          created_at?: string
          id?: string
          limit_amount?: number
        }
        Relationships: [
          {
            foreignKeyName: 'budget_categories_budget_id_fkey'
            columns: ['budget_id']
            isOneToOne: false
            referencedRelation: 'budgets'
            referencedColumns: ['id']
          },
          {
            foreignKeyName: 'budget_categories_category_id_fkey'
            columns: ['category_id']
            isOneToOne: false
            referencedRelation: 'categories'
            referencedColumns: ['id']
          },
        ]
      }
      budgets: {
        Row: {
          created_at: string
          family_id: string
          id: string
          period_month: string
          total_amount: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          family_id: string
          id?: string
          period_month: string
          total_amount: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          family_id?: string
          id?: string
          period_month?: string
          total_amount?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: 'budgets_family_id_fkey'
            columns: ['family_id']
            isOneToOne: false
            referencedRelation: 'families'
            referencedColumns: ['id']
          },
        ]
      }
      calendar_connections: {
        Row: {
          access_token: string | null
          created_at: string
          family_id: string
          id: string
          provider: string
          refresh_token: string | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          access_token?: string | null
          created_at?: string
          family_id: string
          id?: string
          provider: string
          refresh_token?: string | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          access_token?: string | null
          created_at?: string
          family_id?: string
          id?: string
          provider?: string
          refresh_token?: string | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: 'calendar_connections_family_id_fkey'
            columns: ['family_id']
            isOneToOne: false
            referencedRelation: 'families'
            referencedColumns: ['id']
          },
          {
            foreignKeyName: 'calendar_connections_user_id_fkey'
            columns: ['user_id']
            isOneToOne: false
            referencedRelation: 'users'
            referencedColumns: ['id']
          },
        ]
      }
      categories: {
        Row: {
          created_at: string
          family_id: string
          icon: string | null
          id: string
          is_active: boolean
          is_custom: boolean
          name: string
          type: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          family_id: string
          icon?: string | null
          id?: string
          is_active?: boolean
          is_custom?: boolean
          name: string
          type: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          family_id?: string
          icon?: string | null
          id?: string
          is_active?: boolean
          is_custom?: boolean
          name?: string
          type?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: 'categories_family_id_fkey'
            columns: ['family_id']
            isOneToOne: false
            referencedRelation: 'families'
            referencedColumns: ['id']
          },
        ]
      }
      families: {
        Row: {
          created_at: string
          created_by: string
          id: string
          name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by: string
          id?: string
          name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string
          id?: string
          name?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: 'families_created_by_fkey'
            columns: ['created_by']
            isOneToOne: false
            referencedRelation: 'users'
            referencedColumns: ['id']
          },
        ]
      }
      family_invitations: {
        Row: {
          created_at: string
          expires_at: string
          family_id: string
          id: string
          invited_by: string
          role: string
          status: string
          token: string
        }
        Insert: {
          created_at?: string
          expires_at: string
          family_id: string
          id?: string
          invited_by: string
          role: string
          status?: string
          token: string
        }
        Update: {
          created_at?: string
          expires_at?: string
          family_id?: string
          id?: string
          invited_by?: string
          role?: string
          status?: string
          token?: string
        }
        Relationships: [
          {
            foreignKeyName: 'family_invitations_family_id_fkey'
            columns: ['family_id']
            isOneToOne: false
            referencedRelation: 'families'
            referencedColumns: ['id']
          },
          {
            foreignKeyName: 'family_invitations_invited_by_fkey'
            columns: ['invited_by']
            isOneToOne: false
            referencedRelation: 'users'
            referencedColumns: ['id']
          },
        ]
      }
      family_members: {
        Row: {
          created_at: string
          family_id: string
          id: string
          joined_at: string
          role: string
          status: string
          user_id: string
        }
        Insert: {
          created_at?: string
          family_id: string
          id?: string
          joined_at?: string
          role: string
          status?: string
          user_id: string
        }
        Update: {
          created_at?: string
          family_id?: string
          id?: string
          joined_at?: string
          role?: string
          status?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: 'family_members_family_id_fkey'
            columns: ['family_id']
            isOneToOne: false
            referencedRelation: 'families'
            referencedColumns: ['id']
          },
          {
            foreignKeyName: 'family_members_user_id_fkey'
            columns: ['user_id']
            isOneToOne: false
            referencedRelation: 'users'
            referencedColumns: ['id']
          },
        ]
      }
      family_settings: {
        Row: {
          child_visibility: Json
          currency: string
          family_id: string
        }
        Insert: {
          child_visibility?: Json
          currency?: string
          family_id: string
        }
        Update: {
          child_visibility?: Json
          currency?: string
          family_id?: string
        }
        Relationships: [
          {
            foreignKeyName: 'family_settings_family_id_fkey'
            columns: ['family_id']
            isOneToOne: true
            referencedRelation: 'families'
            referencedColumns: ['id']
          },
        ]
      }
      goal_contributions: {
        Row: {
          amount: number
          comment: string | null
          contributed_at: string
          goal_id: string
          id: string
          user_id: string
        }
        Insert: {
          amount: number
          comment?: string | null
          contributed_at?: string
          goal_id: string
          id?: string
          user_id: string
        }
        Update: {
          amount?: number
          comment?: string | null
          contributed_at?: string
          goal_id?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: 'goal_contributions_goal_id_fkey'
            columns: ['goal_id']
            isOneToOne: false
            referencedRelation: 'goals'
            referencedColumns: ['id']
          },
          {
            foreignKeyName: 'goal_contributions_user_id_fkey'
            columns: ['user_id']
            isOneToOne: false
            referencedRelation: 'users'
            referencedColumns: ['id']
          },
        ]
      }
      goals: {
        Row: {
          created_at: string
          family_id: string
          goal_type: string
          icon: string | null
          id: string
          owner_user_id: string | null
          status: string
          target_amount: number
          target_date: string | null
          title: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          family_id: string
          goal_type: string
          icon?: string | null
          id?: string
          owner_user_id?: string | null
          status?: string
          target_amount: number
          target_date?: string | null
          title: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          family_id?: string
          goal_type?: string
          icon?: string | null
          id?: string
          owner_user_id?: string | null
          status?: string
          target_amount?: number
          target_date?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: 'goals_family_id_fkey'
            columns: ['family_id']
            isOneToOne: false
            referencedRelation: 'families'
            referencedColumns: ['id']
          },
          {
            foreignKeyName: 'goals_owner_user_id_fkey'
            columns: ['owner_user_id']
            isOneToOne: false
            referencedRelation: 'users'
            referencedColumns: ['id']
          },
        ]
      }
      notifications: {
        Row: {
          channel: string
          created_at: string
          event_key: string | null
          family_id: string
          id: string
          is_read: boolean
          message: string
          payload: Json | null
          title: string
          type: string
          user_id: string
        }
        Insert: {
          channel?: string
          created_at?: string
          event_key?: string | null
          family_id: string
          id?: string
          is_read?: boolean
          message: string
          payload?: Json | null
          title: string
          type: string
          user_id: string
        }
        Update: {
          channel?: string
          created_at?: string
          event_key?: string | null
          family_id?: string
          id?: string
          is_read?: boolean
          message?: string
          payload?: Json | null
          title?: string
          type?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: 'notifications_family_id_fkey'
            columns: ['family_id']
            isOneToOne: false
            referencedRelation: 'families'
            referencedColumns: ['id']
          },
          {
            foreignKeyName: 'notifications_user_id_fkey'
            columns: ['user_id']
            isOneToOne: false
            referencedRelation: 'users'
            referencedColumns: ['id']
          },
        ]
      }
      planned_expenses: {
        Row: {
          amount: number
          category_id: string | null
          created_at: string
          family_id: string
          id: string
          planned_date: string
          recurring_transaction_id: string | null
          status: string
          title: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          amount: number
          category_id?: string | null
          created_at?: string
          family_id: string
          id?: string
          planned_date: string
          recurring_transaction_id?: string | null
          status?: string
          title: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          amount?: number
          category_id?: string | null
          created_at?: string
          family_id?: string
          id?: string
          planned_date?: string
          recurring_transaction_id?: string | null
          status?: string
          title?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: 'planned_expenses_category_id_fkey'
            columns: ['category_id']
            isOneToOne: false
            referencedRelation: 'categories'
            referencedColumns: ['id']
          },
          {
            foreignKeyName: 'planned_expenses_family_id_fkey'
            columns: ['family_id']
            isOneToOne: false
            referencedRelation: 'families'
            referencedColumns: ['id']
          },
          {
            foreignKeyName: 'planned_expenses_recurring_transaction_id_fkey'
            columns: ['recurring_transaction_id']
            isOneToOne: false
            referencedRelation: 'recurring_transactions'
            referencedColumns: ['id']
          },
          {
            foreignKeyName: 'planned_expenses_user_id_fkey'
            columns: ['user_id']
            isOneToOne: false
            referencedRelation: 'users'
            referencedColumns: ['id']
          },
        ]
      }
      recurring_transactions: {
        Row: {
          amount: number
          category_id: string | null
          created_at: string
          end_date: string | null
          family_id: string
          frequency: string
          id: string
          income_source: string | null
          interval_config: Json | null
          is_active: boolean
          next_run_date: string
          start_date: string
          type: string
          updated_at: string
          user_id: string
        }
        Insert: {
          amount: number
          category_id?: string | null
          created_at?: string
          end_date?: string | null
          family_id: string
          frequency: string
          id?: string
          income_source?: string | null
          interval_config?: Json | null
          is_active?: boolean
          next_run_date: string
          start_date: string
          type: string
          updated_at?: string
          user_id: string
        }
        Update: {
          amount?: number
          category_id?: string | null
          created_at?: string
          end_date?: string | null
          family_id?: string
          frequency?: string
          id?: string
          income_source?: string | null
          interval_config?: Json | null
          is_active?: boolean
          next_run_date?: string
          start_date?: string
          type?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: 'recurring_transactions_category_id_fkey'
            columns: ['category_id']
            isOneToOne: false
            referencedRelation: 'categories'
            referencedColumns: ['id']
          },
          {
            foreignKeyName: 'recurring_transactions_family_id_fkey'
            columns: ['family_id']
            isOneToOne: false
            referencedRelation: 'families'
            referencedColumns: ['id']
          },
          {
            foreignKeyName: 'recurring_transactions_user_id_fkey'
            columns: ['user_id']
            isOneToOne: false
            referencedRelation: 'users'
            referencedColumns: ['id']
          },
        ]
      }
      transactions: {
        Row: {
          amount: number
          category_id: string | null
          comment: string | null
          created_at: string
          family_id: string
          id: string
          income_source: string | null
          transaction_date: string
          type: string
          updated_at: string
          user_id: string
        }
        Insert: {
          amount: number
          category_id?: string | null
          comment?: string | null
          created_at?: string
          family_id: string
          id?: string
          income_source?: string | null
          transaction_date: string
          type: string
          updated_at?: string
          user_id: string
        }
        Update: {
          amount?: number
          category_id?: string | null
          comment?: string | null
          created_at?: string
          family_id?: string
          id?: string
          income_source?: string | null
          transaction_date?: string
          type?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: 'transactions_category_id_fkey'
            columns: ['category_id']
            isOneToOne: false
            referencedRelation: 'categories'
            referencedColumns: ['id']
          },
          {
            foreignKeyName: 'transactions_family_id_fkey'
            columns: ['family_id']
            isOneToOne: false
            referencedRelation: 'families'
            referencedColumns: ['id']
          },
          {
            foreignKeyName: 'transactions_user_id_fkey'
            columns: ['user_id']
            isOneToOne: false
            referencedRelation: 'users'
            referencedColumns: ['id']
          },
        ]
      }
      user_settings: {
        Row: {
          locale: string
          notification_prefs: Json
          theme: string
          updated_at: string
          user_id: string
        }
        Insert: {
          locale?: string
          notification_prefs?: Json
          theme?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          locale?: string
          notification_prefs?: Json
          theme?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: 'user_settings_user_id_fkey'
            columns: ['user_id']
            isOneToOne: true
            referencedRelation: 'users'
            referencedColumns: ['id']
          },
        ]
      }
      users: {
        Row: {
          avatar_url: string | null
          created_at: string
          full_name: string
          id: string
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          full_name: string
          id: string
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          full_name?: string
          id?: string
          updated_at?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      accept_family_invitation: { Args: { p_token: string }; Returns: string }
      add_goal_contribution: {
        Args: {
          p_amount: number
          p_comment: string
          p_contributed_at: string
          p_goal_id: string
        }
        Returns: Json
      }
      calculate_recurring_next_run_date: {
        Args: {
          p_current: string
          p_frequency: string
          p_interval_config: Json
        }
        Returns: string
      }
      cancel_family_invitation: {
        Args: { p_invitation_id: string }
        Returns: undefined
      }
      check_budget_notifications: {
        Args: { p_family_id: string; p_period_start: string }
        Returns: undefined
      }
      create_family: { Args: { p_name: string }; Returns: string }
      create_family_invitation: {
        Args: { p_role: string }
        Returns: {
          created_at: string
          expires_at: string
          id: string
          role: string
          token: string
        }[]
      }
      create_goal: {
        Args: {
          p_goal_type: string
          p_icon: string
          p_owner_user_id: string
          p_target_amount: number
          p_target_date: string
          p_title: string
        }
        Returns: string
      }
      create_notification: {
        Args: {
          p_event_key?: string
          p_family_id: string
          p_message: string
          p_payload?: Json
          p_title: string
          p_type: string
          p_user_id: string
        }
        Returns: string
      }
      delete_notification: {
        Args: { p_notification_id: string }
        Returns: undefined
      }
      family_invitation_ttl: { Args: never; Returns: string }
      generate_due_planned_expenses: { Args: never; Returns: Json }
      get_analytics_categories: {
        Args: { p_date_from: string; p_date_to: string }
        Returns: Json
      }
      get_analytics_income_sources: {
        Args: { p_date_from: string; p_date_to: string }
        Returns: Json
      }
      get_analytics_summary: {
        Args: { p_date_from: string; p_date_to: string }
        Returns: {
          balance: number
          expenses: number
          income: number
          transaction_count: number
        }[]
      }
      get_analytics_timeseries: {
        Args: { p_date_from: string; p_date_to: string }
        Returns: Json
      }
      get_dashboard_summary: {
        Args: { p_period_end: string; p_period_start: string }
        Returns: {
          balance: number
          expenses: number
          income: number
          period_end: string
          period_start: string
        }[]
      }
      get_family_role: { Args: { p_family_id: string }; Returns: string }
      get_goal_summary: { Args: { p_goal_id: string }; Returns: Json }
      get_goals_list: { Args: never; Returns: Json }
      get_invitation_by_token: {
        Args: { p_token: string }
        Returns: {
          expires_at: string
          family_name: string
          is_valid: boolean
          role: string
          status: string
        }[]
      }
      get_monthly_budget_summary: {
        Args: { p_period_month: string }
        Returns: Json
      }
      get_transactions_page: {
        Args: {
          p_category_id?: string
          p_category_mode?: string
          p_date_from?: string
          p_date_to?: string
          p_limit?: number
          p_offset?: number
          p_search?: string
          p_sort?: string
          p_type?: string
        }
        Returns: {
          amount: number
          category_icon: string
          category_id: string
          category_is_active: boolean
          category_name: string
          comment: string
          created_at: string
          id: string
          income_source: string
          transaction_date: string
          type: string
          user_full_name: string
          user_id: string
        }[]
      }
      get_transactions_totals: {
        Args: {
          p_category_id?: string
          p_category_mode?: string
          p_date_from?: string
          p_date_to?: string
          p_search?: string
          p_type?: string
        }
        Returns: {
          balance: number
          expenses: number
          income: number
        }[]
      }
      is_family_admin: { Args: { p_family_id: string }; Returns: boolean }
      is_family_member: { Args: { p_family_id: string }; Returns: boolean }
      leave_family: { Args: never; Returns: undefined }
      mark_all_notifications_read: { Args: never; Returns: number }
      mark_notification_read: {
        Args: { p_notification_id: string }
        Returns: undefined
      }
      shares_family_with: { Args: { p_user_id: string }; Returns: boolean }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, '__InternalSupabase'>

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, 'public'>]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema['Tables'] & DefaultSchema['Views'])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions['schema']]['Tables'] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions['schema']]['Views'])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions['schema']]['Tables'] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions['schema']]['Views'])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema['Tables'] &
        DefaultSchema['Views'])
    ? (DefaultSchema['Tables'] &
        DefaultSchema['Views'])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema['Tables']
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions['schema']]['Tables']
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions['schema']]['Tables'][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema['Tables']
    ? DefaultSchema['Tables'][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema['Tables']
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions['schema']]['Tables']
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions['schema']]['Tables'][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema['Tables']
    ? DefaultSchema['Tables'][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema['Enums']
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions['schema']]['Enums']
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions['schema']]['Enums'][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema['Enums']
    ? DefaultSchema['Enums'][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema['CompositeTypes']
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions['schema']]['CompositeTypes']
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions['schema']]['CompositeTypes'][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema['CompositeTypes']
    ? DefaultSchema['CompositeTypes'][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
