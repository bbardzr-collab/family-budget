import { QueryClient } from '@tanstack/react-query'

/**
 * Единый QueryClient приложения.
 *
 * На Этапе 1 реальных запросов ещё нет (Supabase будет подключён на
 * следующих этапах) — настройки ниже являются разумными значениями
 * по умолчанию для будущей работы с серверными данными.
 */
export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30 * 1000,
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
})
