import { createClient } from '@supabase/supabase-js'
import type { Database } from '@/types/database'

/**
 * Единственный Supabase client приложения (Этап 3, п.2).
 * НЕ создавать вторые/третьи клиенты в других файлах — импортировать `supabase`
 * отсюда.
 *
 * Проверка переменных окружения — намеренно "громкая": если .env.local не
 * настроен, приложение не должно тихо работать с undefined-URL. Значения
 * самих переменных в console НЕ выводятся (только факт "заданы/не заданы").
 */

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

function assertEnv(name: string, value: string | undefined): asserts value is string {
  if (!value) {
    throw new Error(
      `Отсутствует переменная окружения ${name}. Скопируйте .env.example в .env.local ` +
        'и укажите реальные значения из настроек вашего Supabase-проекта (см. README, раздел "Supabase").',
    )
  }
}

assertEnv('VITE_SUPABASE_URL', supabaseUrl)
assertEnv('VITE_SUPABASE_ANON_KEY', supabaseAnonKey)

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey)

/**
 * Технический health-check подключения — используется только dev-only
 * компонентом SupabaseStatus (см. src/components/dev/SupabaseStatus.tsx).
 * НЕ вызывает ничего кроме безобидного auth.getSession() — не течёт секретов,
 * ничего не логирует.
 */
export async function checkSupabaseConnection(): Promise<boolean> {
  try {
    const { error } = await supabase.auth.getSession()
    return !error
  } catch {
    return false
  }
}
