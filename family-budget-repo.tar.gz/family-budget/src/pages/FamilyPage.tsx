import { useState } from 'react'
import { Users, UserPlus, X, Pencil, LogOut, MoreVertical } from 'lucide-react'
import {
  Avatar,
  Badge,
  Button,
  Card,
  CardContent,
  Dropdown,
  EmptyState,
  ErrorState,
  IconButton,
  LoadingState,
  PageTitle,
  SectionTitle,
  Text,
} from '@/components/ui'
import { useToast } from '@/components/ui/Toast'
import { useAuth } from '@/features/auth/AuthContext'
import { useFamily } from '@/features/family/FamilyContext'
import {
  useFamilyInvitations,
  useFamilyMembers,
  useFamilySettings,
  useCancelInvitation,
  useUpdateMemberRole,
} from '@/features/family/hooks'
import { InviteMemberModal } from '@/features/family/InviteMemberModal'
import { CreateFamilyForm } from '@/features/family/CreateFamilyForm'
import { RenameFamilyModal } from '@/features/family/RenameFamilyModal'
import { RemoveFamilyMemberModal } from '@/features/family/RemoveFamilyMemberModal'
import { LeaveFamilyModal } from '@/features/family/LeaveFamilyModal'
import { getFamilyErrorMessage } from '@/features/family/errors'
import { invitationStatusLabel, memberStatusLabel, roleLabel } from '@/features/family/roles'
import type { FamilyRole } from '@/features/family/roles'
import type { FamilyMemberWithProfile } from '@/features/family/api'
import { formatDate } from '@/utils/formatDate'
import type { BadgeVariant } from '@/components/ui'

const INVITATION_BADGE_VARIANT: Record<string, BadgeVariant> = {
  pending: 'default',
  accepted: 'success',
  expired: 'warning',
  cancelled: 'danger',
}

/**
 * Реальная страница «Семья» (Этап 5, п.11, 12, 18). Пока у пользователя нет
 * семьи — показываем ту же форму создания, что и на главной (п.32), чтобы
 * раздел не выглядел сломанным при прямом переходе на /app/family.
 */
export function FamilyPage() {
  const { user } = useAuth()
  const { currentFamily, loading, isAdmin, hasFamily } = useFamily()
  const [inviteOpen, setInviteOpen] = useState(false)
  const [renameOpen, setRenameOpen] = useState(false)
  const [leaveOpen, setLeaveOpen] = useState(false)

  // Только для подсказки в UI (какая кнопка активна) — реальная защита
  // единственного admin'а всегда на сервере (Этап 15, п.12, RLS + триггер).
  const { data: members } = useFamilyMembers(currentFamily?.id)
  const activeAdminsCount = members?.filter((m) => m.role === 'admin').length ?? 0
  const isSoleAdmin = isAdmin && activeAdminsCount <= 1

  if (loading) {
    return <LoadingState label="Загружаем семью…" className="min-h-[50vh]" />
  }

  if (!hasFamily || !currentFamily) {
    return (
      <div className="flex flex-col gap-6">
        <PageTitle>Семья</PageTitle>
        <Card>
          <CardContent className="pt-6">
            <CreateFamilyForm />
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex min-w-0 items-center gap-2">
          <PageTitle className="truncate">{currentFamily.name}</PageTitle>
          {isAdmin && (
            <IconButton
              icon={Pencil}
              aria-label="Переименовать семью"
              variant="ghost"
              size="sm"
              onClick={() => setRenameOpen(true)}
            />
          )}
        </div>
        {/* flex-wrap без shrink-0: shrink-0 держал этот блок на его
            "предпочитаемой" (нешринкнутой) ширине даже когда он остаётся
            один на своей строке после переноса — на 320px две кнопки вместе
            всё равно шире вьюпорта и выталкивали страницу в горизонтальный
            скролл. Без shrink-0 flex-алгоритм сжимает сам блок на его
            собственной строке, и flex-wrap переносит кнопки друг под друга
            (Этап 19, п.36). */}
        <div className="flex flex-wrap items-center gap-2">
          {isAdmin && (
            <Button size="sm" onClick={() => setInviteOpen(true)}>
              <UserPlus className="size-4" aria-hidden="true" />
              Пригласить члена семьи
            </Button>
          )}
          <Button size="sm" variant="outline" onClick={() => setLeaveOpen(true)}>
            <LogOut className="size-4" aria-hidden="true" />
            Покинуть семью
          </Button>
        </div>
      </div>

      <FamilySettingsSummary familyId={currentFamily.id} />

      <FamilyMembersSection familyId={currentFamily.id} currentUserId={user?.id} isAdmin={isAdmin} />

      {isAdmin && <FamilyInvitationsSection familyId={currentFamily.id} />}

      {isAdmin && (
        <InviteMemberModal open={inviteOpen} onClose={() => setInviteOpen(false)} familyId={currentFamily.id} />
      )}

      {isAdmin && (
        <RenameFamilyModal
          open={renameOpen}
          onClose={() => setRenameOpen(false)}
          familyId={currentFamily.id}
          currentName={currentFamily.name}
        />
      )}

      <LeaveFamilyModal open={leaveOpen} onClose={() => setLeaveOpen(false)} isSoleAdmin={isSoleAdmin} />
    </div>
  )
}

/**
 * Read-only отображение семейных настроек (Этап 15, п.30) — сейчас только
 * валюта (RUB по умолчанию). child_visibility сознательно не читается и не
 * отображается здесь — задел под Этап 16, а не его реализация.
 */
function FamilySettingsSummary({ familyId }: { familyId: string }) {
  const { data: settings } = useFamilySettings(familyId)
  if (!settings) return null

  return (
    <Text variant="secondary" className="text-sm">
      Валюта семьи: {settings.currency}
    </Text>
  )
}

function FamilyMembersSection({
  familyId,
  currentUserId,
  isAdmin,
}: {
  familyId: string
  currentUserId?: string
  isAdmin: boolean
}) {
  const { toast } = useToast()
  const { data: members, isLoading, isError, error, refetch } = useFamilyMembers(familyId)
  const updateRole = useUpdateMemberRole(familyId)
  const [memberToRemove, setMemberToRemove] = useState<FamilyMemberWithProfile | null>(null)

  async function handleRoleChange(memberId: string, role: FamilyRole) {
    try {
      await updateRole.mutateAsync({ memberId, role })
      toast({ type: 'success', title: 'Роль изменена' })
    } catch (roleError) {
      toast({ type: 'error', title: 'Не удалось изменить роль', description: getFamilyErrorMessage(roleError) })
    }
  }

  return (
    <div className="flex flex-col gap-3">
      <SectionTitle>Участники</SectionTitle>

      {isLoading && <LoadingState label="Загружаем участников…" />}

      {isError && (
        <ErrorState
          title="Не получилось загрузить участников"
          description={getFamilyErrorMessage(error)}
          onRetry={() => void refetch()}
        />
      )}

      {!isLoading && !isError && members && members.length === 0 && (
        <EmptyState icon={Users} title="В семье пока нет участников" />
      )}

      {!isLoading && !isError && members && members.length > 0 && (
        <Card>
          <CardContent className="flex flex-col divide-y divide-border pt-6">
            {members.map((member) => {
              const name = member.profile?.full_name ?? 'Участник'
              const isSelf = member.user_id === currentUserId
              // Действия над своей же строкой убраны из этого меню намеренно —
              // для себя есть отдельная кнопка «Покинуть семью» (Этап 15, п.14);
              // смешивать два способа менять membership одной и той же строки
              // в одном месте UI не стали (п.14 — "не смешивай несколько моделей").
              const canManage = isAdmin && !isSelf
              const dropdownItems = [
                ...(member.role !== 'adult' ? [{ value: 'make-adult', label: 'Сделать взрослым' }] : []),
                ...(member.role !== 'child' ? [{ value: 'make-child', label: 'Сделать ребёнком' }] : []),
                { value: 'remove', label: 'Удалить из семьи', destructive: true },
              ]

              function handleSelect(value: string) {
                if (value === 'make-adult') void handleRoleChange(member.id, 'adult')
                else if (value === 'make-child') void handleRoleChange(member.id, 'child')
                else if (value === 'remove') setMemberToRemove(member)
              }

              return (
                <div key={member.id} className="flex items-center gap-3 py-3 first:pt-0 last:pb-0">
                  <Avatar name={name} src={member.profile?.avatar_url ?? undefined} size="md" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium text-foreground">
                      {name}
                      {isSelf && <span className="ml-1.5 text-sm font-normal text-muted-foreground">(вы)</span>}
                    </p>
                    <p className="text-sm text-muted-foreground">{roleLabel(member.role)}</p>
                  </div>
                  <Badge variant={member.status === 'active' ? 'success' : 'default'}>
                    {memberStatusLabel(member.status)}
                  </Badge>
                  {canManage && (
                    <Dropdown
                      trigger={<IconButton icon={MoreVertical} aria-label={`Действия с участником ${name}`} size="sm" />}
                      items={dropdownItems}
                      onSelect={handleSelect}
                    />
                  )}
                </div>
              )
            })}
          </CardContent>
        </Card>
      )}

      <RemoveFamilyMemberModal
        member={
          memberToRemove
            ? { id: memberToRemove.id, name: memberToRemove.profile?.full_name ?? 'Участник', role: memberToRemove.role }
            : null
        }
        familyId={familyId}
        onClose={() => setMemberToRemove(null)}
      />
    </div>
  )
}

function FamilyInvitationsSection({ familyId }: { familyId: string }) {
  const { toast } = useToast()
  const { data: invitations, isLoading, isError, error, refetch } = useFamilyInvitations(familyId, true)
  const cancelInvitation = useCancelInvitation(familyId)

  async function handleCancel(invitationId: string) {
    try {
      await cancelInvitation.mutateAsync(invitationId)
      toast({ type: 'success', title: 'Приглашение отменено' })
    } catch (cancelError) {
      toast({ type: 'error', title: 'Не удалось отменить', description: getFamilyErrorMessage(cancelError) })
    }
  }

  return (
    <div className="flex flex-col gap-3">
      <SectionTitle>Приглашения</SectionTitle>

      {isLoading && <LoadingState label="Загружаем приглашения…" />}

      {isError && (
        <ErrorState
          title="Не получилось загрузить приглашения"
          description={getFamilyErrorMessage(error)}
          onRetry={() => void refetch()}
        />
      )}

      {!isLoading && !isError && invitations && invitations.length === 0 && (
        <EmptyState title="Активных приглашений нет" description="Пригласите близких по ссылке." />
      )}

      {!isLoading && !isError && invitations && invitations.length > 0 && (
        <Card>
          <CardContent className="flex flex-col divide-y divide-border pt-6">
            {invitations.map((invitation) => (
              <div key={invitation.id} className="flex items-center gap-3 py-3 first:pt-0 last:pb-0">
                <div className="min-w-0 flex-1">
                  <p className="font-medium text-foreground">Приглашение для роли «{roleLabel(invitation.role)}»</p>
                  <p className="text-sm text-muted-foreground">
                    Действительно до {formatDate(invitation.expires_at)}
                  </p>
                </div>
                <Badge variant={INVITATION_BADGE_VARIANT[invitation.status] ?? 'default'}>
                  {invitationStatusLabel(invitation.status)}
                </Badge>
                {invitation.status === 'pending' && (
                  <IconButton
                    icon={X}
                    aria-label="Отменить приглашение"
                    variant="ghost"
                    size="sm"
                    disabled={cancelInvitation.isPending}
                    onClick={() => void handleCancel(invitation.id)}
                  />
                )}
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
