import { createElement, useMemo, useState, type ReactNode } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { BarChart3 } from 'lucide-react'
import {
  Amount,
  Button,
  Card,
  CardContent,
  EmptyState,
  ErrorState,
  PageTitle,
  ProgressBar,
  SectionTitle,
  Skeleton,
  Text,
} from '@/components/ui'
import { cn } from '@/utils/cn'
import { formatMoney } from '@/utils/formatMoney'
import { sumMoney } from '@/utils/money'
import { formatMonthYear } from '@/utils/formatDate'
import { getCategoryIcon } from '@/features/categories/iconMap'
import { getGoalIcon } from '@/features/goals/iconMap'
import { useHasAnyTransactions } from '@/features/transactions/hooks'
import { useBudgetSummary } from '@/features/budgets/hooks'
import { toMonthParam, toPeriodMonthValue } from '@/features/budgets/period'
import type { BudgetSummaryCategory } from '@/features/budgets/api'
import { useGoals } from '@/features/goals/hooks'
import { usePlannedExpenses } from '@/features/plannedExpenses/hooks'
import {
  useAnalyticsCategories,
  useAnalyticsComparison,
  useAnalyticsIncomeSources,
  useAnalyticsSummary,
  useAnalyticsTimeseries,
} from '@/features/analytics/hooks'
import { formatPercentageChange, type AnalyticsComparisonValue } from '@/features/analytics/comparison'
import {
  ANALYTICS_PERIOD_PRESETS,
  DEFAULT_ANALYTICS_PERIOD,
  parseDateInputValue,
  resolveAnalyticsPeriod,
  type AnalyticsPeriodPreset,
  type AnalyticsPeriodState,
} from '@/features/analytics/period'
import { AnalyticsPeriodSelector } from '@/features/analytics/AnalyticsPeriodSelector'
import { AnalyticsDynamicsChart } from '@/features/analytics/AnalyticsDynamicsChart'
import { AnalyticsStructureChart } from '@/features/analytics/AnalyticsStructureChart'
import type { AnalyticsCategoryStat, AnalyticsIncomeSourceStat } from '@/features/analytics/api'

/**
 * Страница "Аналитика" (Этап 14) — read-only агрегаты семьи за выбранный
 * период: сводка, динамика, расходы по категориям/структуре, доходы по
 * источникам, сравнение с прошлым периодом, справочные блоки бюджета/
 * запланированного/целей. Источник цифр — ИСКЛЮЧИТЕЛЬНО `transactions`
 * (ТЗ, п.1) через 4 новых RPC (миграция 0030, см. features/analytics/api.ts) —
 * страница никогда не суммирует список операций на клиенте.
 *
 * Страница ничего не создаёт/не редактирует/не удаляет (ТЗ, п.24) — ни
 * одной мутации, только useQuery/useQueries (см. features/analytics/hooks.ts).
 * Бюджет/цели/запланированные расходы переиспользуют существующие Stage
 * 10/11/12 хуки как есть — здесь нет новых RPC под них (см. api.ts).
 *
 * Период хранится в URL (?period=&from=&to=), тем же приёмом, что и
 * ?month= на /app/budget — это удобство UI, а не граница безопасности:
 * реальные агрегаты сервер вычисляет через SECURITY INVOKER RPC, которые
 * определяют семью по auth.uid(), а не по параметрам запроса.
 */

function parsePeriodState(params: URLSearchParams): AnalyticsPeriodState {
  const presetParam = params.get('period')
  const preset = (ANALYTICS_PERIOD_PRESETS as readonly string[]).includes(presetParam ?? '')
    ? (presetParam as AnalyticsPeriodPreset)
    : DEFAULT_ANALYTICS_PERIOD.preset
  return { preset, customFrom: params.get('from') ?? '', customTo: params.get('to') ?? '' }
}

export function AnalyticsPage() {
  const [searchParams, setSearchParams] = useSearchParams()
  const periodState = useMemo(() => parsePeriodState(searchParams), [searchParams])
  const period = useMemo(() => resolveAnalyticsPeriod(periodState), [periodState])

  const [showAllCategories, setShowAllCategories] = useState(false)

  function changePreset(preset: AnalyticsPeriodPreset) {
    setShowAllCategories(false)
    setSearchParams((prev) => {
      const next = new URLSearchParams(prev)
      next.set('period', preset)
      if (preset !== 'custom') {
        next.delete('from')
        next.delete('to')
      }
      return next
    })
  }

  function changeCustomRange(from: string, to: string) {
    setSearchParams((prev) => {
      const next = new URLSearchParams(prev)
      next.set('period', 'custom')
      if (from) next.set('from', from)
      else next.delete('from')
      if (to) next.set('to', to)
      else next.delete('to')
      return next
    })
  }

  const hasAnyQuery = useHasAnyTransactions()
  const summaryQuery = useAnalyticsSummary(period)
  const timeseriesQuery = useAnalyticsTimeseries(period)
  const categoriesQuery = useAnalyticsCategories(period)
  const incomeSourcesQuery = useAnalyticsIncomeSources(period)
  const comparison = useAnalyticsComparison(period)

  const budgetMonthDate = parseDateInputValue(period.dateTo)
  const budgetPeriodMonth = toPeriodMonthValue(budgetMonthDate)
  const budgetQuery = useBudgetSummary(budgetPeriodMonth)

  const { data: goals } = useGoals()
  const { data: plannedExpenses } = usePlannedExpenses()

  const activeGoals = (goals ?? []).filter((g) => g.status === 'active')
  // Клиентская фильтрация по периоду — тот же принцип, что и на самой
  // /app/transactions#план (Этап 12): список планов семьи короткий и не
  // пагинируется, поэтому фильтрация на клиенте не нарушает ТЗ п.4/26
  // (запрет загружать МНОГО данных на клиент ради подсчёта — здесь и так
  // загружается не больше, чем сама страница "План" уже загружает).
  const plannedInPeriod = (plannedExpenses ?? []).filter(
    (p) => p.status === 'planned' && p.plannedDate >= period.dateFrom && p.plannedDate <= period.dateTo,
  )
  // sumMoney, не обычный reduce с "+" — тот же класс float-бага, что нашёл
  // живой аудит Этапа 20 в BudgetPage.tsx (см. utils/money.ts).
  const plannedTotal = sumMoney(plannedInPeriod.map((p) => p.amount))

  function retryAll() {
    void hasAnyQuery.refetch()
    void summaryQuery.refetch()
    void timeseriesQuery.refetch()
    void categoriesQuery.refetch()
    void incomeSourcesQuery.refetch()
    comparison.refetch()
  }

  const isInitialLoading = hasAnyQuery.isLoading || summaryQuery.isLoading
  const isCriticalError = !isInitialLoading && (hasAnyQuery.isError || summaryQuery.isError)
  const isEmpty = !isInitialLoading && !isCriticalError && hasAnyQuery.data === false
  const isReady = !isInitialLoading && !isCriticalError && !isEmpty && summaryQuery.data

  return (
    <div className="flex flex-col gap-6">
      <PageTitle>Аналитика</PageTitle>

      <AnalyticsPeriodSelector
        state={periodState}
        resolved={period}
        onChangePreset={changePreset}
        onChangeCustomRange={changeCustomRange}
      />

      {isInitialLoading && <AnalyticsSkeleton />}

      {isCriticalError && (
        <Card>
          <CardContent className="pt-6">
            <ErrorState title="Не удалось загрузить аналитику" onRetry={retryAll} />
          </CardContent>
        </Card>
      )}

      {isEmpty && (
        <Card>
          <CardContent className="pt-6">
            <EmptyState
              icon={BarChart3}
              title="Пока нет данных для аналитики"
              description="Добавьте доходы и расходы, и здесь появится финансовая статистика семьи."
            />
          </CardContent>
        </Card>
      )}

      {isReady && summaryQuery.data && (
        <>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <MetricCard
              label="Доходы"
              valueNode={<Amount value={summaryQuery.data.income} size="lg" tone="success" />}
              comparison={comparison.data?.income}
            />
            <MetricCard
              label="Расходы"
              valueNode={<Amount value={summaryQuery.data.expenses} size="lg" tone="neutral" />}
              comparison={comparison.data?.expenses}
            />
            <MetricCard
              label="Баланс"
              valueNode={
                <Amount
                  value={summaryQuery.data.balance}
                  size="lg"
                  tone={summaryQuery.data.balance < 0 ? 'danger' : 'success'}
                />
              }
              comparison={comparison.data?.balance}
            />
            <MetricCard
              label="Операций"
              valueNode={
                <span className="text-2xl font-semibold tabular-nums text-foreground sm:text-3xl">
                  {summaryQuery.data.transactionCount}
                </span>
              }
              comparison={comparison.data?.transactionCount}
            />
          </div>

          <Card>
            <CardContent className="flex flex-col gap-3 pt-6">
              <SectionTitle>Динамика</SectionTitle>
              {timeseriesQuery.isLoading && <Skeleton className="h-64 w-full rounded-lg" />}
              {timeseriesQuery.isError && (
                <ErrorState
                  title="Не удалось загрузить график"
                  onRetry={() => void timeseriesQuery.refetch()}
                />
              )}
              {timeseriesQuery.data && (
                <AnalyticsDynamicsChart
                  points={timeseriesQuery.data.points}
                  granularity={timeseriesQuery.data.granularity}
                />
              )}
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            <Card>
              <CardContent className="flex flex-col gap-4 pt-6">
                <SectionTitle>Расходы по категориям</SectionTitle>
                {categoriesQuery.isLoading && <Skeleton className="h-40 w-full rounded-lg" />}
                {categoriesQuery.isError && (
                  <ErrorState
                    title="Не удалось загрузить категории"
                    onRetry={() => void categoriesQuery.refetch()}
                  />
                )}
                {categoriesQuery.data &&
                  (categoriesQuery.data.categories.length === 0 ? (
                    <Text variant="secondary">Расходов за период нет.</Text>
                  ) : (
                    <>
                      <div className="flex flex-col divide-y divide-border">
                        {(showAllCategories
                          ? categoriesQuery.data.categories
                          : categoriesQuery.data.categories.slice(0, 5)
                        ).map((stat) => (
                          <CategoryRow key={stat.categoryId ?? 'uncategorized'} stat={stat} />
                        ))}
                      </div>
                      {categoriesQuery.data.categories.length > 5 && (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="self-start"
                          onClick={() => setShowAllCategories((v) => !v)}
                        >
                          {showAllCategories
                            ? 'Свернуть'
                            : `Показать ещё ${categoriesQuery.data.categories.length - 5}`}
                        </Button>
                      )}
                      <SectionTitle className="text-sm">Структура расходов</SectionTitle>
                      <AnalyticsStructureChart byType={categoriesQuery.data.byType} />
                    </>
                  ))}
                <Link to="/app/transactions" className="text-sm font-medium text-primary hover:underline">
                  Посмотреть операции →
                </Link>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="flex flex-col gap-4 pt-6">
                <SectionTitle>Доходы по источникам</SectionTitle>
                {incomeSourcesQuery.isLoading && <Skeleton className="h-40 w-full rounded-lg" />}
                {incomeSourcesQuery.isError && (
                  <ErrorState
                    title="Не удалось загрузить источники дохода"
                    onRetry={() => void incomeSourcesQuery.refetch()}
                  />
                )}
                {incomeSourcesQuery.data &&
                  (incomeSourcesQuery.data.sources.length === 0 ? (
                    <Text variant="secondary">Доходов за период нет.</Text>
                  ) : (
                    <div className="flex flex-col divide-y divide-border">
                      {incomeSourcesQuery.data.sources.map((stat) => (
                        <IncomeSourceRow key={stat.incomeSource ?? 'unknown'} stat={stat} />
                      ))}
                    </div>
                  ))}
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardContent className="flex flex-col gap-4 pt-6">
              <div className="flex items-center justify-between gap-4">
                <SectionTitle>Бюджет</SectionTitle>
                <Link
                  to={`/app/budget?month=${toMonthParam(budgetMonthDate)}`}
                  className="text-sm font-medium text-primary hover:underline"
                >
                  Открыть бюджет →
                </Link>
              </div>
              {/* Аналитика может охватывать период шире одного месяца
                  (например, "Последние 3 месяца") — бюджет в Stage 10 всегда
                  месячный, поэтому здесь однозначно показывается бюджет
                  месяца, В КОТОРЫЙ ВХОДИТ конец выбранного периода (dateTo),
                  с явной подписью, чтобы не создавать впечатление, что это
                  бюджет "за весь период" (см. STAGE14_REPORT.md). */}
              <Text variant="small">За {formatMonthYear(budgetMonthDate)}</Text>
              {budgetQuery.isLoading && <Skeleton className="h-24 w-full rounded-lg" />}
              {budgetQuery.isError && (
                <ErrorState title="Не удалось загрузить бюджет" onRetry={() => void budgetQuery.refetch()} />
              )}
              {!budgetQuery.isLoading && !budgetQuery.isError && !budgetQuery.data?.budget && (
                <Text variant="secondary">Бюджет на этот месяц ещё не создан.</Text>
              )}
              {budgetQuery.data?.budget && (
                <>
                  <ProgressBar value={budgetQuery.data.totalSpent} max={budgetQuery.data.budget.totalAmount} />
                  <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                    <MiniStat label="Лимит" value={formatMoney(budgetQuery.data.budget.totalAmount)} />
                    <MiniStat label="Потрачено" value={formatMoney(budgetQuery.data.totalSpent)} />
                    <MiniStat label="Осталось" value={formatMoney(budgetQuery.data.totalRemaining)} />
                    <MiniStat
                      label="Использовано"
                      value={budgetQuery.data.totalPercent !== null ? `${budgetQuery.data.totalPercent}%` : '—'}
                    />
                  </div>
                  {budgetQuery.data.categories.length > 0 && (
                    <div className="flex flex-col divide-y divide-border pt-2">
                      {budgetQuery.data.categories.map((category) => (
                        <BudgetCategoryMiniRow key={category.id} category={category} />
                      ))}
                    </div>
                  )}
                </>
              )}
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            <Card>
              <CardContent className="flex flex-col gap-3 pt-6">
                <SectionTitle>Запланировано</SectionTitle>
                <Amount value={plannedTotal} size="md" />
                {/* ТЗ прямо требует эту подпись при показе запланированного
                    рядом с фактическими цифрами (п.19) — план НЕ является
                    фактическим расходом, пока не станет реальной transaction. */}
                <Text variant="small">Не входит в фактические расходы</Text>
                <Link to="/app/transactions" className="text-sm font-medium text-primary hover:underline">
                  Посмотреть операции →
                </Link>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="flex flex-col gap-3 pt-6">
                <SectionTitle>Цели</SectionTitle>
                {activeGoals.length === 0 ? (
                  <Text variant="secondary">Активных целей нет.</Text>
                ) : (
                  <div className="flex flex-col gap-3">
                    {activeGoals.slice(0, 3).map((goal) => (
                      <div key={goal.id} className="flex flex-col gap-1.5">
                        <div className="flex items-center gap-2">
                          <div className="flex size-7 shrink-0 items-center justify-center rounded-full bg-primary-soft text-primary">
                            {createElement(getGoalIcon(goal.icon), { className: 'size-3.5', 'aria-hidden': true })}
                          </div>
                          <span className="min-w-0 flex-1 truncate text-sm font-medium text-foreground">
                            {goal.title}
                          </span>
                          <span className="shrink-0 text-xs tabular-nums text-muted-foreground">
                            {goal.percent}%
                          </span>
                        </div>
                        <ProgressBar value={goal.contributedAmount} max={goal.targetAmount} />
                      </div>
                    ))}
                  </div>
                )}
                <Link to="/app/goals" className="text-sm font-medium text-primary hover:underline">
                  Открыть цели →
                </Link>
              </CardContent>
            </Card>
          </div>
        </>
      )}
    </div>
  )
}

/* ───────────────────────────── Metric card ───────────────────────────── */

function MetricCard({
  label,
  valueNode,
  comparison,
}: {
  label: string
  valueNode: ReactNode
  comparison: AnalyticsComparisonValue | undefined
}) {
  return (
    <Card>
      <CardContent className="flex flex-col gap-1.5 pt-6">
        <Text variant="secondary">{label}</Text>
        {valueNode}
        {/* NBSP-заглушка сохраняет высоту карточки, пока сравнение ещё
            грузится (comparison — отдельный запрос, см. useAnalyticsComparison),
            чтобы карточки не "прыгали" после первой отрисовки. */}
        <span className="text-xs text-muted-foreground">
          {comparison ? `${formatPercentageChange(comparison.percentageChange)} к прошлому периоду` : '\u00A0'}
        </span>
      </CardContent>
    </Card>
  )
}

/* ───────────────────────────── Share bar ───────────────────────────── */

function SharePercentBar({ percent, tone = 'primary' }: { percent: number; tone?: 'primary' | 'success' }) {
  const width = Math.min(Math.max(percent, 0), 100)
  return (
    <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted" aria-hidden="true">
      <div
        className={cn('h-full rounded-full', tone === 'success' ? 'bg-success' : 'bg-primary')}
        style={{ width: `${width}%` }}
      />
    </div>
  )
}

/* ───────────────────────────── Category / income rows ───────────────────────────── */

function CategoryRow({ stat }: { stat: AnalyticsCategoryStat }) {
  return (
    <div className="flex flex-col gap-1.5 py-3 first:pt-0 last:pb-0">
      <div className="flex items-center gap-3">
        <div className="flex size-8 shrink-0 items-center justify-center rounded-full bg-muted text-muted-foreground">
          {createElement(getCategoryIcon(stat.categoryIcon), { className: 'size-4', 'aria-hidden': true })}
        </div>
        <span className="min-w-0 flex-1 truncate text-sm font-medium text-foreground">{stat.categoryName}</span>
        <span className="shrink-0 text-sm font-medium tabular-nums text-foreground">{formatMoney(stat.amount)}</span>
        <span className="w-10 shrink-0 text-right text-xs tabular-nums text-muted-foreground">{stat.percent}%</span>
      </div>
      <SharePercentBar percent={stat.percent} />
    </div>
  )
}

function IncomeSourceRow({ stat }: { stat: AnalyticsIncomeSourceStat }) {
  return (
    <div className="flex flex-col gap-1.5 py-3 first:pt-0 last:pb-0">
      <div className="flex items-center gap-3">
        <span className="min-w-0 flex-1 truncate text-sm font-medium text-foreground">
          {stat.incomeSource ?? 'Без источника'}
        </span>
        <span className="shrink-0 text-sm font-medium tabular-nums text-foreground">{formatMoney(stat.amount)}</span>
        <span className="w-10 shrink-0 text-right text-xs tabular-nums text-muted-foreground">{stat.percent}%</span>
      </div>
      <SharePercentBar percent={stat.percent} tone="success" />
    </div>
  )
}

/* ───────────────────────────── Budget mini row ───────────────────────────── */

function BudgetCategoryMiniRow({ category }: { category: BudgetSummaryCategory }) {
  return (
    <div className="flex flex-col gap-1.5 py-3 first:pt-0 last:pb-0">
      <div className="flex items-center gap-3">
        <div className="flex size-7 shrink-0 items-center justify-center rounded-full bg-muted text-muted-foreground">
          {createElement(getCategoryIcon(category.categoryIcon), { className: 'size-3.5', 'aria-hidden': true })}
        </div>
        <span className="min-w-0 flex-1 truncate text-sm text-foreground">{category.categoryName}</span>
        <span className="shrink-0 text-xs tabular-nums text-muted-foreground">
          {category.percent !== null ? `${category.percent}%` : '—'}
        </span>
      </div>
      <ProgressBar value={category.spentAmount} max={category.limitAmount} />
    </div>
  )
}

function MiniStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col gap-0.5">
      <Text variant="small">{label}</Text>
      <span className="text-sm font-medium tabular-nums text-foreground">{value}</span>
    </div>
  )
}

/* ───────────────────────────── Loading skeleton ───────────────────────────── */

function AnalyticsSkeleton() {
  return (
    <div className="flex flex-col gap-6" role="status" aria-label="Загружаем аналитику…">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[0, 1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-24 w-full rounded-lg" />
        ))}
      </div>
      <Skeleton className="h-72 w-full rounded-lg" />
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Skeleton className="h-64 w-full rounded-lg" />
        <Skeleton className="h-64 w-full rounded-lg" />
      </div>
      <Skeleton className="h-48 w-full rounded-lg" />
    </div>
  )
}
