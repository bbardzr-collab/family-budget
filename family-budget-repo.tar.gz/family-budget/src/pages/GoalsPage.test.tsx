import { fireEvent, render, screen, waitFor, within } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { ToastProvider } from '@/components/ui/Toast'
import { GoalsPage } from './GoalsPage'
import type { GoalListItem, GoalSummary } from '@/features/goals/api'

const {
  mockUseGoals,
  mockUseGoal,
  mockCreateGoalMutateAsync,
  mockUpdateGoalMutateAsync,
  mockDeleteGoalMutateAsync,
  mockCancelGoalMutateAsync,
  mockResumeGoalMutateAsync,
  mockAddContributionMutateAsync,
  mockUseAuth,
  mockUseFamily,
  mockUseFamilyMembers,
} = vi.hoisted(() => ({
  mockUseGoals: vi.fn(),
  mockUseGoal: vi.fn(),
  mockCreateGoalMutateAsync: vi.fn(),
  mockUpdateGoalMutateAsync: vi.fn(),
  mockDeleteGoalMutateAsync: vi.fn(),
  mockCancelGoalMutateAsync: vi.fn(),
  mockResumeGoalMutateAsync: vi.fn(),
  mockAddContributionMutateAsync: vi.fn(),
  mockUseAuth: vi.fn(),
  mockUseFamily: vi.fn(),
  mockUseFamilyMembers: vi.fn(),
}))

vi.mock('@/features/goals/hooks', () => ({
  useGoals: mockUseGoals,
  useGoal: mockUseGoal,
  useCreateGoal: () => ({ mutateAsync: mockCreateGoalMutateAsync, isPending: false }),
  useUpdateGoal: () => ({ mutateAsync: mockUpdateGoalMutateAsync, isPending: false }),
  useDeleteGoal: () => ({ mutateAsync: mockDeleteGoalMutateAsync, isPending: false }),
  useCancelGoal: () => ({ mutateAsync: mockCancelGoalMutateAsync, isPending: false }),
  useResumeGoal: () => ({ mutateAsync: mockResumeGoalMutateAsync, isPending: false }),
  useAddGoalContribution: () => ({ mutateAsync: mockAddContributionMutateAsync, isPending: false }),
}))

vi.mock('@/features/auth/AuthContext', () => ({
  useAuth: mockUseAuth,
}))

vi.mock('@/features/family/FamilyContext', () => ({
  useFamily: mockUseFamily,
}))

vi.mock('@/features/family/hooks', () => ({
  useFamilyMembers: mockUseFamilyMembers,
}))

function renderPage() {
  return render(
    <MemoryRouter initialEntries={['/app/goals']}>
      <ToastProvider>
        <GoalsPage />
      </ToastProvider>
    </MemoryRouter>,
  )
}

const MEMBERS = [
  { user_id: 'user-1', status: 'active', profile: { id: 'user-1', full_name: 'Иван', avatar_url: null } },
  { user_id: 'user-2', status: 'active', profile: { id: 'user-2', full_name: 'Мария', avatar_url: null } },
]

function makeGoal(overrides: Partial<GoalListItem> = {}): GoalListItem {
  return {
    id: 'goal-1',
    goalType: 'family',
    ownerUserId: null,
    ownerName: null,
    title: 'Отпуск',
    icon: 'plane',
    targetAmount: 250000,
    targetDate: '2026-12-01',
    status: 'active',
    contributedAmount: 120000,
    remainingAmount: 130000,
    percent: 48,
    createdAt: '2026-01-01T00:00:00Z',
    ...overrides,
  }
}

describe('GoalsPage (Этап 11)', () => {
  beforeEach(() => {
    mockUseAuth.mockReturnValue({
      user: { id: 'user-1' },
      profile: { id: 'user-1', full_name: 'Иван' },
    })
    mockUseFamily.mockReturnValue({
      currentFamily: { id: 'family-1' },
      isAdmin: true,
      isAdult: false,
      isChild: false,
    })
    mockUseFamilyMembers.mockReturnValue({ data: MEMBERS, isLoading: false, isError: false })
    mockUseGoal.mockReturnValue({ data: undefined, isLoading: false, isError: false, refetch: vi.fn() })
    mockCreateGoalMutateAsync.mockResolvedValue({ id: 'new-goal' })
    mockAddContributionMutateAsync.mockResolvedValue({ id: 'contrib-1', goalCompleted: false })
    mockDeleteGoalMutateAsync.mockResolvedValue(undefined)
    mockCancelGoalMutateAsync.mockResolvedValue(undefined)
    mockResumeGoalMutateAsync.mockResolvedValue(undefined)
  })

  it('во время загрузки показывает Skeleton', () => {
    mockUseGoals.mockReturnValue({ data: undefined, isLoading: true, isError: false, refetch: vi.fn() })

    renderPage()

    expect(screen.getByRole('status', { name: /загружаем цели/i })).toBeInTheDocument()
  })

  it('ошибка загрузки показывает ErrorState с кнопкой "Повторить"', () => {
    const refetch = vi.fn()
    mockUseGoals.mockReturnValue({ data: undefined, isLoading: false, isError: true, refetch })

    renderPage()

    expect(screen.getByText('Не удалось загрузить цели')).toBeInTheDocument()
    fireEvent.click(screen.getByRole('button', { name: /повторить/i }))
    expect(refetch).toHaveBeenCalled()
  })

  it('нет целей: EmptyState с кнопкой "Создать первую цель", открывающей форму создания', () => {
    mockUseGoals.mockReturnValue({ data: [], isLoading: false, isError: false, refetch: vi.fn() })

    renderPage()

    expect(screen.getByText('Финансовых целей пока нет')).toBeInTheDocument()
    fireEvent.click(screen.getByRole('button', { name: 'Создать первую цель' }))
    expect(screen.getByRole('dialog', { name: 'Новая финансовая цель' })).toBeInTheDocument()
  })

  it('карточка цели показывает Накоплено/Цель/Осталось, процент и дату (пример ТЗ, п.31: 120 000/250 000 ₽, 48%)', () => {
    mockUseGoals.mockReturnValue({ data: [makeGoal()], isLoading: false, isError: false, refetch: vi.fn() })

    renderPage()

    expect(screen.getByText('Отпуск')).toBeInTheDocument()
    expect(screen.getByText(/120 000/)).toBeInTheDocument()
    expect(screen.getByText(/250 000/)).toBeInTheDocument()
    expect(screen.getByText(/130 000/)).toBeInTheDocument()
    expect(screen.getByText('48%')).toBeInTheDocument()
  })

  it('выполненная цель показывает "Выполнена" вместо остатка, не показывает кнопку "Пополнить" (ТЗ, п.16-19)', () => {
    mockUseGoals.mockReturnValue({
      data: [makeGoal({ status: 'completed', contributedAmount: 250000, remainingAmount: 0, percent: 100 })],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderPage()

    // "Выполнена" встречается и в статус-бейдже, и вместо суммы "Осталось" (ТЗ, п.16-19).
    expect(screen.getAllByText('Выполнена').length).toBeGreaterThanOrEqual(2)
    expect(screen.getByText('100%')).toBeInTheDocument()
    expect(screen.queryByRole('button', { name: 'Пополнить' })).not.toBeInTheDocument()
    // Реальная накопленная сумма всё равно показана полностью, а не скрыта (ТЗ, п.17).
    expect(screen.getAllByText(/250 000/).length).toBeGreaterThanOrEqual(1)
  })

  it('отменённая цель не показывает кнопку "Пополнить", но история остаётся доступна (ТЗ, п.22)', () => {
    mockUseGoals.mockReturnValue({
      data: [makeGoal({ status: 'cancelled' })],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderPage()

    // Отменённая цель по умолчанию скрыта в свёрнутом блоке "Отменённые" (ТЗ, п.29) — раскрываем его.
    fireEvent.click(screen.getByRole('button', { name: 'Отменённые' }))

    expect(screen.queryByRole('button', { name: 'Пополнить' })).not.toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'История' })).toBeInTheDocument()
  })

  it('группировка "Все": активные и выполненные видны сразу, отменённые свёрнуты по умолчанию (ТЗ, п.29)', () => {
    mockUseGoals.mockReturnValue({
      data: [
        makeGoal({ id: 'g-active', title: 'Отпуск', status: 'active' }),
        makeGoal({ id: 'g-completed', title: 'Ремонт', status: 'completed', percent: 100, remainingAmount: 0 }),
        makeGoal({ id: 'g-cancelled', title: 'Машина', status: 'cancelled' }),
      ],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderPage()

    expect(screen.getByText('Отпуск')).toBeInTheDocument()
    expect(screen.getByText('Ремонт')).toBeInTheDocument()
    expect(screen.queryByText('Машина')).not.toBeInTheDocument()

    fireEvent.click(screen.getByRole('button', { name: 'Отменённые' }))
    expect(screen.getByText('Машина')).toBeInTheDocument()
  })

  it('фильтр показывает только выбранный статус (ТЗ, п.30)', () => {
    mockUseGoals.mockReturnValue({
      data: [
        makeGoal({ id: 'g-active', title: 'Отпуск', status: 'active' }),
        makeGoal({ id: 'g-completed', title: 'Ремонт', status: 'completed', percent: 100, remainingAmount: 0 }),
      ],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderPage()

    fireEvent.click(screen.getByRole('tab', { name: 'Выполненные' }))

    expect(screen.getByText('Ремонт')).toBeInTheDocument()
    expect(screen.queryByText('Отпуск')).not.toBeInTheDocument()
  })

  it('валидация формы создания: пустое название и нулевая сумма показывают ошибки (ТЗ, п.10)', async () => {
    mockUseGoals.mockReturnValue({ data: [], isLoading: false, isError: false, refetch: vi.fn() })

    renderPage()

    fireEvent.click(screen.getByRole('button', { name: 'Создать первую цель' }))
    const dialog = screen.getByRole('dialog', { name: 'Новая финансовая цель' })

    fireEvent.change(within(dialog).getByLabelText('Название'), { target: { value: '   ' } })
    fireEvent.change(within(dialog).getByLabelText('Целевая сумма'), { target: { value: '0' } })
    fireEvent.click(within(dialog).getByRole('button', { name: 'Создать цель' }))

    expect(await within(dialog).findByText('Введите название цели')).toBeInTheDocument()
    expect(within(dialog).getByText('Сумма должна быть больше нуля')).toBeInTheDocument()
    expect(mockCreateGoalMutateAsync).not.toHaveBeenCalled()
  })

  it('личная цель без владельца отклоняется валидацией (ТЗ, п.8)', async () => {
    mockUseGoals.mockReturnValue({ data: [], isLoading: false, isError: false, refetch: vi.fn() })

    renderPage()

    fireEvent.click(screen.getByRole('button', { name: 'Создать первую цель' }))
    const dialog = screen.getByRole('dialog', { name: 'Новая финансовая цель' })

    fireEvent.change(within(dialog).getByLabelText('Название'), { target: { value: 'Велосипед' } })
    fireEvent.click(within(dialog).getByRole('button', { name: 'Личная' }))
    fireEvent.change(within(dialog).getByLabelText('Владелец'), { target: { value: '' } })
    fireEvent.change(within(dialog).getByLabelText('Целевая сумма'), { target: { value: '50000' } })
    fireEvent.click(within(dialog).getByRole('button', { name: 'Создать цель' }))

    await waitFor(() => expect(mockCreateGoalMutateAsync).not.toHaveBeenCalled())
  })

  it('CHILD не может выбрать владельца личной цели — виден только он сам (ТЗ, п.8, 26)', () => {
    mockUseFamily.mockReturnValue({
      currentFamily: { id: 'family-1' },
      isAdmin: false,
      isAdult: false,
      isChild: true,
    })
    mockUseGoals.mockReturnValue({ data: [], isLoading: false, isError: false, refetch: vi.fn() })

    renderPage()

    fireEvent.click(screen.getByRole('button', { name: 'Создать первую цель' }))
    const dialog = screen.getByRole('dialog', { name: 'Новая финансовая цель' })

    fireEvent.click(within(dialog).getByRole('button', { name: 'Личная' }))

    expect(within(dialog).queryByLabelText('Владелец')).not.toBeInTheDocument()
    expect(within(dialog).getByText(/только вы можете быть владельцем/i)).toBeInTheDocument()
  })

  it('успешный взнос показывает тост "Взнос добавлен" (ТЗ, п.12-13)', async () => {
    mockUseGoals.mockReturnValue({ data: [makeGoal()], isLoading: false, isError: false, refetch: vi.fn() })

    renderPage()

    fireEvent.click(screen.getByRole('button', { name: 'Пополнить' }))
    const dialog = screen.getByRole('dialog', { name: 'Внести в цель' })

    fireEvent.change(within(dialog).getByLabelText('Сумма'), { target: { value: '10000' } })
    fireEvent.click(within(dialog).getByRole('button', { name: 'Внести' }))

    expect(await screen.findByText('Взнос добавлен')).toBeInTheDocument()
    expect(mockAddContributionMutateAsync).toHaveBeenCalledWith(
      expect.objectContaining({ goalId: 'goal-1', amount: '10000.00' }),
    )
  })

  it('взнос, завершающий цель, показывает тост "Цель достигнута!" (ТЗ, п.18)', async () => {
    mockAddContributionMutateAsync.mockResolvedValue({ id: 'contrib-2', goalCompleted: true })
    mockUseGoals.mockReturnValue({
      data: [makeGoal({ contributedAmount: 240000, remainingAmount: 10000, percent: 96 })],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderPage()

    fireEvent.click(screen.getByRole('button', { name: 'Пополнить' }))
    const dialog = screen.getByRole('dialog', { name: 'Внести в цель' })

    fireEvent.change(within(dialog).getByLabelText('Сумма'), { target: { value: '10000' } })
    fireEvent.click(within(dialog).getByRole('button', { name: 'Внести' }))

    expect(await screen.findByText('Цель достигнута!')).toBeInTheDocument()
  })

  it('история взносов показывает дату/сумму/пользователя/комментарий (ТЗ, п.14)', () => {
    const summary: GoalSummary = {
      goal: {
        id: 'goal-1',
        familyId: 'family-1',
        goalType: 'family',
        ownerUserId: null,
        ownerName: null,
        title: 'Отпуск',
        icon: 'plane',
        targetAmount: 250000,
        targetDate: '2026-12-01',
        status: 'active',
        createdAt: '2026-01-01T00:00:00Z',
      },
      contributedAmount: 120000,
      remainingAmount: 130000,
      percent: 48,
      contributions: [
        {
          id: 'c-1',
          amount: 10000,
          comment: 'Зарплата',
          contributedAt: '2026-09-18',
          userId: 'user-1',
          userName: 'Иван',
        },
      ],
    }
    mockUseGoal.mockReturnValue({ data: summary, isLoading: false, isError: false, refetch: vi.fn() })
    mockUseGoals.mockReturnValue({ data: [makeGoal()], isLoading: false, isError: false, refetch: vi.fn() })

    renderPage()

    fireEvent.click(screen.getByRole('button', { name: 'История' }))
    const dialog = screen.getByRole('dialog', { name: 'История накоплений' })

    expect(within(dialog).getByText('Иван')).toBeInTheDocument()
    expect(within(dialog).getByText('Зарплата')).toBeInTheDocument()
    expect(within(dialog).getByText(/10 000/)).toBeInTheDocument()
  })

  it('удаление цели показывает точный текст подтверждения и вызывает мутацию (ТЗ, п.21)', async () => {
    mockUseGoals.mockReturnValue({ data: [makeGoal()], isLoading: false, isError: false, refetch: vi.fn() })

    renderPage()

    fireEvent.click(screen.getByRole('button', { name: /Действия с целью/i }))
    fireEvent.click(screen.getByRole('menuitem', { name: 'Удалить цель' }))

    const dialog = screen.getByRole('dialog', { name: 'Удалить цель?' })
    // Точный текст ТЗ разбит на два узла («Отпуск». + История...) — сравниваем весь текст диалога.
    expect(dialog.textContent).toContain('«Отпуск»')
    expect(dialog.textContent).toContain('История взносов также будет удалена.')

    fireEvent.click(within(dialog).getByRole('button', { name: 'Удалить' }))

    expect(await screen.findByText('Цель удалена')).toBeInTheDocument()
    expect(mockDeleteGoalMutateAsync).toHaveBeenCalledWith('goal-1')
  })

  it('отмена цели показывает диалог "Отменить цель?" и вызывает мутацию (ТЗ, п.22)', async () => {
    mockUseGoals.mockReturnValue({ data: [makeGoal()], isLoading: false, isError: false, refetch: vi.fn() })

    renderPage()

    fireEvent.click(screen.getByRole('button', { name: /Действия с целью/i }))
    fireEvent.click(screen.getByRole('menuitem', { name: 'Отменить цель' }))

    const dialog = screen.getByRole('dialog', { name: 'Отменить цель?' })
    fireEvent.click(within(dialog).getByRole('button', { name: 'Отменить цель' }))

    expect(await screen.findByText('Цель отменена')).toBeInTheDocument()
    expect(mockCancelGoalMutateAsync).toHaveBeenCalledWith('goal-1')
  })

  it('возобновление отменённой цели вызывает мутацию сразу, без диалога (ТЗ, п.23)', async () => {
    mockUseGoals.mockReturnValue({
      data: [makeGoal({ status: 'cancelled' })],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderPage()

    fireEvent.click(screen.getByRole('button', { name: 'Отменённые' }))
    fireEvent.click(screen.getByRole('button', { name: /Действия с целью/i }))
    fireEvent.click(screen.getByRole('menuitem', { name: 'Возобновить' }))

    expect(await screen.findByText('Цель возобновлена')).toBeInTheDocument()
    expect(mockResumeGoalMutateAsync).toHaveBeenCalledWith('goal-1')
  })
})
