import { createElement, useMemo, useState, type ReactNode } from 'react'
import { useSearchParams } from 'react-router-dom'
import { ArrowDownCircle, ArrowUpCircle, ChevronRight, Plus, Receipt, SlidersHorizontal } from 'lucide-react'
import {
  Amount,
  Button,
  Card,
  CardContent,
  EmptyState,
  ErrorState,
  Modal,
  PageTitle,
  Skeleton,
  Tabs,
  TabsList,
  TabsTrigger,
  Text,
} from '@/components/ui'
import { cn } from '@/utils/cn'
import { formatDate } from '@/utils/formatDate'
import { formatMoney } from '@/utils/formatMoney'
import { useDebouncedValue } from '@/hooks/useDebouncedValue'
import { useFamily } from '@/features/family/FamilyContext'
import { getCategoryIcon } from '@/features/categories/iconMap'
import { useCategories } from '@/features/categories/hooks'
import { isDefaultFilters, toQueryFilters, type TransactionFilters } from '@/features/transactions/filters'
import { useTransactionFilters } from '@/features/transactions/useTransactionFilters'
import { useHasAnyTransactions, useTransactionsList, useTransactionsTotals } from '@/features/transactions/hooks'
import { TransactionFiltersPanel } from '@/features/transactions/TransactionFiltersPanel'
import { TransactionFormModal } from '@/features/transactions/TransactionFormModal'
import { TransactionDetailModal } from '@/features/transactions/TransactionDetailModal'
import { DeleteTransactionModal } from '@/features/transactions/DeleteTransactionModal'
import { PlannedExpensesSection } from '@/features/plannedExpenses/PlannedExpensesSection'
import { RecurringTransactionsSection } from '@/features/recurringTransactions/RecurringTransactionsSection'
import type { TransactionListItem } from '@/features/transactions/api'
import type { TransactionType } from '@/features/transactions/schemas'

type OperationsSection = 'fact' | 'plan' | 'recurring'

const SECTION_PARAM = 'section'

/**
 * Страница "Операции" (Этап 9) — полноценный журнал операций семьи: фильтры
 * (тип/период/категория/поиск), сортировка, серверная пагинация, итоги
 * текущей выборки, просмотр/редактирование/удаление. Все данные и вся
 * фильтрация — из Supabase (см. features/transactions/api.ts,
 * supabase/migrations/0019_transactions_filtered_queries.sql), никакого
 * filter() по уже загруженному массиву на клиенте для основного списка нет.
 *
 * Этап 12 добавляет вкладку "План" (планируемые расходы), Этап 13 — вкладку
 * "Повторяющиеся" (правила автоматизации, recurring_transactions), обе прямо
 * сюда, а не отдельными страницами — предпочтительная архитектура из ТЗ
 * ("Операции ├── Факт ├── План └── Повторяющиеся"; ТЗ Этапа 13 явно допускает
 * интеграцию раздела в "Операции", требуя лишь, чтобы раздел существовал
 * функционально — этим условием и является отдельная вкладка). Активная
 * вкладка — в URL (?section=fact|plan|recurring, по умолчанию fact при
 * отсутствии параметра), тем же принципом, что и фильтры Факт-вкладки в
 * useTransactionFilters — независимый вызов useSearchParams() ничего не
 * ломает, т.к. оба места аккуратно сохраняют остальные параметры через спред
 * prev.
 */
export function TransactionsPage() {
  // Этап 16, п.20 — заголовок отражает то, что CHILD реально видит в журнале
  // (RLS transactions_select_role_aware уже с Этапа 3 отдаёт CHILD только его
  // собственные операции, см. миграцию 0010) — подпись "Мои операции" вместо
  // общего "Операции" не расширяет и не сужает доступ, только не вводит в
  // заблуждение по поводу того, чей это журнал.
  const { isChild } = useFamily()
  const [searchParams, setSearchParams] = useSearchParams()
  const rawSection = searchParams.get(SECTION_PARAM)
  const section: OperationsSection =
    rawSection === 'plan' ? 'plan' : rawSection === 'recurring' ? 'recurring' : 'fact'

  function setSection(next: OperationsSection) {
    setSearchParams(
      (prev) => {
        const nextParams = new URLSearchParams(prev)
        if (next === 'fact') nextParams.delete(SECTION_PARAM)
        else nextParams.set(SECTION_PARAM, next)
        return nextParams
      },
      { replace: false },
    )
  }

  const [creatingPlan, setCreatingPlan] = useState(false)
  const [creatingRecurring, setCreatingRecurring] = useState(false)

  const {
    filters,
    searchInput,
    setType,
    setPeriod,
    setCustomRange,
    setCategory,
    setSearchInput,
    setSort,
    resetFilters,
  } = useTransactionFilters()

  // Debounce (ТЗ, п.6) — сам ввод (searchInput) обновляет поле мгновенно,
  // а в реальный запрос попадает только "устоявшееся" значение спустя 350мс.
  const debouncedSearch = useDebouncedValue(searchInput, 350)
  const effectiveFilters = useMemo<TransactionFilters>(
    () => ({ ...filters, search: debouncedSearch }),
    [filters, debouncedSearch],
  )
  const queryFilters = useMemo(() => toQueryFilters(effectiveFilters), [effectiveFilters])

  const { data: categories } = useCategories()
  const { data: hasAnyTransactions, isLoading: hasAnyLoading } = useHasAnyTransactions()
  const {
    data,
    isLoading,
    isFetching,
    isError,
    refetch,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
  } = useTransactionsList(queryFilters)
  const { data: totals, isLoading: totalsLoading } = useTransactionsTotals(queryFilters)

  const items = useMemo(() => data?.pages.flatMap((page) => page.items) ?? [], [data])

  const [filtersOpen, setFiltersOpen] = useState(false)
  const [addType, setAddType] = useState<TransactionType | null>(null)
  const [detailTransaction, setDetailTransaction] = useState<TransactionListItem | null>(null)
  const [editingTransaction, setEditingTransaction] = useState<TransactionListItem | null>(null)
  const [deletingTransaction, setDeletingTransaction] = useState<TransactionListItem | null>(null)

  const canReset = !isDefaultFilters(filters) || searchInput.trim() !== ''

  function handleEditFromDetail() {
    if (!detailTransaction) return
    setEditingTransaction(detailTransaction)
    setDetailTransaction(null)
  }

  function handleDeleteFromDetail() {
    if (!detailTransaction) return
    setDeletingTransaction(detailTransaction)
    setDetailTransaction(null)
  }

  // Два РАЗНЫХ пустых состояния (ТЗ, п.22): у семьи вообще нет операций vs
  // операции есть, но под текущие фильтры ничего не подходит. hasAnyTransactions
  // — отдельный дешёвый count-запрос (см. features/transactions/hooks.ts),
  // не зависящий от текущих фильтров.
  const showEmptyOverall = !isLoading && !isError && !hasAnyLoading && hasAnyTransactions === false
  const showEmptyFiltered = !isLoading && !isError && !showEmptyOverall && items.length === 0

  const filtersPanel = (
    <TransactionFiltersPanel
      filters={filters}
      searchInput={searchInput}
      categories={categories}
      canReset={canReset}
      onPeriod={setPeriod}
      onCustomRange={setCustomRange}
      onCategory={setCategory}
      onSearchInput={setSearchInput}
      onSort={setSort}
      onReset={resetFilters}
    />
  )

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between gap-4">
        <PageTitle>{isChild ? 'Мои операции' : 'Операции'}</PageTitle>
        {section === 'fact' && (
          <Button onClick={() => setAddType('expense')}>
            <Plus className="size-4" aria-hidden="true" />
            Добавить
          </Button>
        )}
        {section === 'plan' && (
          <Button onClick={() => setCreatingPlan(true)}>
            <Plus className="size-4" aria-hidden="true" />
            Запланировать
          </Button>
        )}
        {section === 'recurring' && (
          <Button onClick={() => setCreatingRecurring(true)}>
            <Plus className="size-4" aria-hidden="true" />
            Новое правило
          </Button>
        )}
      </div>

      <Tabs value={section} onValueChange={(value) => setSection(value as OperationsSection)}>
        <TabsList>
          <TabsTrigger value="fact">Факт</TabsTrigger>
          <TabsTrigger value="plan">План</TabsTrigger>
          <TabsTrigger value="recurring">Повторяющиеся</TabsTrigger>
        </TabsList>
      </Tabs>

      {section === 'fact' && (
        <>
          <Tabs value={filters.type} onValueChange={(value) => setType(value as TransactionFilters['type'])}>
            <TabsList>
              <TabsTrigger value="all">Все</TabsTrigger>
              <TabsTrigger value="expense">Расходы</TabsTrigger>
              <TabsTrigger value="income">Доходы</TabsTrigger>
            </TabsList>
          </Tabs>

          <TotalsBar totals={totals} isLoading={totalsLoading && !totals} />

          {/* Desktop — раскрытая панель фильтров (ТЗ, п.2). */}
          <Card className="hidden lg:block">
            <CardContent className="pt-6">{filtersPanel}</CardContent>
          </Card>

          {/* Мобильный — фильтры через Bottom Sheet (Modal уже стилизован как
              bottom sheet на узких экранах, см. components/ui/Modal.tsx). */}
          <div className="lg:hidden">
            <Button variant="outline" onClick={() => setFiltersOpen(true)} className="relative">
              <SlidersHorizontal className="size-4" aria-hidden="true" />
              Фильтры
              {canReset && (
                <span
                  className="absolute -right-1 -top-1 flex size-2.5 rounded-full bg-primary"
                  aria-hidden="true"
                />
              )}
            </Button>

            <Modal open={filtersOpen} onClose={() => setFiltersOpen(false)} title="Фильтры">
              <div className="flex flex-col gap-4">
                {filtersPanel}
                <Button onClick={() => setFiltersOpen(false)}>Показать результаты</Button>
              </div>
            </Modal>
          </div>

          <Card>
            <CardContent className="pt-6">
              {isLoading && (
                <div className="flex flex-col gap-3" role="status" aria-label="Загружаем операции…">
                  {[0, 1, 2, 3].map((i) => (
                    <Skeleton key={i} className="h-14 w-full" />
                  ))}
                </div>
              )}

              {isError && <ErrorState title="Не удалось загрузить операции" onRetry={() => void refetch()} />}

              {showEmptyOverall && (
                <EmptyState
                  icon={Receipt}
                  title="Операций пока нет"
                  description="Добавьте первую операцию, чтобы начать вести бюджет семьи."
                  action={<Button onClick={() => setAddType('expense')}>Добавить первую операцию</Button>}
                />
              )}

              {showEmptyFiltered && (
                <EmptyState
                  icon={Receipt}
                  title="По выбранным фильтрам ничего не найдено"
                  description="Попробуйте изменить период, категорию или условия поиска."
                  action={
                    <Button variant="secondary" onClick={resetFilters}>
                      Сбросить фильтры
                    </Button>
                  }
                />
              )}

              {!isLoading && !isError && items.length > 0 && (
                <>
                  <ul className={cn('flex flex-col divide-y divide-border', isFetching && 'opacity-60 transition-opacity')}>
                    {items.map((transaction) => (
                      <TransactionRow
                        key={transaction.id}
                        transaction={transaction}
                        onOpen={() => setDetailTransaction(transaction)}
                      />
                    ))}
                  </ul>

                  {hasNextPage && (
                    <div className="pt-4">
                      <Button
                        variant="outline"
                        className="w-full"
                        onClick={() => void fetchNextPage()}
                        isLoading={isFetchingNextPage}
                        disabled={isFetchingNextPage}
                      >
                        Загрузить ещё
                      </Button>
                    </div>
                  )}
                </>
              )}
            </CardContent>
          </Card>

          <TransactionFormModal
            open={addType !== null}
            defaultType={addType ?? 'expense'}
            onClose={() => setAddType(null)}
          />

          <TransactionFormModal
            open={Boolean(editingTransaction)}
            defaultType={editingTransaction?.type ?? 'expense'}
            transaction={editingTransaction}
            onClose={() => setEditingTransaction(null)}
          />

          <TransactionDetailModal
            transaction={detailTransaction}
            onClose={() => setDetailTransaction(null)}
            onEdit={handleEditFromDetail}
            onDelete={handleDeleteFromDetail}
          />

          <DeleteTransactionModal transaction={deletingTransaction} onClose={() => setDeletingTransaction(null)} />
        </>
      )}

      {section === 'plan' && (
        <PlannedExpensesSection createOpen={creatingPlan} onCreateClose={() => setCreatingPlan(false)} />
      )}

      {section === 'recurring' && (
        <RecurringTransactionsSection createOpen={creatingRecurring} onCreateClose={() => setCreatingRecurring(false)} />
      )}
    </div>
  )
}

function TotalsBar({
  totals,
  isLoading,
}: {
  totals: { income: number; expenses: number; balance: number } | undefined
  isLoading: boolean
}) {
  return (
    <Card>
      <CardContent className="grid grid-cols-3 gap-3 pt-6">
        {isLoading ? (
          [0, 1, 2].map((i) => <Skeleton key={i} className="h-12 w-full" />)
        ) : (
          <>
            <TotalsItem label="Доходы">
              <Amount value={totals?.income ?? 0} size="sm" tone="success" showSign />
            </TotalsItem>
            <TotalsItem label="Расходы">
              <Amount value={-(totals?.expenses ?? 0)} size="sm" tone="danger" showSign />
            </TotalsItem>
            <TotalsItem label="Баланс">
              <Amount value={totals?.balance ?? 0} size="sm" tone="auto" showSign />
            </TotalsItem>
          </>
        )}
      </CardContent>
    </Card>
  )
}

function TotalsItem({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex flex-col gap-1">
      <Text variant="small">{label}</Text>
      {children}
    </div>
  )
}

function TransactionRow({ transaction, onOpen }: { transaction: TransactionListItem; onOpen: () => void }) {
  const isIncome = transaction.type === 'income'
  const title = isIncome && transaction.incomeSource ? transaction.incomeSource : (transaction.comment ?? (isIncome ? 'Доход' : 'Расход'))
  const signedAmount = isIncome ? transaction.amount : -transaction.amount
  const ariaLabel = `${isIncome ? 'Доход' : 'Расход'} ${title}, ${formatMoney(signedAmount)}, ${formatDate(transaction.transactionDate)}. Открыть подробности`

  return (
    <li>
      <button
        type="button"
        onClick={onOpen}
        aria-label={ariaLabel}
        className="flex w-full items-center gap-3 rounded-md py-3 text-left transition-colors first:pt-0 last:pb-0 hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      >
        <div
          className={cn(
            'flex size-9 shrink-0 items-center justify-center rounded-full',
            isIncome ? 'bg-success-soft text-success' : 'bg-muted text-muted-foreground',
          )}
        >
          {isIncome ? (
            <ArrowUpCircle className="size-4" aria-hidden="true" />
          ) : (
            <ArrowDownCircle className="size-4" aria-hidden="true" />
          )}
        </div>

        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-medium text-foreground">{title}</p>
          <p className="flex items-center gap-1 truncate text-xs text-muted-foreground">
            <span>{formatDate(transaction.transactionDate)}</span>
            {!isIncome && (
              <>
                <span aria-hidden="true">·</span>
                {/* createElement — см. комментарий в CategoryPickerModal.tsx про
                    react-hooks/static-components и динамический выбор иконки. */}
                {createElement(getCategoryIcon(transaction.category?.icon), {
                  className: 'size-3 shrink-0',
                  'aria-hidden': true,
                })}
                <span className="truncate">{transaction.category?.name ?? 'Без категории'}</span>
              </>
            )}
          </p>
          {isIncome && transaction.incomeSource && transaction.comment && (
            <p className="truncate text-xs text-muted-foreground">{transaction.comment}</p>
          )}
        </div>

        <Amount value={signedAmount} size="sm" tone="auto" showSign />
        <ChevronRight className="size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
      </button>
    </li>
  )
}
