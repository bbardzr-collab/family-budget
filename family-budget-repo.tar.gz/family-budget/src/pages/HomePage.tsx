import { createElement, useMemo, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import {
  ArrowDownCircle,
  ArrowUpCircle,
  CalendarDays,
  Inbox,
  Mail,
  PiggyBank,
  Target,
  Users,
  Wallet,
} from 'lucide-react'
import {
  Amount,
  Badge,
  Button,
  Card,
  CardContent,
  EmptyState,
  ErrorState,
  PageTitle,
  ProgressBar,
  SectionTitle,
  Skeleton,
  Text,
  Avatar,
} from '@/components/ui'
import { useAuth } from '@/features/auth/AuthContext'
import { useFamily } from '@/features/family/FamilyContext'
import { useFamilyMembers } from '@/features/family/hooks'
import { CreateFamilyForm } from '@/features/family/CreateFamilyForm'
import { useDashboardSummary, useRecentTransactions } from '@/features/dashboard/hooks'
import { getCurrentMonthRange } from '@/features/dashboard/period'
import { getGreeting } from '@/features/dashboard/greeting'
import { QUICK_ACTIONS, type QuickActionItem } from '@/features/dashboard/quickActions'
import { QuickActionInfoModal } from '@/features/dashboard/QuickActionInfoModal'
import { formatDate, formatMonthYear, toDateInputValue } from '@/utils/formatDate'
import { formatMoney } from '@/utils/formatMoney'
import type { DashboardSummary, RecentTransaction } from '@/features/dashboard/api'
import { TransactionFormModal } from '@/features/transactions/TransactionFormModal'
import type { TransactionType } from '@/features/transactions/schemas'
import { useBudgetSummary } from '@/features/budgets/hooks'
import { toPeriodMonthValue } from '@/features/budgets/period'
import { useGoals } from '@/features/goals/hooks'
import { sortActiveGoals } from '@/features/goals/sort'
import { getGoalIcon } from '@/features/goals/iconMap'
import { usePlannedExpenses } from '@/features/plannedExpenses/hooks'
import { sortPlannedExpenses } from '@/features/plannedExpenses/sort'
import { useRecurringTransactions } from '@/features/recurringTransactions/hooks'
import { getRecurringTransactionStatus, sortRecurringTransactions } from '@/features/recurringTransactions/status'
import { RECURRING_STATUS_BADGE_VARIANT, RECURRING_STATUS_LABELS } from '@/features/recurringTransactions/labels'
import type { RecurringTransactionListItem } from '@/features/recurringTransactions/api'

/**
 * Главная страница /app — полноценный Dashboard (Этап 6).
 *
 * Три возможных состояния определяются FamilyContext (Этап 5):
 *  - familyLoading → DashboardSkeleton (мы ещё не знаем, есть ли семья);
 *  - !hasFamily → NoFamilyState («Создайте семью» / «У меня есть приглашение»);
 *  - hasFamily → сам Dashboard (приветствие, финансовая сводка, бюджет,
 *    быстрые действия, последние операции, ближайшие события, семья).
 *
 * Операции, бюджеты, цели, планы и т.д. на этом этапе НЕ создаются —
 * соответствующие блоки архитектурно подготовлены (реальные React Query
 * hooks там, где данные уже есть — summary/recent transactions/участники), а
 * там, где источника данных ещё нет (бюджет, ближайшие события) — честно
 * показано пустое состояние без фиктивных цифр (ТЗ, п.33).
 */
export function HomePage() {
  const { profile } = useAuth()
  const { currentFamily, hasFamily, loading: familyLoading } = useFamily()

  if (familyLoading) {
    return <DashboardSkeleton />
  }

  if (!hasFamily || !currentFamily) {
    return <NoFamilyState />
  }

  return <Dashboard familyName={currentFamily.name} fullName={profile?.full_name ?? null} />
}

/* ───────────────────────────── No family ───────────────────────────── */

/** Этап 6, п.19. Переиспользует форму создания семьи и пояснение про ссылку-приглашение из Этапа 5. */
function NoFamilyState() {
  const [mode, setMode] = useState<'none' | 'create' | 'join'>('none')

  return (
    <div className="flex flex-col gap-6">
      <div>
        <PageTitle>Добро пожаловать!</PageTitle>
        <Text variant="secondary" className="mt-1">
          Создайте семью или присоединитесь к существующей.
        </Text>
      </div>

      <div className="flex flex-col gap-3 sm:flex-row">
        <Button
          variant={mode === 'create' ? 'primary' : 'secondary'}
          onClick={() => setMode((current) => (current === 'create' ? 'none' : 'create'))}
        >
          Создать семью
        </Button>
        <Button
          variant={mode === 'join' ? 'primary' : 'outline'}
          onClick={() => setMode((current) => (current === 'join' ? 'none' : 'join'))}
        >
          У меня есть приглашение
        </Button>
      </div>

      {mode === 'create' && (
        <Card>
          <CardContent className="pt-6">
            <CreateFamilyForm />
          </CardContent>
        </Card>
      )}

      {mode === 'join' && (
        <Card>
          <CardContent className="flex items-start gap-2 pt-6 text-sm text-muted-foreground">
            <Mail className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
            <p>
              Присоединение к семье возможно только по ссылке-приглашению, которую прислал её
              администратор — она выглядит как «…/invite/…». Откройте эту ссылку, чтобы принять
              приглашение.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

/* ───────────────────────────── Loading skeleton ───────────────────────────── */

/** Этап 6, п.20 — пока не известно, есть ли семья вообще (не показываем 0 ₽ как настоящий ноль). */
function DashboardSkeleton() {
  return (
    <div className="flex flex-col gap-6" role="status" aria-label="Загружаем панель…">
      <div className="flex flex-col gap-2">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-4 w-40" />
      </div>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        {[0, 1, 2].map((i) => (
          <Card key={i}>
            <CardContent className="flex flex-col gap-2 pt-6">
              <Skeleton className="h-4 w-20" />
              <Skeleton className="h-8 w-32" />
            </CardContent>
          </Card>
        ))}
      </div>
      <Skeleton className="h-32 w-full rounded-lg" />
      <Skeleton className="h-24 w-full rounded-lg" />
    </div>
  )
}

/* ───────────────────────────── Dashboard ───────────────────────────── */

interface DashboardProps {
  familyName: string
  fullName: string | null
}

function Dashboard({ familyName, fullName }: DashboardProps) {
  const { startDate } = getCurrentMonthRange()

  return (
    <div className="flex flex-col gap-6">
      <div>
        <PageTitle>{getGreeting(fullName)}</PageTitle>
        <Text variant="secondary" className="mt-1">
          Семья «{familyName}» · {formatMonthYear(startDate)}
        </Text>
      </div>

      <SummarySection />

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        <BudgetPreviewSection />
        <QuickActionsSection />
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        <GoalsPreviewSection />
        <UpcomingEventsSection />
      </div>

      <RecurringPreviewSection />

      <RecentOperationsSection />

      <FamilyPreviewSection />
    </div>
  )
}

/* ───────────────────────────── Financial summary ───────────────────────────── */

/** Этап 6, п.5, 7, 8, 10, 11. Реальные данные из get_dashboard_summary (Postgres aggregate). */
function SummarySection() {
  const { data, isLoading, isError, error, refetch } = useDashboardSummary()

  if (isError) {
    return (
      <Card>
        <CardContent className="pt-6">
          <ErrorState
            title="Не удалось загрузить данные"
            description={getGenericErrorMessage(error)}
            onRetry={() => void refetch()}
          />
        </CardContent>
      </Card>
    )
  }

  return <SummaryCards summary={data} isLoading={isLoading} />
}

function SummaryCards({
  summary,
  isLoading,
}: {
  summary: DashboardSummary | undefined
  isLoading: boolean
}) {
  if (isLoading || !summary) {
    return (
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        {[0, 1, 2].map((i) => (
          <Card key={i}>
            <CardContent className="flex flex-col gap-2 pt-6">
              <Skeleton className="h-4 w-20" />
              <Skeleton className="h-8 w-32" />
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  const balanceNegative = summary.balance < 0

  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
      <SummaryCard title="Доходы" amount={summary.income} icon={ArrowUpCircle} tone="success" />
      <SummaryCard title="Расходы" amount={summary.expenses} icon={ArrowDownCircle} tone="neutral" />
      <SummaryCard
        title="Осталось"
        amount={summary.balance}
        icon={Wallet}
        tone={balanceNegative ? 'danger' : 'success'}
        secondary={balanceNegative ? 'Расходы превышают доходы' : undefined}
      />
    </div>
  )
}

interface SummaryCardProps {
  title: string
  amount: number
  icon: typeof Wallet
  tone: 'success' | 'danger' | 'neutral'
  secondary?: string
}

const SUMMARY_ICON_TONE_CLASSES: Record<SummaryCardProps['tone'], string> = {
  success: 'bg-success-soft text-success',
  danger: 'bg-danger-soft text-danger',
  neutral: 'bg-muted text-muted-foreground',
}

/** Этап 6, п.10 — карточка с title/amount/icon/secondary, не на весь экран. */
function SummaryCard({ title, amount, icon: Icon, tone, secondary }: SummaryCardProps) {
  return (
    <Card>
      <CardContent className="flex flex-col gap-3 pt-6">
        <div className="flex items-center justify-between">
          <Text variant="secondary">{title}</Text>
          <div className={`flex size-9 items-center justify-center rounded-full ${SUMMARY_ICON_TONE_CLASSES[tone]}`}>
            <Icon className="size-5" aria-hidden="true" />
          </div>
        </div>
        <Amount value={amount} size="lg" tone={tone === 'danger' ? 'danger' : 'neutral'} />
        {secondary && (
          <Badge variant="danger" className="w-fit">
            {secondary}
          </Badge>
        )}
      </CardContent>
    </Card>
  )
}

/* ───────────────────────────── Budget preview ───────────────────────────── */

/**
 * Реальный бюджет текущего месяца (Этап 10, п.22) — та же сводка
 * (get_monthly_budget_summary), что и на полноценной странице /app/budget,
 * TanStack Query кэширует запрос по ключу (familyId, periodMonth), так что
 * переход на /app/budget за текущий месяц не делает повторный fetch.
 *
 * Бюджет НИКОГДА не создаётся автоматически (ТЗ, п.8) — если для текущего
 * месяца бюджета нет, честно показывается пустое состояние с кнопкой
 * "Создать бюджет", а не "0 ₽" как будто бюджет уже существует.
 */
function BudgetPreviewSection() {
  const navigate = useNavigate()
  const periodMonth = useMemo(() => toPeriodMonthValue(new Date()), [])
  const { data: summary, isLoading, isError, refetch } = useBudgetSummary(periodMonth)
  const budget = summary?.budget ?? null

  return (
    <div className="flex flex-col gap-3">
      <SectionTitle>Бюджет месяца</SectionTitle>
      <Card className="flex-1">
        <CardContent className="flex h-full flex-col gap-3 pt-6">
          {isLoading && (
            <div className="flex flex-col gap-2" role="status" aria-label="Загружаем бюджет…">
              <Skeleton className="h-8 w-32" />
              <Skeleton className="h-4 w-40" />
            </div>
          )}

          {!isLoading && isError && (
            <ErrorState title="Не удалось загрузить бюджет" onRetry={() => void refetch()} />
          )}

          {!isLoading && !isError && !budget && (
            <>
              <div className="flex size-11 items-center justify-center rounded-xl bg-primary-soft text-primary">
                <PiggyBank className="size-5" aria-hidden="true" />
              </div>
              <Text variant="secondary">Бюджет на этот месяц не создан.</Text>
              <Button variant="outline" size="sm" onClick={() => navigate('/app/budget')}>
                Создать бюджет
              </Button>
            </>
          )}

          {!isLoading && !isError && budget && summary && (
            <>
              <div className="flex items-center justify-between gap-3">
                <Text variant="secondary">Бюджет месяца</Text>
                <Amount value={budget.totalAmount} size="md" />
              </div>
              <ProgressBar value={summary.totalSpent} max={budget.totalAmount} />
              <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-1 text-sm">
                <span className="text-muted-foreground">Потрачено {formatMoney(summary.totalSpent)}</span>
                <span
                  className={summary.totalRemaining < 0 ? 'font-medium text-danger' : 'font-medium text-foreground'}
                >
                  Осталось {formatMoney(summary.totalRemaining)}
                </span>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="mt-auto self-start"
                onClick={() => navigate('/app/budget')}
              >
                Подробнее
              </Button>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

/* ───────────────────────────── Goals preview ───────────────────────────── */

/**
 * Блок "Финансовые цели" на Dashboard (Этап 11, п.31) — несколько ближайших
 * активных целей (та же сортировка "сначала ближайшая target_date", что и
 * на /app/goals, см. features/goals/sort.ts), без какой-либо аналитики —
 * только сумма/цель/процент, как в примере ТЗ. Данные — тот же useGoals()
 * (get_goals_list, миграция 0026), что и полная страница целей — общий кэш
 * TanStack Query, повторного запроса при переходе на /app/goals не будет.
 */
function GoalsPreviewSection() {
  const navigate = useNavigate()
  const { data: goals, isLoading, isError, refetch } = useGoals()
  const nearestActiveGoals = sortActiveGoals((goals ?? []).filter((g) => g.status === 'active')).slice(0, 3)

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <SectionTitle>Финансовые цели</SectionTitle>
        <Button variant="ghost" size="sm" onClick={() => navigate('/app/goals')}>
          Все цели
        </Button>
      </div>
      <Card className="flex-1">
        <CardContent className="flex h-full flex-col gap-3 pt-6">
          {isLoading && (
            <div className="flex flex-col gap-2" role="status" aria-label="Загружаем цели…">
              <Skeleton className="h-8 w-32" />
              <Skeleton className="h-4 w-40" />
            </div>
          )}

          {!isLoading && isError && (
            <ErrorState title="Не удалось загрузить цели" onRetry={() => void refetch()} />
          )}

          {!isLoading && !isError && nearestActiveGoals.length === 0 && (
            <EmptyState
              icon={Target}
              title="Финансовых целей пока нет"
              action={
                <Button variant="outline" size="sm" onClick={() => navigate('/app/goals')}>
                  Создать цель
                </Button>
              }
            />
          )}

          {!isLoading && !isError && nearestActiveGoals.length > 0 && (
            <ul className="flex flex-col divide-y divide-border">
              {nearestActiveGoals.map((goal) => (
                <li key={goal.id} className="flex items-center gap-3 py-3 first:pt-0 last:pb-0">
                  <div className="flex size-9 shrink-0 items-center justify-center rounded-full bg-primary-soft text-primary">
                    {createElement(getGoalIcon(goal.icon), { className: 'size-4', 'aria-hidden': true })}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-foreground">{goal.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {formatMoney(goal.contributedAmount)} / {formatMoney(goal.targetAmount)}
                    </p>
                  </div>
                  <span className="shrink-0 text-sm font-semibold tabular-nums text-foreground">
                    {goal.percent}%
                  </span>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

/* ───────────────────────────── Quick actions ───────────────────────────── */

/**
 * Этап 6, п.16 — визуальная заготовка; с Этапа 7 действия "Расход"/"Доход"
 * стали рабочими (открывают TransactionFormModal), "Цель"/"План" по-прежнему
 * показывают заглушку — соответствующая бизнес-логика появится на Этапах 11-13.
 */
function QuickActionsSection() {
  const [activeAction, setActiveAction] = useState<QuickActionItem | null>(null)
  const [transactionType, setTransactionType] = useState<TransactionType | null>(null)

  function handleActionClick(action: QuickActionItem) {
    if (action.key === 'expense' || action.key === 'income') {
      setTransactionType(action.key)
    } else {
      setActiveAction(action)
    }
  }

  return (
    <div className="flex flex-col gap-3">
      <SectionTitle>Быстрые действия</SectionTitle>
      <Card className="flex-1">
        <CardContent className="grid h-full grid-cols-2 gap-3 pt-6">
          {QUICK_ACTIONS.map((action) => (
            <button
              key={action.key}
              type="button"
              onClick={() => handleActionClick(action)}
              className="flex min-h-16 flex-col items-center justify-center gap-1.5 rounded-lg border border-border bg-card text-sm font-medium text-foreground transition-colors hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
            >
              <action.icon className="size-5 text-primary" aria-hidden="true" />
              {action.label}
            </button>
          ))}
        </CardContent>
      </Card>

      <QuickActionInfoModal action={activeAction} onClose={() => setActiveAction(null)} />
      <TransactionFormModal
        open={transactionType !== null}
        defaultType={transactionType ?? 'expense'}
        onClose={() => setTransactionType(null)}
      />
    </div>
  )
}

/* ───────────────────────────── Recent operations ───────────────────────────── */

/** Этап 6, п.13-14 — реальный запрос (limit + сортировка на стороне БД); с Этапа 7 EmptyState-кнопка рабочая. */
function RecentOperationsSection() {
  const { data: transactions, isLoading, isError, error, refetch } = useRecentTransactions()
  const [addType, setAddType] = useState<TransactionType | null>(null)

  return (
    <div className="flex flex-col gap-3">
      <SectionTitle>Последние операции</SectionTitle>

      <Card>
        <CardContent className="pt-6">
          {isLoading && (
            <div className="flex flex-col gap-3" role="status" aria-label="Загружаем операции…">
              {[0, 1, 2].map((i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          )}

          {isError && (
            <ErrorState
              title="Не удалось загрузить данные"
              description={getGenericErrorMessage(error)}
              onRetry={() => void refetch()}
            />
          )}

          {!isLoading && !isError && transactions && transactions.length === 0 && (
            <EmptyState
              icon={Inbox}
              title="Пока нет операций"
              description="Добавьте первый доход или расход, чтобы начать вести бюджет семьи."
              action={
                <Button size="sm" onClick={() => setAddType('expense')}>
                  Добавить операцию
                </Button>
              }
            />
          )}

          {!isLoading && !isError && transactions && transactions.length > 0 && (
            <ul className="flex flex-col divide-y divide-border">
              {transactions.map((transaction) => (
                <RecentTransactionRow key={transaction.id} transaction={transaction} />
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      <TransactionFormModal
        open={addType !== null}
        defaultType={addType ?? 'expense'}
        onClose={() => setAddType(null)}
      />
    </div>
  )
}

function RecentTransactionRow({ transaction }: { transaction: RecentTransaction }) {
  const isIncome = transaction.type === 'income'
  return (
    <li className="flex items-center gap-3 py-3 first:pt-0 last:pb-0">
      <div
        className={`flex size-9 items-center justify-center rounded-full ${
          isIncome ? 'bg-success-soft text-success' : 'bg-muted text-muted-foreground'
        }`}
      >
        {isIncome ? (
          <ArrowUpCircle className="size-4" aria-hidden="true" />
        ) : (
          <ArrowDownCircle className="size-4" aria-hidden="true" />
        )}
      </div>
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium text-foreground">
          {transaction.comment || (isIncome ? 'Доход' : 'Расход')}
        </p>
        <p className="text-xs text-muted-foreground">{formatDate(transaction.transactionDate)}</p>
      </div>
      <Amount value={isIncome ? transaction.amount : -transaction.amount} size="sm" tone="auto" showSign />
    </li>
  )
}

/* ───────────────────────────── Upcoming events ───────────────────────────── */

/**
 * Блок "Ближайшие планы" на Dashboard (Этап 12, п.19) — несколько ближайших
 * АКТИВНЫХ (status='planned') планов, отсортированных по planned_date (та же
 * sortPlannedExpenses, что и на /app/transactions?section=plan). Отменённые
 * никогда не показываются здесь, выполненные тоже — это блок именно
 * будущих, ещё предстоящих трат, а не полная история планов (это одно и то
 * же различие active/completed/cancelled, что уже проведено в
 * GoalsPreviewSection выше). Данные — тот же usePlannedExpenses(), что и
 * полная вкладка "План" — общий кэш TanStack Query (см.
 * features/plannedExpenses/hooks.ts), повторного запроса при переходе на
 * /app/transactions?section=plan не будет.
 */
function UpcomingEventsSection() {
  const navigate = useNavigate()
  const { data: plannedExpenses, isLoading, isError, refetch } = usePlannedExpenses()
  const nearestPlans = sortPlannedExpenses((plannedExpenses ?? []).filter((p) => p.status === 'planned')).slice(0, 3)

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <SectionTitle>Ближайшие планы</SectionTitle>
        <Button variant="ghost" size="sm" onClick={() => navigate('/app/transactions?section=plan')}>
          Все планы
        </Button>
      </div>
      <Card className="flex-1">
        <CardContent className="flex h-full flex-col gap-3 pt-6">
          {isLoading && (
            <div className="flex flex-col gap-2" role="status" aria-label="Загружаем планы…">
              <Skeleton className="h-8 w-32" />
              <Skeleton className="h-4 w-40" />
            </div>
          )}

          {!isLoading && isError && (
            <ErrorState title="Не удалось загрузить планы" onRetry={() => void refetch()} />
          )}

          {!isLoading && !isError && nearestPlans.length === 0 && (
            <EmptyState
              icon={CalendarDays}
              title="Ближайших планов пока нет"
              action={
                <Button variant="outline" size="sm" onClick={() => navigate('/app/transactions?section=plan')}>
                  Запланировать расход
                </Button>
              }
            />
          )}

          {!isLoading && !isError && nearestPlans.length > 0 && (
            <ul className="flex flex-col divide-y divide-border">
              {nearestPlans.map((plan) => (
                <li key={plan.id} className="flex items-center gap-3 py-3 first:pt-0 last:pb-0">
                  <div className="flex size-9 shrink-0 items-center justify-center rounded-full bg-muted text-muted-foreground">
                    <CalendarDays className="size-4" aria-hidden="true" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-foreground">{plan.title}</p>
                    <p className="text-xs text-muted-foreground">{formatDate(plan.plannedDate)}</p>
                  </div>
                  <span className="shrink-0 text-sm font-semibold tabular-nums text-foreground">
                    {formatMoney(plan.amount)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

/* ───────────────────────────── Recurring preview ───────────────────────────── */

/**
 * Блок "Ближайшие повторяющиеся операции" (Этап 13) — несколько ближайших
 * ДЕЙСТВУЮЩИХ правил (активных или уже просроченных — оба состояния
 * пользователю важно видеть здесь; "На паузе" и "Истёк срок" в этот блок не
 * попадают, тот же принцип, что и у GoalsPreviewSection/UpcomingEventsSection
 * — превью, а не полный список). Сами правила ничего не создают в
 * transactions — это только напоминание пользователю следить за
 * расписанием; подготовленные системой напоминания на подтверждение
 * находятся во вкладке "План" (см. UpcomingEventsSection выше и
 * useAutoGenerateDuePlannedExpenses в AppLayout). Данные — тот же
 * useRecurringTransactions(), что и полная вкладка "Повторяющиеся" — общий
 * кэш TanStack Query, повторного запроса при переходе туда не будет.
 */
function RecurringPreviewSection() {
  const navigate = useNavigate()
  const { data: recurringTransactions, isLoading, isError, refetch } = useRecurringTransactions()
  const today = toDateInputValue()
  const relevant = (recurringTransactions ?? []).filter((item) => {
    const status = getRecurringTransactionStatus(item, today)
    return status === 'active' || status === 'overdue'
  })
  const nearest = sortRecurringTransactions(relevant).slice(0, 3)

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <SectionTitle>Ближайшие повторяющиеся операции</SectionTitle>
        <Button variant="ghost" size="sm" onClick={() => navigate('/app/transactions?section=recurring')}>
          Все правила
        </Button>
      </div>
      <Card>
        <CardContent className="pt-6">
          {isLoading && (
            <div className="flex flex-col gap-2" role="status" aria-label="Загружаем повторяющиеся операции…">
              <Skeleton className="h-8 w-32" />
              <Skeleton className="h-4 w-40" />
            </div>
          )}

          {!isLoading && isError && (
            <ErrorState title="Не удалось загрузить повторяющиеся операции" onRetry={() => void refetch()} />
          )}

          {!isLoading && !isError && nearest.length === 0 && (
            <EmptyState
              icon={CalendarDays}
              title="Повторяющихся операций пока нет"
              action={
                <Button variant="outline" size="sm" onClick={() => navigate('/app/transactions?section=recurring')}>
                  Настроить правило
                </Button>
              }
            />
          )}

          {!isLoading && !isError && nearest.length > 0 && (
            <ul className="flex flex-col divide-y divide-border">
              {nearest.map((item) => (
                <RecurringPreviewRow key={item.id} item={item} today={today} />
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

function RecurringPreviewRow({ item, today }: { item: RecurringTransactionListItem; today: string }) {
  const isIncome = item.type === 'income'
  const status = getRecurringTransactionStatus(item, today)
  const title = item.category?.name ?? item.incomeSource ?? (isIncome ? 'Доход' : 'Расход')

  return (
    <li className="flex items-center gap-3 py-3 first:pt-0 last:pb-0">
      <div
        className={`flex size-9 shrink-0 items-center justify-center rounded-full ${
          isIncome ? 'bg-success-soft text-success' : 'bg-muted text-muted-foreground'
        }`}
      >
        {isIncome ? (
          <ArrowUpCircle className="size-4" aria-hidden="true" />
        ) : (
          <ArrowDownCircle className="size-4" aria-hidden="true" />
        )}
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-1.5">
          <p className="truncate text-sm font-medium text-foreground">{title}</p>
          {status === 'overdue' && (
            <Badge variant={RECURRING_STATUS_BADGE_VARIANT.overdue}>{RECURRING_STATUS_LABELS.overdue}</Badge>
          )}
        </div>
        <p className="text-xs text-muted-foreground">{formatDate(item.nextRunDate)}</p>
      </div>
      <span className="shrink-0 text-sm font-semibold tabular-nums text-foreground">{formatMoney(item.amount)}</span>
    </li>
  )
}

/* ───────────────────────────── Family preview ───────────────────────────── */

/** Этап 6, п.18 — реальные участники семьи, только avatar+имя (без чувствительных данных). */
function FamilyPreviewSection() {
  const { currentFamily } = useFamily()
  const { data: members, isLoading } = useFamilyMembers(currentFamily?.id)
  const preview = (members ?? []).slice(0, 5)

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <SectionTitle>Семья</SectionTitle>
        <Link to="/app/family" className="text-sm font-medium text-primary hover:underline">
          Все участники
        </Link>
      </div>
      <Card className="flex-1">
        <CardContent className="pt-6">
          {isLoading && (
            <div className="flex gap-3" role="status" aria-label="Загружаем участников…">
              {[0, 1, 2].map((i) => (
                <Skeleton key={i} className="size-10 rounded-full" />
              ))}
            </div>
          )}

          {!isLoading && preview.length === 0 && (
            <EmptyState icon={Users} title="В семье пока нет участников" />
          )}

          {!isLoading && preview.length > 0 && (
            <ul className="flex flex-col gap-3">
              {preview.map((member) => (
                <li key={member.id} className="flex items-center gap-3">
                  <Avatar
                    name={member.profile?.full_name ?? 'Участник'}
                    src={member.profile?.avatar_url ?? undefined}
                    size="sm"
                  />
                  <span className="truncate text-sm font-medium text-foreground">
                    {member.profile?.full_name ?? 'Участник'}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

/* ───────────────────────────── Shared helpers ───────────────────────────── */

/** Понятный текст ошибки без SQL/stack trace (ТЗ, п.21). */
function getGenericErrorMessage(error: unknown): string {
  void error
  return 'Попробуйте ещё раз. Если ошибка повторится, вернитесь чуть позже.'
}
