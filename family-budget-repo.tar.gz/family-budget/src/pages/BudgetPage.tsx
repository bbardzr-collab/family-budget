import { createElement, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { ChevronLeft, ChevronRight, MoreVertical, Pencil, PiggyBank, Plus, Trash2 } from 'lucide-react'
import {
  Amount,
  Button,
  Card,
  CardContent,
  Dropdown,
  EmptyState,
  ErrorState,
  IconButton,
  PageTitle,
  ProgressBar,
  SectionTitle,
  Skeleton,
  Text,
} from '@/components/ui'
import { cn } from '@/utils/cn'
import { formatMoney } from '@/utils/formatMoney'
import { sumMoney } from '@/utils/money'
import { formatMonthYear } from '@/utils/formatDate'
import { getCategoryIcon } from '@/features/categories/iconMap'
import { useCategories } from '@/features/categories/hooks'
import { useFamily } from '@/features/family/FamilyContext'
import {
  formatPeriodMonthLower,
  isSameMonthAs,
  nextMonth,
  parseMonthParam,
  previousMonth,
  toMonthParam,
  toPeriodMonthValue,
} from '@/features/budgets/period'
import { useBudgetSummary } from '@/features/budgets/hooks'
import { BudgetFormModal } from '@/features/budgets/BudgetFormModal'
import { BudgetCategoryFormModal } from '@/features/budgets/BudgetCategoryFormModal'
import { DeleteBudgetModal } from '@/features/budgets/DeleteBudgetModal'
import { DeleteBudgetCategoryModal } from '@/features/budgets/DeleteBudgetCategoryModal'
import type { BudgetInfo, BudgetSummaryCategory } from '@/features/budgets/api'

/**
 * Страница "Бюджет" (Этап 10) — месячный бюджет семьи: общий лимит,
 * фактические расходы месяца, лимиты по категориям и их фактический расход.
 * Все цифры — из get_monthly_budget_summary (см. features/budgets/api.ts),
 * никакой загрузки транзакций месяца на клиент для подсчёта нет (ТЗ, п.13).
 *
 * Месяц навигации хранится в URL (?month=yyyy-MM, ТЗ п.33) — это ТОЛЬКО
 * удобство UI, а не граница безопасности: сама сводка сервер получает через
 * SECURITY INVOKER RPC, которая определяет семью по auth.uid(), а не по
 * тому, что подставлено в URL/параметр запроса.
 */
export function BudgetPage() {
  const [searchParams, setSearchParams] = useSearchParams()
  const { isChild } = useFamily()

  const currentDate = useMemo(() => parseMonthParam(searchParams.get('month')), [searchParams])
  const periodMonthValue = toPeriodMonthValue(currentDate)
  const periodMonthLabel = formatMonthYear(currentDate)
  const periodMonthLabelLower = formatPeriodMonthLower(currentDate)
  const isCurrentMonth = isSameMonthAs(currentDate, new Date())

  const { data: summary, isLoading, isError, isFetching, refetch } = useBudgetSummary(periodMonthValue)
  const { data: categories } = useCategories()

  const [budgetFormOpen, setBudgetFormOpen] = useState(false)
  const [deletingBudget, setDeletingBudget] = useState(false)
  const [categoryForm, setCategoryForm] = useState<{ open: boolean; editing: BudgetSummaryCategory | null }>({
    open: false,
    editing: null,
  })
  const [deletingCategory, setDeletingCategory] = useState<BudgetSummaryCategory | null>(null)

  function goToMonth(date: Date) {
    setSearchParams((prev) => {
      const next = new URLSearchParams(prev)
      next.set('month', toMonthParam(date))
      return next
    })
  }

  const budget: BudgetInfo | null = summary?.budget ?? null
  const categoryItems = summary?.categories ?? []
  const totalSpent = summary?.totalSpent ?? 0
  const totalRemaining = summary?.totalRemaining ?? 0
  const totalPercent = summary?.totalPercent ?? null

  // Предупреждение, а НЕ блокировка (ТЗ, п.16) — сумма лимитов категорий и
  // общий бюджет намеренно могут отличаться в любую сторону.
  // sumMoney (не обычный reduce с "+") — Этап 20 нашёл живым аудитом, что
  // прямое сложение float давало ложное предупреждение при математически
  // равных суммах (10000.10 + 20000.20 !== 30000.30 в обычном JS).
  const limitsSum = sumMoney(categoryItems.map((c) => c.limitAmount))
  const showLimitsWarning = Boolean(budget) && limitsSum > (budget?.totalAmount ?? 0)

  const existingCategoryIds = categoryItems.map((c) => c.categoryId)

  return (
    <div className="flex flex-col gap-6">
      <PageTitle>Бюджет</PageTitle>

      <MonthNav
        label={periodMonthLabel}
        onPrev={() => goToMonth(previousMonth(currentDate))}
        onNext={() => goToMonth(nextMonth(currentDate))}
        onToday={isCurrentMonth ? undefined : () => goToMonth(new Date())}
      />

      {isLoading && <BudgetSkeleton />}

      {isError && (
        <Card>
          <CardContent className="pt-6">
            <ErrorState title="Не удалось загрузить бюджет" onRetry={() => void refetch()} />
          </CardContent>
        </Card>
      )}

      {!isLoading && !isError && !budget && (
        <Card>
          <CardContent className="pt-6">
            <EmptyState
              icon={PiggyBank}
              title="Бюджет на этот месяц ещё не создан"
              description={
                isChild ? undefined : 'Задайте общую сумму на месяц, чтобы отслеживать расходы семьи.'
              }
              action={!isChild && <Button onClick={() => setBudgetFormOpen(true)}>Создать бюджет</Button>}
            />
          </CardContent>
        </Card>
      )}

      {!isLoading && !isError && budget && (
        <>
          <Card className={cn(isFetching && 'opacity-60 transition-opacity')}>
            <CardContent className="flex flex-col gap-4 pt-6">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <Text variant="secondary">Бюджет месяца</Text>
                  <Amount value={budget.totalAmount} size="xl" className="mt-1" />
                </div>
                {!isChild && (
                  <div className="flex shrink-0 gap-2">
                    <IconButton
                      icon={Pencil}
                      aria-label="Редактировать бюджет"
                      variant="outline"
                      size="sm"
                      onClick={() => setBudgetFormOpen(true)}
                    />
                    <IconButton
                      icon={Trash2}
                      aria-label="Удалить бюджет"
                      variant="outline"
                      size="sm"
                      onClick={() => setDeletingBudget(true)}
                    />
                  </div>
                )}
              </div>

              <ProgressBar value={totalSpent} max={budget.totalAmount} />

              <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
                <SummaryStat label="Потрачено" value={totalSpent} tone="neutral" />
                <SummaryStat
                  label="Осталось"
                  value={totalRemaining}
                  tone={totalRemaining < 0 ? 'danger' : 'success'}
                />
                <div className="flex flex-col gap-1">
                  <Text variant="small">Использовано</Text>
                  <span className="text-lg font-semibold tabular-nums text-foreground">
                    {totalPercent !== null ? `${totalPercent}%` : '—'}
                  </span>
                </div>
              </div>

              {totalSpent === 0 && <Text variant="secondary">Пока нет расходов в этом месяце.</Text>}
            </CardContent>
          </Card>

          <div className="flex flex-col gap-3">
            <div className="flex items-center justify-between gap-4">
              <SectionTitle>Лимиты по категориям</SectionTitle>
              {!isChild && categoryItems.length > 0 && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCategoryForm({ open: true, editing: null })}
                >
                  <Plus className="size-4" aria-hidden="true" />
                  Добавить категорию
                </Button>
              )}
            </div>

            {showLimitsWarning && (
              <Card variant="highlighted">
                <CardContent className="pt-6">
                  <Text variant="secondary">
                    Сумма лимитов категорий ({formatMoney(limitsSum)}) больше общего бюджета месяца (
                    {formatMoney(budget.totalAmount)}). Это допустимо, но стоит проверить, осознанный ли это
                    выбор.
                  </Text>
                </CardContent>
              </Card>
            )}

            {categoryItems.length === 0 && (
              <Card>
                <CardContent className="pt-6">
                  <EmptyState
                    title="Лимиты по категориям ещё не настроены"
                    description={
                      isChild ? undefined : 'Добавьте категорию, чтобы отслеживать расходы по ней отдельно.'
                    }
                    action={
                      !isChild && (
                        <Button onClick={() => setCategoryForm({ open: true, editing: null })}>
                          Добавить категорию
                        </Button>
                      )
                    }
                  />
                </CardContent>
              </Card>
            )}

            {categoryItems.length > 0 && (
              <Card>
                <CardContent className="flex flex-col divide-y divide-border pt-6">
                  {categoryItems.map((category) => (
                    <BudgetCategoryRow
                      key={category.id}
                      category={category}
                      isChild={isChild}
                      onEdit={() => setCategoryForm({ open: true, editing: category })}
                      onDelete={() => setDeletingCategory(category)}
                    />
                  ))}
                </CardContent>
              </Card>
            )}
          </div>
        </>
      )}

      <BudgetFormModal
        open={budgetFormOpen}
        onClose={() => setBudgetFormOpen(false)}
        periodMonth={periodMonthValue}
        periodMonthLabel={periodMonthLabel}
        budget={budget}
      />

      <DeleteBudgetModal
        budget={deletingBudget ? budget : null}
        periodMonthLabelLower={periodMonthLabelLower}
        onClose={() => setDeletingBudget(false)}
      />

      {budget && (
        <BudgetCategoryFormModal
          open={categoryForm.open}
          onClose={() => setCategoryForm({ open: false, editing: null })}
          budgetId={budget.id}
          categories={categories ?? []}
          existingCategoryIds={existingCategoryIds}
          editing={categoryForm.editing}
        />
      )}

      <DeleteBudgetCategoryModal category={deletingCategory} onClose={() => setDeletingCategory(null)} />
    </div>
  )
}

/* ───────────────────────────── Month navigation ───────────────────────────── */

function MonthNav({
  label,
  onPrev,
  onNext,
  onToday,
}: {
  label: string
  onPrev: () => void
  onNext: () => void
  onToday?: () => void
}) {
  return (
    <div className="flex items-center justify-between gap-4">
      <div className="flex items-center gap-2">
        <IconButton icon={ChevronLeft} aria-label="Предыдущий месяц" variant="outline" onClick={onPrev} />
        <Text as="span" className="min-w-[9rem] text-center text-base font-medium text-foreground sm:min-w-[11rem]">
          {label}
        </Text>
        <IconButton icon={ChevronRight} aria-label="Следующий месяц" variant="outline" onClick={onNext} />
      </div>
      {onToday && (
        <Button variant="ghost" size="sm" onClick={onToday}>
          Текущий месяц
        </Button>
      )}
    </div>
  )
}

/* ───────────────────────────── Shared bits ───────────────────────────── */

function SummaryStat({
  label,
  value,
  tone,
}: {
  label: string
  value: number
  tone: 'neutral' | 'success' | 'danger'
}) {
  return (
    <div className="flex flex-col gap-1">
      <Text variant="small">{label}</Text>
      <Amount value={value} size="md" tone={tone} />
    </div>
  )
}

function MiniStat({ label, value, tone = 'neutral' }: { label: string; value: string; tone?: 'neutral' | 'danger' }) {
  return (
    <div className="flex flex-col gap-0.5">
      <Text variant="small">{label}</Text>
      <span className={cn('text-sm font-medium tabular-nums', tone === 'danger' ? 'text-danger' : 'text-foreground')}>
        {value}
      </span>
    </div>
  )
}

/* ───────────────────────────── Category row ───────────────────────────── */

function BudgetCategoryRow({
  category,
  isChild,
  onEdit,
  onDelete,
}: {
  category: BudgetSummaryCategory
  isChild: boolean
  onEdit: () => void
  onDelete: () => void
}) {
  // Превышение (ТЗ, п.14, пример: лимит 20 000 ₽, потрачено 25 200 ₽ →
  // "Превышение +5 200 ₽") показывается ВМЕСТО "Осталось", а не вместе с ним.
  const overage = category.spentAmount > category.limitAmount ? category.spentAmount - category.limitAmount : 0

  const dropdownItems = [
    { value: 'edit', label: 'Изменить лимит', icon: <Pencil /> },
    { value: 'delete', label: 'Убрать из бюджета', icon: <Trash2 />, destructive: true },
  ]

  function handleSelect(value: string) {
    if (value === 'edit') onEdit()
    else if (value === 'delete') onDelete()
  }

  return (
    <div className={cn('flex flex-col gap-3 py-4 first:pt-0 last:pb-0', !category.isActive && 'opacity-60')}>
      <div className="flex items-center gap-3">
        <div className="flex size-9 shrink-0 items-center justify-center rounded-full bg-muted text-muted-foreground">
          {/* createElement — см. комментарий в CategoryPickerModal.tsx про
              react-hooks/static-components и динамический выбор иконки. */}
          {createElement(getCategoryIcon(category.categoryIcon), { className: 'size-4', 'aria-hidden': true })}
        </div>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-medium text-foreground">{category.categoryName}</p>
          {/* Деактивированная категория остаётся в бюджете с историческим
              лимитом (ТЗ, п.9) — просто помечается как отключённая, не
              удаляется и не предлагается повторно для добавления. */}
          {!category.isActive && <p className="text-xs text-muted-foreground">Категория отключена</p>}
        </div>
        {!isChild && (
          <Dropdown
            trigger={
              <IconButton icon={MoreVertical} aria-label={`Действия с категорией ${category.categoryName}`} size="sm" />
            }
            items={dropdownItems}
            onSelect={handleSelect}
          />
        )}
      </div>

      <ProgressBar value={category.spentAmount} max={category.limitAmount} />

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <MiniStat label="Лимит" value={formatMoney(category.limitAmount)} />
        <MiniStat label="Потрачено" value={formatMoney(category.spentAmount)} />
        {overage > 0 ? (
          <MiniStat label="Превышение" value={`+${formatMoney(overage)}`} tone="danger" />
        ) : (
          <MiniStat label="Осталось" value={formatMoney(category.remainingAmount)} />
        )}
        <MiniStat label="Использовано" value={category.percent !== null ? `${category.percent}%` : '—'} />
      </div>
    </div>
  )
}

/* ───────────────────────────── Loading skeleton ───────────────────────────── */

function BudgetSkeleton() {
  return (
    <div className="flex flex-col gap-6" role="status" aria-label="Загружаем бюджет…">
      <Skeleton className="h-44 w-full rounded-lg" />
      <Skeleton className="h-64 w-full rounded-lg" />
    </div>
  )
}
