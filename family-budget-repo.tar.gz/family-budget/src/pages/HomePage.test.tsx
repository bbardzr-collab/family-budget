import { fireEvent, render, screen } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { ToastProvider } from '@/components/ui/Toast'
import { HomePage } from './HomePage'

const {
  mockUseAuth,
  mockUseFamily,
  mockUseFamilyMembers,
  mockUseCreateFamily,
  mockUseDashboardSummary,
  mockUseRecentTransactions,
  mockUseBudgetSummary,
  mockUseGoals,
  mockUsePlannedExpenses,
  mockUseRecurringTransactions,
  mockCreateTransactionMutateAsync,
  mockUpdateTransactionMutateAsync,
} = vi.hoisted(() => ({
  mockUseAuth: vi.fn(),
  mockUseFamily: vi.fn(),
  mockUseFamilyMembers: vi.fn(),
  mockUseCreateFamily: vi.fn(),
  mockUseDashboardSummary: vi.fn(),
  mockUseRecentTransactions: vi.fn(),
  mockUseBudgetSummary: vi.fn(),
  mockUseGoals: vi.fn(),
  mockUsePlannedExpenses: vi.fn(),
  mockUseRecurringTransactions: vi.fn(),
  mockCreateTransactionMutateAsync: vi.fn(),
  mockUpdateTransactionMutateAsync: vi.fn(),
}))

vi.mock('@/features/auth/AuthContext', () => ({
  useAuth: mockUseAuth,
}))

vi.mock('@/features/family/FamilyContext', () => ({
  useFamily: mockUseFamily,
}))

vi.mock('@/features/family/hooks', () => ({
  useFamilyMembers: mockUseFamilyMembers,
  useCreateFamily: mockUseCreateFamily,
}))

vi.mock('@/features/dashboard/hooks', () => ({
  useDashboardSummary: mockUseDashboardSummary,
  useRecentTransactions: mockUseRecentTransactions,
}))

// Превью бюджета на Dashboard (Этап 10, п.22) использует ту же сводку, что и
// BudgetPage — мокаем на границе фичи, как и остальные домены выше.
vi.mock('@/features/budgets/hooks', () => ({
  useBudgetSummary: mockUseBudgetSummary,
}))

// Превью целей на Dashboard (Этап 11, п.31) — та же логика мокирования на
// границе фичи, что и для бюджета выше.
vi.mock('@/features/goals/hooks', () => ({
  useGoals: mockUseGoals,
}))

// Блок "Ближайшие планы" на Dashboard (Этап 12, п.19) — та же логика
// мокирования на границе фичи, что и для целей/бюджета выше.
vi.mock('@/features/plannedExpenses/hooks', () => ({
  usePlannedExpenses: mockUsePlannedExpenses,
}))

// Блок "Ближайшие повторяющиеся операции" на Dashboard (Этап 13) — та же
// логика мокирования на границе фичи, что и для планов/целей/бюджета выше.
vi.mock('@/features/recurringTransactions/hooks', () => ({
  useRecurringTransactions: mockUseRecurringTransactions,
}))

// HomePage (через QuickActionsSection/RecentOperationsSection) с Этапа 7
// рендерит TransactionFormModal — мокаем на границе feature-хуков, как и
// остальные домены выше, чтобы не тянуть реальный supabase-клиент в юнит-тест.
vi.mock('@/features/transactions/hooks', () => ({
  useCreateTransaction: () => ({ mutateAsync: mockCreateTransactionMutateAsync, isPending: false }),
  useUpdateTransaction: () => ({ mutateAsync: mockUpdateTransactionMutateAsync, isPending: false }),
}))

// TransactionFormModal с Этапа 8 использует useCategories — мокаем на той же
// границе, что и остальные домены (см. комментарий выше про supabase-клиент).
vi.mock('@/features/categories/hooks', () => ({
  useCategories: () => ({ data: [], isLoading: false, isError: false }),
}))

function renderHome() {
  return render(
    <ToastProvider>
      <MemoryRouter>
        <HomePage />
      </MemoryRouter>
    </ToastProvider>,
  )
}

const EMPTY_SUMMARY_QUERY = {
  data: { income: 0, expenses: 0, balance: 0, periodStart: '2026-09-01', periodEnd: '2026-09-30' },
  isLoading: false,
  isError: false,
  error: null,
  refetch: vi.fn(),
}

const EMPTY_RECENT_QUERY = { data: [], isLoading: false, isError: false, error: null, refetch: vi.fn() }

const EMPTY_BUDGET_QUERY = {
  data: { budget: null, totalSpent: 0, totalRemaining: 0, totalPercent: null, categories: [] },
  isLoading: false,
  isError: false,
  refetch: vi.fn(),
}

const EMPTY_GOALS_QUERY = { data: [], isLoading: false, isError: false, refetch: vi.fn() }

const EMPTY_PLANNED_QUERY = { data: [], isLoading: false, isError: false, refetch: vi.fn() }

const EMPTY_RECURRING_QUERY = { data: [], isLoading: false, isError: false, refetch: vi.fn() }

describe('HomePage / Dashboard (Этап 6)', () => {
  beforeEach(() => {
    mockUseCreateFamily.mockReturnValue({ mutateAsync: vi.fn() })
    mockUseFamilyMembers.mockReturnValue({ data: [], isLoading: false })
    mockUseBudgetSummary.mockReturnValue(EMPTY_BUDGET_QUERY)
    mockUseGoals.mockReturnValue(EMPTY_GOALS_QUERY)
    mockUsePlannedExpenses.mockReturnValue(EMPTY_PLANNED_QUERY)
    mockUseRecurringTransactions.mockReturnValue(EMPTY_RECURRING_QUERY)
    vi.useFakeTimers()
    vi.setSystemTime(new Date('2026-09-18T10:00:00'))
  })

  afterEach(() => {
    vi.useRealTimers()
  })

  it('показывает Skeleton, пока не известно, есть ли семья (п.36.1)', () => {
    mockUseAuth.mockReturnValue({ profile: null })
    mockUseFamily.mockReturnValue({ currentFamily: null, hasFamily: false, loading: true })
    mockUseDashboardSummary.mockReturnValue(EMPTY_SUMMARY_QUERY)
    mockUseRecentTransactions.mockReturnValue(EMPTY_RECENT_QUERY)

    renderHome()

    expect(screen.getByRole('status', { name: /загружаем панель/i })).toBeInTheDocument()
    expect(screen.queryByText('Добро пожаловать!')).not.toBeInTheDocument()
  })

  it('состояние "нет семьи": приветствие + кнопки "Создать семью"/"У меня есть приглашение" (п.36.6)', () => {
    mockUseAuth.mockReturnValue({ profile: null })
    mockUseFamily.mockReturnValue({ currentFamily: null, hasFamily: false, loading: false })
    mockUseDashboardSummary.mockReturnValue(EMPTY_SUMMARY_QUERY)
    mockUseRecentTransactions.mockReturnValue(EMPTY_RECENT_QUERY)

    renderHome()

    expect(screen.getByText('Добро пожаловать!')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Создать семью' })).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'У меня есть приглашение' })).toBeInTheDocument()
  })

  it('Dashboard с семьёй: приветствие по времени суток, суммы 0 ₽, пустые состояния бюджета/операций/событий (п.36.2, 36.7)', () => {
    mockUseAuth.mockReturnValue({ profile: { full_name: 'Анна' } })
    mockUseFamily.mockReturnValue({
      currentFamily: { id: 'fam-1', name: 'Ивановых' },
      hasFamily: true,
      loading: false,
    })
    mockUseDashboardSummary.mockReturnValue(EMPTY_SUMMARY_QUERY)
    mockUseRecentTransactions.mockReturnValue(EMPTY_RECENT_QUERY)

    renderHome()

    // 10:00 → "Доброе утро" (п.3)
    expect(screen.getByText('Доброе утро, Анна!')).toBeInTheDocument()
    expect(screen.getByText(/семья «ивановых»/i)).toBeInTheDocument()

    // Финансовая сводка — реальные нули из БД, посчитанные для 3 карточек (п.5, 8)
    expect(screen.getAllByText('0 ₽')).toHaveLength(3)

    // Бюджет (Этап 10, п.8, 22) — реальный запрос, бюджет на месяц не создан,
    // честное пустое состояние без фиктивного "0 ₽" и рабочая кнопка перехода
    // на страницу создания бюджета.
    expect(screen.getByText('Бюджет на этот месяц не создан.')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Создать бюджет' })).toBeEnabled()

    // Последние операции — пустое состояние (п.13, 36.7). С Этапа 7 кнопка
    // рабочая (открывает TransactionFormModal), а не disabled-заглушка.
    expect(screen.getByText('Пока нет операций')).toBeInTheDocument()
    expect(
      screen.getByText('Добавьте первый доход или расход, чтобы начать вести бюджет семьи.'),
    ).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Добавить операцию' })).toBeEnabled()

    // Ближайшие планы (Этап 12, п.19) — честно пусто, без mock-данных
    expect(screen.getByText('Ближайших планов пока нет')).toBeInTheDocument()

    // Ближайшие повторяющиеся операции (Этап 13) — честно пусто, без mock-данных
    expect(screen.getByText('Повторяющихся операций пока нет')).toBeInTheDocument()

    // Финансовые цели (Этап 11, п.33) — честное пустое состояние без
    // фиктивных целей, с рабочей кнопкой перехода на страницу целей.
    expect(screen.getByText('Финансовых целей пока нет')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Создать цель' })).toBeEnabled()
  })

  it('Dashboard показывает ближайшие активные цели, если они есть (Этап 11, п.31)', () => {
    mockUseAuth.mockReturnValue({ profile: { full_name: 'Анна' } })
    mockUseFamily.mockReturnValue({
      currentFamily: { id: 'fam-1', name: 'Ивановых' },
      hasFamily: true,
      loading: false,
    })
    mockUseDashboardSummary.mockReturnValue(EMPTY_SUMMARY_QUERY)
    mockUseRecentTransactions.mockReturnValue(EMPTY_RECENT_QUERY)
    mockUseGoals.mockReturnValue({
      data: [
        {
          id: 'goal-1',
          goalType: 'family',
          ownerUserId: null,
          ownerName: null,
          title: 'Отпуск',
          icon: 'plane',
          targetAmount: 250000,
          targetDate: '2026-12-01',
          status: 'active',
          contributedAmount: 120000,
          remainingAmount: 130000,
          percent: 48,
          createdAt: '2026-09-01T00:00:00Z',
        },
        {
          id: 'goal-2',
          goalType: 'family',
          ownerUserId: null,
          ownerName: null,
          title: 'Ремонт',
          icon: 'home',
          targetAmount: 500000,
          targetDate: null,
          status: 'active',
          contributedAmount: 80000,
          remainingAmount: 420000,
          percent: 16,
          createdAt: '2026-09-05T00:00:00Z',
        },
      ],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderHome()

    expect(screen.getByText('Отпуск')).toBeInTheDocument()
    expect(screen.getByText('120 000 ₽ / 250 000 ₽')).toBeInTheDocument()
    expect(screen.getByText('48%')).toBeInTheDocument()
    expect(screen.getByText('Ремонт')).toBeInTheDocument()
    expect(screen.getByText('16%')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Все цели' })).toBeInTheDocument()
  })

  it('Dashboard показывает ближайшие АКТИВНЫЕ планы, но не отменённые/выполненные (Этап 12, п.19)', () => {
    mockUseAuth.mockReturnValue({ profile: { full_name: 'Анна' } })
    mockUseFamily.mockReturnValue({
      currentFamily: { id: 'fam-1', name: 'Ивановых' },
      hasFamily: true,
      loading: false,
    })
    mockUseDashboardSummary.mockReturnValue(EMPTY_SUMMARY_QUERY)
    mockUseRecentTransactions.mockReturnValue(EMPTY_RECENT_QUERY)
    mockUsePlannedExpenses.mockReturnValue({
      data: [
        {
          id: 'plan-1',
          title: 'Купить холодильник',
          amount: 65000,
          plannedDate: '2026-09-25',
          status: 'planned',
          userId: null,
          userName: null,
          categoryId: null,
          category: null,
          createdAt: '2026-09-10T00:00:00Z',
        },
        {
          id: 'plan-2',
          title: 'Страховка',
          amount: 12000,
          plannedDate: '2026-09-28',
          status: 'planned',
          userId: null,
          userName: null,
          categoryId: null,
          category: null,
          createdAt: '2026-09-11T00:00:00Z',
        },
        // Отменённый и выполненный план не должны попасть в блок "ближайшие" (ТЗ, п.19).
        {
          id: 'plan-3',
          title: 'Отменённая покупка',
          amount: 5000,
          plannedDate: '2026-09-20',
          status: 'cancelled',
          userId: null,
          userName: null,
          categoryId: null,
          category: null,
          createdAt: '2026-09-01T00:00:00Z',
        },
        {
          id: 'plan-4',
          title: 'Уже выполненный план',
          amount: 3000,
          plannedDate: '2026-09-15',
          status: 'done',
          userId: null,
          userName: null,
          categoryId: null,
          category: null,
          createdAt: '2026-09-01T00:00:00Z',
        },
      ],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderHome()

    expect(screen.getByText('Купить холодильник')).toBeInTheDocument()
    expect(screen.getByText('65 000 ₽')).toBeInTheDocument()
    expect(screen.getByText('Страховка')).toBeInTheDocument()
    expect(screen.getByText('12 000 ₽')).toBeInTheDocument()
    expect(screen.queryByText('Отменённая покупка')).not.toBeInTheDocument()
    expect(screen.queryByText('Уже выполненный план')).not.toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Все планы' })).toBeInTheDocument()
  })

  it('Dashboard показывает ближайшие активные/просроченные правила, но не приостановленные/истёкшие (Этап 13)', () => {
    mockUseAuth.mockReturnValue({ profile: { full_name: 'Анна' } })
    mockUseFamily.mockReturnValue({
      currentFamily: { id: 'fam-1', name: 'Ивановых' },
      hasFamily: true,
      loading: false,
    })
    mockUseDashboardSummary.mockReturnValue(EMPTY_SUMMARY_QUERY)
    mockUseRecentTransactions.mockReturnValue(EMPTY_RECENT_QUERY)
    mockUseRecurringTransactions.mockReturnValue({
      data: [
        {
          id: 'rec-1',
          type: 'expense',
          amount: 15000,
          categoryId: null,
          category: { id: 'cat-1', name: 'Аренда', icon: null, isActive: true },
          incomeSource: null,
          frequency: 'monthly',
          intervalConfig: { interval: 1, day: 5 },
          startDate: '2026-08-05',
          endDate: null,
          nextRunDate: '2026-10-05',
          isActive: true,
          userId: 'user-1',
          userName: 'Анна',
          createdAt: '2026-08-01T00:00:00Z',
        },
        {
          id: 'rec-2',
          type: 'expense',
          amount: 999,
          categoryId: null,
          category: { id: 'cat-2', name: 'Подписка', icon: null, isActive: true },
          incomeSource: null,
          frequency: 'monthly',
          intervalConfig: { interval: 1, day: 1 },
          startDate: '2026-08-01',
          endDate: null,
          // Просрочено относительно fake timers (2026-09-18) — всё ещё должно попасть в блок.
          nextRunDate: '2026-09-01',
          isActive: true,
          userId: 'user-1',
          userName: 'Анна',
          createdAt: '2026-08-01T00:00:00Z',
        },
        // На паузе — не должно попасть в блок "ближайшие", даже если дата в прошлом.
        {
          id: 'rec-3',
          type: 'expense',
          amount: 500,
          categoryId: null,
          category: { id: 'cat-3', name: 'Приостановленное', icon: null, isActive: true },
          incomeSource: null,
          frequency: 'monthly',
          intervalConfig: { interval: 1, day: 1 },
          startDate: '2026-08-01',
          endDate: null,
          nextRunDate: '2026-09-01',
          isActive: false,
          userId: 'user-1',
          userName: 'Анна',
          createdAt: '2026-08-01T00:00:00Z',
        },
        // Истёк срок (end_date в прошлом) — не должно попасть в блок "ближайшие".
        {
          id: 'rec-4',
          type: 'expense',
          amount: 700,
          categoryId: null,
          category: { id: 'cat-4', name: 'Истёкшее', icon: null, isActive: true },
          incomeSource: null,
          frequency: 'monthly',
          intervalConfig: { interval: 1, day: 1 },
          startDate: '2026-01-01',
          endDate: '2026-08-31',
          nextRunDate: '2026-09-01',
          isActive: true,
          userId: 'user-1',
          userName: 'Анна',
          createdAt: '2026-01-01T00:00:00Z',
        },
      ],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderHome()

    expect(screen.getByText('Аренда')).toBeInTheDocument()
    expect(screen.getByText('Подписка')).toBeInTheDocument()
    expect(screen.queryByText('Приостановленное')).not.toBeInTheDocument()
    expect(screen.queryByText('Истёкшее')).not.toBeInTheDocument()
    // Просроченное правило показывает бейдж "Просрочено".
    expect(screen.getByText('Просрочено')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Все правила' })).toBeInTheDocument()
  })

  it('Dashboard показывает реальный бюджет месяца, если он создан (Этап 10, п.22)', () => {
    mockUseAuth.mockReturnValue({ profile: { full_name: 'Анна' } })
    mockUseFamily.mockReturnValue({
      currentFamily: { id: 'fam-1', name: 'Ивановых' },
      hasFamily: true,
      loading: false,
    })
    mockUseDashboardSummary.mockReturnValue(EMPTY_SUMMARY_QUERY)
    mockUseRecentTransactions.mockReturnValue(EMPTY_RECENT_QUERY)
    mockUseBudgetSummary.mockReturnValue({
      data: {
        budget: { id: 'budget-1', periodMonth: '2026-09-01', totalAmount: 100000 },
        totalSpent: 110000,
        totalRemaining: -10000,
        totalPercent: 110,
        categories: [],
      },
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderHome()

    expect(screen.getByText(/потрачено 110 000/i)).toBeInTheDocument()
    expect(screen.getByText(/осталось.*[-−]10 000/i)).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Подробнее' })).toBeEnabled()
    expect(screen.queryByRole('button', { name: 'Создать бюджет' })).not.toBeInTheDocument()
  })

  it('отрицательный остаток показывает знак минус и понятное текстовое состояние (п.11, 36.4)', () => {
    mockUseAuth.mockReturnValue({ profile: { full_name: 'Анна' } })
    mockUseFamily.mockReturnValue({
      currentFamily: { id: 'fam-1', name: 'Ивановых' },
      hasFamily: true,
      loading: false,
    })
    mockUseDashboardSummary.mockReturnValue({
      ...EMPTY_SUMMARY_QUERY,
      data: { income: 1000, expenses: 13500, balance: -12500, periodStart: '2026-09-01', periodEnd: '2026-09-30' },
    })
    mockUseRecentTransactions.mockReturnValue(EMPTY_RECENT_QUERY)

    renderHome()

    const balance = screen.getByText(/12 500/)
    expect(balance.textContent).toMatch(/^[-−]/)
    expect(screen.getByText('Расходы превышают доходы')).toBeInTheDocument()
  })

  it('быстрое действие "Расход" открывает форму добавления операции (Этап 7)', () => {
    mockUseAuth.mockReturnValue({ profile: { full_name: 'Анна' } })
    mockUseFamily.mockReturnValue({
      currentFamily: { id: 'fam-1', name: 'Ивановых' },
      hasFamily: true,
      loading: false,
    })
    mockUseDashboardSummary.mockReturnValue(EMPTY_SUMMARY_QUERY)
    mockUseRecentTransactions.mockReturnValue(EMPTY_RECENT_QUERY)

    renderHome()

    // fireEvent вместо userEvent — этот describe-блок работает с fake timers
    // (vi.useFakeTimers в beforeEach, нужны для детерминированного приветствия
    // по времени суток), а userEvent.click внутри них подвисает на internal delay.
    // Точное совпадение имени (а не /расход/i) — начиная с Этапа 12 на экране
    // есть и другая кнопка, чьё имя содержит "расход" ("Запланировать расход"
    // в пустом состоянии блока "Ближайшие планы").
    fireEvent.click(screen.getByRole('button', { name: 'Расход' }))

    expect(screen.getByRole('dialog', { name: 'Добавить операцию' })).toBeInTheDocument()
  })

  it('показывает ошибку загрузки без технических деталей и кнопку "Повторить" (п.21, 36.5)', () => {
    mockUseAuth.mockReturnValue({ profile: { full_name: 'Анна' } })
    mockUseFamily.mockReturnValue({
      currentFamily: { id: 'fam-1', name: 'Ивановых' },
      hasFamily: true,
      loading: false,
    })
    mockUseDashboardSummary.mockReturnValue({
      data: undefined,
      isLoading: false,
      isError: true,
      error: new Error('relation "transactions" violates row-level security policy'),
      refetch: vi.fn(),
    })
    mockUseRecentTransactions.mockReturnValue(EMPTY_RECENT_QUERY)

    renderHome()

    expect(screen.getByText('Не удалось загрузить данные')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: /повторить/i })).toBeInTheDocument()
    expect(screen.queryByText(/row-level security|relation|sql/i)).not.toBeInTheDocument()
  })
})
