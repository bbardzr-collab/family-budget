import { fireEvent, render, screen } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { AnalyticsPage } from './AnalyticsPage'
import type {
  AnalyticsCategories,
  AnalyticsIncomeSources,
  AnalyticsSummary,
  AnalyticsTimeseries,
} from '@/features/analytics/api'
import type { AnalyticsComparison } from '@/features/analytics/comparison'
import type { BudgetSummary } from '@/features/budgets/api'
import type { GoalListItem } from '@/features/goals/api'
import type { PlannedExpenseListItem } from '@/features/plannedExpenses/api'

const {
  mockUseHasAnyTransactions,
  mockUseAnalyticsSummary,
  mockUseAnalyticsTimeseries,
  mockUseAnalyticsCategories,
  mockUseAnalyticsIncomeSources,
  mockUseAnalyticsComparison,
  mockUseBudgetSummary,
  mockUseGoals,
  mockUsePlannedExpenses,
} = vi.hoisted(() => ({
  mockUseHasAnyTransactions: vi.fn(),
  mockUseAnalyticsSummary: vi.fn(),
  mockUseAnalyticsTimeseries: vi.fn(),
  mockUseAnalyticsCategories: vi.fn(),
  mockUseAnalyticsIncomeSources: vi.fn(),
  mockUseAnalyticsComparison: vi.fn(),
  mockUseBudgetSummary: vi.fn(),
  mockUseGoals: vi.fn(),
  mockUsePlannedExpenses: vi.fn(),
}))

vi.mock('@/features/transactions/hooks', () => ({
  useHasAnyTransactions: mockUseHasAnyTransactions,
}))

vi.mock('@/features/analytics/hooks', () => ({
  useAnalyticsSummary: mockUseAnalyticsSummary,
  useAnalyticsTimeseries: mockUseAnalyticsTimeseries,
  useAnalyticsCategories: mockUseAnalyticsCategories,
  useAnalyticsIncomeSources: mockUseAnalyticsIncomeSources,
  useAnalyticsComparison: mockUseAnalyticsComparison,
}))

vi.mock('@/features/budgets/hooks', () => ({
  useBudgetSummary: mockUseBudgetSummary,
}))

vi.mock('@/features/goals/hooks', () => ({
  useGoals: mockUseGoals,
}))

vi.mock('@/features/plannedExpenses/hooks', () => ({
  usePlannedExpenses: mockUsePlannedExpenses,
}))

// Период страницы фиксируется через URL (?period=custom&from=&to=), а не
// через реальное "сегодня" (см. AnalyticsPage.tsx) — это делает фильтрацию
// "Запланировано" по датам в тестах ниже детерминированной, не зависящей от
// системных часов окружения, где запускаются тесты.
const PERIOD_URL = '/app/analytics?period=custom&from=2026-09-01&to=2026-09-30'

function renderPage(url: string = PERIOD_URL) {
  return render(
    <MemoryRouter initialEntries={[url]}>
      <AnalyticsPage />
    </MemoryRouter>,
  )
}

const SUMMARY: AnalyticsSummary = { income: 150000, expenses: 93500, balance: 56500, transactionCount: 47 }

const EMPTY_TIMESERIES: AnalyticsTimeseries = { granularity: 'day', points: [] }

const CATEGORIES: AnalyticsCategories = {
  totalExpense: 93500,
  categories: [
    { categoryId: 'cat-1', categoryName: 'Продукты', categoryIcon: 'shopping-cart', categoryType: 'OBLIGATORY', amount: 25000, percent: 26.7 },
    { categoryId: 'cat-2', categoryName: 'Жильё', categoryIcon: 'home', categoryType: 'OBLIGATORY', amount: 20000, percent: 21.4 },
    { categoryId: 'cat-3', categoryName: 'Транспорт', categoryIcon: 'car', categoryType: 'OBLIGATORY', amount: 8500, percent: 9.1 },
    { categoryId: 'cat-4', categoryName: 'Развлечения', categoryIcon: 'party-popper', categoryType: 'WANTS', amount: 5000, percent: 5.3 },
    { categoryId: 'cat-5', categoryName: 'Покупки', categoryIcon: 'shopping-bag', categoryType: 'WANTS', amount: 4800, percent: 5.1 },
    { categoryId: null, categoryName: 'Без категории', categoryIcon: null, categoryType: null, amount: 3000, percent: 3.2 },
  ],
  byType: [
    { type: 'OBLIGATORY', amount: 53500, percent: 57.2 },
    { type: 'WANTS', amount: 9800, percent: 10.5 },
    { type: 'UNCATEGORIZED', amount: 3000, percent: 3.2 },
  ],
}

const INCOME_SOURCES: AnalyticsIncomeSources = {
  totalIncome: 150000,
  sources: [
    { incomeSource: 'Зарплата', amount: 120000, percent: 80 },
    { incomeSource: null, amount: 30000, percent: 20 },
  ],
}

const COMPARISON: AnalyticsComparison = {
  income: { current: 150000, previous: 140000, difference: 10000, percentageChange: 7.1 },
  expenses: { current: 93500, previous: 98000, difference: -4500, percentageChange: -4.6 },
  balance: { current: 56500, previous: 42000, difference: 14500, percentageChange: 34.5 },
  transactionCount: { current: 47, previous: 0, difference: 47, percentageChange: null },
}

const NO_BUDGET: BudgetSummary = { budget: null, totalSpent: 0, totalRemaining: 0, totalPercent: null, categories: [] }

const WITH_BUDGET: BudgetSummary = {
  budget: { id: 'budget-1', periodMonth: '2026-09-01', totalAmount: 300000 },
  totalSpent: 215000,
  totalRemaining: 85000,
  totalPercent: 71.7,
  categories: [],
}

const GOALS: GoalListItem[] = [
  {
    id: 'goal-1',
    goalType: 'family',
    ownerUserId: null,
    ownerName: null,
    title: 'Отпуск',
    icon: 'plane',
    targetAmount: 200000,
    targetDate: null,
    status: 'active',
    contributedAmount: 50000,
    remainingAmount: 150000,
    percent: 25,
    createdAt: '2026-01-01T00:00:00Z',
  },
]

const PLANNED: PlannedExpenseListItem[] = [
  {
    id: 'pe-1',
    title: 'Ремонт',
    amount: 12345,
    plannedDate: '2026-09-15',
    status: 'planned',
    userId: null,
    userName: null,
    categoryId: null,
    category: null,
    createdAt: '2026-09-01T00:00:00Z',
  },
  {
    id: 'pe-2',
    title: 'Вне периода',
    amount: 99999,
    plannedDate: '2026-08-15',
    status: 'planned',
    userId: null,
    userName: null,
    categoryId: null,
    category: null,
    createdAt: '2026-08-01T00:00:00Z',
  },
  {
    id: 'pe-3',
    title: 'Уже выполнено',
    amount: 77777,
    plannedDate: '2026-09-10',
    status: 'done',
    userId: null,
    userName: null,
    categoryId: null,
    category: null,
    createdAt: '2026-09-01T00:00:00Z',
  },
]

describe('AnalyticsPage (Этап 14)', () => {
  beforeEach(() => {
    mockUseHasAnyTransactions.mockReturnValue({ data: true, isLoading: false, isError: false, refetch: vi.fn() })
    mockUseAnalyticsSummary.mockReturnValue({ data: SUMMARY, isLoading: false, isError: false, refetch: vi.fn() })
    mockUseAnalyticsTimeseries.mockReturnValue({
      data: EMPTY_TIMESERIES,
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })
    mockUseAnalyticsCategories.mockReturnValue({
      data: CATEGORIES,
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })
    mockUseAnalyticsIncomeSources.mockReturnValue({
      data: INCOME_SOURCES,
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })
    mockUseAnalyticsComparison.mockReturnValue({ data: COMPARISON, isLoading: false, isError: false, refetch: vi.fn() })
    mockUseBudgetSummary.mockReturnValue({
      data: NO_BUDGET,
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })
    mockUseGoals.mockReturnValue({ data: GOALS, isLoading: false, isError: false })
    mockUsePlannedExpenses.mockReturnValue({ data: PLANNED, isLoading: false, isError: false })
  })

  it('во время начальной загрузки показывает Skeleton', () => {
    mockUseHasAnyTransactions.mockReturnValue({ data: undefined, isLoading: true, isError: false, refetch: vi.fn() })

    renderPage()

    expect(screen.getByRole('status', { name: /загружаем аналитику/i })).toBeInTheDocument()
  })

  it('ошибка загрузки сводки показывает ErrorState и "Повторить" перезапрашивает все запросы (ТЗ, п.31)', () => {
    const refetchSummary = vi.fn()
    mockUseAnalyticsSummary.mockReturnValue({ data: undefined, isLoading: false, isError: true, refetch: refetchSummary })

    renderPage()

    expect(screen.getByText('Не удалось загрузить аналитику')).toBeInTheDocument()
    fireEvent.click(screen.getByRole('button', { name: 'Повторить' }))
    expect(refetchSummary).toHaveBeenCalled()
  })

  it('нет ни одной операции у семьи: EmptyState "Пока нет данных для аналитики" (ТЗ, п.30)', () => {
    mockUseHasAnyTransactions.mockReturnValue({ data: false, isLoading: false, isError: false, refetch: vi.fn() })

    renderPage()

    expect(screen.getByText('Пока нет данных для аналитики')).toBeInTheDocument()
    expect(
      screen.getByText('Добавьте доходы и расходы, и здесь появится финансовая статистика семьи.'),
    ).toBeInTheDocument()
  })

  it('показывает доходы/расходы/баланс/количество операций через formatMoney (ТЗ, п.3)', () => {
    renderPage()

    expect(screen.getByText('150 000 ₽')).toBeInTheDocument()
    expect(screen.getByText('93 500 ₽')).toBeInTheDocument()
    expect(screen.getByText('56 500 ₽')).toBeInTheDocument()
    expect(screen.getByText('47')).toBeInTheDocument()
  })

  it('сравнение с предыдущим периодом: показывает объективный процент изменения (ТЗ, п.15-16)', () => {
    renderPage()

    expect(screen.getByText(/\+7,1% к прошлому периоду/)).toBeInTheDocument()
    expect(screen.getByText(/-4,6% к прошлому периоду|−4,6% к прошлому периоду/)).toBeInTheDocument()
  })

  it('деление на ноль в сравнении показывает "—", а не Infinity/NaN (ТЗ, п.16)', () => {
    renderPage()

    expect(screen.getByText(/— к прошлому периоду/)).toBeInTheDocument()
    expect(screen.queryByText(/Infinity/)).not.toBeInTheDocument()
    expect(screen.queryByText(/NaN/)).not.toBeInTheDocument()
  })

  it('расход без category_id показывается как "Без категории" и учтён в списке (ТЗ, п.10)', () => {
    // Отдельный, короткий набор категорий (а не 6-элементный CATEGORIES) —
    // чтобы "Без категории" не попал за границу TOP-5 (см. следующий тест) и
    // этот тест проверял ровно одну вещь: отображение null-категории.
    mockUseAnalyticsCategories.mockReturnValue({
      data: {
        totalExpense: 5000,
        categories: [
          { categoryId: null, categoryName: 'Без категории', categoryIcon: null, categoryType: null, amount: 5000, percent: 100 },
        ],
        byType: [{ type: 'UNCATEGORIZED', amount: 5000, percent: 100 }],
      },
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderPage()

    expect(screen.getByText('Без категории')).toBeInTheDocument()
  })

  it('TOP-5 категорий по умолчанию, остальные — по кнопке "Показать ещё" (ТЗ, п.13)', () => {
    renderPage()

    expect(screen.getByText('Продукты')).toBeInTheDocument()
    expect(screen.getByText('Покупки')).toBeInTheDocument()
    // 6-я категория ("Без категории") изначально скрыта за TOP-5
    expect(screen.queryByText('Без категории')).not.toBeInTheDocument()

    fireEvent.click(screen.getByRole('button', { name: 'Показать ещё 1' }))

    expect(screen.getByText('Без категории')).toBeInTheDocument()
  })

  it('доход без income_source показывается как "Без источника" (ТЗ, п.14)', () => {
    renderPage()

    expect(screen.getByText('Зарплата')).toBeInTheDocument()
    expect(screen.getByText('Без источника')).toBeInTheDocument()
  })

  it('бюджет на месяц не создан — сообщение вместо цифр (ТЗ, п.17)', () => {
    renderPage()

    expect(screen.getByText('Бюджет на этот месяц ещё не создан.')).toBeInTheDocument()
  })

  it('бюджет создан — показывает лимит/потрачено/осталось/использовано из Stage 10 (ТЗ, п.17-18)', () => {
    mockUseBudgetSummary.mockReturnValue({ data: WITH_BUDGET, isLoading: false, isError: false, refetch: vi.fn() })

    renderPage()

    expect(screen.getByText('300 000 ₽')).toBeInTheDocument()
    expect(screen.getByText('215 000 ₽')).toBeInTheDocument()
    expect(screen.getByText('85 000 ₽')).toBeInTheDocument()
    expect(screen.getByText('71.7%')).toBeInTheDocument()
  })

  it('"Запланировано" считает только планы со статусом planned внутри периода, с подписью "Не входит в фактические расходы" (ТЗ, п.19)', () => {
    renderPage()

    // pe-1 (12 345, внутри периода, planned) учтён; pe-2 (вне периода) и pe-3
    // (уже выполнен) — нет. Итог должен быть ровно 12 345, а не 12345+99999+77777.
    expect(screen.getByText('12 345 ₽')).toBeInTheDocument()
    expect(screen.getByText('Не входит в фактические расходы')).toBeInTheDocument()
  })

  it('показывает активную цель с процентом выполнения и ссылку на /app/goals (ТЗ, п.20-21)', () => {
    renderPage()

    expect(screen.getByText('Отпуск')).toBeInTheDocument()
    expect(screen.getByText('25%')).toBeInTheDocument()
    expect(screen.getByRole('link', { name: 'Открыть цели →' })).toHaveAttribute('href', '/app/goals')
  })

  it('read-only: на странице нет ни одной кнопки создания/редактирования финансовых записей (ТЗ, п.21)', () => {
    renderPage()

    expect(screen.queryByRole('button', { name: /добавить|создать|редактировать|удалить/i })).not.toBeInTheDocument()
  })
})
