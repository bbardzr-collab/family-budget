import { fireEvent, render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter } from 'react-router-dom'
import { ToastProvider } from '@/components/ui/Toast'
import { TransactionsPage } from './TransactionsPage'
import type { TransactionListItem } from '@/features/transactions/api'
import type { CategoryListItem } from '@/features/categories/api'

const {
  mockUseTransactionsList,
  mockUseTransactionsTotals,
  mockUseHasAnyTransactions,
  mockUseCategories,
  mockUseFamily,
  mockCreateMutateAsync,
  mockUpdateMutateAsync,
  mockDeleteMutateAsync,
  mockFetchNextPage,
  mockRefetch,
} = vi.hoisted(() => ({
  mockUseTransactionsList: vi.fn(),
  mockUseTransactionsTotals: vi.fn(),
  mockUseHasAnyTransactions: vi.fn(),
  mockUseCategories: vi.fn(),
  mockUseFamily: vi.fn(),
  mockCreateMutateAsync: vi.fn(),
  mockUpdateMutateAsync: vi.fn(),
  mockDeleteMutateAsync: vi.fn(),
  mockFetchNextPage: vi.fn(),
  mockRefetch: vi.fn(),
}))

vi.mock('@/features/transactions/hooks', () => ({
  useTransactionsList: mockUseTransactionsList,
  useTransactionsTotals: mockUseTransactionsTotals,
  useHasAnyTransactions: mockUseHasAnyTransactions,
  useCreateTransaction: () => ({ mutateAsync: mockCreateMutateAsync, isPending: false }),
  useUpdateTransaction: () => ({ mutateAsync: mockUpdateMutateAsync, isPending: false }),
  useDeleteTransaction: () => ({ mutateAsync: mockDeleteMutateAsync, isPending: false }),
}))

vi.mock('@/features/categories/hooks', () => ({
  useCategories: mockUseCategories,
}))

vi.mock('@/features/family/FamilyContext', () => ({
  useFamily: mockUseFamily,
}))

function renderPage() {
  return render(
    <MemoryRouter initialEntries={['/app/transactions']}>
      <ToastProvider>
        <TransactionsPage />
      </ToastProvider>
    </MemoryRouter>,
  )
}

const CATEGORIES: CategoryListItem[] = [
  { id: 'cat-1', name: 'Кафе', type: 'WANTS', icon: 'utensils', isActive: true, isCustom: false },
  { id: 'cat-2', name: 'Продукты', type: 'OBLIGATORY', icon: 'shopping-cart', isActive: true, isCustom: false },
]

const TRANSACTIONS: TransactionListItem[] = [
  {
    id: 'tx-1',
    type: 'expense',
    amount: 1500,
    transactionDate: '2026-09-10',
    incomeSource: null,
    comment: 'Продукты на неделю',
    userId: 'user-1',
    createdByName: 'Анна',
    categoryId: null,
    category: null,
  },
  {
    id: 'tx-2',
    type: 'income',
    amount: 50000,
    transactionDate: '2026-09-05',
    incomeSource: 'Зарплата',
    comment: null,
    userId: 'user-1',
    createdByName: 'Анна',
    categoryId: null,
    category: null,
  },
  {
    id: 'tx-3',
    type: 'expense',
    amount: 300,
    transactionDate: '2026-09-08',
    incomeSource: null,
    comment: 'Обед',
    userId: 'user-1',
    createdByName: 'Пётр',
    categoryId: 'cat-1',
    category: { id: 'cat-1', name: 'Кафе', icon: 'utensils', isActive: true },
  },
]

function mockList(items: TransactionListItem[], overrides: Partial<ReturnType<typeof mockUseTransactionsList>> = {}) {
  mockUseTransactionsList.mockReturnValue({
    data: { pages: [{ items, hasMore: false }] },
    isLoading: false,
    isFetching: false,
    isError: false,
    refetch: mockRefetch,
    fetchNextPage: mockFetchNextPage,
    hasNextPage: false,
    isFetchingNextPage: false,
    ...overrides,
  })
}

describe('TransactionsPage (Этап 9)', () => {
  beforeEach(() => {
    mockCreateMutateAsync.mockReset()
    mockUpdateMutateAsync.mockReset()
    mockDeleteMutateAsync.mockReset()
    mockFetchNextPage.mockReset()
    mockRefetch.mockReset()
    mockDeleteMutateAsync.mockResolvedValue(undefined)
    mockUseCategories.mockReturnValue({ data: CATEGORIES, isLoading: false, isError: false })
    // Суммы намеренно НЕ совпадают ни с одной суммой операций из TRANSACTIONS
    // ниже (1500/50000/300) — иначе "+50 000 ₽" итогов и "+50 000 ₽" строки
    // дохода в списке было бы неразличимо в DOM для текстовых запросов теста.
    mockUseTransactionsTotals.mockReturnValue({
      data: { income: 52340, expenses: 1800, balance: 50540 },
      isLoading: false,
    })
    mockUseHasAnyTransactions.mockReturnValue({ data: true, isLoading: false })
    mockUseFamily.mockReturnValue({ isChild: false, isAdult: true, isAdmin: false })
    mockList(TRANSACTIONS)
  })

  it('заголовок "Операции" для admin/adult и "Мои операции" для child (Этап 16, п.20)', () => {
    renderPage()
    expect(screen.getByText('Операции')).toBeInTheDocument()
    expect(screen.queryByText('Мои операции')).not.toBeInTheDocument()
  })

  it('заголовок "Мои операции" когда роль — child (Этап 16, п.20)', () => {
    mockUseFamily.mockReturnValue({ isChild: true, isAdult: false, isAdmin: false })

    renderPage()

    expect(screen.getByText('Мои операции')).toBeInTheDocument()
    expect(screen.queryByText('Операции')).not.toBeInTheDocument()
  })

  it('операций у семьи вообще нет: EmptyState "Операций пока нет" с кнопкой добавить первую операцию', () => {
    mockUseHasAnyTransactions.mockReturnValue({ data: false, isLoading: false })
    mockList([])

    renderPage()

    expect(screen.getByText('Операций пока нет')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Добавить первую операцию' })).toBeInTheDocument()
  })

  it('операции есть, но фильтр ничего не нашёл: другое EmptyState с кнопкой "Сбросить фильтры" (ТЗ, п.22)', () => {
    mockList([])

    renderPage()

    expect(screen.getByText('По выбранным фильтрам ничего не найдено')).toBeInTheDocument()
    // Кнопка "Сбросить фильтры" есть и в EmptyState, и в самой панели
    // фильтров (там она просто disabled при дефолтных фильтрах) — оба имени
    // совпадают, поэтому getAllByRole вместо getByRole.
    expect(screen.getAllByRole('button', { name: 'Сбросить фильтры' }).length).toBeGreaterThanOrEqual(1)
    expect(screen.queryByText('Операций пока нет')).not.toBeInTheDocument()
  })

  it('ошибка загрузки показывает ErrorState с кнопкой "Повторить"', () => {
    mockList([], { isError: true })

    renderPage()

    expect(screen.getByText('Не удалось загрузить операции')).toBeInTheDocument()
    fireEvent.click(screen.getByRole('button', { name: /повторить/i }))
    expect(mockRefetch).toHaveBeenCalled()
  })

  it('показывает операции: название/дату/категорию/"Без категории"/доход без категории', () => {
    renderPage()

    expect(screen.getByText('Продукты на неделю')).toBeInTheDocument()
    // "Без категории" встречается и в строке tx-1, и как вариант в фильтре
    // "Категория" (<option>) — поэтому длина, а не единичный getByText.
    expect(screen.getAllByText('Без категории').length).toBeGreaterThanOrEqual(1)
    expect(screen.getAllByText('Кафе').length).toBeGreaterThanOrEqual(1)
    expect(screen.getByText('Зарплата')).toBeInTheDocument()
  })

  it('показывает итоги ТЕКУЩЕЙ выборки из useTransactionsTotals, а не Dashboard (ТЗ, п.12)', () => {
    renderPage()

    // "Доходы"/"Расходы" — те же слова, что и названия вкладок, поэтому
    // проверяем по фактическим суммам (уникальны на странице), а не по
    // подписям итогов. Матчер ограничен тегом <span> (сама сумма) — иначе
    // getByText находит и span, и его предков с тем же суммарным textContent
    // ("multiple elements found"), а также толерантен к неразрывным пробелам
    // (formatMoney) и типографскому минусу "−" (U+2212) вместо дефиса.
    function amountSpan(sign: '+' | '-', groups: string[]) {
      return (_content: string, element: Element | null) =>
        element?.tagName === 'SPAN' && new RegExp(`^[${sign}−]${groups.join('\\s')}\\s₽$`).test(element.textContent ?? '')
    }

    expect(screen.getByText(amountSpan('+', ['52', '340']))).toBeInTheDocument()
    expect(screen.getByText(amountSpan('-', ['1', '800']))).toBeInTheDocument()
    expect(screen.getByText(amountSpan('+', ['50', '540']))).toBeInTheDocument()
    expect(screen.getByText('Баланс')).toBeInTheDocument()
  })

  it('вкладка "Расходы" передаёт type="expense" в запрос списка и итогов (ТЗ, п.14, 16)', () => {
    renderPage()

    fireEvent.click(screen.getByRole('tab', { name: 'Расходы' }))

    const lastListCall = mockUseTransactionsList.mock.calls.at(-1)![0]
    const lastTotalsCall = mockUseTransactionsTotals.mock.calls.at(-1)![0]
    expect(lastListCall.type).toBe('expense')
    expect(lastTotalsCall.type).toBe('expense')
  })

  it('выбор категории в фильтре передаёт её id как categoryMode="specific" (ТЗ, п.4, 14)', () => {
    renderPage()

    fireEvent.change(screen.getByLabelText('Категория'), { target: { value: 'cat-1' } })

    const lastCall = mockUseTransactionsList.mock.calls.at(-1)![0]
    expect(lastCall.categoryMode).toBe('specific')
    expect(lastCall.categoryId).toBe('cat-1')
  })

  it('на вкладке "Доходы" фильтр категории отключён и не влияет на запрос (ТЗ, п.4)', () => {
    renderPage()

    fireEvent.click(screen.getByRole('tab', { name: 'Доходы' }))

    expect(screen.getByLabelText('Категория')).toBeDisabled()
    const lastCall = mockUseTransactionsList.mock.calls.at(-1)![0]
    expect(lastCall.categoryMode).toBe('all')
  })

  it('поиск отправляется в запрос с задержкой (debounce), а не на каждый символ (ТЗ, п.5-6)', async () => {
    const user = userEvent.setup()
    renderPage()

    const callsBefore = mockUseTransactionsList.mock.calls.length
    await user.type(screen.getByLabelText('Поиск операций'), 'кафе')

    // Сразу после ввода запрос ещё не должен уйти с новым search.
    expect(mockUseTransactionsList.mock.calls.at(-1)![0].search).not.toBe('кафе')

    await waitFor(
      () => expect(mockUseTransactionsList.mock.calls.at(-1)![0].search).toBe('кафе'),
      { timeout: 1000 },
    )
    expect(mockUseTransactionsList.mock.calls.length).toBeGreaterThan(callsBefore)
  })

  it('сортировка "Старые сначала" передаётся в запрос', () => {
    renderPage()

    fireEvent.change(screen.getByLabelText('Сортировка'), { target: { value: 'date_asc' } })

    expect(mockUseTransactionsList.mock.calls.at(-1)![0].sort).toBe('date_asc')
  })

  it('"Сбросить фильтры" возвращает тип операции на вкладку "Все" (единый источник состояния, ТЗ, п.18, 20)', () => {
    renderPage()

    fireEvent.click(screen.getByRole('tab', { name: 'Расходы' }))
    expect(screen.getByRole('tab', { name: 'Расходы' })).toHaveAttribute('aria-selected', 'true')

    // Открываем мобильную панель фильтров, чтобы добраться до кнопки сброса,
    // либо используем десктопную — обе рендерят один и тот же компонент,
    // здесь просто берём первую найденную кнопку с этим именем.
    fireEvent.click(screen.getAllByRole('button', { name: 'Сбросить фильтры' })[0]!)

    expect(screen.getByRole('tab', { name: 'Все' })).toHaveAttribute('aria-selected', 'true')
  })

  it('"Загрузить ещё" показывается при hasNextPage и вызывает fetchNextPage', () => {
    mockList(TRANSACTIONS, { hasNextPage: true })

    renderPage()

    fireEvent.click(screen.getByRole('button', { name: 'Загрузить ещё' }))
    expect(mockFetchNextPage).toHaveBeenCalled()
  })

  it('кнопка "Добавить" открывает форму создания операции', () => {
    renderPage()

    fireEvent.click(screen.getByRole('button', { name: 'Добавить' }))

    expect(screen.getByRole('dialog', { name: 'Добавить операцию' })).toBeInTheDocument()
  })

  it('клик по операции открывает подробности с категорией/датой/суммой/автором', () => {
    renderPage()

    fireEvent.click(screen.getByRole('button', { name: /Обед/i }))

    const dialog = screen.getByRole('dialog', { name: 'Расход' })
    expect(dialog).toBeInTheDocument()
    expect(screen.getByText('Пётр')).toBeInTheDocument()
    expect(screen.getAllByText('Кафе').length).toBeGreaterThan(0)
  })

  it('из подробностей "Редактировать" открывает форму, предзаполненную данными операции', () => {
    renderPage()

    fireEvent.click(screen.getByRole('button', { name: /Обед/i }))
    fireEvent.click(screen.getByRole('button', { name: 'Редактировать' }))

    expect(screen.getByRole('dialog', { name: 'Изменить операцию' })).toBeInTheDocument()
    expect(screen.getByLabelText('Сумма')).toHaveValue('300.00')
  })

  it('из подробностей "Удалить" открывает подтверждение и вызывает мутацию удаления', async () => {
    renderPage()

    fireEvent.click(screen.getByRole('button', { name: /Обед/i }))
    fireEvent.click(screen.getByRole('button', { name: 'Удалить' }))

    expect(screen.getByRole('dialog', { name: 'Удалить операцию?' })).toBeInTheDocument()
    fireEvent.click(screen.getByRole('button', { name: 'Удалить' }))

    expect(await screen.findByText('Операция удалена')).toBeInTheDocument()
    expect(mockDeleteMutateAsync).toHaveBeenCalledWith('tx-3')
  })
})
