import { fireEvent, render, screen } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { ToastProvider } from '@/components/ui/Toast'
import { BudgetPage } from './BudgetPage'
import type { BudgetSummary } from '@/features/budgets/api'
import type { CategoryListItem } from '@/features/categories/api'

const {
  mockUseBudgetSummary,
  mockUseFamily,
  mockUseCategories,
  mockCreateBudgetMutateAsync,
  mockUpdateBudgetMutateAsync,
  mockDeleteBudgetMutateAsync,
  mockAddBudgetCategoryMutateAsync,
  mockUpdateBudgetCategoryMutateAsync,
  mockDeleteBudgetCategoryMutateAsync,
} = vi.hoisted(() => ({
  mockUseBudgetSummary: vi.fn(),
  mockUseFamily: vi.fn(),
  mockUseCategories: vi.fn(),
  mockCreateBudgetMutateAsync: vi.fn(),
  mockUpdateBudgetMutateAsync: vi.fn(),
  mockDeleteBudgetMutateAsync: vi.fn(),
  mockAddBudgetCategoryMutateAsync: vi.fn(),
  mockUpdateBudgetCategoryMutateAsync: vi.fn(),
  mockDeleteBudgetCategoryMutateAsync: vi.fn(),
}))

vi.mock('@/features/budgets/hooks', () => ({
  useBudgetSummary: mockUseBudgetSummary,
  useCreateBudget: () => ({ mutateAsync: mockCreateBudgetMutateAsync, isPending: false }),
  useUpdateBudget: () => ({ mutateAsync: mockUpdateBudgetMutateAsync, isPending: false }),
  useDeleteBudget: () => ({ mutateAsync: mockDeleteBudgetMutateAsync, isPending: false }),
  useAddBudgetCategory: () => ({ mutateAsync: mockAddBudgetCategoryMutateAsync, isPending: false }),
  useUpdateBudgetCategory: () => ({ mutateAsync: mockUpdateBudgetCategoryMutateAsync, isPending: false }),
  useDeleteBudgetCategory: () => ({ mutateAsync: mockDeleteBudgetCategoryMutateAsync, isPending: false }),
}))

vi.mock('@/features/family/FamilyContext', () => ({
  useFamily: mockUseFamily,
}))

vi.mock('@/features/categories/hooks', () => ({
  useCategories: mockUseCategories,
}))

function renderPage(initialEntries: string[] = ['/app/budget']) {
  return render(
    <MemoryRouter initialEntries={initialEntries}>
      <ToastProvider>
        <BudgetPage />
      </ToastProvider>
    </MemoryRouter>,
  )
}

const EMPTY_SUMMARY: BudgetSummary = {
  budget: null,
  totalSpent: 0,
  totalRemaining: 0,
  totalPercent: null,
  categories: [],
}

const OVER_BUDGET_SUMMARY: BudgetSummary = {
  budget: { id: 'budget-1', periodMonth: '2026-09-01', totalAmount: 100000 },
  totalSpent: 110000,
  totalRemaining: -10000,
  totalPercent: 110,
  categories: [
    {
      id: 'bc-1',
      categoryId: 'cat-1',
      categoryName: 'Продукты',
      categoryIcon: 'shopping-cart',
      categoryType: 'OBLIGATORY',
      limitAmount: 20000,
      spentAmount: 25200,
      remainingAmount: -5200,
      percent: 126,
      isActive: true,
    },
    {
      id: 'bc-2',
      categoryId: 'cat-2',
      categoryName: 'Кафе',
      categoryIcon: 'utensils',
      categoryType: 'WANTS',
      limitAmount: 10000,
      spentAmount: 4000,
      remainingAmount: 6000,
      percent: 40,
      isActive: true,
    },
  ],
}

const CATEGORIES: CategoryListItem[] = [
  { id: 'cat-1', name: 'Продукты', type: 'OBLIGATORY', icon: 'shopping-cart', isActive: true, isCustom: false },
  { id: 'cat-2', name: 'Кафе', type: 'WANTS', icon: 'utensils', isActive: true, isCustom: false },
  { id: 'cat-3', name: 'Транспорт', type: 'OBLIGATORY', icon: 'car', isActive: true, isCustom: false },
]

describe('BudgetPage (Этап 10)', () => {
  beforeEach(() => {
    mockUseCategories.mockReturnValue({ data: CATEGORIES, isLoading: false, isError: false })
    mockUseFamily.mockReturnValue({ isChild: false })
  })

  it('во время загрузки показывает Skeleton', () => {
    mockUseBudgetSummary.mockReturnValue({
      data: undefined,
      isLoading: true,
      isError: false,
      isFetching: true,
      refetch: vi.fn(),
    })

    renderPage()

    expect(screen.getByRole('status', { name: /загружаем бюджет/i })).toBeInTheDocument()
  })

  it('ошибка загрузки показывает ErrorState с кнопкой "Повторить"', () => {
    const refetch = vi.fn()
    mockUseBudgetSummary.mockReturnValue({
      data: undefined,
      isLoading: false,
      isError: true,
      isFetching: false,
      refetch,
    })

    renderPage()

    expect(screen.getByText('Не удалось загрузить бюджет')).toBeInTheDocument()
    fireEvent.click(screen.getByRole('button', { name: /повторить/i }))
    expect(refetch).toHaveBeenCalled()
  })

  it('бюджет на месяц не создан: EmptyState с кнопкой "Создать бюджет", открывающей форму', () => {
    mockUseBudgetSummary.mockReturnValue({
      data: EMPTY_SUMMARY,
      isLoading: false,
      isError: false,
      isFetching: false,
      refetch: vi.fn(),
    })

    renderPage()

    expect(screen.getByText('Бюджет на этот месяц ещё не создан')).toBeInTheDocument()
    fireEvent.click(screen.getByRole('button', { name: 'Создать бюджет' }))
    expect(screen.getByRole('dialog', { name: 'Создать бюджет' })).toBeInTheDocument()
  })

  it('CHILD не видит кнопку "Создать бюджет" (ТЗ, п.21 — скрытие в UI, не единственная защита)', () => {
    mockUseFamily.mockReturnValue({ isChild: true })
    mockUseBudgetSummary.mockReturnValue({
      data: EMPTY_SUMMARY,
      isLoading: false,
      isError: false,
      isFetching: false,
      refetch: vi.fn(),
    })

    renderPage()

    expect(screen.getByText('Бюджет на этот месяц ещё не создан')).toBeInTheDocument()
    expect(screen.queryByRole('button', { name: 'Создать бюджет' })).not.toBeInTheDocument()
  })

  it('показывает превышение общего бюджета: потрачено больше бюджета, остаток отрицательный, % > 100 (ТЗ, п.7)', () => {
    mockUseBudgetSummary.mockReturnValue({
      data: OVER_BUDGET_SUMMARY,
      isLoading: false,
      isError: false,
      isFetching: false,
      refetch: vi.fn(),
    })

    renderPage()

    expect(screen.getByText(/100 000/)).toBeInTheDocument() // общий бюджет
    expect(screen.getByText(/110 000/)).toBeInTheDocument() // потрачено
    expect(screen.getByText(/[-−]10 000/)).toBeInTheDocument() // остаток отрицательный
    expect(screen.getByText('110%')).toBeInTheDocument()
  })

  it('показывает превышение по категории явно: "Превышение +5 200 ₽" вместо "Осталось" (ТЗ, п.14)', () => {
    mockUseBudgetSummary.mockReturnValue({
      data: OVER_BUDGET_SUMMARY,
      isLoading: false,
      isError: false,
      isFetching: false,
      refetch: vi.fn(),
    })

    renderPage()

    expect(screen.getByText('Превышение')).toBeInTheDocument()
    expect(screen.getByText(/\+5 200/)).toBeInTheDocument()
    // "Осталось" встречается и в общей карточке бюджета, и у второй категории
    // (Кафе), лимит которой не превышен — показывается "Осталось", а не
    // "Превышение", поэтому здесь достаточно хотя бы одного вхождения.
    expect(screen.getAllByText('Осталось').length).toBeGreaterThanOrEqual(1)
  })

  it('показывает предупреждение, если сумма лимитов категорий больше общего бюджета, но не блокирует ничего (ТЗ, п.16)', () => {
    mockUseBudgetSummary.mockReturnValue({
      data: {
        ...OVER_BUDGET_SUMMARY,
        budget: { id: 'budget-1', periodMonth: '2026-09-01', totalAmount: 25000 },
      },
      isLoading: false,
      isError: false,
      isFetching: false,
      refetch: vi.fn(),
    })

    renderPage()

    expect(screen.getByText(/сумма лимитов категорий/i)).toBeInTheDocument()
  })

  it('НЕ показывает предупреждение при математически равной (но float-небезопасной) сумме лимитов и бюджета (Этап 20 — регресс-тест на найденный баг: 10000.10 + 20000.20 !== 30000.30 в обычном JS)', () => {
    mockUseBudgetSummary.mockReturnValue({
      data: {
        ...OVER_BUDGET_SUMMARY,
        budget: { id: 'budget-1', periodMonth: '2026-09-01', totalAmount: 30000.3 },
        categories: [
          { ...OVER_BUDGET_SUMMARY.categories[0], limitAmount: 10000.1 },
          { ...OVER_BUDGET_SUMMARY.categories[1], limitAmount: 20000.2 },
        ],
      },
      isLoading: false,
      isError: false,
      isFetching: false,
      refetch: vi.fn(),
    })

    renderPage()

    expect(screen.queryByText(/сумма лимитов категорий/i)).not.toBeInTheDocument()
  })

  it('лимиты категорий ещё не настроены: EmptyState с кнопкой "Добавить категорию"', () => {
    mockUseBudgetSummary.mockReturnValue({
      data: { ...OVER_BUDGET_SUMMARY, categories: [] },
      isLoading: false,
      isError: false,
      isFetching: false,
      refetch: vi.fn(),
    })

    renderPage()

    expect(screen.getByText('Лимиты по категориям ещё не настроены')).toBeInTheDocument()
    fireEvent.click(screen.getByRole('button', { name: 'Добавить категорию' }))
    expect(screen.getByRole('dialog', { name: 'Добавить категорию' })).toBeInTheDocument()
  })

  it('CHILD не видит кнопки редактирования/удаления бюджета, действий с категориями и "Добавить категорию" (ТЗ, п.21)', () => {
    mockUseFamily.mockReturnValue({ isChild: true })
    mockUseBudgetSummary.mockReturnValue({
      data: OVER_BUDGET_SUMMARY,
      isLoading: false,
      isError: false,
      isFetching: false,
      refetch: vi.fn(),
    })

    renderPage()

    expect(screen.queryByRole('button', { name: 'Редактировать бюджет' })).not.toBeInTheDocument()
    expect(screen.queryByRole('button', { name: 'Удалить бюджет' })).not.toBeInTheDocument()
    expect(screen.queryByRole('button', { name: 'Добавить категорию' })).not.toBeInTheDocument()
    expect(screen.queryByRole('button', { name: /Действия с категорией/i })).not.toBeInTheDocument()
  })

  it('переключение на следующий месяц запрашивает сводку за новый период (ТЗ, п.30, 33)', () => {
    mockUseBudgetSummary.mockReturnValue({
      data: EMPTY_SUMMARY,
      isLoading: false,
      isError: false,
      isFetching: false,
      refetch: vi.fn(),
    })

    renderPage(['/app/budget?month=2026-09'])

    fireEvent.click(screen.getByRole('button', { name: 'Следующий месяц' }))

    const lastCall = mockUseBudgetSummary.mock.calls.at(-1)
    expect(lastCall?.[0]).toBe('2026-10-01')
  })

  it('удаление бюджета показывает подтверждение с точным текстом ТЗ и вызывает мутацию', async () => {
    mockDeleteBudgetMutateAsync.mockResolvedValue(undefined)
    mockUseBudgetSummary.mockReturnValue({
      data: OVER_BUDGET_SUMMARY,
      isLoading: false,
      isError: false,
      isFetching: false,
      refetch: vi.fn(),
    })

    renderPage(['/app/budget?month=2026-09'])

    fireEvent.click(screen.getByRole('button', { name: 'Удалить бюджет' }))

    expect(screen.getByRole('dialog', { name: 'Удалить бюджет за сентябрь 2026?' })).toBeInTheDocument()
    expect(screen.getByText('История операций не будет удалена.')).toBeInTheDocument()

    fireEvent.click(screen.getByRole('button', { name: 'Удалить' }))

    expect(await screen.findByText('Бюджет удалён')).toBeInTheDocument()
    expect(mockDeleteBudgetMutateAsync).toHaveBeenCalledWith('budget-1')
  })
})
