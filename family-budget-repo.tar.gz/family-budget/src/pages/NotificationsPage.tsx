import { useState } from 'react'
import { CheckCheck, Inbox } from 'lucide-react'
import { Button, Card, CardContent, EmptyState, ErrorState, PageTitle, Skeleton, Tabs, TabsList, TabsTrigger } from '@/components/ui'
import { useToast } from '@/components/ui/Toast'
import { NotificationRow } from '@/features/notifications/NotificationRow'
import {
  useDeleteNotification,
  useMarkAllNotificationsRead,
  useMarkNotificationRead,
  useNotifications,
} from '@/features/notifications/hooks'
import { getNotificationErrorMessage } from '@/features/notifications/errors'
import type { NotificationItem } from '@/features/notifications/api'

type NotificationFilter = 'all' | 'unread'

/**
 * Центр уведомлений (Этап 17, п.6) — "Все"/"Непрочитанные" (ТЗ, п.6),
 * "Прочитать все" видна только при наличии непрочитанных (ТЗ, п.8). Данные
 * читаются напрямую через RLS notifications_select_own (features/
 * notifications/api.ts) — сервер уже отдаёт только уведомления текущего
 * пользователя, здесь нет и не может быть клиентской "дофильтровки чужого".
 */
export function NotificationsPage() {
  const { toast } = useToast()
  const [filter, setFilter] = useState<NotificationFilter>('all')

  const { data: items, isLoading, isError, refetch } = useNotifications({ unreadOnly: filter === 'unread' })
  const markRead = useMarkNotificationRead()
  const markAllRead = useMarkAllNotificationsRead()
  const deleteNotificationMutation = useDeleteNotification()

  const hasUnread = (items ?? []).some((item) => !item.isRead)
  const showEmpty = !isLoading && !isError && (items ?? []).length === 0

  function handleOpen(item: NotificationItem) {
    if (!item.isRead) markRead.mutate(item.id)
  }

  async function handleMarkAllRead() {
    try {
      await markAllRead.mutateAsync()
    } catch (error) {
      toast({ type: 'error', title: getNotificationErrorMessage(error) })
    }
  }

  async function handleDelete(item: NotificationItem) {
    try {
      await deleteNotificationMutation.mutateAsync(item.id)
    } catch (error) {
      toast({ type: 'error', title: getNotificationErrorMessage(error) })
    }
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <PageTitle>Уведомления</PageTitle>
        {hasUnread && (
          <Button variant="secondary" size="sm" onClick={() => void handleMarkAllRead()} isLoading={markAllRead.isPending}>
            <CheckCheck className="size-4" aria-hidden="true" />
            Прочитать все
          </Button>
        )}
      </div>

      <Tabs value={filter} onValueChange={(value) => setFilter(value as NotificationFilter)}>
        <TabsList>
          <TabsTrigger value="all">Все</TabsTrigger>
          <TabsTrigger value="unread">Непрочитанные</TabsTrigger>
        </TabsList>
      </Tabs>

      <Card>
        <CardContent className="pt-6">
          {isLoading && (
            <div className="flex flex-col gap-3" role="status" aria-label="Загружаем уведомления…">
              {[0, 1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          )}

          {isError && <ErrorState title="Не удалось загрузить уведомления" onRetry={() => void refetch()} />}

          {showEmpty &&
            (filter === 'unread' ? (
              <EmptyState icon={CheckCheck} title="Нет непрочитанных уведомлений" />
            ) : (
              <EmptyState icon={Inbox} title="Всё чисто" description="Новых уведомлений пока нет." />
            ))}

          {!isLoading && !isError && items && items.length > 0 && (
            <ul className="flex flex-col divide-y divide-border">
              {items.map((item) => (
                <NotificationRow key={item.id} item={item} onOpen={handleOpen} onDelete={handleDelete} />
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
