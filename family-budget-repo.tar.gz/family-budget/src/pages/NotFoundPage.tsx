import { Link } from 'react-router-dom'
import { Button } from '@/components/ui'

export function NotFoundPage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-background px-4 text-center">
      <p className="text-6xl font-semibold text-primary">404</p>
      <div>
        <p className="font-medium text-foreground">Страница не найдена</p>
        <p className="text-sm text-muted-foreground">Проверьте адрес или вернитесь на главную.</p>
      </div>
      <Link to="/">
        <Button variant="secondary">На главную</Button>
      </Link>
    </div>
  )
}
