import { fireEvent, render, screen } from '@testing-library/react'
import { ToastProvider } from '@/components/ui/Toast'
import { CategoriesPage } from './CategoriesPage'
import type { CategoryListItem } from '@/features/categories/api'

const {
  mockUseCategories,
  mockToggleMutateAsync,
  mockCreateMutateAsync,
  mockUpdateMutateAsync,
  mockDeleteMutateAsync,
  mockUseCategoryUsage,
} = vi.hoisted(() => ({
  mockUseCategories: vi.fn(),
  mockToggleMutateAsync: vi.fn(),
  mockCreateMutateAsync: vi.fn(),
  mockUpdateMutateAsync: vi.fn(),
  mockDeleteMutateAsync: vi.fn(),
  mockUseCategoryUsage: vi.fn(),
}))

vi.mock('@/features/categories/hooks', () => ({
  useCategories: mockUseCategories,
  useToggleCategory: () => ({ mutateAsync: mockToggleMutateAsync, isPending: false }),
  useCreateCategory: () => ({ mutateAsync: mockCreateMutateAsync, isPending: false }),
  useUpdateCategory: () => ({ mutateAsync: mockUpdateMutateAsync, isPending: false }),
  useDeleteCategory: () => ({ mutateAsync: mockDeleteMutateAsync, isPending: false }),
  useCategoryUsage: mockUseCategoryUsage,
}))

function renderPage() {
  return render(
    <ToastProvider>
      <CategoriesPage />
    </ToastProvider>,
  )
}

const CATEGORIES: CategoryListItem[] = [
  { id: 'cat-1', name: 'Продукты', type: 'OBLIGATORY', icon: 'shopping-cart', isActive: true, isCustom: false },
  { id: 'cat-2', name: 'Кафе', type: 'WANTS', icon: 'utensils', isActive: true, isCustom: false },
  { id: 'cat-3', name: 'Хобби', type: 'WANTS', icon: 'palette', isActive: false, isCustom: true },
]

describe('CategoriesPage (Этап 8, п.6-7, 12, 26, 30)', () => {
  beforeEach(() => {
    mockToggleMutateAsync.mockReset()
    mockToggleMutateAsync.mockResolvedValue({})
    mockUseCategoryUsage.mockReturnValue({ data: undefined, isLoading: false })
  })

  it('пустой список: показывает EmptyState с кнопкой добавить категорию', () => {
    mockUseCategories.mockReturnValue({ data: [], isLoading: false, isError: false, refetch: vi.fn() })

    renderPage()

    expect(screen.getByText('Категорий пока нет')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Добавить первую категорию' })).toBeInTheDocument()
  })

  it('ошибка загрузки показывает ErrorState с кнопкой "Повторить"', () => {
    const refetch = vi.fn()
    mockUseCategories.mockReturnValue({ data: undefined, isLoading: false, isError: true, refetch })

    renderPage()

    expect(screen.getByText('Не удалось загрузить категории')).toBeInTheDocument()
    fireEvent.click(screen.getByRole('button', { name: /повторить/i }))
    expect(refetch).toHaveBeenCalled()
  })

  it('группирует категории по типу с человеческими подписями (не сырой enum) и показывает статус "Выключена"', () => {
    mockUseCategories.mockReturnValue({ data: CATEGORIES, isLoading: false, isError: false, refetch: vi.fn() })

    renderPage()

    expect(screen.getByText('Обязательное')).toBeInTheDocument()
    expect(screen.getByText('Желания')).toBeInTheDocument()
    expect(screen.getByText('Цели')).toBeInTheDocument()
    expect(screen.getByText('Другое')).toBeInTheDocument()

    expect(screen.getByText('Продукты')).toBeInTheDocument()
    expect(screen.getByText('Кафе')).toBeInTheDocument()
    expect(screen.getByText('Хобби')).toBeInTheDocument()
    expect(screen.getByText('Выключена')).toBeInTheDocument()
  })

  it('кнопка "Добавить категорию" открывает форму создания', () => {
    mockUseCategories.mockReturnValue({ data: [], isLoading: false, isError: false, refetch: vi.fn() })

    renderPage()

    fireEvent.click(screen.getByRole('button', { name: 'Добавить категорию' }))

    expect(screen.getByRole('dialog', { name: 'Добавить категорию' })).toBeInTheDocument()
  })

  it('меню действий позволяет включить/отключить категорию (toggle active↔inactive)', async () => {
    mockUseCategories.mockReturnValue({ data: CATEGORIES, isLoading: false, isError: false, refetch: vi.fn() })

    renderPage()

    const menuButtons = screen.getAllByRole('button', { name: 'Действия с категорией' })
    fireEvent.click(menuButtons[0]!)

    const disableItem = await screen.findByRole('menuitem', { name: 'Отключить' })
    fireEvent.click(disableItem)

    expect(mockToggleMutateAsync).toHaveBeenCalledWith({ id: 'cat-1', isActive: false })
  })

  it('у системной категории меню не предлагает "Удалить"; у пользовательской — предлагает', async () => {
    mockUseCategories.mockReturnValue({ data: CATEGORIES, isLoading: false, isError: false, refetch: vi.fn() })

    renderPage()

    const menuButtons = screen.getAllByRole('button', { name: 'Действия с категорией' })

    // cat-1 — системная (Продукты)
    fireEvent.click(menuButtons[0]!)
    expect(screen.queryByRole('menuitem', { name: 'Удалить' })).not.toBeInTheDocument()
    fireEvent.click(menuButtons[0]!)

    // cat-3 — пользовательская (Хобби)
    fireEvent.click(menuButtons[2]!)
    expect(await screen.findByRole('menuitem', { name: 'Удалить' })).toBeInTheDocument()
  })
})
