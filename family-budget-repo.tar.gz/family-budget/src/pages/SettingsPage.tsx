import { ChevronRight, Tag } from 'lucide-react'
import { Link } from 'react-router-dom'
import { Settings } from 'lucide-react'
import { Card, CardContent, PageTitle } from '@/components/ui'
import { StagePlaceholder } from '@/components/StagePlaceholder'
import { SupabaseStatus } from '@/components/dev/SupabaseStatus'
import { NotificationSettingsSection } from '@/features/notifications/NotificationSettingsSection'
import { InstallPWAButton } from '@/components/InstallPWAButton'

export function SettingsPage() {
  return (
    <div className="flex flex-col gap-4">
      <PageTitle>Настройки</PageTitle>

      {/* Точка входа в категории (Этап 8, п.6, 29) — маршрут /app/categories
          существует и напрямую, но основная точка входа — отсюда, как и
          предлагает ТЗ ("Настройки → Категории"), чтобы не трогать
          зафиксированную навигацию из 5 вкладок. */}
      <Card>
        <CardContent className="pt-6">
          <Link
            to="/app/categories"
            className="flex items-center gap-3 rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <span className="flex size-10 shrink-0 items-center justify-center rounded-full bg-muted text-muted-foreground">
              <Tag className="size-5" aria-hidden="true" />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block text-sm font-medium text-foreground">Категории</span>
              <span className="block text-sm text-muted-foreground">Категории расходов вашей семьи</span>
            </span>
            <ChevronRight className="size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
          </Link>
        </CardContent>
      </Card>

      <NotificationSettingsSection />

      {/* Устанавливается/скрывается сама (см. InstallPWAButton) — на
          standalone-режиме и платформах без поддержки установки ничего не
          рендерит, отдельной проверки здесь не требуется (Этап 18, п.19-22). */}
      <InstallPWAButton />

      <StagePlaceholder
        icon={Settings}
        title="Остальные настройки"
        description="Профиль и (в будущем) тёмная тема."
        stage="Этап 19"
      />
      {/* Технический health-check для разработки (Этап 3, п.35) — отсутствует в production-сборке */}
      {import.meta.env.DEV && <SupabaseStatus />}
    </div>
  )
}
