import { fireEvent, render, screen, waitFor, within } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { ToastProvider } from '@/components/ui/Toast'
import { FamilyPage } from './FamilyPage'

const {
  mockUseAuth,
  mockUseFamily,
  mockUseFamilyMembers,
  mockUseFamilyInvitations,
  mockUseFamilySettings,
  mockUseCancelInvitation,
  mockUpdateRoleMutateAsync,
  mockRemoveMemberMutateAsync,
  mockLeaveFamilyMutateAsync,
  mockRenameFamilyMutateAsync,
} = vi.hoisted(() => ({
  mockUseAuth: vi.fn(),
  mockUseFamily: vi.fn(),
  mockUseFamilyMembers: vi.fn(),
  mockUseFamilyInvitations: vi.fn(),
  mockUseFamilySettings: vi.fn(),
  mockUseCancelInvitation: vi.fn(),
  mockUpdateRoleMutateAsync: vi.fn(),
  mockRemoveMemberMutateAsync: vi.fn(),
  mockLeaveFamilyMutateAsync: vi.fn(),
  mockRenameFamilyMutateAsync: vi.fn(),
}))

vi.mock('@/features/auth/AuthContext', () => ({
  useAuth: mockUseAuth,
}))

vi.mock('@/features/family/FamilyContext', () => ({
  useFamily: mockUseFamily,
}))

vi.mock('@/features/family/hooks', () => ({
  useFamilyMembers: mockUseFamilyMembers,
  useFamilyInvitations: mockUseFamilyInvitations,
  useFamilySettings: mockUseFamilySettings,
  useCancelInvitation: mockUseCancelInvitation,
  useCreateInvitation: () => ({ mutateAsync: vi.fn() }),
  useCreateFamily: () => ({ mutateAsync: vi.fn() }),
  useUpdateMemberRole: () => ({ mutateAsync: mockUpdateRoleMutateAsync, isPending: false }),
  useRemoveMember: () => ({ mutateAsync: mockRemoveMemberMutateAsync, isPending: false }),
  useLeaveFamily: () => ({ mutateAsync: mockLeaveFamilyMutateAsync, isPending: false }),
  useRenameFamily: () => ({ mutateAsync: mockRenameFamilyMutateAsync, isPending: false }),
}))

function renderPage() {
  return render(
    <MemoryRouter initialEntries={['/app/family']}>
      <ToastProvider>
        <FamilyPage />
      </ToastProvider>
    </MemoryRouter>,
  )
}

const ADMIN_MEMBER = {
  id: 'm1',
  user_id: 'u-admin',
  role: 'admin',
  status: 'active',
  profile: { id: 'u-admin', full_name: 'Анна Иванова', avatar_url: null },
}
const ADULT_MEMBER = {
  id: 'm2',
  user_id: 'u-adult',
  role: 'adult',
  status: 'active',
  profile: { id: 'u-adult', full_name: 'Мария Иванова', avatar_url: null },
}
const CHILD_MEMBER = {
  id: 'm3',
  user_id: 'u-child',
  role: 'child',
  status: 'active',
  profile: { id: 'u-child', full_name: 'Петя Иванов', avatar_url: null },
}

describe('FamilyPage', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    mockUseAuth.mockReturnValue({ user: { id: 'u-admin' } })
    mockUseCancelInvitation.mockReturnValue({ mutateAsync: vi.fn(), isPending: false })
    mockUseFamilySettings.mockReturnValue({ data: { currency: 'RUB' } })
  })

  it('показывает форму создания семьи, если семьи ещё нет (п.32)', () => {
    mockUseFamily.mockReturnValue({ loading: false, hasFamily: false, currentFamily: null, isAdmin: false })
    mockUseFamilyMembers.mockReturnValue({ data: undefined, isLoading: false, isError: false })
    mockUseFamilyInvitations.mockReturnValue({ data: undefined, isLoading: false, isError: false })

    renderPage()

    expect(screen.getByText('Создайте семью')).toBeInTheDocument()
  })

  it('показывает загрузку, пока семейный контекст не определён', () => {
    mockUseFamily.mockReturnValue({ loading: true, hasFamily: false, currentFamily: null, isAdmin: false })
    mockUseFamilyMembers.mockReturnValue({ data: undefined, isLoading: true, isError: false })
    mockUseFamilyInvitations.mockReturnValue({ data: undefined, isLoading: true, isError: false })

    renderPage()

    expect(screen.getByText(/загружаем семью/i)).toBeInTheDocument()
  })

  it('ADMIN видит участников с человекочитаемыми ролями, кнопку приглашения, валюту семьи и список приглашений', () => {
    mockUseFamily.mockReturnValue({
      loading: false,
      hasFamily: true,
      currentFamily: { id: 'fam-1', name: 'Семья Ивановых' },
      isAdmin: true,
    })
    mockUseFamilyMembers.mockReturnValue({
      data: [ADMIN_MEMBER, CHILD_MEMBER],
      isLoading: false,
      isError: false,
    })
    mockUseFamilyInvitations.mockReturnValue({
      data: [
        {
          id: 'inv-1',
          role: 'adult',
          status: 'pending',
          expires_at: new Date(Date.now() + 86400000).toISOString(),
          created_at: new Date().toISOString(),
        },
      ],
      isLoading: false,
      isError: false,
    })

    renderPage()

    expect(screen.getByText('Семья Ивановых')).toBeInTheDocument()
    // Имя участника дублируется в sr-only span аватара (доступность) и в
    // видимом <p> списка участников — уточняем селектор, чтобы не ловить
    // ошибку неоднозначного совпадения (это баг теста, а не приложения).
    expect(screen.getByText('Анна Иванова', { selector: 'p' })).toBeInTheDocument()
    expect(screen.getByText('Администратор')).toBeInTheDocument()
    expect(screen.getByText('Петя Иванов', { selector: 'p' })).toBeInTheDocument()
    expect(screen.getByText('Ребёнок')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: /пригласить члена семьи/i })).toBeInTheDocument()
    expect(screen.getByText(/приглашение для роли «взрослый»/i)).toBeInTheDocument()
    expect(screen.getByText(/валюта семьи:\s*RUB/i)).toBeInTheDocument()
  })

  it('НЕ-admin не видит кнопку приглашения, список приглашений и меню действий над участниками', () => {
    mockUseFamily.mockReturnValue({
      loading: false,
      hasFamily: true,
      currentFamily: { id: 'fam-1', name: 'Семья Ивановых' },
      isAdmin: false,
    })
    mockUseAuth.mockReturnValue({ user: { id: 'u-child' } })
    mockUseFamilyMembers.mockReturnValue({
      data: [ADMIN_MEMBER, CHILD_MEMBER],
      isLoading: false,
      isError: false,
    })
    mockUseFamilyInvitations.mockReturnValue({ data: undefined, isLoading: false, isError: false })

    renderPage()

    expect(screen.queryByRole('button', { name: /пригласить члена семьи/i })).not.toBeInTheDocument()
    expect(screen.queryByText('Приглашения')).not.toBeInTheDocument()
    expect(screen.queryByRole('button', { name: /действия с участником/i })).not.toBeInTheDocument()
    // Переименование — тоже только ADMIN.
    expect(screen.queryByRole('button', { name: /переименовать семью/i })).not.toBeInTheDocument()
  })

  it('ADMIN видит меню действий у ДРУГИХ участников, но не у своей же строки (Этап 15, п.11, 13, 29)', () => {
    mockUseFamily.mockReturnValue({
      loading: false,
      hasFamily: true,
      currentFamily: { id: 'fam-1', name: 'Семья Ивановых' },
      isAdmin: true,
    })
    mockUseFamilyMembers.mockReturnValue({
      data: [ADMIN_MEMBER, ADULT_MEMBER, CHILD_MEMBER],
      isLoading: false,
      isError: false,
    })
    mockUseFamilyInvitations.mockReturnValue({ data: [], isLoading: false, isError: false })

    renderPage()

    // 2 других участника => 2 кнопки действий, ни одной — на собственной строке.
    expect(screen.getAllByRole('button', { name: /действия с участником/i })).toHaveLength(2)
  })

  it('смена роли участника (adult -> child) вызывает мутацию с новой ролью (Этап 15, п.11)', async () => {
    mockUseFamily.mockReturnValue({
      loading: false,
      hasFamily: true,
      currentFamily: { id: 'fam-1', name: 'Семья Ивановых' },
      isAdmin: true,
    })
    mockUseFamilyMembers.mockReturnValue({
      data: [ADMIN_MEMBER, ADULT_MEMBER],
      isLoading: false,
      isError: false,
    })
    mockUseFamilyInvitations.mockReturnValue({ data: [], isLoading: false, isError: false })
    mockUpdateRoleMutateAsync.mockResolvedValue(undefined)

    renderPage()

    fireEvent.click(screen.getByRole('button', { name: /действия с участником Мария Иванова/i }))
    fireEvent.click(screen.getByRole('menuitem', { name: 'Сделать ребёнком' }))

    await waitFor(() => {
      expect(mockUpdateRoleMutateAsync).toHaveBeenCalledWith({ memberId: 'm2', role: 'child' })
    })
  })

  it('удаление участника требует подтверждения в модалке и вызывает мутацию по клику "Удалить" (Этап 15, п.13)', async () => {
    mockUseFamily.mockReturnValue({
      loading: false,
      hasFamily: true,
      currentFamily: { id: 'fam-1', name: 'Семья Ивановых' },
      isAdmin: true,
    })
    mockUseFamilyMembers.mockReturnValue({
      data: [ADMIN_MEMBER, CHILD_MEMBER],
      isLoading: false,
      isError: false,
    })
    mockUseFamilyInvitations.mockReturnValue({ data: [], isLoading: false, isError: false })
    mockRemoveMemberMutateAsync.mockResolvedValue(undefined)

    renderPage()

    fireEvent.click(screen.getByRole('button', { name: /действия с участником Петя Иванов/i }))
    fireEvent.click(screen.getByRole('menuitem', { name: 'Удалить из семьи' }))

    const dialog = await screen.findByRole('dialog')
    expect(within(dialog).getByText(/уверены, что хотите удалить/i)).toBeInTheDocument()

    fireEvent.click(within(dialog).getByRole('button', { name: 'Удалить' }))

    await waitFor(() => {
      expect(mockRemoveMemberMutateAsync).toHaveBeenCalledWith('m3')
    })
  })

  it('"Покинуть семью" — единственному admin действие заблокировано, кнопка подтверждения недоступна (Этап 15, п.12, 14)', async () => {
    mockUseFamily.mockReturnValue({
      loading: false,
      hasFamily: true,
      currentFamily: { id: 'fam-1', name: 'Семья Ивановых' },
      isAdmin: true,
    })
    mockUseFamilyMembers.mockReturnValue({
      data: [ADMIN_MEMBER, CHILD_MEMBER],
      isLoading: false,
      isError: false,
    })
    mockUseFamilyInvitations.mockReturnValue({ data: [], isLoading: false, isError: false })

    renderPage()

    fireEvent.click(screen.getByRole('button', { name: /покинуть семью/i }))

    const dialog = await screen.findByRole('dialog')
    expect(within(dialog).getByText(/единственный администратор/i)).toBeInTheDocument()
    expect(within(dialog).getByRole('button', { name: 'Покинуть семью' })).toBeDisabled()
    expect(mockLeaveFamilyMutateAsync).not.toHaveBeenCalled()
  })

  it('"Покинуть семью" — не единственный admin может подтвердить выход', async () => {
    mockUseFamily.mockReturnValue({
      loading: false,
      hasFamily: true,
      currentFamily: { id: 'fam-1', name: 'Семья Ивановых' },
      isAdmin: false,
    })
    mockUseAuth.mockReturnValue({ user: { id: 'u-child' } })
    mockUseFamilyMembers.mockReturnValue({
      data: [ADMIN_MEMBER, CHILD_MEMBER],
      isLoading: false,
      isError: false,
    })
    mockUseFamilyInvitations.mockReturnValue({ data: undefined, isLoading: false, isError: false })
    mockLeaveFamilyMutateAsync.mockResolvedValue(undefined)

    renderPage()

    fireEvent.click(screen.getByRole('button', { name: /покинуть семью/i }))
    const dialog = await screen.findByRole('dialog')
    const confirmButton = within(dialog).getByRole('button', { name: 'Покинуть семью' })
    expect(confirmButton).not.toBeDisabled()

    fireEvent.click(confirmButton)

    await waitFor(() => {
      expect(mockLeaveFamilyMutateAsync).toHaveBeenCalled()
    })
  })

  it('переименование семьи ADMIN\'ом вызывает мутацию с новым именем (Этап 15, п.15)', async () => {
    mockUseFamily.mockReturnValue({
      loading: false,
      hasFamily: true,
      currentFamily: { id: 'fam-1', name: 'Семья Ивановых' },
      isAdmin: true,
    })
    mockUseFamilyMembers.mockReturnValue({ data: [ADMIN_MEMBER], isLoading: false, isError: false })
    mockUseFamilyInvitations.mockReturnValue({ data: [], isLoading: false, isError: false })
    mockRenameFamilyMutateAsync.mockResolvedValue(undefined)

    renderPage()

    fireEvent.click(screen.getByRole('button', { name: /переименовать семью/i }))
    const dialog = await screen.findByRole('dialog')
    const input = within(dialog).getByLabelText('Название семьи')
    fireEvent.change(input, { target: { value: 'Семья Петровых' } })
    fireEvent.click(within(dialog).getByRole('button', { name: 'Сохранить' }))

    await waitFor(() => {
      expect(mockRenameFamilyMutateAsync).toHaveBeenCalledWith('Семья Петровых')
    })
  })
})
