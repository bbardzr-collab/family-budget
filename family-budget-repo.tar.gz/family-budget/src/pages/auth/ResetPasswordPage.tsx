import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { useNavigate } from 'react-router-dom'
import { Card, CardContent, Button, ErrorState, LoadingState } from '@/components/ui'
import { PasswordField } from '@/features/auth/PasswordField'
import { useAuth } from '@/features/auth/AuthContext'
import { resetPasswordSchema, type ResetPasswordFormValues } from '@/features/auth/schemas'
import { getAuthErrorMessage } from '@/features/auth/authErrors'

/**
 * Экран после перехода по ссылке восстановления пароля (Этап 4, п.11).
 *
 * Supabase JS сам обрабатывает параметры ссылки (`detectSessionInUrl`) и
 * заводит временную сессию восстановления ещё до рендера этого компонента —
 * onAuthStateChange в AuthProvider её подхватывает как обычную session.
 * Поэтому здесь просто проверяем isAuthenticated: если сессии нет — ссылка
 * недействительна/устарела.
 */
export function ResetPasswordPage() {
  const { isAuthenticated, isLoading, updatePassword } = useAuth()
  const navigate = useNavigate()
  const [formError, setFormError] = useState<string | null>(null)
  const [done, setDone] = useState(false)

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<ResetPasswordFormValues>({ resolver: zodResolver(resetPasswordSchema) })

  const onSubmit = handleSubmit(async ({ password }) => {
    setFormError(null)
    const { error } = await updatePassword(password)
    if (error) {
      setFormError(getAuthErrorMessage(error))
      return
    }
    setDone(true)
  })

  if (isLoading) {
    return <LoadingState label="Проверяем ссылку…" />
  }

  if (!isAuthenticated) {
    return (
      <Card>
        <CardContent className="pt-6">
          <ErrorState
            title="Ссылка недействительна или устарела"
            description="Запросите новую ссылку для восстановления пароля."
            action={
              <Button size="sm" onClick={() => navigate('/forgot-password')}>
                Запросить новую ссылку
              </Button>
            }
          />
        </CardContent>
      </Card>
    )
  }

  if (done) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center gap-3 pt-6 text-center">
          <h1 className="text-lg font-semibold text-foreground">Пароль обновлён</h1>
          <p className="text-sm text-muted-foreground">
            Новый пароль сохранён. Теперь можно пользоваться приложением.
          </p>
          <Button size="lg" className="w-full" onClick={() => navigate('/app')}>
            Перейти в приложение
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardContent className="flex flex-col gap-4 pt-6">
        <div>
          <h1 className="text-lg font-semibold text-foreground">Новый пароль</h1>
          <p className="text-sm text-muted-foreground">Придумайте новый пароль для входа.</p>
        </div>

        <form className="flex flex-col gap-4" onSubmit={onSubmit} noValidate>
          <PasswordField
            label="Новый пароль"
            autoComplete="new-password"
            helperText="Минимум 8 символов"
            error={errors.password?.message}
            {...register('password')}
          />
          <PasswordField
            label="Подтверждение пароля"
            autoComplete="new-password"
            error={errors.confirmPassword?.message}
            {...register('confirmPassword')}
          />

          {formError && (
            <p role="alert" className="text-sm text-destructive">
              {formError}
            </p>
          )}

          <Button type="submit" size="lg" isLoading={isSubmitting} disabled={isSubmitting}>
            Сохранить пароль
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
