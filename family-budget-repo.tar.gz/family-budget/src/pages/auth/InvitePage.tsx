import { useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { MailWarning, Users } from 'lucide-react'
import { Button, Card, CardContent, LoadingState, Text } from '@/components/ui'
import { useToast } from '@/components/ui/Toast'
import { useAuth } from '@/features/auth/AuthContext'
import { useAcceptInvitation, useInvitationPreview } from '@/features/family/hooks'
import { getFamilyErrorMessage } from '@/features/family/errors'
import { roleLabel } from '@/features/family/roles'
import { formatDate } from '@/utils/formatDate'

/**
 * /invite/:token (Этап 5, п.20-23). Работает независимо от того, авторизован
 * пользователь или нет — проверка приглашения идёт через публичную RPC
 * get_invitation_by_token (не прямой SELECT family_invitations, п.28).
 * Токен нигде не логируется и не попадает в localStorage (п.29) — он живёт
 * только в URL и передаётся напрямую в RPC.
 */
export function InvitePage() {
  const { token } = useParams<{ token: string }>()
  const { isAuthenticated, isLoading: authLoading } = useAuth()
  const { data: preview, isLoading, isError } = useInvitationPreview(token)
  const acceptInvitation = useAcceptInvitation()
  const { toast } = useToast()
  const navigate = useNavigate()
  const [acceptError, setAcceptError] = useState<string | null>(null)

  if (isLoading || authLoading) {
    return <LoadingState label="Проверяем приглашение…" />
  }

  if (isError || !preview || !preview.isValid) {
    return <InvalidInvitationCard status={preview?.status} />
  }

  const redirectTarget = `/invite/${token}`

  async function handleAccept() {
    if (!token) return
    setAcceptError(null)
    try {
      await acceptInvitation.mutateAsync(token)
      toast({ type: 'success', title: 'Вы присоединились к семье' })
      navigate('/app/family', { replace: true })
    } catch (error) {
      setAcceptError(getFamilyErrorMessage(error))
    }
  }

  return (
    <Card>
      <CardContent className="flex flex-col items-center gap-4 pt-6 text-center">
        <div className="flex size-12 items-center justify-center rounded-full bg-accent">
          <Users className="size-6 text-primary" aria-hidden="true" />
        </div>
        <div>
          <h1 className="text-lg font-semibold text-foreground">Вас приглашают в семью</h1>
          <p className="mt-1 text-muted-foreground">
            «{preview.familyName}» — роль: {roleLabel(preview.role ?? '')}
          </p>
          {preview.expiresAt && (
            <p className="mt-1 text-sm text-muted-foreground">
              Ссылка действительна до {formatDate(preview.expiresAt)}
            </p>
          )}
        </div>

        {isAuthenticated ? (
          <div className="flex w-full flex-col gap-3">
            {acceptError && (
              <p role="alert" className="text-sm text-destructive">
                {acceptError}
              </p>
            )}
            <Button
              size="lg"
              isLoading={acceptInvitation.isPending}
              disabled={acceptInvitation.isPending}
              onClick={() => void handleAccept()}
            >
              Присоединиться
            </Button>
          </div>
        ) : (
          <div className="flex w-full flex-col gap-3">
            <Text variant="secondary">Чтобы присоединиться к семье, войдите или создайте аккаунт.</Text>
            <Button size="lg" onClick={() => navigate(`/login?redirect=${encodeURIComponent(redirectTarget)}`)}>
              Войти
            </Button>
            <Button
              variant="outline"
              size="lg"
              onClick={() => navigate(`/register?redirect=${encodeURIComponent(redirectTarget)}`)}
            >
              Создать аккаунт
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

const INVALID_REASON: Record<string, string> = {
  not_found: 'Такое приглашение не найдено. Проверьте, что ссылка скопирована полностью.',
  expired: 'Срок действия этой ссылки истёк. Попросите администратора семьи создать новое приглашение.',
  cancelled: 'Это приглашение было отменено администратором семьи.',
  accepted: 'Это приглашение уже использовано.',
}

function InvalidInvitationCard({ status }: { status?: string }) {
  const navigate = useNavigate()
  const description = (status && INVALID_REASON[status]) ?? 'Проверьте ссылку или запросите новое приглашение.'

  return (
    <Card>
      <CardContent className="flex flex-col items-center gap-4 pt-6 text-center">
        <div className="flex size-12 items-center justify-center rounded-full bg-danger-soft">
          <MailWarning className="size-6 text-danger" aria-hidden="true" />
        </div>
        <div>
          <h1 className="text-lg font-semibold text-foreground">Приглашение недействительно</h1>
          <p className="mt-1 text-muted-foreground">{description}</p>
        </div>
        <Button variant="outline" onClick={() => navigate('/')}>
          На главную
        </Button>
      </CardContent>
    </Card>
  )
}
