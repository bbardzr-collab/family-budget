import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { Link } from 'react-router-dom'
import { MailCheck } from 'lucide-react'
import { Button, Card, CardContent, Input } from '@/components/ui'
import { PasswordField } from '@/features/auth/PasswordField'
import { useAuth } from '@/features/auth/AuthContext'
import { registerSchema, type RegisterFormValues } from '@/features/auth/schemas'
import { getAuthErrorMessage } from '@/features/auth/authErrors'

/**
 * Регистрация (Этап 4, п.4–7). Создаёт ТОЛЬКО учётную запись в Supabase Auth
 * (+ автоматически public.users через триггер handle_new_auth_user, Этап 3) —
 * семья на этом этапе не создаётся, это Этап 5.
 *
 * После signUp — два возможных исхода, оба обрабатываем без предположений
 * о текущей настройке Supabase (п.7):
 *  - если email confirmation отключён, Supabase сразу возвращает session —
 *    isAuthenticated в AuthContext станет true, и PublicOnlyRoute сам уведёт на /app;
 *  - если включён, session отсутствует — показываем экран "проверьте почту".
 */
export function RegisterPage() {
  const { signUp } = useAuth()
  const [formError, setFormError] = useState<string | null>(null)
  const [awaitingConfirmation, setAwaitingConfirmation] = useState(false)

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<RegisterFormValues>({ resolver: zodResolver(registerSchema) })

  const onSubmit = handleSubmit(async (values) => {
    setFormError(null)
    const { error } = await signUp(values)
    if (error) {
      setFormError(getAuthErrorMessage(error))
      return
    }
    setAwaitingConfirmation(true)
  })

  if (awaitingConfirmation) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center gap-3 pt-6 text-center">
          <div className="flex size-12 items-center justify-center rounded-full bg-success-soft">
            <MailCheck className="size-6 text-success" aria-hidden="true" />
          </div>
          <div>
            <h1 className="text-lg font-semibold text-foreground">Проверьте почту</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Если для входа требуется подтверждение email, мы отправили ссылку на указанный адрес.
              Если подтверждение не требуется — можно сразу войти.
            </p>
          </div>
          <Link to="/login" className="text-sm text-primary hover:underline">
            Перейти ко входу
          </Link>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardContent className="flex flex-col gap-4 pt-6">
        <div>
          <h1 className="text-lg font-semibold text-foreground">Регистрация</h1>
          <p className="text-sm text-muted-foreground">
            Создание семьи будет доступно сразу после входа.
          </p>
        </div>

        <form className="flex flex-col gap-4" onSubmit={onSubmit} noValidate>
          <Input
            label="Имя"
            placeholder="Александр"
            autoComplete="name"
            error={errors.fullName?.message}
            {...register('fullName')}
          />
          <Input
            label="Email"
            type="email"
            placeholder="you@example.com"
            autoComplete="email"
            error={errors.email?.message}
            {...register('email')}
          />
          <PasswordField
            label="Пароль"
            autoComplete="new-password"
            helperText="Минимум 8 символов"
            error={errors.password?.message}
            {...register('password')}
          />
          <PasswordField
            label="Подтверждение пароля"
            autoComplete="new-password"
            error={errors.confirmPassword?.message}
            {...register('confirmPassword')}
          />

          {formError && (
            <p role="alert" className="text-sm text-destructive">
              {formError}
            </p>
          )}

          <Button type="submit" size="lg" isLoading={isSubmitting} disabled={isSubmitting}>
            Создать аккаунт
          </Button>
        </form>

        <p className="text-center text-sm text-muted-foreground">
          Уже есть аккаунт?{' '}
          <Link to="/login" className="text-primary hover:underline">
            Войти
          </Link>
        </p>
      </CardContent>
    </Card>
  )
}
