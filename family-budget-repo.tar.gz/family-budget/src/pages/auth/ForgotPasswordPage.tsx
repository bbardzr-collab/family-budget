import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { Link } from 'react-router-dom'
import { MailCheck } from 'lucide-react'
import { Button, Card, CardContent, Input } from '@/components/ui'
import { useAuth } from '@/features/auth/AuthContext'
import { forgotPasswordSchema, type ForgotPasswordFormValues } from '@/features/auth/schemas'
import { getAuthErrorMessage } from '@/features/auth/authErrors'

/**
 * Восстановление пароля (Этап 4, п.10). redirectTo строится из
 * window.location.origin — работает и на localhost, и на будущем домене,
 * без хардкода.
 */
export function ForgotPasswordPage() {
  const { resetPassword } = useAuth()
  const [formError, setFormError] = useState<string | null>(null)
  const [sent, setSent] = useState(false)

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<ForgotPasswordFormValues>({ resolver: zodResolver(forgotPasswordSchema) })

  const onSubmit = handleSubmit(async ({ email }) => {
    setFormError(null)
    const { error } = await resetPassword(email)
    if (error) {
      setFormError(getAuthErrorMessage(error))
      return
    }
    setSent(true)
  })

  if (sent) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center gap-3 pt-6 text-center">
          <div className="flex size-12 items-center justify-center rounded-full bg-success-soft">
            <MailCheck className="size-6 text-success" aria-hidden="true" />
          </div>
          <div>
            <h1 className="text-lg font-semibold text-foreground">Письмо отправлено</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Если такой email зарегистрирован, на него отправлена ссылка для сброса пароля.
            </p>
          </div>
          <Link to="/login" className="text-sm text-primary hover:underline">
            Вернуться ко входу
          </Link>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardContent className="flex flex-col gap-4 pt-6">
        <div>
          <h1 className="text-lg font-semibold text-foreground">Восстановление пароля</h1>
          <p className="text-sm text-muted-foreground">
            Укажите email — мы пришлём ссылку для сброса пароля.
          </p>
        </div>

        <form className="flex flex-col gap-4" onSubmit={onSubmit} noValidate>
          <Input
            label="Email"
            type="email"
            placeholder="you@example.com"
            autoComplete="email"
            error={errors.email?.message}
            {...register('email')}
          />

          {formError && (
            <p role="alert" className="text-sm text-destructive">
              {formError}
            </p>
          )}

          <Button type="submit" size="lg" isLoading={isSubmitting} disabled={isSubmitting}>
            Отправить ссылку
          </Button>
        </form>

        <p className="text-center text-sm text-muted-foreground">
          Вспомнили пароль?{' '}
          <Link to="/login" className="text-primary hover:underline">
            Войти
          </Link>
        </p>
      </CardContent>
    </Card>
  )
}
