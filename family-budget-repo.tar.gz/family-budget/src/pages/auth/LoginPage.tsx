import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { Link } from 'react-router-dom'
import { Button, Card, CardContent, Input } from '@/components/ui'
import { PasswordField } from '@/features/auth/PasswordField'
import { useAuth } from '@/features/auth/AuthContext'
import { loginSchema, type LoginFormValues } from '@/features/auth/schemas'
import { getAuthErrorMessage } from '@/features/auth/authErrors'

/**
 * Вход (Этап 4, п.8). После успешного signIn перенаправление на /app
 * делает PublicOnlyRoute сам, реагируя на изменение isAuthenticated —
 * здесь достаточно дождаться результата запроса.
 */
export function LoginPage() {
  const { signIn } = useAuth()
  const [formError, setFormError] = useState<string | null>(null)

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<LoginFormValues>({ resolver: zodResolver(loginSchema) })

  const onSubmit = handleSubmit(async (values) => {
    setFormError(null)
    const { error } = await signIn(values)
    if (error) setFormError(getAuthErrorMessage(error))
  })

  return (
    <Card>
      <CardContent className="flex flex-col gap-4 pt-6">
        <div>
          <h1 className="text-lg font-semibold text-foreground">Вход</h1>
          <p className="text-sm text-muted-foreground">С возвращением!</p>
        </div>

        <form className="flex flex-col gap-4" onSubmit={onSubmit} noValidate>
          <Input
            label="Email"
            type="email"
            placeholder="you@example.com"
            autoComplete="email"
            error={errors.email?.message}
            {...register('email')}
          />
          <PasswordField
            label="Пароль"
            autoComplete="current-password"
            error={errors.password?.message}
            {...register('password')}
          />

          {formError && (
            <p role="alert" className="text-sm text-destructive">
              {formError}
            </p>
          )}

          <Button type="submit" size="lg" isLoading={isSubmitting} disabled={isSubmitting}>
            Войти
          </Button>
        </form>

        <div className="flex flex-col gap-1 text-center text-sm text-muted-foreground">
          <Link to="/forgot-password" className="text-primary hover:underline">
            Забыли пароль?
          </Link>
          <span>
            Нет аккаунта?{' '}
            <Link to="/register" className="text-primary hover:underline">
              Зарегистрироваться
            </Link>
          </span>
        </div>
      </CardContent>
    </Card>
  )
}
