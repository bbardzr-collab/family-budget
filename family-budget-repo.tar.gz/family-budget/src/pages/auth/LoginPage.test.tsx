import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter } from 'react-router-dom'
import { LoginPage } from './LoginPage'

const { mockSignIn } = vi.hoisted(() => ({ mockSignIn: vi.fn() }))

vi.mock('@/features/auth/AuthContext', () => ({
  useAuth: () => ({ signIn: mockSignIn }),
}))

function renderLogin() {
  return render(
    <MemoryRouter>
      <LoginPage />
    </MemoryRouter>,
  )
}

describe('LoginPage', () => {
  beforeEach(() => {
    mockSignIn.mockReset()
  })

  it('показывает ошибки валидации при пустой отправке и не вызывает signIn', async () => {
    const user = userEvent.setup()
    renderLogin()

    await user.click(screen.getByRole('button', { name: /войти/i }))

    expect(await screen.findByText('Укажите email')).toBeInTheDocument()
    expect(screen.getByText('Укажите пароль')).toBeInTheDocument()
    expect(mockSignIn).not.toHaveBeenCalled()
  })

  it('вызывает signIn с введёнными email/паролем', async () => {
    mockSignIn.mockResolvedValue({ error: null })
    const user = userEvent.setup()
    renderLogin()

    await user.type(screen.getByLabelText('Email'), 'test@example.com')
    await user.type(screen.getByLabelText('Пароль'), 'password123')
    await user.click(screen.getByRole('button', { name: /войти/i }))

    await waitFor(() =>
      expect(mockSignIn).toHaveBeenCalledWith({ email: 'test@example.com', password: 'password123' }),
    )
  })

  it('показывает понятное сообщение при неверных данных для входа', async () => {
    mockSignIn.mockResolvedValue({ error: { message: 'Invalid login credentials' } })
    const user = userEvent.setup()
    renderLogin()

    await user.type(screen.getByLabelText('Email'), 'test@example.com')
    await user.type(screen.getByLabelText('Пароль'), 'wrongpassword')
    await user.click(screen.getByRole('button', { name: /войти/i }))

    expect(await screen.findByRole('alert')).toHaveTextContent('Неверный email или пароль.')
  })

  it('переключает видимость пароля по кнопке-глазу', async () => {
    const user = userEvent.setup()
    renderLogin()

    const passwordInput = screen.getByLabelText('Пароль')
    expect(passwordInput).toHaveAttribute('type', 'password')

    await user.click(screen.getByRole('button', { name: /показать пароль/i }))
    expect(passwordInput).toHaveAttribute('type', 'text')
  })
})
