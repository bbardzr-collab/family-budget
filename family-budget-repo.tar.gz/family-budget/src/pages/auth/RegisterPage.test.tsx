import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter } from 'react-router-dom'
import { RegisterPage } from './RegisterPage'

const { mockSignUp } = vi.hoisted(() => ({ mockSignUp: vi.fn() }))
vi.mock('@/features/auth/AuthContext', () => ({
  useAuth: () => ({ signUp: mockSignUp }),
}))

function renderRegister() {
  return render(
    <MemoryRouter>
      <RegisterPage />
    </MemoryRouter>,
  )
}

describe('RegisterPage', () => {
  beforeEach(() => {
    mockSignUp.mockReset()
  })

  it('показывает ошибку, если пароли не совпадают', async () => {
    const user = userEvent.setup()
    renderRegister()
    await user.type(screen.getByLabelText('Имя'), 'Тест Тестов')
    await user.type(screen.getByLabelText(/email/i), 'test@example.com')
    await user.type(screen.getByLabelText('Пароль'), 'password123')
    await user.type(screen.getByLabelText('Подтверждение пароля'), 'different123')
    await user.click(screen.getByRole('button', { name: /создать аккаунт/i }))
    expect(await screen.findByText('Пароли не совпадают')).toBeInTheDocument()
    expect(mockSignUp).not.toHaveBeenCalled()
  })

  it('показывает экран "проверьте почту" после успешной регистрации', async () => {
    mockSignUp.mockResolvedValue({ error: null })
    const user = userEvent.setup()
    renderRegister()
    await user.type(screen.getByLabelText('Имя'), 'Тест Тестов')
    await user.type(screen.getByLabelText(/email/i), 'test@example.com')
    await user.type(screen.getByLabelText('Пароль'), 'password123')
    await user.type(screen.getByLabelText('Подтверждение пароля'), 'password123')
    await user.click(screen.getByRole('button', { name: /создать аккаунт/i }))
    expect(await screen.findByRole('heading', { name: /проверьте почту/i })).toBeInTheDocument()
    expect(mockSignUp).toHaveBeenCalledWith({
      fullName: 'Тест Тестов',
      email: 'test@example.com',
      password: 'password123',
      confirmPassword: 'password123',
    })
  })
})
