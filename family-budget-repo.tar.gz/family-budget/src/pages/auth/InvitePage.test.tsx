import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Route, Routes } from 'react-router-dom'
import { ToastProvider } from '@/components/ui/Toast'
import { InvitePage } from './InvitePage'

const { mockUseAuth, mockUseInvitationPreview, mockAcceptMutateAsync } = vi.hoisted(() => ({
  mockUseAuth: vi.fn(),
  mockUseInvitationPreview: vi.fn(),
  mockAcceptMutateAsync: vi.fn(),
}))

vi.mock('@/features/auth/AuthContext', () => ({
  useAuth: mockUseAuth,
}))

vi.mock('@/features/family/hooks', () => ({
  useInvitationPreview: mockUseInvitationPreview,
  useAcceptInvitation: () => ({ mutateAsync: mockAcceptMutateAsync, isPending: false }),
}))

function renderAt(path: string) {
  return render(
    <ToastProvider>
      <MemoryRouter initialEntries={[path]}>
        <Routes>
          <Route path="/invite/:token" element={<InvitePage />} />
          <Route path="/login" element={<div>Login Page</div>} />
          <Route path="/register" element={<div>Register Page</div>} />
          <Route path="/app/family" element={<div>Family Page</div>} />
          <Route path="/" element={<div>Landing Page</div>} />
        </Routes>
      </MemoryRouter>
    </ToastProvider>,
  )
}

describe('InvitePage', () => {
  beforeEach(() => {
    mockAcceptMutateAsync.mockReset()
  })

  it('показывает "Приглашение недействительно" для истёкшей ссылки, без технических деталей (п.21)', () => {
    mockUseAuth.mockReturnValue({ isAuthenticated: false, isLoading: false })
    mockUseInvitationPreview.mockReturnValue({
      data: { familyName: null, role: null, status: 'expired', expiresAt: null, isValid: false },
      isLoading: false,
      isError: false,
    })

    renderAt('/invite/expired-token')

    expect(screen.getByText('Приглашение недействительно')).toBeInTheDocument()
    expect(screen.getByText(/срок действия этой ссылки истёк/i)).toBeInTheDocument()
    expect(screen.queryByText(/sql|constraint|exception/i)).not.toBeInTheDocument()
  })

  it('неавторизованному пользователю предлагает войти/зарегистрироваться и вернуться на ссылку приглашения (п.22)', async () => {
    mockUseAuth.mockReturnValue({ isAuthenticated: false, isLoading: false })
    mockUseInvitationPreview.mockReturnValue({
      data: { familyName: 'Семья Ивановых', role: 'adult', status: 'pending', expiresAt: null, isValid: true },
      isLoading: false,
      isError: false,
    })

    const user = userEvent.setup()
    renderAt('/invite/real-token')

    expect(screen.getByText(/вас приглашают в семью/i)).toBeInTheDocument()
    expect(screen.getByText(/семья ивановых/i)).toBeInTheDocument()

    await user.click(screen.getByRole('button', { name: /войти/i }))
    expect(await screen.findByText('Login Page')).toBeInTheDocument()
  })

  it('авторизованный пользователь может присоединиться — успех ведёт на /app/family', async () => {
    mockUseAuth.mockReturnValue({ isAuthenticated: true, isLoading: false })
    mockUseInvitationPreview.mockReturnValue({
      data: { familyName: 'Семья Ивановых', role: 'child', status: 'pending', expiresAt: null, isValid: true },
      isLoading: false,
      isError: false,
    })
    mockAcceptMutateAsync.mockResolvedValue('fam-1')

    const user = userEvent.setup()
    renderAt('/invite/real-token')

    await user.click(screen.getByRole('button', { name: /присоединиться/i }))

    await waitFor(() => expect(mockAcceptMutateAsync).toHaveBeenCalledWith('real-token'))
    expect(await screen.findByText('Family Page')).toBeInTheDocument()
  })

  it('показывает понятную ошибку, если у пользователя уже есть своя семья', async () => {
    mockUseAuth.mockReturnValue({ isAuthenticated: true, isLoading: false })
    mockUseInvitationPreview.mockReturnValue({
      data: { familyName: 'Семья Ивановых', role: 'child', status: 'pending', expiresAt: null, isValid: true },
      isLoading: false,
      isError: false,
    })
    mockAcceptMutateAsync.mockRejectedValue({ message: 'FAMILY_ALREADY_EXISTS' })

    const user = userEvent.setup()
    renderAt('/invite/real-token')

    await user.click(screen.getByRole('button', { name: /присоединиться/i }))

    expect(await screen.findByRole('alert')).toHaveTextContent(/уже состоите в семье/i)
  })
})
