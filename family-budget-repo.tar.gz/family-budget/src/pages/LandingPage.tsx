import { Link } from 'react-router-dom'
import { Button, Card, CardContent } from '@/components/ui'

export function LandingPage() {
  return (
    <Card>
      <CardContent className="flex flex-col gap-5 pt-6 text-center">
        <div>
          <h1 className="text-xl font-semibold text-foreground">
            Все деньги семьи — в одном месте
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Доходы, расходы, бюджет, цели и аналитика — для всей семьи, на любом устройстве.
          </p>
        </div>

        <div className="flex flex-col gap-2">
          <Link to="/register">
            <Button size="lg" className="w-full">
              Создать семью
            </Button>
          </Link>
          <Link to="/login">
            <Button size="lg" variant="secondary" className="w-full">
              Войти
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  )
}
