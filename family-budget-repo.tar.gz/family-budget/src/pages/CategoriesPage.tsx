import { createElement, useState } from 'react'
import { Eye, EyeOff, MoreVertical, Pencil, Plus, Tag, Trash2 } from 'lucide-react'
import {
  Badge,
  Button,
  Card,
  CardContent,
  Dropdown,
  EmptyState,
  ErrorState,
  IconButton,
  PageTitle,
  SectionTitle,
  Skeleton,
  Text,
} from '@/components/ui'
import { useToast } from '@/components/ui/Toast'
import { cn } from '@/utils/cn'
import { CATEGORY_TYPE_LABELS, CATEGORY_TYPE_ORDER, type CategoryType } from '@/features/categories/constants'
import { getCategoryIcon } from '@/features/categories/iconMap'
import { useCategories, useToggleCategory } from '@/features/categories/hooks'
import { getCategoryErrorMessage } from '@/features/categories/errors'
import { CategoryFormModal } from '@/features/categories/CategoryFormModal'
import { DeleteCategoryModal } from '@/features/categories/DeleteCategoryModal'
import type { CategoryListItem } from '@/features/categories/api'

/**
 * Страница "Категории" (Этап 8, п.6-7) — реальные категории семьи из
 * Supabase, сгруппированные по типу (Обязательное/Желания/Цели/Другое),
 * с созданием, редактированием, включением/выключением и безопасным
 * удалением. Доступна по прямому маршруту /app/categories и через
 * «Настройки → Категории» (п.29) — в основной навигации (5 вкладок)
 * намеренно не участвует, чтобы её не ломать.
 */
export function CategoriesPage() {
  const { data: categories, isLoading, isError, refetch } = useCategories()
  const toggleCategoryMutation = useToggleCategory()
  const { toast } = useToast()

  // undefined — модалка закрыта; null — создание; CategoryListItem — редактирование.
  const [formCategory, setFormCategory] = useState<CategoryListItem | null | undefined>(undefined)
  const [deletingCategory, setDeletingCategory] = useState<CategoryListItem | null>(null)

  async function handleToggle(category: CategoryListItem) {
    try {
      await toggleCategoryMutation.mutateAsync({ id: category.id, isActive: !category.isActive })
      toast({ type: 'success', title: category.isActive ? 'Категория отключена' : 'Категория включена' })
    } catch (err) {
      toast({
        type: 'error',
        title: 'Не удалось изменить категорию',
        description: getCategoryErrorMessage(err),
      })
    }
  }

  const grouped = CATEGORY_TYPE_ORDER.map((type) => ({
    type,
    items: (categories ?? []).filter((c) => c.type === type),
  }))

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between gap-4">
        <div>
          <PageTitle>Категории</PageTitle>
          <Text variant="secondary" className="mt-1">
            Настройте категории расходов вашей семьи
          </Text>
        </div>
        <Button onClick={() => setFormCategory(null)}>
          <Plus className="size-4" aria-hidden="true" />
          Добавить категорию
        </Button>
      </div>

      {isLoading && (
        <div className="flex flex-col gap-3" role="status" aria-label="Загружаем категории…">
          {[0, 1, 2].map((i) => (
            <Skeleton key={i} className="h-32 w-full" />
          ))}
        </div>
      )}

      {isError && <ErrorState title="Не удалось загрузить категории" onRetry={() => void refetch()} />}

      {!isLoading && !isError && (categories?.length ?? 0) === 0 && (
        <EmptyState
          icon={Tag}
          title="Категорий пока нет"
          description="Стандартные категории создаются автоматически при создании семьи. Добавьте свою, если чего-то не хватает."
          action={<Button onClick={() => setFormCategory(null)}>Добавить первую категорию</Button>}
        />
      )}

      {!isLoading && !isError && (categories?.length ?? 0) > 0 && (
        <div className="flex flex-col gap-6">
          {grouped.map((group) => (
            <CategoryGroupSection
              key={group.type}
              type={group.type}
              items={group.items}
              onEdit={setFormCategory}
              onToggle={(category) => void handleToggle(category)}
              onDelete={setDeletingCategory}
            />
          ))}
        </div>
      )}

      <CategoryFormModal
        open={formCategory !== undefined}
        category={formCategory ?? null}
        onClose={() => setFormCategory(undefined)}
      />

      <DeleteCategoryModal category={deletingCategory} onClose={() => setDeletingCategory(null)} />
    </div>
  )
}

function CategoryGroupSection({
  type,
  items,
  onEdit,
  onToggle,
  onDelete,
}: {
  type: CategoryType
  items: CategoryListItem[]
  onEdit: (category: CategoryListItem) => void
  onToggle: (category: CategoryListItem) => void
  onDelete: (category: CategoryListItem) => void
}) {
  return (
    <div className="flex flex-col gap-3">
      <SectionTitle>{CATEGORY_TYPE_LABELS[type]}</SectionTitle>

      {items.length === 0 && (
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-muted-foreground">Пока нет категорий этого типа.</p>
          </CardContent>
        </Card>
      )}

      {items.length > 0 && (
        <Card>
          <CardContent className="flex flex-col divide-y divide-border pt-6">
            {items.map((category) => (
              <CategoryRow
                key={category.id}
                category={category}
                onEdit={() => onEdit(category)}
                onToggle={() => onToggle(category)}
                onDelete={() => onDelete(category)}
              />
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  )
}

function CategoryRow({
  category,
  onEdit,
  onToggle,
  onDelete,
}: {
  category: CategoryListItem
  onEdit: () => void
  onToggle: () => void
  onDelete: () => void
}) {
  const items = [
    { value: 'edit', label: 'Изменить', icon: <Pencil /> },
    {
      value: 'toggle',
      label: category.isActive ? 'Отключить' : 'Включить',
      icon: category.isActive ? <EyeOff /> : <Eye />,
    },
    ...(category.isCustom ? [{ value: 'delete', label: 'Удалить', icon: <Trash2 />, destructive: true }] : []),
  ]

  function handleSelect(value: string) {
    if (value === 'edit') onEdit()
    else if (value === 'toggle') onToggle()
    else if (value === 'delete') onDelete()
  }

  return (
    <div
      className={cn(
        'flex items-center gap-3 py-3 first:pt-0 last:pb-0',
        !category.isActive && 'opacity-60',
      )}
    >
      <div className="flex size-9 shrink-0 items-center justify-center rounded-full bg-muted text-muted-foreground">
        {/* createElement — см. комментарий в CategoryPickerModal.tsx про
            react-hooks/static-components и динамический выбор иконки. */}
        {createElement(getCategoryIcon(category.icon), { className: 'size-4', 'aria-hidden': true })}
      </div>

      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium text-foreground">{category.name}</p>
        {!category.isCustom && <p className="text-xs text-muted-foreground">Стандартная категория</p>}
      </div>

      {!category.isActive && <Badge variant="default">Выключена</Badge>}

      <Dropdown
        trigger={<IconButton icon={MoreVertical} aria-label="Действия с категорией" size="sm" />}
        items={items}
        onSelect={handleSelect}
      />
    </div>
  )
}
