import { createElement, useState } from 'react'
import { ChevronDown, MoreVertical, Pencil, Plus, RotateCcw, Target, Trash2, XCircle } from 'lucide-react'
import {
  Badge,
  Button,
  Card,
  CardContent,
  Dropdown,
  EmptyState,
  ErrorState,
  IconButton,
  PageTitle,
  ProgressBar,
  SectionTitle,
  Skeleton,
  Tabs,
  TabsList,
  TabsTrigger,
  Text,
} from '@/components/ui'
import { useToast } from '@/components/ui/Toast'
import { cn } from '@/utils/cn'
import { formatDate } from '@/utils/formatDate'
import { formatMoney } from '@/utils/formatMoney'
import { getGoalIcon } from '@/features/goals/iconMap'
import { goalStatusLabel, goalTypeLabel } from '@/features/goals/labels'
import { sortActiveGoals } from '@/features/goals/sort'
import { useGoals, useResumeGoal } from '@/features/goals/hooks'
import { getGoalErrorMessage } from '@/features/goals/errors'
import { GoalFormModal } from '@/features/goals/GoalFormModal'
import { GoalContributionFormModal } from '@/features/goals/GoalContributionFormModal'
import { GoalHistoryModal } from '@/features/goals/GoalHistoryModal'
import { DeleteGoalModal } from '@/features/goals/DeleteGoalModal'
import { CancelGoalModal } from '@/features/goals/CancelGoalModal'
import type { GoalListItem } from '@/features/goals/api'

type FilterValue = 'active' | 'completed' | 'cancelled' | 'all'

/**
 * Страница "Финансовые цели" (Этап 11) — список целей семьи (личных и
 * семейных) с накопленной суммой, остатком и процентом выполнения, все
 * агрегаты — из get_goals_list (миграция 0026), без загрузки всех
 * contributions на клиент (ТЗ, п.28-29).
 *
 * Переключатель ТЗ п.30 (Активные/Выполненные/Отменённые/Все) реализован
 * так: конкретный статус — плоский список только этого статуса; "Все" —
 * группировка из ТЗ п.29 (активные первыми, затем выполненные, затем
 * сворачиваемый блок отменённых) — то есть переключатель не заменяет
 * группировку, а даёт быстрый доступ к одному срезу вместо неё.
 */
export function GoalsPage() {
  const { data: goals, isLoading, isError, refetch } = useGoals()
  const { toast } = useToast()
  const resumeGoalMutation = useResumeGoal()

  const [filter, setFilter] = useState<FilterValue>('all')
  const [formState, setFormState] = useState<{ open: boolean; editing: GoalListItem | null }>({
    open: false,
    editing: null,
  })
  const [contributingGoal, setContributingGoal] = useState<GoalListItem | null>(null)
  const [historyGoal, setHistoryGoal] = useState<GoalListItem | null>(null)
  const [deletingGoal, setDeletingGoal] = useState<GoalListItem | null>(null)
  const [cancellingGoal, setCancellingGoal] = useState<GoalListItem | null>(null)

  const allGoals = goals ?? []
  const activeGoals = sortActiveGoals(allGoals.filter((g) => g.status === 'active'))
  const completedGoals = allGoals.filter((g) => g.status === 'completed')
  const cancelledGoals = allGoals.filter((g) => g.status === 'cancelled')

  function openCreate() {
    setFormState({ open: true, editing: null })
  }
  function openEdit(goal: GoalListItem) {
    setFormState({ open: true, editing: goal })
  }
  function closeForm() {
    setFormState({ open: false, editing: null })
  }

  async function handleResume(goal: GoalListItem) {
    try {
      await resumeGoalMutation.mutateAsync(goal.id)
      toast({ type: 'success', title: 'Цель возобновлена' })
    } catch (error) {
      toast({ type: 'error', title: getGoalErrorMessage(error) })
    }
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between gap-4">
        <PageTitle>Финансовые цели</PageTitle>
        <Button onClick={openCreate}>
          <Plus className="size-4" aria-hidden="true" />
          Добавить цель
        </Button>
      </div>

      {isLoading && <GoalsSkeleton />}

      {!isLoading && isError && (
        <Card>
          <CardContent className="pt-6">
            <ErrorState title="Не удалось загрузить цели" onRetry={() => void refetch()} />
          </CardContent>
        </Card>
      )}

      {!isLoading && !isError && allGoals.length === 0 && (
        <Card>
          <CardContent className="pt-6">
            <EmptyState
              icon={Target}
              title="Финансовых целей пока нет"
              description="Создайте первую цель — например, отпуск, ремонт или подушку безопасности."
              action={<Button onClick={openCreate}>Создать первую цель</Button>}
            />
          </CardContent>
        </Card>
      )}

      {!isLoading && !isError && allGoals.length > 0 && (
        <>
          <Tabs value={filter} onValueChange={(value) => setFilter(value as FilterValue)}>
            <TabsList>
              <TabsTrigger value="active">Активные</TabsTrigger>
              <TabsTrigger value="completed">Выполненные</TabsTrigger>
              <TabsTrigger value="cancelled">Отменённые</TabsTrigger>
              <TabsTrigger value="all">Все</TabsTrigger>
            </TabsList>
          </Tabs>

          {filter === 'active' && (
            <GoalList
              goals={activeGoals}
              emptyText="Активных целей нет"
              onEdit={openEdit}
              onContribute={setContributingGoal}
              onHistory={setHistoryGoal}
              onDelete={setDeletingGoal}
              onCancel={setCancellingGoal}
              onResume={handleResume}
            />
          )}

          {filter === 'completed' && (
            <GoalList
              goals={completedGoals}
              emptyText="Выполненных целей пока нет"
              onEdit={openEdit}
              onContribute={setContributingGoal}
              onHistory={setHistoryGoal}
              onDelete={setDeletingGoal}
              onCancel={setCancellingGoal}
              onResume={handleResume}
            />
          )}

          {filter === 'cancelled' && (
            <GoalList
              goals={cancelledGoals}
              emptyText="Отменённых целей нет"
              onEdit={openEdit}
              onContribute={setContributingGoal}
              onHistory={setHistoryGoal}
              onDelete={setDeletingGoal}
              onCancel={setCancellingGoal}
              onResume={handleResume}
            />
          )}

          {filter === 'all' && (
            <div className="flex flex-col gap-6">
              <div className="flex flex-col gap-3">
                <SectionTitle>Активные</SectionTitle>
                <GoalList
                  goals={activeGoals}
                  emptyText="Активных целей нет"
                  onEdit={openEdit}
                  onContribute={setContributingGoal}
                  onHistory={setHistoryGoal}
                  onDelete={setDeletingGoal}
                  onCancel={setCancellingGoal}
                  onResume={handleResume}
                />
              </div>

              {completedGoals.length > 0 && (
                <div className="flex flex-col gap-3">
                  <SectionTitle>Выполненные</SectionTitle>
                  <GoalList
                    goals={completedGoals}
                    emptyText=""
                    onEdit={openEdit}
                    onContribute={setContributingGoal}
                    onHistory={setHistoryGoal}
                    onDelete={setDeletingGoal}
                    onCancel={setCancellingGoal}
                    onResume={handleResume}
                  />
                </div>
              )}

              {/* История выполненных/отменённых целей не удаляется из интерфейса
                  (ТЗ, п.29) — отменённые сворачиваемы, чтобы не перегружать
                  экран по умолчанию. */}
              {cancelledGoals.length > 0 && (
                <CollapsibleCancelledSection
                  goals={cancelledGoals}
                  onEdit={openEdit}
                  onContribute={setContributingGoal}
                  onHistory={setHistoryGoal}
                  onDelete={setDeletingGoal}
                  onCancel={setCancellingGoal}
                  onResume={handleResume}
                />
              )}
            </div>
          )}
        </>
      )}

      <GoalFormModal open={formState.open} onClose={closeForm} goal={formState.editing} />

      <GoalContributionFormModal
        open={Boolean(contributingGoal)}
        goalId={contributingGoal?.id ?? null}
        goalTitle={contributingGoal?.title ?? ''}
        onClose={() => setContributingGoal(null)}
      />

      <GoalHistoryModal
        goalId={historyGoal?.id ?? null}
        goalTitle={historyGoal?.title ?? ''}
        onClose={() => setHistoryGoal(null)}
      />

      <DeleteGoalModal goal={deletingGoal} onClose={() => setDeletingGoal(null)} />
      <CancelGoalModal goal={cancellingGoal} onClose={() => setCancellingGoal(null)} />
    </div>
  )
}

/* ───────────────────────────── Collapsible cancelled section ───────────────────────────── */

function CollapsibleCancelledSection(props: Omit<GoalListProps, 'emptyText'>) {
  const [open, setOpen] = useState(false)
  return (
    <div className="flex flex-col gap-3">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-2 text-left"
        aria-expanded={open}
      >
        <SectionTitle>Отменённые</SectionTitle>
        <ChevronDown className={cn('size-4 text-muted-foreground transition-transform', open && 'rotate-180')} aria-hidden="true" />
      </button>
      {open && <GoalList {...props} emptyText="" />}
    </div>
  )
}

/* ───────────────────────────── Goal list ───────────────────────────── */

interface GoalListProps {
  goals: GoalListItem[]
  emptyText: string
  onEdit: (goal: GoalListItem) => void
  onContribute: (goal: GoalListItem) => void
  onHistory: (goal: GoalListItem) => void
  onDelete: (goal: GoalListItem) => void
  onCancel: (goal: GoalListItem) => void
  onResume: (goal: GoalListItem) => void
}

function GoalList({ goals, emptyText, ...actions }: GoalListProps) {
  if (goals.length === 0) {
    if (!emptyText) return null
    return (
      <Card>
        <CardContent className="pt-6">
          <Text variant="secondary">{emptyText}</Text>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
      {goals.map((goal) => (
        <GoalCard key={goal.id} goal={goal} {...actions} />
      ))}
    </div>
  )
}

/* ───────────────────────────── Goal card ───────────────────────────── */

function GoalCard({
  goal,
  onEdit,
  onContribute,
  onHistory,
  onDelete,
  onCancel,
  onResume,
}: {
  goal: GoalListItem
} & Omit<GoalListProps, 'goals' | 'emptyText'>) {
  const isActive = goal.status === 'active'
  const isCancelled = goal.status === 'cancelled'
  const isCompleted = goal.status === 'completed'

  const dropdownItems = [
    { value: 'edit', label: 'Редактировать', icon: <Pencil /> },
    ...(isActive ? [{ value: 'cancel', label: 'Отменить цель', icon: <XCircle /> }] : []),
    ...(isCancelled ? [{ value: 'resume', label: 'Возобновить', icon: <RotateCcw /> }] : []),
    { value: 'delete', label: 'Удалить цель', icon: <Trash2 />, destructive: true },
  ]

  function handleSelect(value: string) {
    if (value === 'edit') onEdit(goal)
    else if (value === 'cancel') onCancel(goal)
    else if (value === 'resume') onResume(goal)
    else if (value === 'delete') onDelete(goal)
  }

  return (
    <Card className={cn(isCancelled && 'opacity-70')}>
      <CardContent className="flex flex-col gap-4 pt-6">
        <div className="flex items-start justify-between gap-3">
          {/* min-w-0 на этом уровне обязателен: без него truncate у
              заголовка (ниже) не работает внутри flexbox — этот промежуточный
              flex-item иначе сам не сжимается меньше нешринкнутой ширины
              полного текста заголовка, раздвигая карточку и страницу шире
              экрана на узких вьюпортах (тот же паттерн, что уже применён в
              шапке /app/family, Этап 19, п.36). */}
          <div className="flex min-w-0 items-center gap-3">
            <div className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-primary-soft text-primary">
              {createElement(getGoalIcon(goal.icon), { className: 'size-5', 'aria-hidden': true })}
            </div>
            <div className="min-w-0">
              <p className="truncate font-medium text-foreground">{goal.title}</p>
              <div className="mt-0.5 flex flex-wrap items-center gap-1.5">
                <Badge variant={isCompleted ? 'success' : 'default'}>{goalStatusLabel(goal.status)}</Badge>
                <span className="text-xs text-muted-foreground">{goalTypeLabel(goal.goalType)}</span>
              </div>
            </div>
          </div>
          <Dropdown
            trigger={
              <IconButton icon={MoreVertical} aria-label={`Действия с целью ${goal.title}`} size="sm" />
            }
            items={dropdownItems}
            onSelect={handleSelect}
          />
        </div>

        {goal.goalType === 'personal' && goal.ownerName && (
          <Text variant="secondary">Владелец: {goal.ownerName}</Text>
        )}

        <ProgressBar value={goal.contributedAmount} max={goal.targetAmount} />

        {/* grid-cols-1 до sm: 3 узкие колонки на 320-414px оставляют для
            каждой суммы ~90px, и даже с break-words это ломает крупные
            суммы (например "1 158 000,25 ₽") посреди числа, а не только по
            разрядам — некрасиво для финансового приложения. Один столбец на
            самых узких экранах даёт сумме всю ширину карточки, перенос не
            нужен вовсе; с sm (640px) карточка уже достаточно широкая для
            привычных 3 колонок (Этап 19, п.36 — форматирование крупных чисел
            в карточках). */}
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <MiniStat label="Накоплено" value={formatMoney(goal.contributedAmount)} />
          <MiniStat label="Цель" value={formatMoney(goal.targetAmount)} />
          <MiniStat
            label={isCompleted ? 'Статус' : 'Осталось'}
            value={isCompleted ? 'Выполнена' : formatMoney(goal.remainingAmount)}
          />
        </div>

        <div className="flex items-center justify-between">
          <span className="text-sm font-semibold tabular-nums text-foreground">{goal.percent}%</span>
          {goal.targetDate && (
            <span className="text-xs text-muted-foreground">до {formatDate(goal.targetDate)}</span>
          )}
        </div>

        <div className="flex gap-2">
          {isActive && (
            <Button size="sm" onClick={() => onContribute(goal)}>
              Пополнить
            </Button>
          )}
          <Button variant="outline" size="sm" onClick={() => onHistory(goal)}>
            История
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

function MiniStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col gap-0.5">
      <Text variant="small">{label}</Text>
      {/* break-words — formatMoney (Intl.NumberFormat) разделяет разряды
          неразрывными пробелами, поэтому крупная сумма (например,
          "1 158 000,25 ₽") — это один "неразбиваемый" по обычным пробелам
          токен и без break-words не переносится в узкой grid-колонке
          (grid-cols-3), раздвигая карточку шире экрана на узких вьюпортах
          (Этап 19, п.36). */}
      <span className="break-words text-sm font-medium tabular-nums text-foreground">{value}</span>
    </div>
  )
}

/* ───────────────────────────── Loading skeleton ───────────────────────────── */

function GoalsSkeleton() {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3" role="status" aria-label="Загружаем цели…">
      {[0, 1, 2].map((i) => (
        <Skeleton key={i} className="h-56 w-full rounded-lg" />
      ))}
    </div>
  )
}
