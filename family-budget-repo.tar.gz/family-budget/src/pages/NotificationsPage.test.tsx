import { fireEvent, render, screen } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { ToastProvider } from '@/components/ui/Toast'
import { NotificationsPage } from './NotificationsPage'
import type { NotificationItem } from '@/features/notifications/api'

const {
  mockUseNotifications,
  mockMarkReadMutate,
  mockMarkAllReadMutateAsync,
  mockDeleteMutateAsync,
} = vi.hoisted(() => ({
  mockUseNotifications: vi.fn(),
  mockMarkReadMutate: vi.fn(),
  mockMarkAllReadMutateAsync: vi.fn(),
  mockDeleteMutateAsync: vi.fn(),
}))

vi.mock('@/features/notifications/hooks', () => ({
  useNotifications: mockUseNotifications,
  useMarkNotificationRead: () => ({ mutate: mockMarkReadMutate }),
  useMarkAllNotificationsRead: () => ({ mutateAsync: mockMarkAllReadMutateAsync, isPending: false }),
  useDeleteNotification: () => ({ mutateAsync: mockDeleteMutateAsync }),
}))

function makeItem(overrides: Partial<NotificationItem> = {}): NotificationItem {
  return {
    id: 'notif-1',
    type: 'budget_exceeded',
    title: 'Бюджет превышен',
    message: 'Расходы семьи превысили установленный бюджет на 8 500 ₽.',
    payload: { budget_id: 'budget-1' },
    isRead: false,
    createdAt: new Date().toISOString(),
    ...overrides,
  }
}

function renderPage() {
  return render(
    <MemoryRouter initialEntries={['/app/notifications']}>
      <ToastProvider>
        <NotificationsPage />
      </ToastProvider>
    </MemoryRouter>,
  )
}

describe('NotificationsPage (Этап 17)', () => {
  beforeEach(() => {
    mockMarkReadMutate.mockReset()
    mockMarkAllReadMutateAsync.mockReset().mockResolvedValue(1)
    mockDeleteMutateAsync.mockReset().mockResolvedValue(undefined)
  })

  it('во время загрузки показывает skeleton, не пустой экран', () => {
    mockUseNotifications.mockReturnValue({ data: undefined, isLoading: true, isError: false, refetch: vi.fn() })

    renderPage()

    expect(screen.getByRole('status', { name: /загружаем уведомления/i })).toBeInTheDocument()
  })

  it('ошибка загрузки показывает ErrorState с кнопкой "Повторить" (ТЗ, п.21)', () => {
    const refetch = vi.fn()
    mockUseNotifications.mockReturnValue({ data: undefined, isLoading: false, isError: true, refetch })

    renderPage()

    expect(screen.getByText('Не удалось загрузить уведомления')).toBeInTheDocument()
    fireEvent.click(screen.getByRole('button', { name: 'Повторить' }))
    expect(refetch).toHaveBeenCalled()
  })

  it('пустой список (все): "Всё чисто / Новых уведомлений пока нет" (ТЗ, п.20)', () => {
    mockUseNotifications.mockReturnValue({ data: [], isLoading: false, isError: false, refetch: vi.fn() })

    renderPage()

    expect(screen.getByText('Всё чисто')).toBeInTheDocument()
    expect(screen.getByText('Новых уведомлений пока нет.')).toBeInTheDocument()
  })

  it('нет непрочитанных на вкладке "Непрочитанные": "Нет непрочитанных уведомлений" (ТЗ, п.20)', () => {
    mockUseNotifications.mockReturnValue({ data: [], isLoading: false, isError: false, refetch: vi.fn() })

    renderPage()
    fireEvent.click(screen.getByRole('tab', { name: 'Непрочитанные' }))

    expect(screen.getByText('Нет непрочитанных уведомлений')).toBeInTheDocument()
  })

  it('переключение вкладки "Непрочитанные" запрашивает список с unreadOnly: true', () => {
    mockUseNotifications.mockReturnValue({ data: [], isLoading: false, isError: false, refetch: vi.fn() })

    renderPage()
    fireEvent.click(screen.getByRole('tab', { name: 'Непрочитанные' }))

    const lastCall = mockUseNotifications.mock.calls.at(-1)
    expect(lastCall?.[0]).toEqual({ unreadOnly: true })
  })

  it('"Прочитать все" видна только при наличии непрочитанных (ТЗ, п.8)', () => {
    mockUseNotifications.mockReturnValue({
      data: [makeItem({ isRead: true })],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderPage()

    expect(screen.queryByRole('button', { name: 'Прочитать все' })).not.toBeInTheDocument()
  })

  it('"Прочитать все" вызывает mark_all_notifications_read', async () => {
    mockUseNotifications.mockReturnValue({
      data: [makeItem({ isRead: false })],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderPage()
    fireEvent.click(screen.getByRole('button', { name: 'Прочитать все' }))

    expect(mockMarkAllReadMutateAsync).toHaveBeenCalled()
  })

  it('открытие непрочитанного уведомления помечает его прочитанным', () => {
    mockUseNotifications.mockReturnValue({
      data: [makeItem({ id: 'notif-unread', isRead: false })],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderPage()
    fireEvent.click(screen.getByText('Бюджет превышен'))

    expect(mockMarkReadMutate).toHaveBeenCalledWith('notif-unread')
  })

  it('открытие уже прочитанного уведомления НЕ вызывает повторную мутацию', () => {
    mockUseNotifications.mockReturnValue({
      data: [makeItem({ id: 'notif-read', isRead: true })],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderPage()
    fireEvent.click(screen.getByText('Бюджет превышен'))

    expect(mockMarkReadMutate).not.toHaveBeenCalled()
  })

  it('удаление уведомления вызывает delete_notification', async () => {
    mockUseNotifications.mockReturnValue({
      data: [makeItem({ id: 'notif-1' })],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderPage()
    fireEvent.click(screen.getByRole('button', { name: /Удалить уведомление/i }))

    expect(mockDeleteMutateAsync).toHaveBeenCalledWith('notif-1')
  })

  it('показывает заголовок/сообщение/время уведомления (пример ТЗ)', () => {
    mockUseNotifications.mockReturnValue({
      data: [makeItem()],
      isLoading: false,
      isError: false,
      refetch: vi.fn(),
    })

    renderPage()

    expect(screen.getByText('Бюджет превышен')).toBeInTheDocument()
    expect(screen.getByText('Расходы семьи превысили установленный бюджет на 8 500 ₽.')).toBeInTheDocument()
  })
})
