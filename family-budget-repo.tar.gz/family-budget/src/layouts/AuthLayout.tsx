import { Outlet } from 'react-router-dom'
import { Wallet } from 'lucide-react'

/**
 * Layout для неавторизованных экранов: вход, регистрация, приглашение,
 * восстановление пароля. Простой центрированный контейнер.
 */
export function AuthLayout() {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <div className="flex flex-1 flex-col items-center justify-center px-4 py-10">
        <div className="mb-8 flex items-center gap-2">
          <div className="flex size-10 items-center justify-center rounded-xl bg-primary text-primary-foreground">
            <Wallet className="size-5" aria-hidden="true" />
          </div>
          <span className="text-lg font-semibold text-foreground">Семейный бюджет</span>
        </div>

        <div className="w-full max-w-sm">
          <Outlet />
        </div>
      </div>
    </div>
  )
}
