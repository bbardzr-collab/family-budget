import { render, screen } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClient } from '@/lib/queryClient'
import { ThemeProvider } from '@/app/ThemeContext'
import { AuthProvider } from '@/features/auth/AuthContext'
import { ToastProvider } from '@/components/ui/Toast'
import App from './App'

const { mockGetSession, mockOnAuthStateChange, mockFrom } = vi.hoisted(() => ({
  mockGetSession: vi.fn(),
  mockOnAuthStateChange: vi.fn(),
  mockFrom: vi.fn(),
}))

vi.mock('@/lib/supabase', () => ({
  supabase: {
    auth: {
      getSession: mockGetSession,
      onAuthStateChange: mockOnAuthStateChange,
    },
    from: mockFrom,
  },
}))

// UpdateBanner (Этап 18) использует virtual:pwa-register/react — виртуальный
// модуль vite-plugin-pwa, недоступный в тестовой сборке напрямую.
vi.mock('virtual:pwa-register/react', () => ({
  useRegisterSW: () => ({
    needRefresh: [false, vi.fn()],
    offlineReady: [false, vi.fn()],
    updateServiceWorker: vi.fn(),
  }),
}))

/**
 * Универсальная цепочка-заглушка Supabase query builder: любой метод
 * (select/eq/order/limit/...) возвращает саму цепочку, а терминальные
 * (single/maybeSingle) — резолвят один и тот же результат. Так тест не
 * привязан к конкретной последовательности вызовов конкретной таблицы —
 * начиная с Этапа 6 HomePage дополнительно запрашивает family_members через
 * FamilyProvider (.eq().eq().maybeSingle()), а не только users (.eq().single()).
 */
function createQueryChain(result: { data: unknown; error: unknown }) {
  const chain = {
    select: () => chain,
    eq: () => chain,
    order: () => chain,
    limit: () => chain,
    single: () => Promise.resolve(result),
    maybeSingle: () => Promise.resolve(result),
  }
  return chain
}

function mockSession(session: unknown) {
  mockGetSession.mockResolvedValue({ data: { session } })
  mockOnAuthStateChange.mockReturnValue({ data: { subscription: { unsubscribe: vi.fn() } } })
  // И профиль (users), и членство в семье (family_members) в этом тесте
  // отсутствуют — приходит { data: null, error: null } для любой таблицы,
  // как и раньше для users. HomePage в таком состоянии показывает
  // "Добро пожаловать!" (нет семьи), что и проверяют тесты ниже.
  mockFrom.mockImplementation(() => createQueryChain({ data: null, error: null }))
}

function renderApp(initialEntries: string[] = ['/']) {
  return render(
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <AuthProvider>
          <ToastProvider>
            <MemoryRouter initialEntries={initialEntries}>
              <App />
            </MemoryRouter>
          </ToastProvider>
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>,
  )
}

beforeEach(() => {
  vi.clearAllMocks()
})

describe('App', () => {
  it('рендерит стартовую страницу с заголовком', async () => {
    mockSession(null)
    renderApp(['/'])

    expect(
      await screen.findByRole('heading', { name: /все деньги семьи — в одном месте/i }),
    ).toBeInTheDocument()
  })

  it('перенаправляет неавторизованного пользователя с /app на /login', async () => {
    mockSession(null)
    renderApp(['/app'])

    expect(await screen.findByRole('heading', { name: /вход/i })).toBeInTheDocument()
  })

  it('показывает главный экран авторизованному пользователю на /app', async () => {
    mockSession({ user: { id: 'u1', email: 'a@example.com', user_metadata: {} } })
    renderApp(['/app'])

    expect(await screen.findByRole('heading', { name: /добро пожаловать/i })).toBeInTheDocument()
  })

  it('рендерит 404 для неизвестного маршрута', async () => {
    mockSession(null)
    renderApp(['/does-not-exist'])

    expect(await screen.findByText('404')).toBeInTheDocument()
  })
})
