# ЭТАП 9 — Операции + Фильтры. Отчёт

## 1. Изменённые файлы

**Миграции (Supabase, применены к продакшен-проекту `ttgsdllidpafxwhkttly`):**
- `supabase/migrations/0019_transactions_filtered_queries.sql` (новый) — RPC `get_transactions_page` и `get_transactions_totals`.
- `supabase/migrations/0020_fix_category_none_income_leak.sql` (новый) — исправление найденного тестами бага (см. п.8).
- `src/types/database.ts` — перегенерирован (добавлены типы обеих новых функций).

**Домен операций (`src/features/transactions/`):**
- `filters.ts` (новый) — доменная модель фильтров, пресеты периода, `resolveDateRange`, `toQueryFilters`, `isDefaultFilters`.
- `useTransactionFilters.ts` (новый) — состояние фильтров, синхронизация с URL.
- `TransactionFiltersPanel.tsx` (новый) — панель фильтров (десктоп-карточка / мобильный Bottom Sheet через существующий `Modal`).
- `TransactionDetailModal.tsx` (новый) — модалка деталей операции.
- `api.ts` — добавлены `fetchTransactionsPage`, `fetchTransactionsTotals`, `fetchHasAnyTransaction`; `TransactionListItem` дополнен `createdByName`.
- `queryKeys.ts` — переписан: ключи теперь включают фильтры (`filteredList`, `totals`).
- `hooks.ts` — переписан: `useTransactionsList` (infinite query), `useTransactionsTotals`, `useHasAnyTransactions`, единый `invalidateTransactionQueries`.
- `TransactionFormModal.test.tsx` — обновлены фикстуры (`createdByName`).
- `filters.test.ts` (новый) — юнит-тесты доменной логики фильтров.

**Общее:**
- `src/hooks/useDebouncedValue.ts` (новый) — generic debounce-хук.
- `src/pages/TransactionsPage.tsx` — полностью переписан.
- `src/pages/TransactionsPage.test.tsx` — полностью переписан.

## 2. Новые компоненты/хуки/сервисы

- **Хуки**: `useDebouncedValue`, `useTransactionFilters`, `useTransactionsList` (infinite query, пагинация «Загрузить ещё»), `useTransactionsTotals`, `useHasAnyTransactions`.
- **Компоненты**: `TransactionFiltersPanel` (форма фильтров, общая для десктопа и мобильного Bottom Sheet), `TransactionDetailModal` (модалка деталей операции с переходом в редактирование/удаление).
- **Сервисный слой**: `fetchTransactionsPage(filters, limit, offset)`, `fetchTransactionsTotals(filters)`, `fetchHasAnyTransaction(familyId)` в `api.ts`; типы `TransactionQueryFilters`/`TransactionFilters` в `filters.ts` вместо набора отдельных параметров.

## 3. Как реализована фильтрация

Полностью на сервере, через две новые SQL-функции (`SECURITY INVOKER`, по образцу `get_dashboard_summary` Этапа 6): `get_transactions_page` и `get_transactions_totals`. Фильтры на клиенте собираются в единый объект `TransactionFilters` (тип/период/произвольные даты/категория/поиск/сортировка), из него `toQueryFilters()` строит `TransactionQueryFilters`, который один-в-один уходит параметрами в RPC (`p_type`, `p_date_from`, `p_date_to`, `p_category_mode`, `p_category_id`, `p_search`, `p_sort`). Категория для дохода принудительно приводится к `categoryMode: 'all'` на уровне данных (не только UI `disabled`) — гарантия не может рассинхронизироваться. Единый источник состояния — хук `useTransactionFilters()`: и вкладки, и десктопная панель, и мобильный Bottom Sheet, и список, и итоги читают ровно одно и то же значение.

Категория «Без категории» (`category_mode = 'none'`) на сервере проверяется как `category_id IS NULL AND type = 'expense'` — важность этого уточнения и найденный без него баг описаны в п.8.

## 4. Как реализована серверная пагинация

`useTransactionsList` — `useInfiniteQuery` (TanStack Query v5), `initialPageParam: 0`, следующая страница — `offset = allPages.length * 30`. На сервере используется приём «limit+1»: у `get_transactions_page` запрашивается `p_limit + 1` строк, `hasMore = rows.length > limit`, лишняя строка отрезается перед возвратом — не требует отдельного `COUNT(*)`. Размер страницы — 30. На мобильных и десктопе — кнопка «Загрузить ещё» (ТЗ явно допускает этот вариант вместо курсорной пагинации при аккуратной реализации); дублирование строк между страницами исключено стабильной сортировкой (`transaction_date` + вторичный ключ `created_at`), что подтверждено отдельным SQL-тестом (сценарий 12 — пересечение страниц 1 и 2 равно нулю).

## 5. Как реализован поиск

Поиск — по `comment` (и расходов, и доходов), `income_source` (доходы) и названию связанной категории (`categories.name`, только расходы) через `ILIKE '%...%'` в одном SQL-запросе (`LEFT JOIN categories` + `OR`) — регистронезависимо. На клиенте `searchInput` (immediate, для controlled `<input>`) отделён от значения, которое реально уходит в query key/RPC, через `useDebouncedValue` (350мс) — печатание не порождает запрос на каждый символ. Поиск и сортировка сознательно не синхронизируются с URL (ТЗ прямо разрешает не усложнять архитектуру ради второстепенных фильтров).

## 6. Как реализована сортировка

Два порядка — `date_desc` (по умолчанию) и `date_asc`, выбираются пользователем через `Select` в панели фильтров. В SQL-функции реализованы двумя явными `return query`-ветками (а не CASE-WHEN в `ORDER BY`) — менее компактно, но однозначно читаемо. Обе ветки используют стабильную вторичную сортировку по `created_at` в том же направлении — операции с одинаковой датой никогда не переставляются местами между запросами (подтверждено сценарием 13 SQL-теста).

## 7. Как считаются итоги

`useTransactionsTotals` вызывает `get_transactions_totals` с теми же фильтрами, что и список (без `sort`/`limit`/`offset`, которые на сумму не влияют) — SQL считает `SUM(amount) FILTER (WHERE type = 'income'/'expense')` по **всем** подходящим строкам в БД, не только по одной загруженной странице. Это принципиально другое число, чем сводка Dashboard «за текущий месяц» (`get_dashboard_summary`) — на `/app/transactions` период и остальные фильтры произвольные, задаются пользователем. Оба хука (список и итоги) используют `placeholderData: keepPreviousData`, поэтому смена фильтра не обнуляет экран — старые данные остаются видимыми (слегка притемнёнными) до прихода новых.

## 8. Как защищена выборка через RLS

`get_transactions_page`/`get_transactions_totals` — `SECURITY INVOKER`: выполняются под правами вызывающего пользователя, поэтому RLS-политики `transactions_select_role_aware` (CHILD видит только свои операции, ADMIN/ADULT — всю семью), `categories_select_family` и `users_select_self_or_family` применяются к запросам внутри функции ровно так же, как к прямому SELECT с клиента — обхода RLS нет. `family_id` НЕ принимается параметром — семья определяется только через `family_members` по `auth.uid()` внутри функции; JOIN на `family_id` ограничивает набор строк ДО применения любых остальных фильтров, поэтому ни один клиентский параметр (`category_id`, поисковая строка, даты) не может быть использован, чтобы получить операции чужой семьи. Обе функции — `revoke all from public` + `revoke execute from anon` + `grant execute to authenticated` (с учётом нюанса, обнаруженного на Этапе 6: `anon` в этом проекте получает `EXECUTE` не только через псевдо-роль `PUBLIC`, поэтому нужна отдельная строка `revoke ... from anon`).

Значения из URL (`type`/`period`/`from`/`to`/`category`) валидируются на клиенте только против явного мусора (формат даты, непустая короткая строка для категории) — это НЕ граница безопасности: если в адресную строку подставить `category=<id-чужой-категории>`, в худшем случае это даст пустой список (RLS уже ограничила набор строк по СВОЕЙ семье до применения category-фильтра) — операции другой семьи никогда не попадут в ответ.

**Найденный и исправленный по ходу тестирования баг** (сценарий 14 живого SQL-теста): в первой версии обеих функций (`0019`) фильтр `category_mode = 'none'` проверялся как `category_id IS NULL`. Но у операций типа `income` `category_id` **всегда** `NULL` (доход не имеет категории — ТЗ, п.4), поэтому «Без категории» на вкладке «Все» незаметно подмешивал в выдачу ВСЕ доходы семьи. Тест поймал расхождение: вместо ожидаемых 2 строк (два расхода без категории) вернулось 3 (лишняя — доход 90 000 ₽). Это баг корректности данных, а не утечка между семьями — RLS по `family_id` в обоих случаях работала верно. Исправлено миграцией `0020`: для `category_mode = 'none'` дополнительно требуется `type = 'expense'`. После фикса — все 15 сценариев PASS.

**Результаты полного прогона (Family A / Family B / ребёнок в Family A, реальная база, RLS impersonation через `set_config('request.jwt.claims', ...)` + `set local role authenticated/anon`):**

| # | Сценарий | Результат |
|---|---|---|
| 1 | admin A видит все 5 операций семьи (4 своих + 1 ребёнка) | PASS (rows=5) |
| 2 | category_mode=specific (своя категория) — ровно 1 операция | PASS (rows=1) |
| 3 | поиск «продукты» находит операцию по comment | PASS (rows=1) |
| 4 | поиск по названию категории «Кафе и рестораны» (JOIN categories.name) | PASS (rows=1) |
| 5 | admin Б видит ровно 1 (свою) операцию, семья А невидима | PASS (rows=1) |
| 6 | admin Б подделывает category_id семьи А как specific — 0 строк | PASS (rows=0) |
| 7 | admin Б ищет «продукты» (существует только в семье А) — 0 строк | PASS (rows=0) |
| 8 | totals: Б + чужой (А) category_id — доход/расход = 0 | PASS (income=0.00, expenses=0.00) |
| 9 | totals для Б без доп. фильтров = его 0/400 | PASS (income=0.00, expenses=400.00) |
| 10 | CHILD видит ровно 1 (свою) операцию из 5 в семье А | PASS (rows=1) |
| 11 | пагинация: limit=2 offset=0 из 5 операций → ровно 2 строки | PASS (rows=2) |
| 12 | страница 1 и страница 2 не пересекаются | PASS (overlap=0) |
| 13 | date_asc/date_desc порядок | PASS (asc_first=2026-09-01, desc_first=2026-09-10) |
| 14 | category_mode=none — ровно 2 расхода без категории, доход не подмешан | PASS (rows=2, amounts=[50.00, 200.00], оба type=expense) |
| 15 | anon не может выполнить get_transactions_page | PASS (permission denied for function get_transactions_page) |

Все временные QA-фикстуры (3 тестовых пользователя и производные строки — семьи, членство, категории, операции) удалены из продакшен-базы после тестирования; повторной проверкой подтверждено 0 строк по всем связанным таблицам.

Дополнительно проверены security-advisories (`get_advisors`, тип security) — новых предупреждений по `get_transactions_page`/`get_transactions_totals` нет (обе `SECURITY INVOKER`, не попадают в категорию «доступные анониму/authenticated SECURITY DEFINER функции»); имеющиеся 9 WARN-записей — те же, что и до Этапа 9, унаследованы с Этапов 5/8 (`accept_family_invitation` и другие штатные `SECURITY DEFINER` RPC для управления семьёй/приглашениями, доступ к которым осознанно ограничен только явной ролевой и бизнес-логикой внутри самих функций).

## 9. Результаты build

```
npm run build
> tsc -b && vite build
✓ 2985 modules transformed.
✓ built in 2.56s
```

Успешно, 0 ошибок TypeScript. Предупреждение Vite про размер общего чанка (>500 kB) — не блокирующее, не относится к изменениям Этапа 9 (унаследовано от предыдущих этапов).

## 10. Результаты lint

```
npm run lint
✖ 9 problems (0 errors, 9 warnings)
```

0 ошибок. 9 предупреждений — тот же набор, что на Этапах 7-8 (react-refresh/only-export-components на файлах с именованными экспортами констант рядом с компонентом; react-hooks/incompatible-library на `watch()` из react-hook-form в `CategoryFormModal`/`TransactionFormModal`) — не связаны с изменениями Этапа 9, новых предупреждений не добавлено.

## 11. Результаты test

```
npm run test -- --run
Test Files  20 passed (20)
     Tests  143 passed (143)
```

Все 143 теста проходят, включая:
- новые юнит-тесты доменной логики фильтров (`filters.test.ts`: все 6 периодов, границы месяца/года, приведение категории для дохода, `isDefaultFilters`);
- переписанные тесты `TransactionsPage.test.tsx` (оба пустых состояния, ошибка+retry, отображение списка и итогов, смена вкладки/категории/периода/поиска/сортировки → аргументы запроса, «Загрузить ещё», открытие формы создания, клик по строке → модалка деталей → редактирование/удаление);
- регрессия по Этапам 6-8 не нарушена: создание расхода/дохода, редактирование, удаление, категории (включая отключённые и «без категории»), Dashboard — все соответствующие тесты (`TransactionFormModal.test.tsx`, `DeleteTransactionModal`, `CategoryFormModal` и др.) проходят без изменений в их бизнес-логике.

---

**ЭТАП 9 ГОТОВ. ЖДУ ПРОВЕРКУ.**
