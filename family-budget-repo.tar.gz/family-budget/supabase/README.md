# Supabase

Backend проекта — Supabase (PostgreSQL + Auth + Row Level Security). Подробная
инструкция по настройке — в корневом [README.md](../README.md), раздел «Supabase».

## Структура

- `migrations/` — SQL-миграции, источник истины схемы БД. Применяются по
  порядку номеров в имени файла (`0001_extensions.sql` → `0011_harden_functions.sql`).
  Таблицы создаются **только** через миграции, не вручную через Dashboard.
- `seed/seed.sql` — демонстрационные данные (демо-семья + 17 стандартных
  категорий) для **локальной** разработки через `supabase db reset`. Не
  содержит реальных пользовательских данных и не применяется к боевому проекту.

## Проект

- Имя: `family-budget`
- Организация: `bbardzr@gmail.com's Org`
- Регион: `eu-central-1`
- Тариф: Free ($0/мес.)

Реальные `Project URL` и `anon key` — только в `.env.local` (не в Git). См.
корневой README, раздел «Supabase», пункты 2–4.
