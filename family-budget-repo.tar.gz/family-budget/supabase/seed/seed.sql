-- ============================================================================
-- Этап 3: seed для ЛОКАЛЬНОЙ разработки.
--
-- ВАЖНО — прочитать перед запуском:
--   * Этот файл предназначен ТОЛЬКО для локального Supabase (`supabase start` +
--     `supabase db reset`, который автоматически выполняет supabase/seed.sql).
--   * Он НЕ применялся и НЕ должен применяться к боевому/облачному проекту
--     (family-budget, ttgsdllidpafxwhkttly) — там сейчас 0 строк в auth.users.
--   * Демо-пользователь ниже — не настоящий аккаунт: email заведомо
--     нерабочий (*.invalid), пароль — случайная непригодная для входа строка.
--     Это единственный способ создать валидную auth.users-запись для FK
--     (public.users.id -> auth.users.id), не смешивая её с реальной регистрацией
--     (которая появится как UI только на Этапе 5).
--   * Скрипт идемпотентен (ON CONFLICT DO NOTHING) — безопасно перезапускать.
-- ============================================================================

-- 1) Демо-пользователь в auth.users.
-- Вставка в auth.users автоматически запускает триггер handle_new_auth_user
-- (миграция 0007), который сам создаст public.users и public.user_settings —
-- вручную их вставлять не нужно.
insert into auth.users (
  instance_id, id, aud, role, email, encrypted_password,
  email_confirmed_at, raw_app_meta_data, raw_user_meta_data,
  created_at, updated_at,
  confirmation_token, email_change, email_change_token_new, recovery_token
) values (
  '00000000-0000-0000-0000-000000000000',
  '00000000-0000-0000-0000-0000000000f1',
  'authenticated',
  'authenticated',
  'demo-family@example.invalid',
  crypt('not-a-real-password-' || gen_random_uuid()::text, gen_salt('bf')),
  now(),
  '{"provider":"email","providers":["email"]}',
  '{"full_name":"Демонстрационная семья"}',
  now(),
  now(),
  '', '', '', ''
)
on conflict (id) do nothing;

-- 2) Демо-семья.
insert into public.families (id, name, created_by)
values (
  '00000000-0000-0000-0000-0000000000f2',
  'Демонстрационная семья',
  '00000000-0000-0000-0000-0000000000f1'
)
on conflict (id) do nothing;
-- Вставка в families автоматически создаст family_settings (триггер handle_new_family,
-- миграция 0008).

-- 3) Демо-участник семьи (admin), чтобы дальнейшие RLS-зависимые проверки
--    (is_family_admin и т.д.) для этой семьи были осмысленны.
insert into public.family_members (family_id, user_id, role, status)
values (
  '00000000-0000-0000-0000-0000000000f2',
  '00000000-0000-0000-0000-0000000000f1',
  'admin',
  'active'
)
on conflict (family_id, user_id) do nothing;

-- 4) Стандартные категории (17 шт., п.28 ТЗ) для демо-семьи.
-- Тип GOALS сознательно не использован ни для одной из 17 стандартных категорий:
-- он предназначен для пользовательских категорий, привязанных к конкретной цели
-- накопления (is_custom = true), которые по своей природе не могут быть частью
-- стандартного набора по умолчанию.
insert into public.categories (family_id, name, icon, type, is_active, is_custom)
values
  ('00000000-0000-0000-0000-0000000000f2', 'Продукты',              'shopping-cart', 'OBLIGATORY', true, false),
  ('00000000-0000-0000-0000-0000000000f2', 'Дом',                    'home',          'OBLIGATORY', true, false),
  ('00000000-0000-0000-0000-0000000000f2', 'Коммунальные услуги',    'droplet',       'OBLIGATORY', true, false),
  ('00000000-0000-0000-0000-0000000000f2', 'Автомобиль',             'car',           'OBLIGATORY', true, false),
  ('00000000-0000-0000-0000-0000000000f2', 'Бензин',                 'fuel',          'OBLIGATORY', true, false),
  ('00000000-0000-0000-0000-0000000000f2', 'Одежда',                 'shirt',         'WANTS',      true, false),
  ('00000000-0000-0000-0000-0000000000f2', 'Здоровье',               'heart-pulse',   'OBLIGATORY', true, false),
  ('00000000-0000-0000-0000-0000000000f2', 'Образование',            'graduation-cap','OBLIGATORY', true, false),
  ('00000000-0000-0000-0000-0000000000f2', 'Развлечения',            'party-popper',  'WANTS',      true, false),
  ('00000000-0000-0000-0000-0000000000f2', 'Кафе',                   'coffee',        'WANTS',      true, false),
  ('00000000-0000-0000-0000-0000000000f2', 'Связь',                  'phone',         'OBLIGATORY', true, false),
  ('00000000-0000-0000-0000-0000000000f2', 'Кредиты',                'landmark',      'OBLIGATORY', true, false),
  ('00000000-0000-0000-0000-0000000000f2', 'Путешествия',            'plane',         'WANTS',      true, false),
  ('00000000-0000-0000-0000-0000000000f2', 'Подарки',                'gift',          'WANTS',      true, false),
  ('00000000-0000-0000-0000-0000000000f2', 'Дети',                   'baby',          'OBLIGATORY', true, false),
  ('00000000-0000-0000-0000-0000000000f2', 'Животные',               'paw-print',     'OBLIGATORY', true, false),
  ('00000000-0000-0000-0000-0000000000f2', 'Другое',                 'more-horizontal','OTHER',     true, false)
on conflict (family_id, name) do nothing;
