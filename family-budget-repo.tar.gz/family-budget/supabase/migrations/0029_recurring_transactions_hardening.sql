-- ЭТАП 13 — Повторяющиеся операции.
--
-- Таблица recurring_transactions существует без изменений с Этапа 3
-- (миграция 0002_tables.sql) вместе с RLS-политиками (миграция 0010).
-- Аудит перед этой миграцией (Task #59-60) сравнил её политики с
-- transactions и нашёл, что recurring_transactions_update_own_or_admin /
-- recurring_transactions_delete_own_or_admin УЖЕ ограничены владельцем или
-- ADMIN (не расширены до ADULT) — это НЕ пробел, а сознательное решение
-- Этапа 3 ("та же CHILD-осторожная логика, что и у transactions"), явно
-- задокументированное комментарием в 0010_rls_policies.sql. В отличие от
-- planned_expenses/budgets/goals (таблицы семейного ПЛАНИРОВАНИЯ, расширенные
-- до admin+adult на Этапах 10-12), recurring_transactions — правило
-- автоматизации ЧУЖИХ денег конкретного человека, той же природы, что и сама
-- transactions. Поэтому здесь НЕТ такой миграции, как 0028 для planned_expenses
-- (расширение UPDATE/DELETE) — это единственный найденный аудитом "пробел",
-- оказавшийся не пробелом, а согласованной архитектурой, и правки не требует.
--
-- Реально найденных аудитом пробела — два, оба по тому же классу проблем, что
-- уже решался на Этапах 10-12:
--
--  1. INSERT/UPDATE не проверяют, что category_id (и user_id, если не сам
--     вызывающий) реально принадлежат той же семье — RLS WITH CHECK такую
--     JOIN-проверку выразить не может. Исправлено триггером, 4-е применение
--     паттерна: budget_categories_check_same_family (Этап 10) →
--     goals_check_owner_in_family (Этап 11) →
--     planned_expenses_check_same_family (Этап 12) →
--     recurring_transactions_check_same_family (этот файл).
--
--  2. next_run_date — расчёт следующей даты не должен полностью зависеть от
--     frontend (ТЗ, критическое требование). Решение:
--       a) при создании правила next_run_date ВСЕГДА принудительно
--          устанавливается сервером в start_date (BEFORE INSERT триггер),
--          независимо от того, что прислал клиент — первое "срабатывание"
--          правила всегда совпадает с его собственной датой начала;
--       b) calculate_recurring_next_run_date(...) — единственный источник
--          истины для шага "текущая дата → следующая по расписанию" (ТЗ:
--          "не дублируй алгоритм в нескольких местах"), используется и
--          внутри generate_due_planned_expenses() ниже, и доступен клиенту
--          как RPC для превью в форме (чистая функция дат, без обращения к
--          данным — безопасна для SECURITY INVOKER/любого authenticated).

-- ─────────────────────────────────────────────────────────────────────────
-- 1. Триггер same-family (user_id/category_id), 4-е применение паттерна.
-- ─────────────────────────────────────────────────────────────────────────
create or replace function public.recurring_transactions_check_same_family()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.user_id is not null and not exists (
    select 1 from public.family_members fm
    where fm.family_id = new.family_id
      and fm.user_id = new.user_id
      and fm.status = 'active'
  ) then
    raise exception 'RECURRING_USER_NOT_IN_FAMILY: user % is not an active member of family %',
      new.user_id, new.family_id
      using errcode = 'P0001';
  end if;

  if new.category_id is not null and not exists (
    select 1 from public.categories c
    where c.id = new.category_id
      and c.family_id = new.family_id
  ) then
    raise exception 'RECURRING_CATEGORY_NOT_IN_FAMILY: category % does not belong to family %',
      new.category_id, new.family_id
      using errcode = 'P0001';
  end if;

  return new;
end;
$$;

revoke all on function public.recurring_transactions_check_same_family() from public;
revoke execute on function public.recurring_transactions_check_same_family() from anon;
revoke execute on function public.recurring_transactions_check_same_family() from authenticated;

drop trigger if exists trg_recurring_transactions_check_same_family on public.recurring_transactions;
create trigger trg_recurring_transactions_check_same_family
before insert or update of user_id, category_id, family_id on public.recurring_transactions
for each row
execute function public.recurring_transactions_check_same_family();

-- ─────────────────────────────────────────────────────────────────────────
-- 2. next_run_date при создании — ВСЕГДА = start_date, сервер игнорирует то,
--    что прислал клиент в этом поле (колонка NOT NULL, поэтому клиент обязан
--    что-то отправить, но итоговое значение определяет только сервер).
-- ─────────────────────────────────────────────────────────────────────────
create or replace function public.recurring_transactions_set_initial_next_run_date()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  new.next_run_date := new.start_date;
  return new;
end;
$$;

revoke all on function public.recurring_transactions_set_initial_next_run_date() from public;
revoke execute on function public.recurring_transactions_set_initial_next_run_date() from anon;
revoke execute on function public.recurring_transactions_set_initial_next_run_date() from authenticated;

drop trigger if exists trg_recurring_transactions_set_initial_next_run_date on public.recurring_transactions;
create trigger trg_recurring_transactions_set_initial_next_run_date
before insert on public.recurring_transactions
for each row
execute function public.recurring_transactions_set_initial_next_run_date();

-- ─────────────────────────────────────────────────────────────────────────
-- 3. calculate_recurring_next_run_date — чистая функция дат, единственный
--    источник истины для шага расписания. p_current уже гарантированно "на
--    расписании" (это либо start_date, либо предыдущий next_run_date,
--    выставленный этой же функцией) — поэтому просто прибавляем ровно один
--    интервал; Postgres сам корректно обрабатывает конец месяца/29 февраля
--    при прибавлении interval 'N months'/'N years' (обрезает до последнего
--    валидного дня результирующего месяца).
-- ─────────────────────────────────────────────────────────────────────────
create or replace function public.calculate_recurring_next_run_date(
  p_current date,
  p_frequency text,
  p_interval_config jsonb
)
returns date
language sql
immutable
as $$
  select case p_frequency
    when 'weekly' then p_current + (greatest(coalesce((p_interval_config->>'interval')::int, 1), 1) * 7)
    when 'monthly' then
      (p_current + (greatest(coalesce((p_interval_config->>'interval')::int, 1), 1)::text || ' months')::interval)::date
    when 'yearly' then
      (p_current + (greatest(coalesce((p_interval_config->>'interval')::int, 1), 1)::text || ' years')::interval)::date
    else null
  end
$$;
comment on function public.calculate_recurring_next_run_date(date, text, jsonb) is
  'Следующая дата по расписанию строго после p_current (Этап 13). Единственный
   источник истины для шага повторения — используется и в
   generate_due_planned_expenses(), и как RPC для превью на клиенте, чтобы
   алгоритм не дублировался (ТЗ, критическое требование).';

revoke all on function public.calculate_recurring_next_run_date(date, text, jsonb) from public;
revoke execute on function public.calculate_recurring_next_run_date(date, text, jsonb) from anon;
grant execute on function public.calculate_recurring_next_run_date(date, text, jsonb) to authenticated;

-- ─────────────────────────────────────────────────────────────────────────
-- 4. generate_due_planned_expenses() — единственное место, где "наступление"
--    next_run_date превращается в НАПОМИНАНИЕ (строку planned_expenses).
--    КРИТИЧЕСКОЕ требование ТЗ: это НИКОГДА не создаёт запись в transactions
--    — здесь буквально нет ни одного обращения к этой таблице. Реальная
--    операция появляется только через отдельное явное действие пользователя
--    в уже существующем UI Этапа 12 ("Добавить фактический расход" →
--    TransactionFormModal с prefill), которое эта функция не вызывает и не
--    может вызвать.
--
--    Идемпотентность/защита от дублей при повторных вызовах (несколько
--    открытий приложения, два браузерных таба) — БЕЗ новых полей в схеме,
--    минимальным решением поверх уже существующих данных (ТЗ явно требует
--    сначала проанализировать схему, не изобретать лишнее):
--      1. `select ... for update` блокирует строку recurring_transactions на
--         время обработки — конкурентный вызов для того же правила ждёт и
--         видит уже сдвинутый next_run_date, а не то же самое "due" состояние.
--      2. Перед вставкой проверяется, нет ли уже planned_expenses с той же
--         парой (recurring_transaction_id, planned_date) — если есть,
--         напоминание для этого периода уже создано (например, предыдущий
--         вызов упал после INSERT, но до UPDATE next_run_date), повторной
--         записи не будет, а next_run_date всё равно продвигается дальше.
--
--    Защита от "нескольких пропущенных периодов сразу" (ТЗ, критическое
--    требование): цикл обрабатывает РОВНО ОДНО вхождение (текущий
--    next_run_date) за одно правило за один вызов функции — next_run_date
--    сдвигается только на один шаг вперёд, даже если результат всё ещё <=
--    today (несколько пропущенных периодов). Если правило по-прежнему
--    просрочено после этого — это будет видно как "Просрочено" в UI
--    (next_run_date < today, ТЗ) и обработано следующим отдельным вызовом
--    (следующее открытие приложения / повторное явное обновление), а не
--    циклом до "победного конца" внутри одной транзакции — то есть система
--    никогда не создаёт больше одного нового напоминания на правило за раз
--    без отдельного шага пользователя между ними.
--
--    SECURITY DEFINER необходим не для обхода прав, а потому что операция
--    затрагивает ДВЕ таблицы одним атомарным действием, и сочетание политик
--    двух таблиц делает эту связку невыразимой через RLS по отдельности: recurring_transactions_update_own_or_admin ограничивает
--    UPDATE next_run_date только владельцем/ADMIN, а
--    planned_expenses_insert_family разрешает INSERT любому ADULT/ADMIN —
--    без единой транзакции с серверной проверкой членства простой ADULT
--    (не владелец, не ADMIN) мог бы создать напоминание, но не смог бы
--    продвинуть next_run_date, и то же напоминание создавалось бы заново при
--    каждом его следующем визите. Внутри функции членство в семье проверяется
--    вручную (is_family_member), т.к. SECURITY DEFINER сам не проходит через
--    RLS вызываемых таблиц.
-- ─────────────────────────────────────────────────────────────────────────
create or replace function public.generate_due_planned_expenses()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_family_id uuid;
  v_can_manage_all boolean;
  v_rec record;
  v_title text;
  v_existing_id uuid;
  v_planned_id uuid;
  v_new_next_run_date date;
  v_results jsonb := '[]'::jsonb;
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  select fm.family_id into v_family_id
  from public.family_members fm
  where fm.user_id = v_user_id and fm.status = 'active'
  limit 1;

  if v_family_id is null then
    return '[]'::jsonb;
  end if;

  v_can_manage_all := public.get_family_role(v_family_id) in ('admin', 'adult');

  for v_rec in
    select rt.*
    from public.recurring_transactions rt
    where rt.family_id = v_family_id
      and rt.is_active = true
      and rt.next_run_date <= current_date
      and rt.start_date <= current_date
      and (rt.end_date is null or rt.end_date >= current_date)
      -- Тот же принцип видимости/прав, что planned_expenses_insert_family
      -- реализует через RLS — здесь переносится вручную, т.к. функция
      -- SECURITY DEFINER обходит RLS обеих таблиц (см. комментарий выше).
      and (v_can_manage_all or rt.user_id = v_user_id)
    order by rt.next_run_date asc
    for update of rt
  loop
    select pe.id into v_existing_id
    from public.planned_expenses pe
    where pe.recurring_transaction_id = v_rec.id
      and pe.planned_date = v_rec.next_run_date
    limit 1;

    if v_existing_id is null then
      select c.name into v_title
      from public.categories c
      where c.id = v_rec.category_id;

      v_title := coalesce(
        v_title,
        nullif(btrim(v_rec.income_source), ''),
        case when v_rec.type = 'income' then 'Доход' else 'Расход' end
      );

      insert into public.planned_expenses (
        family_id, user_id, category_id, title, amount, planned_date, status, recurring_transaction_id
      )
      values (
        v_rec.family_id, v_rec.user_id, v_rec.category_id, v_title, v_rec.amount,
        v_rec.next_run_date, 'planned', v_rec.id
      )
      returning id into v_planned_id;

      v_results := v_results || jsonb_build_object(
        'plannedExpenseId', v_planned_id,
        'recurringTransactionId', v_rec.id,
        'plannedDate', v_rec.next_run_date,
        'title', v_title,
        'amount', v_rec.amount,
        'type', v_rec.type
      );
    end if;

    v_new_next_run_date := public.calculate_recurring_next_run_date(v_rec.next_run_date, v_rec.frequency, v_rec.interval_config);

    update public.recurring_transactions
    set next_run_date = v_new_next_run_date
    where id = v_rec.id;
  end loop;

  return v_results;
end;
$$;
comment on function public.generate_due_planned_expenses() is
  'Обнаруживает "наступившие" повторяющиеся операции текущей семьи и готовит
   напоминание — строку planned_expenses(status=planned, recurring_transaction_id).
   НИКОГДА не создаёт transactions (Этап 13, критическое требование). Ровно
   одно новое напоминание на правило за вызов; next_run_date всегда
   продвигается на один шаг. Идемпотентна при повторных вызовах.';

revoke all on function public.generate_due_planned_expenses() from public;
revoke execute on function public.generate_due_planned_expenses() from anon;
grant execute on function public.generate_due_planned_expenses() to authenticated;
