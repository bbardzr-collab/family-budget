-- Этап 15: Семья и роли — защита единственного администратора + выход из
-- семьи по собственной инициативе.
--
-- Изменение роли участника (adult <-> child) и удаление участника ADMIN'ом
-- НЕ получают новых RPC — они уже полностью покрыты существующими RLS-
-- политиками family_members_update_admin (Этап 3, миграция 0010): ADMIN
-- может UPDATE любую строку family_members своей семьи. Единственное, чего
-- эта RLS-политика не может выразить (тот же класс ограничения, что и
-- "категория/ответственный из другой семьи" на Этапах 10-13) — агрегатную
-- проверку "останется ли в семье хотя бы один активный admin после этого
-- изменения". Для этого — новый BEFORE-триггер ниже, а не новая RPC (тот же
-- архитектурный выбор, что budget_categories_check_same_family/
-- planned_expenses_check_same_family/recurring_transactions_check_same_family).
--
-- "Удаление участника" реализовано как status -> 'inactive' (soft), НЕ DELETE
-- строки family_members — эта модель уже заложена в схему Этапа 3
-- (family_members.status check ('active','inactive') + partial unique index
-- family_members_one_active_per_user), просто ни разу не использовалась до
-- этого этапа. Она ничего не удаляет из transactions/goals/planned_expenses/
-- recurring_transactions (у них вообще нет FK на family_members.id — только
-- на family_id/user_id напрямую), поэтому история не теряется (ТЗ, п.13), а
-- освобождённый partial unique index сразу позволяет пользователю
-- присоединиться к другой семье (ТЗ, п.14). Выбран ровно один согласованный
-- подход для обоих сценариев ("удалили" и "ушёл сам") — п.14 требует не
-- смешивать модели.
--
-- Самостоятельный выход (leave_family) НЕ может быть просто прямым клиентским
-- UPDATE: family_members_update_admin разрешает UPDATE только ADMIN'у семьи —
-- у adult/child нет прав на UPDATE собственной же строки family_members
-- вообще. Поэтому это единственная новая RPC этого этапа (SECURITY DEFINER,
-- по необходимости — обходит RLS исключительно для строки самого вызывающего).

-- ───────────────────── 1. Защита "хотя бы один активный admin" ─────────────────────
-- Общая функция на UPDATE (role и/или status) и DELETE: если строка ДО
-- изменения была активным admin'ом и ПОСЛЕ изменения перестаёт им быть
-- (роль сменилась, статус стал inactive, либо строка удаляется), проверяем,
-- что в той же семье остаётся хотя бы один ДРУГОЙ активный admin — иначе
-- отклоняем операцию.
create or replace function public.family_members_guard_admin_invariant()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_remaining_admins integer;
  v_row record;
begin
  v_row := old;

  -- Затронутая строка и до изменения не была активным admin'ом — ничего
  -- не проверяем (типичный случай: смена роли/статуса adult/child).
  if v_row.role <> 'admin' or v_row.status <> 'active' then
    if tg_op = 'DELETE' then
      return old;
    end if;
    return new;
  end if;

  -- UPDATE, после которого строка остаётся активным admin'ом той же семьи —
  -- ничего не меняется по факту, проверка не нужна.
  if tg_op = 'UPDATE'
     and new.role = 'admin'
     and new.status = 'active'
     and new.family_id = old.family_id
  then
    return new;
  end if;

  select count(*) into v_remaining_admins
  from public.family_members fm
  where fm.family_id = v_row.family_id
    and fm.role = 'admin'
    and fm.status = 'active'
    and fm.id <> v_row.id;

  if v_remaining_admins = 0 then
    raise exception 'LAST_ADMIN_PROTECTED: family % must always keep at least one active admin', v_row.family_id;
  end if;

  if tg_op = 'DELETE' then
    return old;
  end if;
  return new;
end;
$$;
comment on function public.family_members_guard_admin_invariant() is
  'Этап 15, п.12: нельзя понизить/удалить единственного активного admin семьи.
   Срабатывает только когда затронутая строка ДО изменения была активным admin''ом.';

revoke all on function public.family_members_guard_admin_invariant() from public;
revoke execute on function public.family_members_guard_admin_invariant() from anon;
revoke execute on function public.family_members_guard_admin_invariant() from authenticated;

drop trigger if exists trg_family_members_guard_admin_update on public.family_members;
create trigger trg_family_members_guard_admin_update
  before update of role, status on public.family_members
  for each row execute function public.family_members_guard_admin_invariant();

drop trigger if exists trg_family_members_guard_admin_delete on public.family_members;
create trigger trg_family_members_guard_admin_delete
  before delete on public.family_members
  for each row execute function public.family_members_guard_admin_invariant();
-- Примечание: family_id намеренно НЕ входит в "update of" — переезд строки в
-- чужую семью уже структурно невозможен через RLS (family_members_update_admin
-- требует is_family_admin(family_id) и в USING на старом family_id, и в WITH
-- CHECK на новом — единовременно быть admin''ом обеих семей нельзя, т.к.
-- пользователь состоит максимум в одной активной семье, п.2).

-- ───────────────────────────── 2. leave_family() ─────────────────────────────
-- Самостоятельный выход текущего пользователя из своей семьи (ТЗ, п.14).
create or replace function public.leave_family()
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_member_id uuid;
  v_family_id uuid;
  v_role text;
  v_remaining_admins integer;
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  select fm.id, fm.family_id, fm.role
  into v_member_id, v_family_id, v_role
  from public.family_members fm
  where fm.user_id = v_user_id and fm.status = 'active'
  limit 1;

  if v_member_id is null then
    raise exception 'NO_FAMILY';
  end if;

  if v_role = 'admin' then
    select count(*) into v_remaining_admins
    from public.family_members fm
    where fm.family_id = v_family_id
      and fm.role = 'admin'
      and fm.status = 'active'
      and fm.id <> v_member_id;

    if v_remaining_admins = 0 then
      raise exception 'LAST_ADMIN_PROTECTED: family % must always keep at least one active admin', v_family_id;
    end if;
  end if;

  -- Тот же soft-remove, что и у remove_family_member (прямой UPDATE от
  -- ADMIN'а) — единая модель (ТЗ, п.14). Триггер выше — дополнительный
  -- рубеж защиты на случай ошибки в проверке above, а не единственный.
  update public.family_members
  set status = 'inactive'
  where id = v_member_id;
end;
$$;
comment on function public.leave_family() is
  'Этап 15, п.14: пользователь выходит из СВОЕЙ активной семьи. SECURITY DEFINER
   нужен, т.к. family_members_update_admin разрешает UPDATE только ADMIN''у —
   у adult/child иначе нет прав изменить даже собственную строку. auth.uid()
   определяется сервером; family_id/user_id никогда не принимаются параметром.';

revoke all on function public.leave_family() from public;
revoke execute on function public.leave_family() from anon;
grant execute on function public.leave_family() to authenticated;
