-- Этап 10 — обнаружено security advisor'ом сразу после миграции 0022:
-- budget_categories_check_same_family() — это ВНУТРЕННЯЯ триггерная функция
-- (BEFORE INSERT/UPDATE на budget_categories), она никогда не должна
-- вызываться напрямую как RPC, но по умолчанию Postgres даёт EXECUTE всем
-- ролям через PUBLIC, из-за чего PostgREST выставляет её на
-- /rest/v1/rpc/budget_categories_check_same_family (тот же нюанс, что уже
-- был учтён для get_monthly_budget_summary в миграции 0021).
--
-- Отзыв EXECUTE у public/anon/authenticated НЕ ломает сам триггер: Postgres
-- вызывает триггерные функции по внутреннему механизму, минуя проверку
-- EXECUTE-привилегии вызывающей роли — она нужна только для прямого вызова
-- через SELECT/RPC, который здесь как раз и запрещаем.
revoke all on function public.budget_categories_check_same_family() from public;
revoke execute on function public.budget_categories_check_same_family() from anon;
revoke execute on function public.budget_categories_check_same_family() from authenticated;
