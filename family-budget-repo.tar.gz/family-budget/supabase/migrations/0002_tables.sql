-- Этап 3: полная схема БД «Семейный бюджет 1.0» — 16 таблиц.
--
-- Общие правила:
--   * PK — uuid, default gen_random_uuid() (кроме users/user_settings/family_settings,
--     где PK — это FK на «родительскую» сущность: 1:1 связь).
--   * Деньги — NUMERIC(14,2) (решение Этапа 0), никогда FLOAT/копейки.
--   * created_at есть у всех таблиц. updated_at + триггер — только там, где строки
--     реально редактируются пользователем после создания (см. 0005_updated_at_trigger.sql
--     и обоснование в финальном отчёте Этапа 3).
--
-- ON DELETE — сознательная матрица, а не значение по умолчанию:
--   RESTRICT — таблицы с финансовой историей (transactions, budgets, goals,
--     planned_expenses, recurring_transactions) и их owner/family FK: удаление
--     пользователя или семьи не должно молча стереть деньги/историю. Сначала нужно
--     явно перенести или удалить финансовые данные.
--   CASCADE — таблицы-метаданные без самостоятельной финансовой ценности
--     (family_members, family_invitations, categories, notifications, settings,
--     calendar_connections, а также budget_categories/goal_contributions — они
--     полностью подчинены своей родительской budgets/goals записи и не имеют смысла
--     без неё).
--   SET NULL — необязательные ссылки, где потеря связи не означает потерю ценности
--     записи (transactions.category_id, goals.owner_user_id и т.д.).

-- 1) users — профиль, 1:1 к auth.users.
create table public.users (
  id uuid primary key references auth.users (id) on delete cascade,
  -- CASCADE: строка профиля бессмысленна без аккаунта auth.users (стандартный паттерн Supabase).
  full_name text not null,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
comment on table public.users is 'Профиль пользователя, 1:1 с auth.users. Заполняется триггером handle_new_auth_user.';

-- 2) families
create table public.families (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_by uuid not null references public.users (id) on delete restrict,
  -- RESTRICT: нельзя удалить аккаунт создателя, пока семья существует — иначе
  -- семья и её финансовая история (transactions и т.д., которые сами RESTRICT-защищены
  -- через family_id) останутся без явного владельца. Сначала нужно передать семью
  -- или удалить её целиком.
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
comment on table public.families is 'Семья — верхнеуровневая единица, к которой привязаны все финансовые данные.';

-- 3) family_members
create table public.family_members (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families (id) on delete cascade,
  -- CASCADE: членство бессмысленно без семьи (метаданные-связка).
  user_id uuid not null references public.users (id) on delete cascade,
  -- CASCADE: если аккаунт пользователя удалён, запись о его членстве не несёт
  -- финансовой ценности сама по себе — удаляется вместе с пользователем.
  role text not null check (role in ('admin', 'adult', 'child')),
  status text not null default 'active' check (status in ('active', 'inactive')),
  joined_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (family_id, user_id)
);
comment on table public.family_members is 'Членство пользователя в семье: роль (admin/adult/child) и статус.';

-- 4) family_invitations
create table public.family_invitations (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families (id) on delete cascade,
  -- CASCADE: приглашение бессмысленно без семьи, в которую оно приглашает.
  invited_by uuid not null references public.users (id) on delete cascade,
  -- CASCADE: приглашение — метаданные, а не финансовая история; если пригласивший
  -- удалил аккаунт, приглашение теряет смысл вместе с ним.
  role text not null check (role in ('admin', 'adult', 'child')),
  token text not null unique,
  expires_at timestamptz not null,
  status text not null default 'pending' check (status in ('pending', 'accepted', 'expired', 'revoked')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
comment on table public.family_invitations is
  'Приглашение в семью по ссылке с токеном (решение Этапа 0: только ссылка, без email-рассылки).';

-- 5) categories — сидируются на каждую семью отдельно (не глобальный NULL family_id).
create table public.categories (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families (id) on delete cascade,
  -- CASCADE: список категорий — метаданные семьи, бессмысленны без неё.
  name text not null,
  icon text,
  type text not null check (type in ('OBLIGATORY', 'WANTS', 'GOALS', 'OTHER')),
  is_active boolean not null default true,
  is_custom boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (family_id, name)
);
comment on table public.categories is 'Категории операций, свои у каждой семьи. Тип определяет группу в аналитике.';

-- 6) transactions — ядро финансовой истории.
create table public.transactions (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families (id) on delete restrict,
  -- RESTRICT: финансовая история семьи не должна исчезать молча при удалении семьи.
  user_id uuid not null references public.users (id) on delete restrict,
  -- RESTRICT: операция — финансовая история конкретного человека, не удаляется
  -- молча вместе с его аккаунтом.
  type text not null check (type in ('income', 'expense')),
  amount numeric(14, 2) not null check (amount > 0),
  category_id uuid references public.categories (id) on delete set null,
  -- SET NULL: категория — классификация, а не сама операция; операция должна
  -- пережить удаление категории.
  income_source text,
  transaction_date date not null default current_date,
  comment text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
comment on table public.transactions is 'Фактические операции дохода/расхода. amount всегда положительное, знак определяет type.';

-- 7) budgets
create table public.budgets (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families (id) on delete restrict,
  -- RESTRICT: бюджет — финансовое планирование, защищаем от молчаливой потери.
  period_month date not null,
  total_amount numeric(14, 2) not null check (total_amount >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (family_id, period_month)
);
comment on table public.budgets is 'Общий бюджет семьи на календарный месяц (period_month хранит первое число месяца).';

-- 8) budget_categories
create table public.budget_categories (
  id uuid primary key default gen_random_uuid(),
  budget_id uuid not null references public.budgets (id) on delete cascade,
  -- CASCADE: лимит по категории не имеет смысла без родительского бюджета —
  -- полностью подчинённая запись (не самостоятельная финансовая история).
  category_id uuid not null references public.categories (id) on delete cascade,
  -- CASCADE: лимит для несуществующей категории бессмысленен; блокировать удаление
  -- категории из-за этого было бы избыточно строго (категории — редактируемые метаданные).
  limit_amount numeric(14, 2) not null check (limit_amount >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (budget_id, category_id)
);
comment on table public.budget_categories is 'Лимит расходов по конкретной категории в рамках месячного бюджета.';

-- 9) goals
create table public.goals (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families (id) on delete restrict,
  -- RESTRICT: цель накопления — финансовое планирование, защищаем от молчаливой потери.
  goal_type text not null check (goal_type in ('personal', 'family')),
  owner_user_id uuid references public.users (id) on delete set null,
  -- SET NULL: для personal-цели владелец обязателен по CHECK ниже, но если его
  -- аккаунт удалён, сама цель и история взносов не должны исчезать — она просто
  -- становится «ничьей» видимой семье записью, а не молча удаляется.
  title text not null,
  icon text,
  target_amount numeric(14, 2) not null check (target_amount > 0),
  target_date date,
  status text not null default 'active' check (status in ('active', 'achieved', 'cancelled')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint goals_owner_matches_type check (
    (goal_type = 'personal' and owner_user_id is not null) or
    (goal_type = 'family' and owner_user_id is null)
  )
);
comment on table public.goals is
  'Цель накопления. current_amount не хранится — считается агрегатом суммы goal_contributions.';

-- 10) goal_contributions
create table public.goal_contributions (
  id uuid primary key default gen_random_uuid(),
  goal_id uuid not null references public.goals (id) on delete cascade,
  -- CASCADE: взносы полностью подчинены цели и агрегируются в её текущую сумму;
  -- при явном удалении цели её история взносов не может быть привязана ни к чему
  -- другому и удаляется вместе с ней (в отличие от transactions, это не самостоятельная
  -- финансовая история, а производная от goals запись).
  user_id uuid not null references public.users (id) on delete restrict,
  -- RESTRICT: сам факт взноса конкретного человека — финансовая история,
  -- не удаляется молча вместе с его аккаунтом.
  amount numeric(14, 2) not null check (amount > 0),
  comment text,
  contributed_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);
comment on table public.goal_contributions is 'Взносы в цель накопления. Сумма goal.current_amount — агрегат по этой таблице.';

-- 11) planned_expenses
-- Внимание: recurring_transaction_id ссылается на таблицу recurring_transactions,
-- которая создаётся ниже в этой же миграции — сам FK добавляется отдельным
-- ALTER TABLE в 0003_planned_expenses_fk.sql, чтобы не менять порядок создания таблиц.
create table public.planned_expenses (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families (id) on delete restrict,
  -- RESTRICT: план расходов — финансовое планирование, защищаем от молчаливой потери.
  user_id uuid references public.users (id) on delete set null,
  -- SET NULL: плановая операция может быть не привязана к конкретному человеку
  -- (общий семейный план); если ответственный удалил аккаунт, план остаётся
  -- видимым семье, а не исчезает.
  category_id uuid references public.categories (id) on delete set null,
  -- SET NULL: та же логика, что и у transactions.category_id.
  title text not null,
  amount numeric(14, 2) not null check (amount > 0),
  planned_date date not null,
  status text not null default 'planned' check (status in ('planned', 'done', 'cancelled')),
  recurring_transaction_id uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
comment on table public.planned_expenses is
  'Запланированные расходы: ручной план или сгенерированное напоминание от recurring_transactions.';

-- 12) recurring_transactions
-- Решение Этапа 0: повторяющиеся операции НЕ создают запись расхода автоматически —
-- только напоминание/plan-запись, пользователь подтверждает вручную.
create table public.recurring_transactions (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families (id) on delete restrict,
  -- RESTRICT: правило автоматизации финансово значимо, защищаем от молчаливой потери.
  user_id uuid not null references public.users (id) on delete restrict,
  -- RESTRICT: правило принадлежит конкретному человеку и имеет финансовую значимость.
  type text not null check (type in ('income', 'expense')),
  amount numeric(14, 2) not null check (amount > 0),
  category_id uuid references public.categories (id) on delete set null,
  income_source text,
  frequency text not null check (frequency in ('weekly', 'monthly', 'yearly')),
  interval_config jsonb not null default '{}'::jsonb,
  start_date date not null,
  end_date date,
  next_run_date date not null,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint recurring_transactions_end_after_start check (end_date is null or end_date >= start_date)
);
comment on table public.recurring_transactions is
  'Правило повторяющейся операции. Само по себе НЕ создаёт transactions — только основание для напоминаний.';

-- 13) notifications
create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families (id) on delete cascade,
  -- CASCADE: уведомление — эфемерные метаданные без самостоятельной финансовой ценности.
  user_id uuid not null references public.users (id) on delete cascade,
  -- CASCADE: адресная доставка конкретному пользователю, бессмысленна без него.
  type text not null check (
    type in ('payment_due', 'budget_exceeded', 'limit_reached', 'goal_achieved', 'family_invite')
  ),
  title text not null,
  message text not null,
  payload jsonb not null default '{}'::jsonb,
  is_read boolean not null default false,
  channel text not null default 'in_app',
  created_at timestamptz not null default now()
);
comment on table public.notifications is 'Уведомления пользователя. Создаются системными функциями/триггерами, не напрямую с фронта.';

-- 14) user_settings — 1:1 с users.
create table public.user_settings (
  user_id uuid primary key references public.users (id) on delete cascade,
  -- CASCADE: настройки бессмысленны без пользователя (1:1 запись).
  theme text not null default 'light',
  notification_prefs jsonb not null default '{}'::jsonb,
  locale text not null default 'ru',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
comment on table public.user_settings is 'Персональные настройки пользователя. Создаётся автоматически триггером handle_new_auth_user.';

-- 15) family_settings — 1:1 с families.
create table public.family_settings (
  family_id uuid primary key references public.families (id) on delete cascade,
  -- CASCADE: настройки бессмысленны без семьи (1:1 запись).
  currency text not null default 'RUB',
  child_visibility jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
comment on table public.family_settings is
  'Настройки семьи: валюта, приватность для CHILD (child_visibility). Создаётся триггером handle_new_family.';

-- 16) calendar_connections — схема готова, интеграция Google Calendar НЕ входит в 1.0.
create table public.calendar_connections (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families (id) on delete cascade,
  -- CASCADE: интеграционные метаданные, не финансовая история.
  user_id uuid not null references public.users (id) on delete cascade,
  -- CASCADE: личное подключение календаря конкретного пользователя.
  provider text not null,
  access_token text,
  refresh_token text,
  status text not null default 'disconnected' check (status in ('disconnected', 'connected', 'error')),
  created_at timestamptz not null default now()
);
comment on table public.calendar_connections is
  'Заготовка под интеграцию с Google Calendar. Функциональность не активна в 1.0.';
