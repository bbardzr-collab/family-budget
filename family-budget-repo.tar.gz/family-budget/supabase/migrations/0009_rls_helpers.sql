-- Этап 3: SECURITY DEFINER вспомогательные функции для RLS-политик.
--
-- Зачем SECURITY DEFINER: функции выполняются от имени владельца (роль миграций,
-- у неё есть BYPASSRLS), поэтому их внутренние SELECT-запросы к family_members
-- НЕ проходят через RLS-политики самой family_members. Это специально —
-- иначе любая RLS-политика family_members, которая сама вызывает эти функции
-- для проверки членства, привела бы к бесконечной рекурсии (политика вызывает
-- функцию → функция читает family_members → снова применяется политика → ...).
-- `set search_path = public` защищает от search_path hijacking (обязательная
-- практика для SECURITY DEFINER функций в Postgres).
--
-- STABLE — функции не модифицируют данные и возвращают одинаковый результат
-- в рамках одного запроса, что позволяет планировщику их кэшировать/оптимизировать.

create or replace function public.is_family_member(p_family_id uuid)
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select exists (
    select 1
    from public.family_members fm
    where fm.family_id = p_family_id
      and fm.user_id = auth.uid()
      and fm.status = 'active'
  );
$$;
comment on function public.is_family_member(uuid) is
  'true, если текущий auth.uid() — активный участник семьи p_family_id.';

create or replace function public.get_family_role(p_family_id uuid)
returns text
language sql
security definer
stable
set search_path = public
as $$
  select fm.role
  from public.family_members fm
  where fm.family_id = p_family_id
    and fm.user_id = auth.uid()
    and fm.status = 'active'
  limit 1;
$$;
comment on function public.get_family_role(uuid) is
  'Роль текущего пользователя (admin/adult/child) в семье p_family_id, либо NULL.';

create or replace function public.is_family_admin(p_family_id uuid)
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select exists (
    select 1
    from public.family_members fm
    where fm.family_id = p_family_id
      and fm.user_id = auth.uid()
      and fm.status = 'active'
      and fm.role = 'admin'
  );
$$;
comment on function public.is_family_admin(uuid) is
  'true, если текущий auth.uid() — активный admin семьи p_family_id.';

create or replace function public.shares_family_with(p_user_id uuid)
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select exists (
    select 1
    from public.family_members my
    join public.family_members their on their.family_id = my.family_id
    where my.user_id = auth.uid()
      and their.user_id = p_user_id
      and my.status = 'active'
      and their.status = 'active'
  );
$$;
comment on function public.shares_family_with(uuid) is
  'true, если текущий auth.uid() состоит хотя бы в одной активной семье вместе с p_user_id
   (используется, чтобы участники семьи видели профили друг друга в public.users).';

grant execute on function public.is_family_member(uuid) to authenticated;
grant execute on function public.get_family_role(uuid) to authenticated;
grant execute on function public.is_family_admin(uuid) to authenticated;
grant execute on function public.shares_family_with(uuid) to authenticated;
