-- Этап 17: система уведомлений (in-app notification center).
--
-- Используется исключительно уже существующая с Этапа 3 таблица
-- notifications (family_id/user_id/type/title/message/payload/is_read/
-- channel/created_at) и уже существующий с Этапа 3 user_settings.notification_prefs
-- — новая таблица настроек не создаётся (ТЗ, п.3). RLS notifications
-- (select_own/update_own/delete_own — "user_id = auth.uid()") уже была
-- полностью корректна с Этапа 3 и НЕ меняется в этой миграции: у неё нет и
-- не появляется INSERT-политики для authenticated — это намеренно, единственный
-- способ создать уведомление для пользователя — SECURITY DEFINER-функция
-- create_notification() ниже, которая никогда не берёт user_id с фронта, а
-- вызывается только изнутри других SECURITY DEFINER-функций/триггеров
-- проекта (никогда не выдаётся EXECUTE напрямую клиенту). Это и есть граница
-- "нельзя получить чужие уведомления даже через family_id" (ТЗ, п.4).
--
-- Состав миграции:
--   A) event_key + индексы (ТЗ, п.26-27) — дедупликация "одно и то же событие
--      не создаёт уведомление повторно".
--   B) create_notification() — единая точка вставки, учитывает
--      user_settings.notification_prefs (ТЗ, п.3, 9, 19) и дедуп по event_key.
--   C) RPC для клиента: mark_notification_read/mark_all_notifications_read/
--      delete_notification (ТЗ, п.5) — SECURITY INVOKER, реальная защита
--      по-прежнему RLS (см. выше), RPC — явная именованная точка входа с
--      понятными кодами ошибок, как и просило ТЗ.
--   D) Генерация уведомлений — везде используется единая функция
--      create_notification() поверх УЖЕ существующих механизмов проекта, не
--      новая параллельная система:
--        - payment_due  → внутри generate_due_planned_expenses() (Этап 13,
--          уже безопасно вызывается сама один раз за вкладку); НИКОГДА не
--          создаёт transactions — существующий инвариант Этапа 13 не тронут.
--        - goal_achieved → внутри goal_check_auto_complete() (Этап 11) —
--          на переходе active → completed (уже дедуплицирован WHERE status =
--          'active' в самом UPDATE).
--        - budget_exceeded / limit_reached → новый AFTER-триггер на
--          transactions, event_key на budget_id/бюджетной категории +
--          текущий total_amount/limit_amount (см. комментарий у C ниже).
--        - family_invite → СОЗНАТЕЛЬНО не автогенерируется: модель
--          приглашений (Этап 5) — только shareable-токен без user_id
--          получателя (InviteMemberModal не запрашивает email), реального
--          получателя на момент создания приглашения определить нельзя (ТЗ,
--          п.17: "если модель приглашения основана только на token без
--          user_id... уведомление создаётся только там, где существует
--          реальный получатель" — такого места в текущей архитектуре нет).
--   E) Безопасные дефолты user_settings.notification_prefs (по аналогии с
--      family_settings.child_visibility на Этапе 16) — backfill + новая
--      строка default в handle_new_auth_user().

-- ═══════════════════════ A) event_key + индексы ═══════════════════════

alter table public.notifications add column if not exists event_key text;

comment on column public.notifications.event_key is
  'Ключ дедупликации события-источника (например budget_exceeded:<budget_id>:<total_amount>). '
  'NULL для уведомлений без дедупликации. Уникален в пределах (user_id, event_key).';

-- Партиальный уникальный индекс (не обычный UNIQUE(user_id, event_key)) —
-- NULL не участвует в дедупликации в принципе, а уведомления без event_key
-- (в этой миграции таких нет, но конструкция общая) не должны блокировать
-- друг друга.
create unique index if not exists notifications_user_event_key_unique
  on public.notifications (user_id, event_key)
  where event_key is not null;

-- ТЗ, п.27 — недостающие индексы (idx_notifications_user_id и
-- idx_notifications_family_id уже существовали с Этапа 3, не трогаем).
-- idx_notifications_is_read (одиночный) заменяется составным
-- (user_id, is_read), который реально соответствует паттерну запросов этого
-- этапа ("мои непрочитанные") — отдельный индекс по одному is_read не нужен.
drop index if exists public.idx_notifications_is_read;
create index if not exists idx_notifications_user_id_is_read
  on public.notifications (user_id, is_read);
create index if not exists idx_notifications_created_at
  on public.notifications (created_at desc);

-- ═══════════════════════ B) create_notification() ═══════════════════════

-- Единственная точка вставки в notifications. НИКОГДА не должна быть
-- вызываемой напрямую с клиента — p_user_id полностью доверенный параметр
-- (только для внутренних вызовов из других SECURITY DEFINER-функций,
-- работающих от имени владельца функции, что не требует отдельного EXECUTE
-- у вызываемой функции). См. явный тройной revoke внизу — тот же паттерн,
-- что у всех internal-only триггерных функций проекта (budget_categories_
-- check_same_family и т.д., см. STAGE6_REPORT.md, п.13).
create or replace function public.create_notification(
  p_user_id uuid,
  p_family_id uuid,
  p_type text,
  p_title text,
  p_message text,
  p_payload jsonb default null,
  p_event_key text default null
) returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_id uuid;
  v_enabled boolean;
begin
  -- ТЗ, п.3, 9, 19 — уважаем notification_prefs получателя: если пользователь
  -- явно выключил этот тип, уведомление вообще не создаётся (не просто
  -- скрывается в UI). Отсутствие ключа/строки трактуется как "включено"
  -- (безопасный дефолт, см. блок E ниже).
  select coalesce((us.notification_prefs ->> p_type)::boolean, true)
  into v_enabled
  from public.user_settings us
  where us.user_id = p_user_id;

  if v_enabled is null then
    v_enabled := true;
  end if;

  if not v_enabled then
    return null;
  end if;

  if p_event_key is not null then
    insert into public.notifications (family_id, user_id, type, title, message, payload, event_key)
    values (p_family_id, p_user_id, p_type, p_title, p_message, p_payload, p_event_key)
    on conflict (user_id, event_key) where event_key is not null do nothing
    returning id into v_id;
  else
    insert into public.notifications (family_id, user_id, type, title, message, payload)
    values (p_family_id, p_user_id, p_type, p_title, p_message, p_payload)
    returning id into v_id;
  end if;

  return v_id;
end;
$$;

revoke all on function public.create_notification(uuid, uuid, text, text, text, jsonb, text) from public;
revoke execute on function public.create_notification(uuid, uuid, text, text, text, jsonb, text) from anon;
revoke execute on function public.create_notification(uuid, uuid, text, text, text, jsonb, text) from authenticated;

-- ═══════════════════ C) RPC для клиента (ТЗ, п.5) ═══════════════════

-- SECURITY INVOKER — реальная защита по-прежнему notifications_update_own
-- (user_id = auth.uid()): если p_notification_id принадлежит другому
-- пользователю, RLS отфильтрует строку из UPDATE ещё до RETURNING, поэтому
-- v_updated_id останется NULL и функция вернёт понятную ошибку, а не тихо
-- "успех" без изменений (ТЗ, п.28, сценарии 2-3).
create or replace function public.mark_notification_read(p_notification_id uuid)
returns void
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_updated_id uuid;
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  update public.notifications
  set is_read = true
  where id = p_notification_id
  returning id into v_updated_id;

  if v_updated_id is null then
    raise exception 'NOTIFICATION_NOT_FOUND';
  end if;
end;
$$;

comment on function public.mark_notification_read(uuid) is
  'Отметить одно уведомление прочитанным. RLS notifications_update_own — единственная граница '
  '(user_id = auth.uid()); подмена чужого id даёт NOTIFICATION_NOT_FOUND, а не тихий no-op.';

revoke all on function public.mark_notification_read(uuid) from public;
revoke execute on function public.mark_notification_read(uuid) from anon;
grant execute on function public.mark_notification_read(uuid) to authenticated;

-- Массовая отметка — тоже SECURITY INVOKER: RLS сама сужает
-- "where is_read = false" до строк вызывающего, поэтому явный user_id-фильтр
-- в WHERE не нужен и не может быть подменён.
create or replace function public.mark_all_notifications_read()
returns integer
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_count integer;
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  with updated as (
    update public.notifications
    set is_read = true
    where is_read = false
    returning id
  )
  select count(*) into v_count from updated;

  return v_count;
end;
$$;

comment on function public.mark_all_notifications_read() is
  'Отметить прочитанными ВСЕ непрочитанные уведомления текущего пользователя. '
  'RLS notifications_update_own ограничивает область действия его собственными строками.';

revoke all on function public.mark_all_notifications_read() from public;
revoke execute on function public.mark_all_notifications_read() from anon;
grant execute on function public.mark_all_notifications_read() to authenticated;

create or replace function public.delete_notification(p_notification_id uuid)
returns void
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_deleted_id uuid;
begin
  if auth.uid() is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  delete from public.notifications
  where id = p_notification_id
  returning id into v_deleted_id;

  if v_deleted_id is null then
    raise exception 'NOTIFICATION_NOT_FOUND';
  end if;
end;
$$;

comment on function public.delete_notification(uuid) is
  'Удалить одно уведомление. RLS notifications_delete_own — единственная граница.';

revoke all on function public.delete_notification(uuid) from public;
revoke execute on function public.delete_notification(uuid) from anon;
grant execute on function public.delete_notification(uuid) to authenticated;

-- get_notifications() сознательно НЕ создаётся как RPC (ТЗ, п.5 формулирует
-- это как "предпочтительно", а не императивно, в отличие от трёх функций
-- выше) — тот же принцип, что и у planned_expenses на Этапе 12: простой
-- однотабличный фильтр/сортировка полностью покрывается RLS
-- (notifications_select_own) через обычный Supabase REST
-- (.from('notifications').select().order().range()/.eq('is_read', false)) —
-- никакой агрегации или бизнес-логики, которая оправдывала бы RPC, здесь нет.

-- ═══════════════ D.1) budget_exceeded / limit_reached ═══════════════

-- Внутренний helper, вызывается и из триггера ниже, и мог бы быть вызван
-- вручную для отладки — НЕ экспортируется клиенту (revoke все три роли).
-- SECURITY DEFINER нужен по двум причинам: (1) читает budgets/
-- budget_categories/family_members всей семьи независимо от того, кто из
-- участников (в т.ч. CHILD) инициировал транзакцию, вызвавшую пересчёт;
-- (2) создаёт уведомления для ДРУГИХ пользователей семьи через
-- create_notification(), что структурно невозможно как SECURITY INVOKER
-- (у notifications нет INSERT-политики). family_id/period всегда берутся из
-- параметров, переданных триггером из строки transactions, которую
-- вызывающий и так уже имел право записать (см. комментарий у триггера) —
-- ни одного параметра не берётся "по доверию" от клиента напрямую.
create or replace function public.check_budget_notifications(p_family_id uuid, p_period_start date)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_period_end date := (p_period_start + interval '1 month' - interval '1 day')::date;
  v_budget record;
  v_total_spent numeric(14, 2);
  v_cat record;
  v_cat_spent numeric(14, 2);
  v_percent numeric;
  v_member_id uuid;
begin
  select b.id, b.total_amount into v_budget
  from public.budgets b
  where b.family_id = p_family_id and b.period_month = p_period_start;

  if v_budget.id is null then
    return;
  end if;

  select coalesce(sum(t.amount), 0) into v_total_spent
  from public.transactions t
  where t.family_id = p_family_id
    and t.type = 'expense'
    and t.transaction_date between p_period_start and v_period_end;

  -- Семейный агрегат "превышен ли бюджет" — та же величина, что видит CHILD
  -- на /app/budget с Этапа 16 (family_aggregate), поэтому уведомление можно
  -- безопасно отправлять всем активным участникам семьи, включая CHILD, без
  -- нарушения приватности (ТЗ, п.18) — никаких "кто из взрослых сколько
  -- потратил" здесь нет и не будет.
  if v_budget.total_amount > 0 and v_total_spent > v_budget.total_amount then
    for v_member_id in
      select fm.user_id from public.family_members fm
      where fm.family_id = p_family_id and fm.status = 'active'
    loop
      perform public.create_notification(
        v_member_id,
        p_family_id,
        'budget_exceeded',
        'Бюджет превышен',
        'Расходы семьи превысили установленный бюджет на '
          || trim(to_char(v_total_spent - v_budget.total_amount, 'FM999G999G999D00')) || ' ₽.',
        jsonb_build_object('budget_id', v_budget.id),
        -- event_key включает total_amount — если admin/adult изменит сумму
        -- бюджета, это "новая ситуация" (ТЗ, п.14) и уведомление сможет
        -- сработать заново под новым лимитом.
        'budget_exceeded:' || v_budget.id::text || ':' || v_budget.total_amount::text
      );
    end loop;
  end if;

  for v_cat in
    select bc.id as budget_category_id, bc.category_id, bc.limit_amount, c.name as category_name
    from public.budget_categories bc
    join public.categories c on c.id = bc.category_id
    where bc.budget_id = v_budget.id and bc.limit_amount > 0
  loop
    select coalesce(sum(t.amount), 0) into v_cat_spent
    from public.transactions t
    where t.family_id = p_family_id
      and t.type = 'expense'
      and t.category_id = v_cat.category_id
      and t.transaction_date between p_period_start and v_period_end;

    v_percent := v_cat_spent / v_cat.limit_amount * 100;

    if v_percent >= 100 then
      for v_member_id in
        select fm.user_id from public.family_members fm
        where fm.family_id = p_family_id and fm.status = 'active'
      loop
        perform public.create_notification(
          v_member_id,
          p_family_id,
          'limit_reached',
          'Лимит превышен',
          'Расходы на «' || v_cat.category_name || '» превысили лимит на '
            || trim(to_char(v_cat_spent - v_cat.limit_amount, 'FM999G999G999D00')) || ' ₽.',
          jsonb_build_object('budget_id', v_budget.id, 'category_id', v_cat.category_id),
          'limit_reached:' || v_cat.budget_category_id::text || ':' || v_cat.limit_amount::text || ':100'
        );
      end loop;
    elsif v_percent >= 90 then
      for v_member_id in
        select fm.user_id from public.family_members fm
        where fm.family_id = p_family_id and fm.status = 'active'
      loop
        perform public.create_notification(
          v_member_id,
          p_family_id,
          'limit_reached',
          'Лимит категории',
          'Расходы на «' || v_cat.category_name || '» достигли ' || round(v_percent) || '% установленного лимита.',
          jsonb_build_object('budget_id', v_budget.id, 'category_id', v_cat.category_id),
          'limit_reached:' || v_cat.budget_category_id::text || ':' || v_cat.limit_amount::text || ':90'
        );
      end loop;
    end if;
  end loop;
end;
$$;

revoke all on function public.check_budget_notifications(uuid, date) from public;
revoke execute on function public.check_budget_notifications(uuid, date) from anon;
revoke execute on function public.check_budget_notifications(uuid, date) from authenticated;

-- Триггер на transactions — единственный НЕ "по требованию со страницы"
-- источник событий budget_exceeded/limit_reached (ТЗ, п.14-15: "не создавать
-- уведомление повторно на каждом запросе страницы"): срабатывает только на
-- реальную запись (INSERT/UPDATE/DELETE), никогда на простое открытие
-- /app/budget или /app/analytics. family_id/период берутся из самой строки
-- transactions, которую пишущий уже прошёл через RLS transactions_insert_own
-- / _update_own_or_admin (family_id = его собственная семья) — поэтому
-- пересчёт никогда не затрагивает чужую семью, независимо от роли
-- инициатора (в т.ч. CHILD, создающий свою собственную операцию).
create or replace function public.transactions_notify_budget_events()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if tg_op in ('INSERT', 'UPDATE') and new.type = 'expense' then
    perform public.check_budget_notifications(new.family_id, date_trunc('month', new.transaction_date)::date);
  end if;

  -- На UPDATE намеренно перепроверяем и старый период тоже (сумма могла
  -- уменьшиться/операция могла "уехать" в другой месяц/категорию) — дешёвая
  -- операция, а create_notification всё равно дедуплицирует по event_key,
  -- так что повторный вызов для того же периода — no-op.
  if tg_op in ('UPDATE', 'DELETE') and old.type = 'expense' then
    perform public.check_budget_notifications(old.family_id, date_trunc('month', old.transaction_date)::date);
  end if;

  return null;
end;
$$;

revoke all on function public.transactions_notify_budget_events() from public;
revoke execute on function public.transactions_notify_budget_events() from anon;
revoke execute on function public.transactions_notify_budget_events() from authenticated;

drop trigger if exists trg_transactions_notify_budget_events on public.transactions;
create trigger trg_transactions_notify_budget_events
  after insert or update or delete on public.transactions
  for each row execute function public.transactions_notify_budget_events();

-- ═══════════════════ D.2) goal_achieved ═══════════════════

-- Расширение уже существующего триггера Этапа 11 (goal_check_auto_complete)
-- — не новый механизм обнаружения достижения цели, а notification-хук ровно
-- в момент атомарного перехода active → completed. Условие
-- "where id = new.goal_id and status = 'active'" в UPDATE уже гарантирует,
-- что переход происходит максимум один раз (конкурентные вставки взносов
-- сериализуются через обычную блокировку строки) — v_goal_row.id будет NULL
-- при повторном/параллельном срабатывании, поэтому уведомление создаётся
-- ровно один раз за жизнь цели (ТЗ, п.16: "не создавать при каждом открытии
-- страницы").
create or replace function public.goal_check_auto_complete()
returns trigger
language plpgsql
security definer
set search_path = public
as $function$
declare
  v_target numeric(14, 2);
  v_status text;
  v_contributed numeric(14, 2);
  v_goal_row public.goals%rowtype;
  v_member_id uuid;
begin
  select target_amount, status into v_target, v_status
  from public.goals
  where id = new.goal_id;

  if v_status is distinct from 'active' then
    return new;
  end if;

  select coalesce(sum(amount), 0) into v_contributed
  from public.goal_contributions
  where goal_id = new.goal_id;

  if v_contributed >= v_target then
    update public.goals set status = 'completed'
    where id = new.goal_id and status = 'active'
    returning * into v_goal_row;

    if v_goal_row.id is not null then
      -- Семейная цель — новость безопасна для всей семьи (никакой
      -- персональной детализации, кто сколько внёс, в самом уведомлении
      -- нет, ТЗ, п.16, 18). Личная цель — только владельцу (её вообще не
      -- видят остальные участники семьи, кроме admin через RLS, но
      -- уведомлять о ЧУЖОМ личном достижении никого, кроме владельца, не
      -- нужно — сознательный выбор, не расширяем видимость события сверх
      -- видимости самой цели).
      if v_goal_row.goal_type = 'family' then
        for v_member_id in
          select fm.user_id from public.family_members fm
          where fm.family_id = v_goal_row.family_id and fm.status = 'active'
        loop
          perform public.create_notification(
            v_member_id,
            v_goal_row.family_id,
            'goal_achieved',
            'Цель достигнута',
            'Цель «' || v_goal_row.title || '» достигнута.',
            jsonb_build_object('goal_id', v_goal_row.id),
            'goal_achieved:' || v_goal_row.id::text
          );
        end loop;
      else
        perform public.create_notification(
          v_goal_row.owner_user_id,
          v_goal_row.family_id,
          'goal_achieved',
          'Цель достигнута',
          'Цель «' || v_goal_row.title || '» достигнута.',
          jsonb_build_object('goal_id', v_goal_row.id),
          'goal_achieved:' || v_goal_row.id::text
        );
      end if;
    end if;
  end if;

  return new;
end;
$function$;

-- ═══════════════════ D.3) payment_due ═══════════════════

-- Расширение generate_due_planned_expenses() (Этап 13) — уведомление
-- создаётся ТОЛЬКО в ветке "новое напоминание" (v_existing_id is null),
-- которая сама уже дедуплицирована по (recurring_transaction_id,
-- planned_date) — то есть событие "наступил срок оплаты" физически не может
-- произойти дважды для одной и той же пары. Получатель — только
-- v_rec.user_id (ответственный за это правило), НИКОГДА не вся семья: тот
-- же принцип приватности, что и у самой таблицы recurring_transactions с
-- Этапа 16 (ипотечный платёж родителя не должен быть виден ребёнку). Само
-- создание transactions по-прежнему НИГДЕ не происходит — инвариант Этапа
-- 13 не тронут ни одной строкой.
create or replace function public.generate_due_planned_expenses()
returns jsonb
language plpgsql
security definer
set search_path = public
as $function$
declare
  v_user_id uuid := auth.uid();
  v_family_id uuid;
  v_can_manage_all boolean;
  v_rec record;
  v_title text;
  v_existing_id uuid;
  v_planned_id uuid;
  v_new_next_run_date date;
  v_results jsonb := '[]'::jsonb;
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  select fm.family_id into v_family_id
  from public.family_members fm
  where fm.user_id = v_user_id and fm.status = 'active'
  limit 1;

  if v_family_id is null then
    return '[]'::jsonb;
  end if;

  v_can_manage_all := public.get_family_role(v_family_id) in ('admin', 'adult');

  for v_rec in
    select rt.*
    from public.recurring_transactions rt
    where rt.family_id = v_family_id
      and rt.is_active = true
      and rt.next_run_date <= current_date
      and rt.start_date <= current_date
      and (rt.end_date is null or rt.end_date >= current_date)
      and (v_can_manage_all or rt.user_id = v_user_id)
    order by rt.next_run_date asc
    for update of rt
  loop
    select pe.id into v_existing_id
    from public.planned_expenses pe
    where pe.recurring_transaction_id = v_rec.id
      and pe.planned_date = v_rec.next_run_date
    limit 1;

    if v_existing_id is null then
      select c.name into v_title
      from public.categories c
      where c.id = v_rec.category_id;

      v_title := coalesce(
        v_title,
        nullif(btrim(v_rec.income_source), ''),
        case when v_rec.type = 'income' then 'Доход' else 'Расход' end
      );

      insert into public.planned_expenses (
        family_id, user_id, category_id, title, amount, planned_date, status, recurring_transaction_id
      )
      values (
        v_rec.family_id, v_rec.user_id, v_rec.category_id, v_title, v_rec.amount,
        v_rec.next_run_date, 'planned', v_rec.id
      )
      returning id into v_planned_id;

      v_results := v_results || jsonb_build_object(
        'plannedExpenseId', v_planned_id,
        'recurringTransactionId', v_rec.id,
        'plannedDate', v_rec.next_run_date,
        'title', v_title,
        'amount', v_rec.amount,
        'type', v_rec.type
      );

      -- payment_due — только для type='expense'; регулярный ДОХОД (например
      -- зарплата) — не "платёж, который нужно оплатить", уведомлять об этом
      -- в стилистике "Оплата сегодня" было бы вводящим в заблуждение (ТЗ,
      -- п.13, пример именно про исходящий платёж).
      if v_rec.type = 'expense' and v_rec.user_id is not null then
        perform public.create_notification(
          v_rec.user_id,
          v_rec.family_id,
          'payment_due',
          case when v_rec.next_run_date = current_date then 'Оплата сегодня' else 'Просроченный платёж' end,
          'Сегодня нужно оплатить: ' || v_title || ' — '
            || trim(to_char(v_rec.amount, 'FM999G999G999D00')) || ' ₽.',
          jsonb_build_object('recurring_transaction_id', v_rec.id, 'planned_expense_id', v_planned_id),
          'payment_due:' || v_planned_id::text
        );
      end if;
    end if;

    v_new_next_run_date := public.calculate_recurring_next_run_date(v_rec.next_run_date, v_rec.frequency, v_rec.interval_config);

    update public.recurring_transactions
    set next_run_date = v_new_next_run_date
    where id = v_rec.id;
  end loop;

  return v_results;
end;
$function$;

-- ═══════════════ E) Безопасные дефолты notification_prefs ═══════════════

update public.user_settings
set notification_prefs = jsonb_build_object(
  'payment_due', true,
  'budget_exceeded', true,
  'limit_reached', true,
  'goal_achieved', true,
  'family_invite', true
)
where notification_prefs = '{}'::jsonb;

create or replace function public.handle_new_auth_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $function$
begin
  insert into public.users (id, full_name, avatar_url)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', new.email, 'Новый пользователь'),
    new.raw_user_meta_data ->> 'avatar_url'
  );

  insert into public.user_settings (user_id, notification_prefs)
  values (
    new.id,
    jsonb_build_object(
      'payment_due', true,
      'budget_exceeded', true,
      'limit_reached', true,
      'goal_achieved', true,
      'family_invite', true
    )
  );

  return new;
end;
$function$;
