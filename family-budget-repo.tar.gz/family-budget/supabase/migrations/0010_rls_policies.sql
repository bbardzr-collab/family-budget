-- Этап 3: RLS-политики для всех 16 таблиц.
--
-- Общий принцип: RLS включена везде, по умолчанию — запрет (Postgres deny-by-default,
-- пока не создана политика на конкретную операцию). INSERT для notifications,
-- users и user_settings НЕ имеет прямой политики для authenticated — эти строки
-- создаются только SECURITY DEFINER триггерами/функциями (0006, 0007), которые
-- обходят RLS как владелец функции.
--
-- Ключевое требование ТЗ: CHILD НЕ должен получать неограниченный SELECT на
-- transactions — видит только свои операции. То же самое правило применено
-- к recurring_transactions и planned_expenses для консистентности.

-- ───────────────────────────── users ─────────────────────────────
alter table public.users enable row level security;

create policy users_select_self_or_family on public.users
  for select
  using (id = auth.uid() or public.shares_family_with(id));

create policy users_update_self on public.users
  for update
  using (id = auth.uid())
  with check (id = auth.uid());
-- INSERT/DELETE: нет политик — строки создаются только триггером handle_new_auth_user,
-- удаление профиля происходит каскадом от auth.users, не напрямую.

-- ───────────────────────────── families ─────────────────────────────
alter table public.families enable row level security;

create policy families_select_member on public.families
  for select
  using (public.is_family_member(id));

create policy families_insert_self on public.families
  for insert
  with check (created_by = auth.uid());

create policy families_update_admin on public.families
  for update
  using (public.is_family_admin(id))
  with check (public.is_family_admin(id));

create policy families_delete_admin on public.families
  for delete
  using (public.is_family_admin(id));

-- ─────────────────────────── family_members ───────────────────────────
alter table public.family_members enable row level security;

create policy family_members_select_family on public.family_members
  for select
  using (public.is_family_member(family_id));

create policy family_members_insert_admin on public.family_members
  for insert
  with check (public.is_family_admin(family_id));

create policy family_members_update_admin on public.family_members
  for update
  using (public.is_family_admin(family_id))
  with check (public.is_family_admin(family_id));

create policy family_members_delete_admin on public.family_members
  for delete
  using (public.is_family_admin(family_id));
-- Известный пробел (см. финальный отчёт Этапа 3): при создании семьи ещё нет
-- ни одного admin, поэтому bootstrap первой записи family_members должен идти
-- через SECURITY DEFINER RPC на Этапе 5 вместе с формой регистрации — не строится
-- сейчас, т.к. это бизнес-логика регистрации, запрещённая в Этапе 3.

-- ────────────────────────── family_invitations ──────────────────────────
alter table public.family_invitations enable row level security;

create policy family_invitations_select_admin on public.family_invitations
  for select
  using (public.is_family_admin(family_id));

create policy family_invitations_insert_admin on public.family_invitations
  for insert
  with check (public.is_family_admin(family_id) and invited_by = auth.uid());

create policy family_invitations_update_admin on public.family_invitations
  for update
  using (public.is_family_admin(family_id))
  with check (public.is_family_admin(family_id));

create policy family_invitations_delete_admin on public.family_invitations
  for delete
  using (public.is_family_admin(family_id));
-- Известный пробел (см. финальный отчёт Этапа 3): человек, переходящий по
-- приглашению, ещё не состоит в семье, поэтому найти приглашение по token
-- нельзя обычной SELECT-политикой (утекло бы существование/роли приглашений
-- любому запрашивающему). Публичный lookup по token сознательно НЕ реализован
-- здесь — это узкая SECURITY DEFINER RPC-функция для Этапа 5, вместе с
-- реальным UI принятия приглашения.

-- ────────────────────────────── categories ──────────────────────────────
alter table public.categories enable row level security;

create policy categories_select_family on public.categories
  for select
  using (public.is_family_member(family_id));

create policy categories_insert_adult_admin on public.categories
  for insert
  with check (public.get_family_role(family_id) in ('admin', 'adult'));

create policy categories_update_adult_admin on public.categories
  for update
  using (public.get_family_role(family_id) in ('admin', 'adult'))
  with check (public.get_family_role(family_id) in ('admin', 'adult'));

create policy categories_delete_adult_admin on public.categories
  for delete
  using (public.get_family_role(family_id) in ('admin', 'adult'));

-- ────────────────────────────── transactions ──────────────────────────────
-- КЛЮЧЕВОЕ требование ТЗ: CHILD видит только свои операции, не всю семью.
alter table public.transactions enable row level security;

create policy transactions_select_role_aware on public.transactions
  for select
  using (
    public.is_family_member(family_id)
    and (
      public.get_family_role(family_id) in ('admin', 'adult')
      or user_id = auth.uid()
    )
  );

create policy transactions_insert_own on public.transactions
  for insert
  with check (public.is_family_member(family_id) and user_id = auth.uid());

create policy transactions_update_own_or_admin on public.transactions
  for update
  using (user_id = auth.uid() or public.is_family_admin(family_id))
  with check (
    public.is_family_member(family_id)
    and (user_id = auth.uid() or public.is_family_admin(family_id))
  );

create policy transactions_delete_own_or_admin on public.transactions
  for delete
  using (user_id = auth.uid() or public.is_family_admin(family_id));

-- ──────────────────────────────── budgets ────────────────────────────────
alter table public.budgets enable row level security;

create policy budgets_select_family on public.budgets
  for select
  using (public.is_family_member(family_id));

create policy budgets_insert_admin on public.budgets
  for insert
  with check (public.is_family_admin(family_id));

create policy budgets_update_admin on public.budgets
  for update
  using (public.is_family_admin(family_id))
  with check (public.is_family_admin(family_id));

create policy budgets_delete_admin on public.budgets
  for delete
  using (public.is_family_admin(family_id));

-- ─────────────────────────── budget_categories ───────────────────────────
alter table public.budget_categories enable row level security;

create policy budget_categories_select_family on public.budget_categories
  for select
  using (
    exists (
      select 1 from public.budgets b
      where b.id = budget_id and public.is_family_member(b.family_id)
    )
  );

create policy budget_categories_insert_admin on public.budget_categories
  for insert
  with check (
    exists (
      select 1 from public.budgets b
      where b.id = budget_id and public.is_family_admin(b.family_id)
    )
  );

create policy budget_categories_update_admin on public.budget_categories
  for update
  using (
    exists (
      select 1 from public.budgets b
      where b.id = budget_id and public.is_family_admin(b.family_id)
    )
  )
  with check (
    exists (
      select 1 from public.budgets b
      where b.id = budget_id and public.is_family_admin(b.family_id)
    )
  );

create policy budget_categories_delete_admin on public.budget_categories
  for delete
  using (
    exists (
      select 1 from public.budgets b
      where b.id = budget_id and public.is_family_admin(b.family_id)
    )
  );

-- ───────────────────────────────── goals ─────────────────────────────────
-- personal-цель видна только владельцу и admin; family-цель видна всей семье.
alter table public.goals enable row level security;

create policy goals_select_visible on public.goals
  for select
  using (
    public.is_family_member(family_id)
    and (
      goal_type = 'family'
      or owner_user_id = auth.uid()
      or public.is_family_admin(family_id)
    )
  );

create policy goals_insert_own_or_family on public.goals
  for insert
  with check (
    public.is_family_member(family_id)
    and (
      (goal_type = 'personal' and owner_user_id = auth.uid())
      or (goal_type = 'family' and public.get_family_role(family_id) in ('admin', 'adult'))
    )
  );

create policy goals_update_owner_or_admin on public.goals
  for update
  using (owner_user_id = auth.uid() or public.is_family_admin(family_id))
  with check (
    public.is_family_member(family_id)
    and (owner_user_id = auth.uid() or public.is_family_admin(family_id))
  );

create policy goals_delete_owner_or_admin on public.goals
  for delete
  using (owner_user_id = auth.uid() or public.is_family_admin(family_id));

-- ─────────────────────────── goal_contributions ───────────────────────────
alter table public.goal_contributions enable row level security;

create policy goal_contributions_select_visible_goal on public.goal_contributions
  for select
  using (
    exists (
      select 1 from public.goals g
      where g.id = goal_id
        and public.is_family_member(g.family_id)
        and (g.goal_type = 'family' or g.owner_user_id = auth.uid() or public.is_family_admin(g.family_id))
    )
  );

create policy goal_contributions_insert_own on public.goal_contributions
  for insert
  with check (
    user_id = auth.uid()
    and exists (
      select 1 from public.goals g
      where g.id = goal_id
        and public.is_family_member(g.family_id)
        and (g.goal_type = 'family' or g.owner_user_id = auth.uid() or public.is_family_admin(g.family_id))
    )
  );

create policy goal_contributions_update_own_or_admin on public.goal_contributions
  for update
  using (
    user_id = auth.uid()
    or exists (select 1 from public.goals g where g.id = goal_id and public.is_family_admin(g.family_id))
  )
  with check (
    user_id = auth.uid()
    or exists (select 1 from public.goals g where g.id = goal_id and public.is_family_admin(g.family_id))
  );

create policy goal_contributions_delete_own_or_admin on public.goal_contributions
  for delete
  using (
    user_id = auth.uid()
    or exists (select 1 from public.goals g where g.id = goal_id and public.is_family_admin(g.family_id))
  );

-- ─────────────────────────────── planned_expenses ───────────────────────────────
-- Та же CHILD-осторожная логика, что и у transactions — для консистентности.
alter table public.planned_expenses enable row level security;

create policy planned_expenses_select_role_aware on public.planned_expenses
  for select
  using (
    public.is_family_member(family_id)
    and (
      public.get_family_role(family_id) in ('admin', 'adult')
      or user_id = auth.uid()
    )
  );

create policy planned_expenses_insert_family on public.planned_expenses
  for insert
  with check (
    public.is_family_member(family_id)
    and (user_id = auth.uid() or public.get_family_role(family_id) in ('admin', 'adult'))
  );

create policy planned_expenses_update_own_or_admin on public.planned_expenses
  for update
  using (user_id = auth.uid() or public.is_family_admin(family_id))
  with check (
    public.is_family_member(family_id)
    and (user_id = auth.uid() or public.is_family_admin(family_id))
  );

create policy planned_expenses_delete_own_or_admin on public.planned_expenses
  for delete
  using (user_id = auth.uid() or public.is_family_admin(family_id));

-- ─────────────────────────── recurring_transactions ───────────────────────────
-- Та же CHILD-осторожная логика, что и у transactions — по требованию ТЗ
-- ("консистентно на recurring_transactions").
alter table public.recurring_transactions enable row level security;

create policy recurring_transactions_select_role_aware on public.recurring_transactions
  for select
  using (
    public.is_family_member(family_id)
    and (
      public.get_family_role(family_id) in ('admin', 'adult')
      or user_id = auth.uid()
    )
  );

create policy recurring_transactions_insert_own on public.recurring_transactions
  for insert
  with check (public.is_family_member(family_id) and user_id = auth.uid());

create policy recurring_transactions_update_own_or_admin on public.recurring_transactions
  for update
  using (user_id = auth.uid() or public.is_family_admin(family_id))
  with check (
    public.is_family_member(family_id)
    and (user_id = auth.uid() or public.is_family_admin(family_id))
  );

create policy recurring_transactions_delete_own_or_admin on public.recurring_transactions
  for delete
  using (user_id = auth.uid() or public.is_family_admin(family_id));

-- ────────────────────────────── notifications ──────────────────────────────
alter table public.notifications enable row level security;

create policy notifications_select_own on public.notifications
  for select
  using (user_id = auth.uid());

create policy notifications_update_own on public.notifications
  for update
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

create policy notifications_delete_own on public.notifications
  for delete
  using (user_id = auth.uid());
-- INSERT: нет прямой политики для authenticated — уведомления создаются
-- системными SECURITY DEFINER функциями/Edge Functions (Этапы 8+), не с фронта.

-- ────────────────────────────── user_settings ──────────────────────────────
alter table public.user_settings enable row level security;

create policy user_settings_select_own on public.user_settings
  for select
  using (user_id = auth.uid());

create policy user_settings_update_own on public.user_settings
  for update
  using (user_id = auth.uid())
  with check (user_id = auth.uid());
-- INSERT: нет прямой политики — строка создаётся триггером handle_new_auth_user.

-- ────────────────────────────── family_settings ──────────────────────────────
alter table public.family_settings enable row level security;

create policy family_settings_select_family on public.family_settings
  for select
  using (public.is_family_member(family_id));

create policy family_settings_update_admin on public.family_settings
  for update
  using (public.is_family_admin(family_id))
  with check (public.is_family_admin(family_id));
-- INSERT: нет прямой политики — строка создаётся триггером handle_new_family.

-- ───────────────────────────── calendar_connections ─────────────────────────────
alter table public.calendar_connections enable row level security;

create policy calendar_connections_select_own on public.calendar_connections
  for select
  using (user_id = auth.uid());

create policy calendar_connections_insert_own on public.calendar_connections
  for insert
  with check (user_id = auth.uid() and public.is_family_member(family_id));

create policy calendar_connections_update_own on public.calendar_connections
  for update
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

create policy calendar_connections_delete_own on public.calendar_connections
  for delete
  using (user_id = auth.uid());
