-- Этап 3: устранение предупреждений security-advisor после первого прохода.

-- 1) set_updated_at не имел зафиксированного search_path (WARN: function_search_path_mutable).
create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- 2) Триггерные SECURITY DEFINER функции не должны быть напрямую вызываемы через
-- REST RPC ни анонимными, ни авторизованными пользователями — они предназначены
-- только для срабатывания по триггеру (auth.users / families INSERT).
revoke execute on function public.handle_new_auth_user() from public;
revoke execute on function public.handle_new_auth_user() from anon;
revoke execute on function public.handle_new_auth_user() from authenticated;

revoke execute on function public.handle_new_family() from public;
revoke execute on function public.handle_new_family() from anon;
revoke execute on function public.handle_new_family() from authenticated;

-- 3) RLS-хелперы должны быть доступны только авторизованным пользователям
-- (anon получил EXECUTE по умолчанию через PUBLIC при создании функции — убираем).
revoke execute on function public.is_family_member(uuid) from public;
revoke execute on function public.is_family_member(uuid) from anon;

revoke execute on function public.get_family_role(uuid) from public;
revoke execute on function public.get_family_role(uuid) from anon;

revoke execute on function public.is_family_admin(uuid) from public;
revoke execute on function public.is_family_admin(uuid) from anon;

revoke execute on function public.shares_family_with(uuid) from public;
revoke execute on function public.shares_family_with(uuid) from anon;
