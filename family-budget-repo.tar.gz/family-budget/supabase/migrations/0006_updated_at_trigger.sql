-- Этап 3: единая переиспользуемая функция-триггер для updated_at.
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;
comment on function public.set_updated_at() is
  'Единый триггер для всех таблиц с updated_at: проставляет now() перед UPDATE.';

-- Применяется буквально к списку таблиц из п.21 ТЗ: users, families, categories,
-- transactions, budgets, goals, planned_expenses, recurring_transactions,
-- user_settings, calendar_connections — 10 таблиц.

create trigger trg_users_updated_at
  before update on public.users
  for each row execute function public.set_updated_at();

create trigger trg_families_updated_at
  before update on public.families
  for each row execute function public.set_updated_at();

create trigger trg_categories_updated_at
  before update on public.categories
  for each row execute function public.set_updated_at();

create trigger trg_transactions_updated_at
  before update on public.transactions
  for each row execute function public.set_updated_at();

create trigger trg_budgets_updated_at
  before update on public.budgets
  for each row execute function public.set_updated_at();

create trigger trg_goals_updated_at
  before update on public.goals
  for each row execute function public.set_updated_at();

create trigger trg_planned_expenses_updated_at
  before update on public.planned_expenses
  for each row execute function public.set_updated_at();

create trigger trg_recurring_transactions_updated_at
  before update on public.recurring_transactions
  for each row execute function public.set_updated_at();

create trigger trg_user_settings_updated_at
  before update on public.user_settings
  for each row execute function public.set_updated_at();

create trigger trg_calendar_connections_updated_at
  before update on public.calendar_connections
  for each row execute function public.set_updated_at();
