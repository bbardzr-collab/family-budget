-- Этап 5: исправление реальной ошибки, найденной security review (п.39) —
-- НЕ скрываем, фиксируем отдельной миграцией.
--
-- cancel_family_invitation() в 0012_family_rpcs.sql устанавливал
-- status = 'revoked', но фактическое ограничение family_invitations_status_check
-- (наложено в 0003_align_schema_with_spec.sql, Этап 3) допускает только
-- ('pending', 'accepted', 'expired', 'cancelled') — без 'revoked'. Из-за этого
-- отмена приглашения падала с ошибкой "violates check constraint" вместо
-- того, чтобы отменить приглашение. Обнаружено при ручной проверке сценария
-- "ADMIN отменяет приглашение" (п.39: "может ли ADMIN отменить приглашение").
create or replace function public.cancel_family_invitation(p_invitation_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_family_id uuid;
  v_status text;
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  select fi.family_id, fi.status into v_family_id, v_status
  from public.family_invitations fi
  where fi.id = p_invitation_id;

  if v_family_id is null then
    raise exception 'INVITATION_NOT_FOUND';
  end if;

  if not public.is_family_admin(v_family_id) then
    raise exception 'FORBIDDEN';
  end if;

  if v_status <> 'pending' then
    raise exception 'INVITATION_NOT_PENDING';
  end if;

  update public.family_invitations
  set status = 'cancelled'
  where id = p_invitation_id;
end;
$$;
comment on function public.cancel_family_invitation(uuid) is
  'Только ADMIN своей семьи может отменить своё же pending-приглашение (Этап 5, п.19).
   status -> cancelled (см. family_invitations_status_check из 0003, Этап 3).';
