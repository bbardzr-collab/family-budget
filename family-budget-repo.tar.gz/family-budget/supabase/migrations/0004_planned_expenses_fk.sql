-- Этап 3: отложенный FK planned_expenses.recurring_transaction_id → recurring_transactions.id.
-- Добавляется отдельной миграцией, потому что recurring_transactions создаётся
-- позже planned_expenses в 0002_tables.sql (обе таблицы ссылаются друг на друга
-- по смыслу: recurring_transactions порождает напоминания-planned_expenses).
alter table public.planned_expenses
  add constraint planned_expenses_recurring_transaction_id_fkey
  foreign key (recurring_transaction_id)
  references public.recurring_transactions (id)
  on delete set null;
-- SET NULL: если правило автоматизации удалено, уже созданные план-записи не должны
-- исчезать — они просто теряют связь с породившим их правилом.
