-- Этап 3: включаем расширения, необходимые схеме.
-- pgcrypto даёт gen_random_uuid() для UUID PRIMARY KEY во всех таблицах.
create extension if not exists pgcrypto with schema extensions;
