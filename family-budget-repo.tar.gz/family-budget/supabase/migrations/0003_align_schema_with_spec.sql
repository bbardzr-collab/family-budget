-- Этап 3: приведение схемы к дословному тексту ТЗ.
--
-- Контекст: миграция 0002_tables.sql была написана по восстановленному описанию
-- схемы из проектного документа (после сжатия контекста диалога), до того как
-- в этот же диалог пришёл дословный текст ТЗ Этапа 3. Как только текст пришёл —
-- эта миграция приводит уже применённую схему к нему буквально, поле в поле.
-- Таблицы только что созданы и пусты, поэтому ALTER безопасен и без риска потери
-- данных.

-- family_members: в ТЗ нет updated_at (только created_at/joined_at).
alter table public.family_members drop column if exists updated_at;

-- family_invitations: в ТЗ нет updated_at; допустимые статусы —
-- pending/accepted/expired/cancelled (а не revoked).
alter table public.family_invitations drop column if exists updated_at;
alter table public.family_invitations drop constraint if exists family_invitations_status_check;
alter table public.family_invitations
  add constraint family_invitations_status_check
  check (status in ('pending', 'accepted', 'expired', 'cancelled'));

-- transactions: transaction_date — "DATE NOT NULL" без значения по умолчанию.
alter table public.transactions alter column transaction_date drop default;

-- goals: допустимые статусы — active/completed/cancelled (а не achieved).
alter table public.goals drop constraint if exists goals_status_check;
alter table public.goals
  add constraint goals_status_check
  check (status in ('active', 'completed', 'cancelled'));

-- budget_categories: в ТЗ нет updated_at (только created_at).
alter table public.budget_categories drop column if exists updated_at;

-- goal_contributions: в ТЗ нет created_at (роль метки времени играет contributed_at).
alter table public.goal_contributions drop column if exists created_at;

-- recurring_transactions: interval_config — "JSONB NULL", без принудительного
-- NOT NULL/DEFAULT.
alter table public.recurring_transactions alter column interval_config drop not null;
alter table public.recurring_transactions alter column interval_config drop default;

-- notifications: payload — "JSONB NULL", без принудительного NOT NULL/DEFAULT.
alter table public.notifications alter column payload drop not null;
alter table public.notifications alter column payload drop default;

-- user_settings: в ТЗ нет created_at; theme по умолчанию 'system' с допустимыми
-- значениями system/light/dark (updated_at оставляем — п.21 ТЗ явно требует
-- применить к user_settings общий updated_at-триггер, что подразумевает наличие
-- колонки; расцениваем это как более сильное и однозначное указание, чем
-- отсутствие updated_at в списке полей п.17).
alter table public.user_settings drop column if exists created_at;
alter table public.user_settings alter column theme set default 'system';
update public.user_settings set theme = 'system' where theme = 'light';
alter table public.user_settings
  add constraint user_settings_theme_check
  check (theme in ('system', 'light', 'dark'));

-- family_settings: в ТЗ нет created_at.
alter table public.family_settings drop column if exists created_at;

-- calendar_connections: в ТЗ есть updated_at (пропущен в первой версии миграции —
-- добавляем); статус по умолчанию 'active', допустимые значения
-- active/revoked/error (а не disconnected/connected).
alter table public.calendar_connections
  add column if not exists updated_at timestamptz not null default now();
alter table public.calendar_connections drop constraint if exists calendar_connections_status_check;
update public.calendar_connections set status = 'active' where status = 'disconnected';
alter table public.calendar_connections alter column status set default 'active';
alter table public.calendar_connections
  add constraint calendar_connections_status_check
  check (status in ('active', 'revoked', 'error'));
