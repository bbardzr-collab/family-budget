-- Этап 10: месячные бюджеты — усиление ограничений, расширение прав до
-- adult+admin, серверная сводка бюджета месяца.
--
-- Таблицы budgets/budget_categories уже существуют с Этапа 3 (миграция
-- 0002) вместе с базовыми RLS-политиками (миграция 0010) — новой системы
-- бюджетов здесь не создаётся, только точечные исправления и один RPC для
-- агрегации (по прямому указанию ТЗ Этапа 10).

-- ─────────────────────────────────────────────────────────────────────────
-- 1) limit_amount > 0 (ТЗ, п.11, 27): "если категория добавлена в
-- budget_categories, у неё должен быть корректный limit_amount > 0" — до
-- этой миграции CHECK допускал 0 (limit_amount >= 0, миграция 0002).
-- "Категория без лимита" не должна существовать как строка вообще —
-- пользователь просто не добавляет категорию в бюджет, если не хочет её
-- контролировать (ТЗ, п.11).
-- ─────────────────────────────────────────────────────────────────────────
alter table public.budget_categories drop constraint budget_categories_limit_amount_check;
alter table public.budget_categories add constraint budget_categories_limit_amount_check check (limit_amount > 0);

-- ─────────────────────────────────────────────────────────────────────────
-- 2) Роли: ADMIN и ADULT могут создавать/изменять/удалять бюджет, CHILD —
-- не может (ТЗ, п.21). До этой миграции INSERT/UPDATE/DELETE на budgets и
-- budget_categories были доступны только is_family_admin(...) (миграция
-- 0010) — то есть даже ADULT не мог управлять бюджетом, что не совпадает
-- с этим этапом. Проверка роли обязана быть на уровне БД (ТЗ, п.21) — не
-- только в UI.
--
-- Решение — минимально необходимое (ТЗ, п.21: "если ролевая система ещё не
-- полностью подготовлена для этого ограничения, реализуй минимально
-- необходимую серверную проверку"): переиспользуем уже существующий
-- SECURITY DEFINER хелпер get_family_role(...) (миграция 0009) и инлайним
-- `get_family_role(family_id) in ('admin', 'adult')` — ровно тот же паттерн,
-- что уже применён для categories_insert_adult_admin/update/delete
-- (миграция 0010/0017). Отдельная новая SECURITY DEFINER функция-хелпер не
-- нужна — get_family_role уже возвращает нужное значение.
--
-- SELECT-политики (budgets_select_family/budget_categories_select_family)
-- НЕ меняются — бюджет виден всем активным членам семьи, включая CHILD
-- (только для чтения); это то же самое решение, что уже принято для
-- categories_select_family/transactions (просмотр без ограничения роли,
-- изменение — с ограничением).
-- ─────────────────────────────────────────────────────────────────────────

drop policy if exists budgets_insert_admin on public.budgets;
drop policy if exists budgets_update_admin on public.budgets;
drop policy if exists budgets_delete_admin on public.budgets;

create policy budgets_insert_adult_admin on public.budgets
  for insert
  with check (public.get_family_role(family_id) in ('admin', 'adult'));

create policy budgets_update_adult_admin on public.budgets
  for update
  using (public.get_family_role(family_id) in ('admin', 'adult'))
  with check (public.get_family_role(family_id) in ('admin', 'adult'));

create policy budgets_delete_adult_admin on public.budgets
  for delete
  using (public.get_family_role(family_id) in ('admin', 'adult'));

drop policy if exists budget_categories_insert_admin on public.budget_categories;
drop policy if exists budget_categories_update_admin on public.budget_categories;
drop policy if exists budget_categories_delete_admin on public.budget_categories;

create policy budget_categories_insert_adult_admin on public.budget_categories
  for insert
  with check (
    exists (
      select 1 from public.budgets b
      where b.id = budget_id and public.get_family_role(b.family_id) in ('admin', 'adult')
    )
  );

create policy budget_categories_update_adult_admin on public.budget_categories
  for update
  using (
    exists (
      select 1 from public.budgets b
      where b.id = budget_id and public.get_family_role(b.family_id) in ('admin', 'adult')
    )
  )
  with check (
    exists (
      select 1 from public.budgets b
      where b.id = budget_id and public.get_family_role(b.family_id) in ('admin', 'adult')
    )
  );

create policy budget_categories_delete_adult_admin on public.budget_categories
  for delete
  using (
    exists (
      select 1 from public.budgets b
      where b.id = budget_id and public.get_family_role(b.family_id) in ('admin', 'adult')
    )
  );

-- ─────────────────────────────────────────────────────────────────────────
-- 3) get_monthly_budget_summary(p_period_month date) — серверная сводка
-- бюджета месяца (ТЗ, п.13, 25-27): бюджет + фактические расходы (общие и
-- по каждой категории) считаются одним запросом в Postgres, без загрузки
-- транзакций месяца на клиент. SECURITY INVOKER, как get_dashboard_summary
-- (0015) и get_transactions_page/_totals (0019) — функция выполняется под
-- правами вызывающего, поэтому RLS на transactions (приватность CHILD),
-- budgets/budget_categories/categories применяется к запросам ВНУТРИ функции
-- ровно так же, как и к прямому SELECT с клиента. family_id НЕ принимается
-- параметром — определяется только через family_members по auth.uid(),
-- поэтому ни один входной параметр не может быть использован, чтобы
-- получить бюджет чужой семьи.
--
-- Возвращает jsonb (а не table/setof) — единственный результат на вызов,
-- со вложенным массивом категорий; это проще замаппить на клиенте одним
-- объектом, чем разворачивать в N строк с повторяющимися полями budget.*.
-- ─────────────────────────────────────────────────────────────────────────

create or replace function public.get_monthly_budget_summary(p_period_month date)
returns jsonb
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_family_id uuid;
  v_period_start date := date_trunc('month', p_period_month)::date;
  v_period_end date := (date_trunc('month', p_period_month) + interval '1 month' - interval '1 day')::date;
  v_budget_id uuid;
  v_budget_total numeric(14, 2);
  v_total_spent numeric(14, 2);
  v_categories jsonb;
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  select fm.family_id into v_family_id
  from public.family_members fm
  where fm.user_id = v_user_id and fm.status = 'active'
  limit 1;

  if v_family_id is null then
    return jsonb_build_object(
      'budget', null,
      'totalSpent', 0,
      'totalRemaining', 0,
      'totalPercent', null,
      'categories', '[]'::jsonb
    );
  end if;

  select b.id, b.total_amount
  into v_budget_id, v_budget_total
  from public.budgets b
  where b.family_id = v_family_id and b.period_month = v_period_start;

  -- Бюджет на этот месяц не создан (ТЗ, п.23, 29) — честный пустой результат,
  -- а не автосоздание "нулевого" бюджета.
  if v_budget_id is null then
    return jsonb_build_object(
      'budget', null,
      'totalSpent', 0,
      'totalRemaining', 0,
      'totalPercent', null,
      'categories', '[]'::jsonb
    );
  end if;

  -- Фактические расходы месяца (ТЗ, п.8, 15): только type='expense', по
  -- transaction_date (не created_at), строго в границах календарного месяца
  -- бюджета — работает одинаково для текущего, прошлого и будущего месяца
  -- (ТЗ, п.30-32).
  select coalesce(sum(t.amount), 0)
  into v_total_spent
  from public.transactions t
  where t.family_id = v_family_id
    and t.type = 'expense'
    and t.transaction_date >= v_period_start
    and t.transaction_date <= v_period_end;

  -- Лимиты по категориям (ТЗ, п.9, 12-14) — LEFT JOIN LATERAL считает расход
  -- КАЖДОЙ категории отдельным агрегатом в том же запросе (без N+1 с
  -- клиента). Отключённые категории (is_active=false) не исключаются из
  -- budget_categories — исторический лимит показывается по-прежнему (ТЗ,
  -- п.12), просто c isActive=false, чтобы клиент показал пометку "Выключена".
  select coalesce(
    jsonb_agg(
      jsonb_build_object(
        'id', bc.id,
        'categoryId', bc.category_id,
        'categoryName', c.name,
        'categoryIcon', c.icon,
        'categoryType', c.type,
        'limitAmount', bc.limit_amount,
        'spentAmount', coalesce(cat_spent.spent, 0),
        'remainingAmount', bc.limit_amount - coalesce(cat_spent.spent, 0),
        -- limit_amount > 0 гарантирован CHECK-ограничением (см. п.1 выше),
        -- но защитная проверка на 0 (ТЗ, п.27) оставлена как явный guard,
        -- а не полагается только на ограничение схемы.
        'percent', case when bc.limit_amount > 0
          then round(coalesce(cat_spent.spent, 0) / bc.limit_amount * 100, 1)
          else null
        end,
        'isActive', c.is_active
      )
      order by c.name
    ),
    '[]'::jsonb
  )
  into v_categories
  from public.budget_categories bc
  join public.categories c on c.id = bc.category_id
  left join lateral (
    select sum(t.amount) as spent
    from public.transactions t
    where t.family_id = v_family_id
      and t.type = 'expense'
      and t.category_id = bc.category_id
      and t.transaction_date >= v_period_start
      and t.transaction_date <= v_period_end
  ) cat_spent on true
  where bc.budget_id = v_budget_id;

  return jsonb_build_object(
    'budget', jsonb_build_object('id', v_budget_id, 'periodMonth', v_period_start, 'totalAmount', v_budget_total),
    'totalSpent', v_total_spent,
    'totalRemaining', v_budget_total - v_total_spent,
    'totalPercent', case when v_budget_total > 0 then round(v_total_spent / v_budget_total * 100, 1) else null end,
    'categories', v_categories
  );
end;
$$;

-- См. STAGE6_REPORT.md/architecture-v1.md — в этом Supabase-проекте `anon`
-- получает EXECUTE не только через псевдо-роль PUBLIC, поэтому обязательна
-- отдельная строка revoke ... from anon.
revoke all on function public.get_monthly_budget_summary(date) from public;
revoke execute on function public.get_monthly_budget_summary(date) from anon;
grant execute on function public.get_monthly_budget_summary(date) to authenticated;
