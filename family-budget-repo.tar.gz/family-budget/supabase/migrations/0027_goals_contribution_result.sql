-- Этап 11 — add_goal_contribution должен сообщить фронту, если ИМЕННО этот
-- взнос завершил цель (ТЗ, п.18: "Покажи пользователю: Цель достигнута!"),
-- без отдельного запроса статуса цели после мутации. AFTER INSERT триггер
-- trg_goal_check_auto_complete (миграция 0025) выполняется синхронно ДО
-- того, как управление возвращается в тело этой функции после INSERT —
-- поэтому достаточно просто перечитать status цели следующей строкой.
--
-- Меняем возвращаемый тип (uuid -> jsonb), поэтому явный drop перед create.
drop function if exists public.add_goal_contribution(uuid, numeric, text, date);

create function public.add_goal_contribution(
  p_goal_id uuid,
  p_amount numeric,
  p_comment text,
  p_contributed_at date
)
returns jsonb
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_status text;
  v_id uuid;
  v_new_status text;
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  select status into v_status from public.goals where id = p_goal_id;

  if v_status is null then
    raise exception 'GOAL_NOT_FOUND';
  end if;

  if v_status <> 'active' then
    raise exception 'GOAL_NOT_ACTIVE';
  end if;

  insert into public.goal_contributions (goal_id, user_id, amount, comment, contributed_at)
  values (p_goal_id, v_user_id, p_amount, nullif(trim(p_comment), ''), coalesce(p_contributed_at, current_date))
  returning id into v_id;

  -- trg_goal_check_auto_complete уже отработал к этому моменту (AFTER INSERT
  -- того же INSERT-запроса выше) — просто читаем итоговый статус.
  select status into v_new_status from public.goals where id = p_goal_id;

  return jsonb_build_object(
    'id', v_id,
    'goalCompleted', (v_status = 'active' and v_new_status = 'completed')
  );
end;
$$;

revoke all on function public.add_goal_contribution(uuid, numeric, text, date) from public;
revoke execute on function public.add_goal_contribution(uuid, numeric, text, date) from anon;
grant execute on function public.add_goal_contribution(uuid, numeric, text, date) to authenticated;
