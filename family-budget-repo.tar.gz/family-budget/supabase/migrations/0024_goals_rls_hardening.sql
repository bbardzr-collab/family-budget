-- Этап 11 — аудит существующих RLS-политик goals/goal_contributions
-- (созданы предварительно в базовой схеме, миграции 0002/0009/0010, ещё
-- до того, как ТЗ Этапа 11 было известно в деталях). Найдено и здесь
-- исправляется:
--
-- 1) ADULT не мог редактировать/удалять СЕМЕЙНЫЕ цели (owner_user_id IS
--    NULL у goal_type='family'), только ADMIN — старые
--    goals_update_owner_or_admin/goals_delete_owner_or_admin проверяли
--    только `owner_user_id = auth.uid() OR is_family_admin(family_id)`.
--    Это противоречит ТЗ п.26: "adult может управлять семейными целями"
--    (наравне с admin). Личные цели по-прежнему редактирует/удаляет
--    только владелец или admin — эта часть поведения не менялась.
--
-- 2) Личную цель можно было создать только с owner_user_id = auth.uid()
--    (ТЗ п.3, 8, 9: "пользователь может выбрать владельца из членов
--    текущей семьи" — например, "Велосипед ребёнку" создаёт родитель, а
--    не сам ребёнок). Новая политика позволяет ADMIN/ADULT указать
--    владельцем любого участника — проверка, что владелец из ТОЙ ЖЕ
--    семьи, реализована отдельным триггером (см. миграцию
--    goals_owner_and_autocomplete_triggers), а не здесь, потому что
--    сверка "owner_user_id принадлежит family_id" требует JOIN на
--    family_members по двум столбцам сразу — надёжнее и нагляднее в
--    отдельной функции, которая гарантированно вызывается при любом
--    пути записи (в т.ч. в обход RLS для service_role/postgres).
--
-- 3) Пополнение (goal_contributions INSERT) не проверяло, что цель ещё
--    активна — ТЗ п.22, 24 требуют скрывать «Пополнить» в UI для
--    cancelled/completed, но UI — не граница безопасности. Добавлена
--    проверка `g.status = 'active'` прямо в WITH CHECK.

-- ─── goals: INSERT ───
drop policy if exists goals_insert_own_or_family on public.goals;
create policy goals_insert_own_or_family
on public.goals
for insert
with check (
  is_family_member(family_id)
  and (
    (goal_type = 'family' and get_family_role(family_id) in ('admin', 'adult'))
    or (goal_type = 'personal' and (
      owner_user_id = auth.uid()
      or get_family_role(family_id) in ('admin', 'adult')
    ))
  )
);

-- ─── goals: UPDATE ───
drop policy if exists goals_update_owner_or_admin on public.goals;
create policy goals_update_owner_or_admin
on public.goals
for update
using (
  owner_user_id = auth.uid()
  or is_family_admin(family_id)
  or (goal_type = 'family' and get_family_role(family_id) = 'adult')
)
with check (
  is_family_member(family_id)
  and (
    owner_user_id = auth.uid()
    or is_family_admin(family_id)
    or (goal_type = 'family' and get_family_role(family_id) = 'adult')
    -- смена personal -> family (owner_user_id становится NULL) тем же
    -- ADULT/ADMIN, кто мог редактировать семейные цели, покрывается веткой
    -- выше через новое значение goal_type; смена family -> personal с
    -- назначением owner_user_id = другой участник требует admin/adult —
    -- обеспечивается тем, что goal_type в новой строке уже 'personal', а
    -- owner_user_id != auth.uid() не проходит первую ветку, только
    -- is_family_admin — то есть ADULT (не admin) не может назначить
    -- personal-цель НЕ на себя при редактировании семейной цели в личную;
    -- это осознанное ограничение (управление персональным владением —
    -- прерогатива admin либо самого владельца, см. обоснование выше).
  )
);

-- ─── goals: DELETE ───
drop policy if exists goals_delete_owner_or_admin on public.goals;
create policy goals_delete_owner_or_admin
on public.goals
for delete
using (
  owner_user_id = auth.uid()
  or is_family_admin(family_id)
  or (goal_type = 'family' and get_family_role(family_id) = 'adult')
);

-- ─── goal_contributions: INSERT — цель должна быть активной ───
drop policy if exists goal_contributions_insert_own on public.goal_contributions;
create policy goal_contributions_insert_own
on public.goal_contributions
for insert
with check (
  user_id = auth.uid()
  and exists (
    select 1 from public.goals g
    where g.id = goal_contributions.goal_id
      and is_family_member(g.family_id)
      and g.status = 'active'
      and (
        g.goal_type = 'family'
        or g.owner_user_id = auth.uid()
        or is_family_admin(g.family_id)
      )
  )
);
