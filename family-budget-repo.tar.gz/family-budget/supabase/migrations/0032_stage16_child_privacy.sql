-- Этап 16 — приватность CHILD на уровне Supabase/PostgreSQL/RLS/RPC (ТЗ,
-- целиком). Не создаёт новых таблиц, не меняет существующую систему ролей
-- (Этап 15) — только точечно исправляет то, что аудит нашёл несогласованным
-- с целевой моделью приватности, и переиспользует уже существующие с Этапа 3
-- таблицы/RLS-хелперы (is_family_member/get_family_role/is_family_admin).
--
-- ═══════════════════════════════════════════════════════════════════════
-- ЧТО АУДИТ УЖЕ НАШЁЛ КОРРЕКТНЫМ И НЕ МЕНЯЕТСЯ (ТЗ, п.4-5, 9-10, 12-13):
-- ═══════════════════════════════════════════════════════════════════════
-- transactions_select_role_aware / planned_expenses_select_role_aware /
-- recurring_transactions_select_role_aware (миграция 0010) — CHILD УЖЕ
-- видит только свои строки (user_id = auth.uid()), ADMIN/ADULT — всю семью,
-- с Этапа 3. Это ровно целевая модель ТЗ п.4-5, 9-10 — RLS здесь НЕ
-- переписывается, а только подтверждается живым тестом ниже.
-- budgets_insert/update/delete_adult_admin, budget_categories_*_adult_admin
-- (миграция 0021) — CHILD уже структурно не может создавать/менять/удалять
-- бюджет (ТЗ п.12) — тоже без изменений, только подтверждается тестом.
-- categories_select_family — категории не приватны (ТЗ п.13) — без изменений.
--
-- ═══════════════════════════════════════════════════════════════════════
-- ЧТО РЕАЛЬНО МЕНЯЕТСЯ И ПОЧЕМУ:
-- ═══════════════════════════════════════════════════════════════════════
--
-- (A) goal_contributions: RLS ослаблена только для CHILD на family-целях.
--     До этой миграции goal_contributions_select_visible_goal показывала
--     ЛЮБОМУ участнику видимой цели ВСЕ взносы (включая user_id/amount/
--     comment каждого) — для family-целей это означало, что CHILD прямым
--     REST-запросом `supabase.from('goal_contributions').select('*')` мог
--     увидеть, кто из взрослых сколько внёс (ТЗ п.7-8: "нельзя раскрывать
--     ... кто сколько внёс, если это идентифицирует финансовую активность
--     взрослого"). Новая политика: CHILD видит ТОЛЬКО свои собственные
--     строки (user_id = auth.uid()) на family-целях; ADMIN — всё; ADULT —
--     всё на family-целях (без изменений); владелец personal-цели — все
--     взносы своей цели (в т.ч. добавленные admin'ом от его имени).
--
-- (B) get_goal_summary / get_goals_list: SECURITY INVOKER -> SECURITY
--     DEFINER. Причина СИММЕТРИЧНА пункту (C) ниже: contributedAmount/
--     percent должны быть суммой ВСЕХ взносов цели (иначе прогресс
--     family-цели для CHILD после пункта (A) стал бы занижен — CHILD видел
--     бы только свою долю, что противоречит ТЗ п.7: "показывать... общий
--     прогресс"). Раз функция теперь сознательно обходит RLS ради
--     корректного агрегата — она ОБЯЗАНА сама воспроизвести проверку
--     видимости цели (which goals_select_visible делала раньше) и сама
--     решить, кому показывать детализацию contributions (ТЗ п.18: "RPC не
--     должен доверять параметрам, должен проверять auth.uid()/membership/
--     role", "не возвращать лишние колонки").
--
-- (C) get_dashboard_summary / get_monthly_budget_summary /
--     get_analytics_summary / get_analytics_timeseries /
--     get_analytics_categories / get_analytics_income_sources: SECURITY
--     INVOKER -> SECURITY DEFINER. Все шесть и раньше, и сейчас возвращают
--     ИСКЛЮЧИТЕЛЬНО агрегаты (суммы/группировки по категории/времени/
--     источнику дохода) — НИ ОДНА никогда не возвращала отдельные операции
--     или разбивку по user_id. Проблема была в обратную сторону: будучи
--     INVOKER, они полагались на RLS transactions_select_role_aware, которая
--     для CHILD ограничивает исходные строки только его собственными
--     операциями — то есть "общий доход/расход семьи" для CHILD ФАКТИЧЕСКИ
--     считался только по его личным операциям, что прямо противоречит ТЗ
--     п.3 ("ребёнок может видеть общий доход/расход/баланс СЕМЬИ") и п.11-12
--     ("бюджет/аналитика — family_aggregate для CHILD"). Перевод в SECURITY
--     DEFINER заставляет их считать агрегат по ВСЕЙ семье для ЛЮБОЙ роли —
--     семья по-прежнему определяется исключительно через family_members по
--     auth.uid() (family_id никогда не принимается параметром — структурная
--     защита от чужой семьи не изменилась), а наружу отдаются только суммы,
--     что безопасно для CHILD по определению целевой модели.
--     Тела функций (сама агрегирующая логика/фильтры/период) НЕ меняются —
--     меняется только `security invoker` -> `security definer` и, для
--     get_dashboard_summary, замена IN-подзапроса на однозначный v_family_id
--     (семантически эквивалентно: у пользователя не может быть больше одной
--     активной семьи, частичный уникальный индекс с Этапа 5).
--
-- (D) family_settings.child_visibility — заполняется безопасным MVP-
--     дефолтом (структура — буквально из ТЗ п.15) вместо пустого '{}'.
--     Используется как ДОКУМЕНТИРОВАННАЯ основа политики (ТЗ п.15: "не
--     создавай сложную систему настроек без необходимости") — сама модель
--     приватности реализована структурно через RLS/RPC выше (а не читается
--     динамически из этого JSON построчно в каждой функции), но колонка
--     отражает реальное поведение и готова к тому, чтобы будущий этап сделал
--     её реально настраиваемой. WRITE remains admin-only (family_settings_
--     update_admin, миграция 0010, без изменений) — ADULT/CHILD структурно
--     не могут её изменить ни через REST, ни через RPC (RPC для этого нет
--     вообще), что и требует ТЗ п.16.

-- ─────────────────────────────────────────────────────────────────────────
-- (A) goal_contributions: CHILD на family-целях видит только свои взносы.
-- ─────────────────────────────────────────────────────────────────────────
drop policy if exists goal_contributions_select_visible_goal on public.goal_contributions;

create policy goal_contributions_select_visible_goal on public.goal_contributions
  for select
  using (
    -- Собственный взнос виден всегда, независимо от роли и типа цели.
    user_id = auth.uid()
    or exists (
      select 1 from public.goals g
      where g.id = goal_contributions.goal_id
        and public.is_family_member(g.family_id)
        and (
          public.is_family_admin(g.family_id)
          or g.owner_user_id = auth.uid()
          or (g.goal_type = 'family' and public.get_family_role(g.family_id) = 'adult')
        )
    )
  );

-- ─────────────────────────────────────────────────────────────────────────
-- (B) get_goal_summary — SECURITY DEFINER, с ручной проверкой видимости
-- цели и ролевой редакцией детализации взносов на family-целях.
-- ─────────────────────────────────────────────────────────────────────────
create or replace function public.get_goal_summary(p_goal_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_role text;
  v_goal record;
  v_contributed numeric(14, 2);
  v_contributions jsonb;
  v_full_detail boolean;
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  select g.id, g.family_id, g.goal_type, g.owner_user_id, owner.full_name as owner_name,
         g.title, g.icon, g.target_amount, g.target_date, g.status, g.created_at
  into v_goal
  from public.goals g
  left join public.users owner on owner.id = g.owner_user_id
  where g.id = p_goal_id;

  if v_goal.id is null then
    return null;
  end if;

  -- SECURITY DEFINER обходит RLS goals_select_visible — видимость цели
  -- (та же формула, что в этой политике) проверяется здесь вручную, иначе
  -- любой пользователь смог бы получить summary чужой/невидимой цели.
  select fm.role into v_role
  from public.family_members fm
  where fm.user_id = v_user_id and fm.family_id = v_goal.family_id and fm.status = 'active';

  if v_role is null then
    return null;
  end if;

  if not (v_goal.goal_type = 'family' or v_goal.owner_user_id = v_user_id or v_role = 'admin') then
    return null;
  end if;

  select coalesce(sum(gc.amount), 0) into v_contributed
  from public.goal_contributions gc
  where gc.goal_id = p_goal_id;

  -- Полная история взносов — admin'у, владельцу личной цели (это его же
  -- данные) и adult'у на family-цели (без изменений). CHILD на family-цели
  -- получает только свои строки ниже (Этап 16, п.7-8) — прогресс/сумма при
  -- этом остаются ПОЛНЫМИ (v_contributed выше), редактируется только список.
  v_full_detail := (
    v_role = 'admin'
    or v_goal.owner_user_id = v_user_id
    or (v_goal.goal_type = 'family' and v_role = 'adult')
  );

  select coalesce(
    jsonb_agg(
      jsonb_build_object(
        'id', gc.id,
        'amount', gc.amount,
        'comment', gc.comment,
        'contributedAt', gc.contributed_at,
        'userId', gc.user_id,
        'userName', u.full_name
      )
      order by gc.contributed_at desc, gc.id desc
    ),
    '[]'::jsonb
  )
  into v_contributions
  from public.goal_contributions gc
  left join public.users u on u.id = gc.user_id
  where gc.goal_id = p_goal_id
    and (v_full_detail or gc.user_id = v_user_id);

  return jsonb_build_object(
    'goal', jsonb_build_object(
      'id', v_goal.id,
      'familyId', v_goal.family_id,
      'goalType', v_goal.goal_type,
      'ownerUserId', v_goal.owner_user_id,
      'ownerName', v_goal.owner_name,
      'title', v_goal.title,
      'icon', v_goal.icon,
      'targetAmount', v_goal.target_amount,
      'targetDate', v_goal.target_date,
      'status', v_goal.status,
      'createdAt', v_goal.created_at
    ),
    'contributedAmount', v_contributed,
    'remainingAmount', greatest(v_goal.target_amount - v_contributed, 0),
    'percent', least(round(v_contributed / v_goal.target_amount * 100, 1), 100),
    'contributions', v_contributions
  );
end;
$$;

revoke all on function public.get_goal_summary(uuid) from public;
revoke execute on function public.get_goal_summary(uuid) from anon;
grant execute on function public.get_goal_summary(uuid) to authenticated;

-- ─────────────────────────────────────────────────────────────────────────
-- (B) get_goals_list — SECURITY DEFINER, с ручным воспроизведением
-- видимости целей (personal чужого участника больше не должна утечь).
-- ─────────────────────────────────────────────────────────────────────────
create or replace function public.get_goals_list()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_family_id uuid;
  v_role text;
  v_goals jsonb;
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  select fm.family_id, fm.role into v_family_id, v_role
  from public.family_members fm
  where fm.user_id = v_user_id and fm.status = 'active'
  limit 1;

  if v_family_id is null then
    return '[]'::jsonb;
  end if;

  select coalesce(
    jsonb_agg(
      jsonb_build_object(
        'id', g.id,
        'goalType', g.goal_type,
        'ownerUserId', g.owner_user_id,
        'ownerName', owner.full_name,
        'title', g.title,
        'icon', g.icon,
        'targetAmount', g.target_amount,
        'targetDate', g.target_date,
        'status', g.status,
        'contributedAmount', coalesce(contrib.total, 0),
        'remainingAmount', greatest(g.target_amount - coalesce(contrib.total, 0), 0),
        'percent', least(round(coalesce(contrib.total, 0) / g.target_amount * 100, 1), 100),
        'createdAt', g.created_at
      )
    ),
    '[]'::jsonb
  )
  into v_goals
  from public.goals g
  left join public.users owner on owner.id = g.owner_user_id
  left join lateral (
    select sum(gc.amount) as total from public.goal_contributions gc where gc.goal_id = g.id
  ) contrib on true
  where g.family_id = v_family_id
    -- Этап 16: SECURITY DEFINER обходит RLS goals_select_visible — без этого
    -- явного условия личные цели ДРУГИХ участников (включая другого CHILD)
    -- попали бы в список у кого угодно — ровно утечка, которую ТЗ п.7
    -- запрещает ("не видит личные цели других детей/взрослых").
    and (g.goal_type = 'family' or g.owner_user_id = v_user_id or v_role = 'admin');

  return v_goals;
end;
$$;

revoke all on function public.get_goals_list() from public;
revoke execute on function public.get_goals_list() from anon;
grant execute on function public.get_goals_list() to authenticated;

-- ─────────────────────────────────────────────────────────────────────────
-- (C) get_dashboard_summary — SECURITY DEFINER, семья по-прежнему только
-- через family_members+auth.uid(), family_id не параметр.
-- ─────────────────────────────────────────────────────────────────────────
create or replace function public.get_dashboard_summary(
  p_period_start date,
  p_period_end date
)
returns table (
  income numeric(14, 2),
  expenses numeric(14, 2),
  balance numeric(14, 2),
  period_start date,
  period_end date
)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_family_id uuid;
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  if p_period_start is null or p_period_end is null or p_period_start > p_period_end then
    raise exception 'INVALID_PERIOD';
  end if;

  select fm.family_id into v_family_id
  from public.family_members fm
  where fm.user_id = v_user_id and fm.status = 'active'
  limit 1;

  return query
    select
      coalesce(sum(t.amount) filter (where t.type = 'income'), 0)::numeric(14, 2) as income,
      coalesce(sum(t.amount) filter (where t.type = 'expense'), 0)::numeric(14, 2) as expenses,
      (
        coalesce(sum(t.amount) filter (where t.type = 'income'), 0)
        - coalesce(sum(t.amount) filter (where t.type = 'expense'), 0)
      )::numeric(14, 2) as balance,
      p_period_start as period_start,
      p_period_end as period_end
    from public.transactions t
    where v_family_id is not null
      and t.family_id = v_family_id
      and t.transaction_date >= p_period_start
      and t.transaction_date <= p_period_end;
end;
$$;

revoke all on function public.get_dashboard_summary(date, date) from public;
revoke execute on function public.get_dashboard_summary(date, date) from anon;
grant execute on function public.get_dashboard_summary(date, date) to authenticated;

-- ─────────────────────────────────────────────────────────────────────────
-- (C) get_monthly_budget_summary — тело без изменений (уже явно фильтровало
-- по v_family_id, а не полагалось на RLS-подзапрос), меняется только режим.
-- ─────────────────────────────────────────────────────────────────────────
create or replace function public.get_monthly_budget_summary(p_period_month date)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_family_id uuid;
  v_period_start date := date_trunc('month', p_period_month)::date;
  v_period_end date := (date_trunc('month', p_period_month) + interval '1 month' - interval '1 day')::date;
  v_budget_id uuid;
  v_budget_total numeric(14, 2);
  v_total_spent numeric(14, 2);
  v_categories jsonb;
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  select fm.family_id into v_family_id
  from public.family_members fm
  where fm.user_id = v_user_id and fm.status = 'active'
  limit 1;

  if v_family_id is null then
    return jsonb_build_object(
      'budget', null,
      'totalSpent', 0,
      'totalRemaining', 0,
      'totalPercent', null,
      'categories', '[]'::jsonb
    );
  end if;

  select b.id, b.total_amount
  into v_budget_id, v_budget_total
  from public.budgets b
  where b.family_id = v_family_id and b.period_month = v_period_start;

  if v_budget_id is null then
    return jsonb_build_object(
      'budget', null,
      'totalSpent', 0,
      'totalRemaining', 0,
      'totalPercent', null,
      'categories', '[]'::jsonb
    );
  end if;

  select coalesce(sum(t.amount), 0)
  into v_total_spent
  from public.transactions t
  where t.family_id = v_family_id
    and t.type = 'expense'
    and t.transaction_date >= v_period_start
    and t.transaction_date <= v_period_end;

  select coalesce(
    jsonb_agg(
      jsonb_build_object(
        'id', bc.id,
        'categoryId', bc.category_id,
        'categoryName', c.name,
        'categoryIcon', c.icon,
        'categoryType', c.type,
        'limitAmount', bc.limit_amount,
        'spentAmount', coalesce(cat_spent.spent, 0),
        'remainingAmount', bc.limit_amount - coalesce(cat_spent.spent, 0),
        'percent', case when bc.limit_amount > 0
          then round(coalesce(cat_spent.spent, 0) / bc.limit_amount * 100, 1)
          else null
        end,
        'isActive', c.is_active
      )
      order by c.name
    ),
    '[]'::jsonb
  )
  into v_categories
  from public.budget_categories bc
  join public.categories c on c.id = bc.category_id
  left join lateral (
    select sum(t.amount) as spent
    from public.transactions t
    where t.family_id = v_family_id
      and t.type = 'expense'
      and t.category_id = bc.category_id
      and t.transaction_date >= v_period_start
      and t.transaction_date <= v_period_end
  ) cat_spent on true
  where bc.budget_id = v_budget_id;

  return jsonb_build_object(
    'budget', jsonb_build_object('id', v_budget_id, 'periodMonth', v_period_start, 'totalAmount', v_budget_total),
    'totalSpent', v_total_spent,
    'totalRemaining', v_budget_total - v_total_spent,
    'totalPercent', case when v_budget_total > 0 then round(v_total_spent / v_budget_total * 100, 1) else null end,
    'categories', v_categories
  );
end;
$$;

revoke all on function public.get_monthly_budget_summary(date) from public;
revoke execute on function public.get_monthly_budget_summary(date) from anon;
grant execute on function public.get_monthly_budget_summary(date) to authenticated;

-- ─────────────────────────────────────────────────────────────────────────
-- (C) Аналитика — четыре функции, тела без изменений (уже явно фильтровали
-- по v_family_ids, полученному через family_members+auth.uid()), меняется
-- только security invoker -> security definer.
-- ─────────────────────────────────────────────────────────────────────────
create or replace function public.get_analytics_summary(
  p_date_from date,
  p_date_to date
)
returns table (
  income numeric(14, 2),
  expenses numeric(14, 2),
  balance numeric(14, 2),
  transaction_count integer
)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;
  if p_date_from is null or p_date_to is null or p_date_from > p_date_to then
    raise exception 'INVALID_PERIOD';
  end if;
  if p_date_to - p_date_from > 3660 then
    raise exception 'PERIOD_TOO_LONG';
  end if;

  return query
    select
      coalesce(sum(t.amount) filter (where t.type = 'income'), 0)::numeric(14, 2) as income,
      coalesce(sum(t.amount) filter (where t.type = 'expense'), 0)::numeric(14, 2) as expenses,
      (
        coalesce(sum(t.amount) filter (where t.type = 'income'), 0)
        - coalesce(sum(t.amount) filter (where t.type = 'expense'), 0)
      )::numeric(14, 2) as balance,
      count(*)::integer as transaction_count
    from public.transactions t
    where t.family_id in (
      select fm.family_id from public.family_members fm
      where fm.user_id = v_user_id and fm.status = 'active'
    )
    and t.transaction_date >= p_date_from
    and t.transaction_date <= p_date_to;
end;
$$;

revoke all on function public.get_analytics_summary(date, date) from public;
revoke execute on function public.get_analytics_summary(date, date) from anon;
grant execute on function public.get_analytics_summary(date, date) to authenticated;

create or replace function public.get_analytics_timeseries(
  p_date_from date,
  p_date_to date
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_family_ids uuid[];
  v_days integer;
  v_granularity text;
  v_points jsonb;
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;
  if p_date_from is null or p_date_to is null or p_date_from > p_date_to then
    raise exception 'INVALID_PERIOD';
  end if;
  if p_date_to - p_date_from > 3660 then
    raise exception 'PERIOD_TOO_LONG';
  end if;

  select array_agg(fm.family_id) into v_family_ids
  from public.family_members fm
  where fm.user_id = v_user_id and fm.status = 'active';

  v_days := (p_date_to - p_date_from) + 1;
  v_granularity := case when v_days <= 31 then 'day' else 'month' end;

  if v_granularity = 'day' then
    select coalesce(jsonb_agg(
      jsonb_build_object(
        'bucket', gs.d::date,
        'income', coalesce(agg.income, 0)::numeric(14, 2),
        'expenses', coalesce(agg.expenses, 0)::numeric(14, 2)
      )
      order by gs.d
    ), '[]'::jsonb)
    into v_points
    from generate_series(p_date_from::timestamp, p_date_to::timestamp, interval '1 day') as gs(d)
    left join (
      select
        t.transaction_date as bucket,
        sum(t.amount) filter (where t.type = 'income') as income,
        sum(t.amount) filter (where t.type = 'expense') as expenses
      from public.transactions t
      where t.family_id = any(coalesce(v_family_ids, array[]::uuid[]))
        and t.transaction_date >= p_date_from
        and t.transaction_date <= p_date_to
      group by t.transaction_date
    ) agg on agg.bucket = gs.d::date;
  else
    select coalesce(jsonb_agg(
      jsonb_build_object(
        'bucket', gs.d::date,
        'income', coalesce(agg.income, 0)::numeric(14, 2),
        'expenses', coalesce(agg.expenses, 0)::numeric(14, 2)
      )
      order by gs.d
    ), '[]'::jsonb)
    into v_points
    from generate_series(
      date_trunc('month', p_date_from::timestamp),
      date_trunc('month', p_date_to::timestamp),
      interval '1 month'
    ) as gs(d)
    left join (
      select
        date_trunc('month', t.transaction_date)::date as bucket,
        sum(t.amount) filter (where t.type = 'income') as income,
        sum(t.amount) filter (where t.type = 'expense') as expenses
      from public.transactions t
      where t.family_id = any(coalesce(v_family_ids, array[]::uuid[]))
        and t.transaction_date >= p_date_from
        and t.transaction_date <= p_date_to
      group by 1
    ) agg on agg.bucket = gs.d::date;
  end if;

  return jsonb_build_object('granularity', v_granularity, 'points', v_points);
end;
$$;

revoke all on function public.get_analytics_timeseries(date, date) from public;
revoke execute on function public.get_analytics_timeseries(date, date) from anon;
grant execute on function public.get_analytics_timeseries(date, date) to authenticated;

create or replace function public.get_analytics_categories(
  p_date_from date,
  p_date_to date
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_family_ids uuid[];
  v_total numeric(14, 2);
  v_categories jsonb;
  v_by_type jsonb;
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;
  if p_date_from is null or p_date_to is null or p_date_from > p_date_to then
    raise exception 'INVALID_PERIOD';
  end if;
  if p_date_to - p_date_from > 3660 then
    raise exception 'PERIOD_TOO_LONG';
  end if;

  select array_agg(fm.family_id) into v_family_ids
  from public.family_members fm
  where fm.user_id = v_user_id and fm.status = 'active';

  select coalesce(sum(t.amount), 0)::numeric(14, 2)
  into v_total
  from public.transactions t
  where t.family_id = any(coalesce(v_family_ids, array[]::uuid[]))
    and t.type = 'expense'
    and t.transaction_date >= p_date_from
    and t.transaction_date <= p_date_to;

  select coalesce(
    jsonb_agg(
      jsonb_build_object(
        'categoryId', x.category_id,
        'categoryName', coalesce(x.category_name, 'Без категории'),
        'categoryIcon', x.category_icon,
        'categoryType', x.category_type,
        'amount', x.amount,
        'percent', case when v_total > 0 then round(x.amount / v_total * 100, 1) else 0 end
      )
      order by x.amount desc, x.category_name nulls last
    ),
    '[]'::jsonb
  )
  into v_categories
  from (
    select
      t.category_id,
      c.name as category_name,
      c.icon as category_icon,
      c.type as category_type,
      sum(t.amount)::numeric(14, 2) as amount
    from public.transactions t
    left join public.categories c on c.id = t.category_id
    where t.family_id = any(coalesce(v_family_ids, array[]::uuid[]))
      and t.type = 'expense'
      and t.transaction_date >= p_date_from
      and t.transaction_date <= p_date_to
    group by t.category_id, c.name, c.icon, c.type
  ) x;

  select coalesce(
    jsonb_agg(
      jsonb_build_object(
        'type', y.category_type,
        'amount', y.amount,
        'percent', case when v_total > 0 then round(y.amount / v_total * 100, 1) else 0 end
      )
      order by y.amount desc
    ),
    '[]'::jsonb
  )
  into v_by_type
  from (
    select
      coalesce(c.type, 'UNCATEGORIZED') as category_type,
      sum(t.amount)::numeric(14, 2) as amount
    from public.transactions t
    left join public.categories c on c.id = t.category_id
    where t.family_id = any(coalesce(v_family_ids, array[]::uuid[]))
      and t.type = 'expense'
      and t.transaction_date >= p_date_from
      and t.transaction_date <= p_date_to
    group by coalesce(c.type, 'UNCATEGORIZED')
  ) y;

  return jsonb_build_object('totalExpense', v_total, 'categories', v_categories, 'byType', v_by_type);
end;
$$;

revoke all on function public.get_analytics_categories(date, date) from public;
revoke execute on function public.get_analytics_categories(date, date) from anon;
grant execute on function public.get_analytics_categories(date, date) to authenticated;

create or replace function public.get_analytics_income_sources(
  p_date_from date,
  p_date_to date
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_family_ids uuid[];
  v_total numeric(14, 2);
  v_sources jsonb;
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;
  if p_date_from is null or p_date_to is null or p_date_from > p_date_to then
    raise exception 'INVALID_PERIOD';
  end if;
  if p_date_to - p_date_from > 3660 then
    raise exception 'PERIOD_TOO_LONG';
  end if;

  select array_agg(fm.family_id) into v_family_ids
  from public.family_members fm
  where fm.user_id = v_user_id and fm.status = 'active';

  select coalesce(sum(t.amount), 0)::numeric(14, 2)
  into v_total
  from public.transactions t
  where t.family_id = any(coalesce(v_family_ids, array[]::uuid[]))
    and t.type = 'income'
    and t.transaction_date >= p_date_from
    and t.transaction_date <= p_date_to;

  select coalesce(
    jsonb_agg(
      jsonb_build_object(
        'incomeSource', z.income_source,
        'amount', z.amount,
        'percent', case when v_total > 0 then round(z.amount / v_total * 100, 1) else 0 end
      )
      order by z.amount desc, z.income_source nulls last
    ),
    '[]'::jsonb
  )
  into v_sources
  from (
    select
      t.income_source,
      sum(t.amount)::numeric(14, 2) as amount
    from public.transactions t
    where t.family_id = any(coalesce(v_family_ids, array[]::uuid[]))
      and t.type = 'income'
      and t.transaction_date >= p_date_from
      and t.transaction_date <= p_date_to
    group by t.income_source
  ) z;

  return jsonb_build_object('totalIncome', v_total, 'sources', v_sources);
end;
$$;

revoke all on function public.get_analytics_income_sources(date, date) from public;
revoke execute on function public.get_analytics_income_sources(date, date) from anon;
grant execute on function public.get_analytics_income_sources(date, date) to authenticated;

-- ─────────────────────────────────────────────────────────────────────────
-- (D) family_settings.child_visibility — безопасный MVP-дефолт (структура
-- из ТЗ п.15), для новых семей (триггер) и backfill существующих (только
-- тех, что ещё не были изменены вручную — child_visibility = '{}').
-- ─────────────────────────────────────────────────────────────────────────
update public.family_settings
set child_visibility = '{
  "transactions": "own_only",
  "personal_goals": "own_only",
  "family_goals": "aggregate",
  "planned_expenses": "own_only",
  "recurring_transactions": "own_only",
  "analytics": "family_aggregate",
  "budget": "family_aggregate"
}'::jsonb
where child_visibility = '{}'::jsonb;

create or replace function public.handle_new_family()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.family_settings (family_id, child_visibility)
  values (
    new.id,
    '{
      "transactions": "own_only",
      "personal_goals": "own_only",
      "family_goals": "aggregate",
      "planned_expenses": "own_only",
      "recurring_transactions": "own_only",
      "analytics": "family_aggregate",
      "budget": "family_aggregate"
    }'::jsonb
  );

  return new;
end;
$$;
