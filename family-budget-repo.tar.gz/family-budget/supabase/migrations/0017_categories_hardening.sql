-- Этап 8 (Категории): усиление ограничений вокруг categories перед тем, как
-- открывать полноценный CRUD категорий в приложении. Три независимых
-- изменения, каждое отвечает на свой пункт ТЗ Этапа 8.

-- ── 1. Уникальность названия категории без учёта регистра/пробелов (п.10) ──
-- Старый UNIQUE(family_id, name) был чувствителен к регистру ("Продукты" и
-- "продукты" считались разными названиями) — ТЗ прямо требует считать их
-- одинаковыми. Индекс по-прежнему включает family_id, поэтому одинаковые
-- названия в РАЗНЫХ семьях остаются разрешены (п.10, последний абзац).
alter table public.categories
  drop constraint if exists categories_family_id_name_key;

create unique index if not exists categories_family_id_normalized_name_key
  on public.categories (family_id, lower(btrim(name)));

-- ── 2. Защита исторических операций от удаления категории (п.13, 24) ──
-- ON DELETE SET NULL тихо обнулял бы category_id у уже существующих
-- транзакций при удалении категории — ТЗ явно запрещает это ("не удаляй
-- связанные... сохрани историческую связь либо запрети физическое удаление").
-- RESTRICT — Postgres физически откажет в DELETE, пока есть хоть одна
-- ссылающаяся транзакция; приложение в такой ситуации предлагает "Отключить".
alter table public.transactions
  drop constraint if exists transactions_category_id_fkey;

alter table public.transactions
  add constraint transactions_category_id_fkey
  foreign key (category_id) references public.categories(id) on delete restrict;

-- ── 3. Физически удалять можно только пользовательские категории (п.13) ──
-- Раньше DELETE был доступен админу/взрослому для любой категории семьи.
-- Теперь RLS сама отказывает в удалении системных (is_custom=false)
-- категорий — это защита на сервере, а не только скрытая в UI кнопка.
-- Отключение (is_active=false) по-прежнему доступно для категорий любого
-- типа через UPDATE (categories_update_adult_admin — без изменений).
drop policy if exists categories_delete_adult_admin on public.categories;

create policy categories_delete_adult_admin
  on public.categories
  for delete
  using (
    public.get_family_role(family_id) in ('admin', 'adult')
    and is_custom = true
  );
