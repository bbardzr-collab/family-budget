-- Этап 5: устранение предупреждения security-advisor после первого прохода
-- по 0012_family_rpcs.sql (тот же класс проблемы, что уже чинился в
-- 0011_harden_functions.sql для Этапа 3 — не редактируем 0012 задним числом,
-- фиксируем отдельной миграцией, как и было сделано тогда).
--
-- family_invitation_ttl() не имела зафиксированного search_path
-- (WARN: function_search_path_mutable). Функция ничего не читает из таблиц
-- и не обращается к auth.*, поэтому реального риска не было, но фиксируем
-- search_path для консистentности со всеми остальными функциями схемы.
create or replace function public.family_invitation_ttl()
returns interval
language sql
immutable
set search_path = public
as $$
  select interval '7 days';
$$;

-- Остальные предупреждения advisor после 0012 (anon_security_definer_function_executable
-- на get_invitation_by_token и authenticated_security_definer_function_executable на
-- всех остальных RPC) — намеренные и объяснены в итоговом отчёте Этапа 5: это ожидаемые
-- публичные/авторизованные входные точки, каждая из которых сама проверяет права внутри
-- (auth.uid(), is_family_admin и т.д.), а не разрешает произвольный доступ к данным.
