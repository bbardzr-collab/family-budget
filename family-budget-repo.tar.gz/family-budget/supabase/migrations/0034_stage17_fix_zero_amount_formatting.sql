-- Этап 17 — исправление найденной живым тестом ошибки форматирования суммы.
--
-- to_char(0, 'FM999G999G999D00') в Postgres возвращает ".00" (без ведущего
-- "0"), потому что маска 'FM999...' целиком состоит из "9" (цифра без
-- принудительного отображения), и FM обрезает всё, что можно обрезать —
-- включая единственный "0" перед точкой, когда целая часть равна нулю.
-- Обнаружено при живом тесте лимита категории: расход ровно равен лимиту
-- (percent = 100, overage = 0) → уведомление "превысили лимит на .00 ₽"
-- вместо "на 0,00 ₽".
--
-- Затронуты 3 места, использующие ту же маску в create_notification()
-- сообщениях (миграция 0033): overage бюджета (check_budget_notifications,
-- overage всегда > 0 благодаря строгому "> " в условии — практически не
-- задевается, но маска для консистентности исправляется тоже), overage
-- лимита категории (реально ловится живым тестом при percent = 100) и сумма
-- payment_due (generate_due_planned_expenses, amount всегда > 0 по CHECK
-- recurring_transactions_amount_check — не задевается, исправлено для
-- консистентности форматирования по всему проекту).
--
-- Исправление: последняя "9" перед разделителем дробной части заменена на
-- "0" ('FM999G999G990D00') — цифра "0" в маске to_char всегда печатается,
-- даже когда она единственная значащая цифра целой части. Остальное
-- поведение маски (группировка тысяч через G, две цифры после запятой)
-- не меняется — только это.
--
-- Только эти два тела функций меняются; сигнатуры, права (EXECUTE revoked
-- from public/anon/authenticated — обе функции internal-only DEFINER),
-- триггеры и остальная логика Этапа 17 не затронуты.

create or replace function public.check_budget_notifications(p_family_id uuid, p_period_start date)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_period_end date := (p_period_start + interval '1 month' - interval '1 day')::date;
  v_budget record;
  v_total_spent numeric(14, 2);
  v_cat record;
  v_cat_spent numeric(14, 2);
  v_percent numeric;
  v_member_id uuid;
begin
  select b.id, b.total_amount into v_budget
  from public.budgets b
  where b.family_id = p_family_id and b.period_month = p_period_start;

  if v_budget.id is null then
    return;
  end if;

  select coalesce(sum(t.amount), 0) into v_total_spent
  from public.transactions t
  where t.family_id = p_family_id
    and t.type = 'expense'
    and t.transaction_date between p_period_start and v_period_end;

  if v_budget.total_amount > 0 and v_total_spent > v_budget.total_amount then
    for v_member_id in
      select fm.user_id from public.family_members fm
      where fm.family_id = p_family_id and fm.status = 'active'
    loop
      perform public.create_notification(
        v_member_id,
        p_family_id,
        'budget_exceeded',
        'Бюджет превышен',
        'Расходы семьи превысили установленный бюджет на '
          || trim(to_char(v_total_spent - v_budget.total_amount, 'FM999G999G990D00')) || ' ₽.',
        jsonb_build_object('budget_id', v_budget.id),
        'budget_exceeded:' || v_budget.id::text || ':' || v_budget.total_amount::text
      );
    end loop;
  end if;

  for v_cat in
    select bc.id as budget_category_id, bc.category_id, bc.limit_amount, c.name as category_name
    from public.budget_categories bc
    join public.categories c on c.id = bc.category_id
    where bc.budget_id = v_budget.id and bc.limit_amount > 0
  loop
    select coalesce(sum(t.amount), 0) into v_cat_spent
    from public.transactions t
    where t.family_id = p_family_id
      and t.type = 'expense'
      and t.category_id = v_cat.category_id
      and t.transaction_date between p_period_start and v_period_end;

    v_percent := v_cat_spent / v_cat.limit_amount * 100;

    if v_percent >= 100 then
      for v_member_id in
        select fm.user_id from public.family_members fm
        where fm.family_id = p_family_id and fm.status = 'active'
      loop
        perform public.create_notification(
          v_member_id,
          p_family_id,
          'limit_reached',
          'Лимит превышен',
          'Расходы на «' || v_cat.category_name || '» превысили лимит на '
            || trim(to_char(v_cat_spent - v_cat.limit_amount, 'FM999G999G990D00')) || ' ₽.',
          jsonb_build_object('budget_id', v_budget.id, 'category_id', v_cat.category_id),
          'limit_reached:' || v_cat.budget_category_id::text || ':' || v_cat.limit_amount::text || ':100'
        );
      end loop;
    elsif v_percent >= 90 then
      for v_member_id in
        select fm.user_id from public.family_members fm
        where fm.family_id = p_family_id and fm.status = 'active'
      loop
        perform public.create_notification(
          v_member_id,
          p_family_id,
          'limit_reached',
          'Лимит категории',
          'Расходы на «' || v_cat.category_name || '» достигли ' || round(v_percent) || '% установленного лимита.',
          jsonb_build_object('budget_id', v_budget.id, 'category_id', v_cat.category_id),
          'limit_reached:' || v_cat.budget_category_id::text || ':' || v_cat.limit_amount::text || ':90'
        );
      end loop;
    end if;
  end loop;
end;
$$;

create or replace function public.generate_due_planned_expenses()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_family_id uuid;
  v_can_manage_all boolean;
  v_rec record;
  v_title text;
  v_existing_id uuid;
  v_planned_id uuid;
  v_new_next_run_date date;
  v_results jsonb := '[]'::jsonb;
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  select fm.family_id into v_family_id
  from public.family_members fm
  where fm.user_id = v_user_id and fm.status = 'active'
  limit 1;

  if v_family_id is null then
    return '[]'::jsonb;
  end if;

  v_can_manage_all := public.get_family_role(v_family_id) in ('admin', 'adult');

  for v_rec in
    select rt.*
    from public.recurring_transactions rt
    where rt.family_id = v_family_id
      and rt.is_active = true
      and rt.next_run_date <= current_date
      and rt.start_date <= current_date
      and (rt.end_date is null or rt.end_date >= current_date)
      and (v_can_manage_all or rt.user_id = v_user_id)
    order by rt.next_run_date asc
    for update of rt
  loop
    select pe.id into v_existing_id
    from public.planned_expenses pe
    where pe.recurring_transaction_id = v_rec.id
      and pe.planned_date = v_rec.next_run_date
    limit 1;

    if v_existing_id is null then
      select c.name into v_title
      from public.categories c
      where c.id = v_rec.category_id;

      v_title := coalesce(
        v_title,
        nullif(btrim(v_rec.income_source), ''),
        case when v_rec.type = 'income' then 'Доход' else 'Расход' end
      );

      insert into public.planned_expenses (
        family_id, user_id, category_id, title, amount, planned_date, status, recurring_transaction_id
      )
      values (
        v_rec.family_id, v_rec.user_id, v_rec.category_id, v_title, v_rec.amount,
        v_rec.next_run_date, 'planned', v_rec.id
      )
      returning id into v_planned_id;

      v_results := v_results || jsonb_build_object(
        'plannedExpenseId', v_planned_id,
        'recurringTransactionId', v_rec.id,
        'plannedDate', v_rec.next_run_date,
        'title', v_title,
        'amount', v_rec.amount,
        'type', v_rec.type
      );

      if v_rec.type = 'expense' and v_rec.user_id is not null then
        perform public.create_notification(
          v_rec.user_id,
          v_rec.family_id,
          'payment_due',
          case when v_rec.next_run_date = current_date then 'Оплата сегодня' else 'Просроченный платёж' end,
          'Сегодня нужно оплатить: ' || v_title || ' — '
            || trim(to_char(v_rec.amount, 'FM999G999G990D00')) || ' ₽.',
          jsonb_build_object('recurring_transaction_id', v_rec.id, 'planned_expense_id', v_planned_id),
          'payment_due:' || v_planned_id::text
        );
      end if;
    end if;

    v_new_next_run_date := public.calculate_recurring_next_run_date(v_rec.next_run_date, v_rec.frequency, v_rec.interval_config);

    update public.recurring_transactions
    set next_run_date = v_new_next_run_date
    where id = v_rec.id;
  end loop;

  return v_results;
end;
$$;
