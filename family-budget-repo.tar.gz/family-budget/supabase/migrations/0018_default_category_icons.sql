-- Этап 8 (Категории), п.3: минимальное исправление найденного пробела в
-- create_family() (Этап 5) — стандартные категории создавались с icon = NULL
-- для всех 17 строк. Этап 8 явно требует иконку у каждой категории (п.8-9:
-- "икону... для каждой категории"), поэтому пустая icon у 100% стандартного
-- набора — это баг предыдущего этапа, а не просто отсутствие улучшения, и
-- ТЗ прямо разрешает исправлять такое минимальным изменением RPC (п.3).
--
-- Изменение точечное: тот же INSERT ... SELECT ... FROM (VALUES ...), только
-- добавлен третий столбец icon. Всё остальное тело create_family() (проверки,
-- auth.uid(), обработка гонки unique_violation, GRANT/REVOKE) — без изменений.
create or replace function public.create_family(p_name text)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_name text;
  v_family_id uuid;
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  if not exists (select 1 from public.users where id = v_user_id) then
    raise exception 'USER_PROFILE_NOT_FOUND';
  end if;

  v_name := btrim(coalesce(p_name, ''));
  if char_length(v_name) < 2 then
    raise exception 'FAMILY_NAME_TOO_SHORT';
  end if;
  if char_length(v_name) > 100 then
    raise exception 'FAMILY_NAME_TOO_LONG';
  end if;

  if exists (
    select 1 from public.family_members
    where user_id = v_user_id and status = 'active'
  ) then
    raise exception 'FAMILY_ALREADY_EXISTS';
  end if;

  insert into public.families (name, created_by)
  values (v_name, v_user_id)
  returning id into v_family_id;

  begin
    insert into public.family_members (family_id, user_id, role, status)
    values (v_family_id, v_user_id, 'admin', 'active');
  exception when unique_violation then
    raise exception 'FAMILY_ALREADY_EXISTS';
  end;

  -- family_settings создаётся автоматически триггером trg_on_family_created
  -- (0008_family_settings_trigger.sql, Этап 3) — не дублируем здесь.

  -- Стандартные категории (Этап 5, п.7) — теперь с icon (Этап 8, п.3, 8).
  insert into public.categories (family_id, name, type, icon, is_custom, is_active)
  select v_family_id, c.name, c.type, c.icon, false, true
  from (values
    ('Продукты', 'OBLIGATORY', 'shopping-cart'),
    ('Дом', 'OBLIGATORY', 'home'),
    ('Коммунальные услуги', 'OBLIGATORY', 'plug'),
    ('Автомобиль', 'OBLIGATORY', 'car'),
    ('Бензин', 'OBLIGATORY', 'fuel'),
    ('Здоровье', 'OBLIGATORY', 'heart-pulse'),
    ('Образование', 'OBLIGATORY', 'graduation-cap'),
    ('Связь', 'OBLIGATORY', 'wifi'),
    ('Кредиты', 'OBLIGATORY', 'credit-card'),
    ('Дети', 'OBLIGATORY', 'baby'),
    ('Животные', 'OBLIGATORY', 'dog'),
    ('Одежда', 'WANTS', 'shirt'),
    ('Развлечения', 'WANTS', 'party-popper'),
    ('Кафе', 'WANTS', 'utensils'),
    ('Путешествия', 'WANTS', 'plane'),
    ('Подарки', 'WANTS', 'gift'),
    ('Другое', 'OTHER', 'more-horizontal')
  ) as c(name, type, icon);

  return v_family_id;
end;
$$;
comment on function public.create_family(text) is
  'Атомарно создаёт семью: families + family_members(admin,active) + 17 стандартных
   категорий (теперь с иконками, Этап 8, п.3); family_settings — триггером.
   auth.uid() определяется на сервере. Откатывается целиком при любой ошибке.';

-- Защитный backfill — на случай, если к моменту применения миграции уже
-- существуют стандартные категории без иконки (в проде на момент Этапа 8 их
-- нет, но это делает миграцию идемпотентной и безопасной для повторного
-- применения / для сред, где семьи уже созданы).
update public.categories set icon = 'shopping-cart' where is_custom = false and icon is null and lower(btrim(name)) = 'продукты';
update public.categories set icon = 'home' where is_custom = false and icon is null and lower(btrim(name)) = 'дом';
update public.categories set icon = 'plug' where is_custom = false and icon is null and lower(btrim(name)) = 'коммунальные услуги';
update public.categories set icon = 'car' where is_custom = false and icon is null and lower(btrim(name)) = 'автомобиль';
update public.categories set icon = 'fuel' where is_custom = false and icon is null and lower(btrim(name)) = 'бензин';
update public.categories set icon = 'heart-pulse' where is_custom = false and icon is null and lower(btrim(name)) = 'здоровье';
update public.categories set icon = 'graduation-cap' where is_custom = false and icon is null and lower(btrim(name)) = 'образование';
update public.categories set icon = 'wifi' where is_custom = false and icon is null and lower(btrim(name)) = 'связь';
update public.categories set icon = 'credit-card' where is_custom = false and icon is null and lower(btrim(name)) = 'кредиты';
update public.categories set icon = 'baby' where is_custom = false and icon is null and lower(btrim(name)) = 'дети';
update public.categories set icon = 'dog' where is_custom = false and icon is null and lower(btrim(name)) = 'животные';
update public.categories set icon = 'shirt' where is_custom = false and icon is null and lower(btrim(name)) = 'одежда';
update public.categories set icon = 'party-popper' where is_custom = false and icon is null and lower(btrim(name)) = 'развлечения';
update public.categories set icon = 'utensils' where is_custom = false and icon is null and lower(btrim(name)) = 'кафе';
update public.categories set icon = 'plane' where is_custom = false and icon is null and lower(btrim(name)) = 'путешествия';
update public.categories set icon = 'gift' where is_custom = false and icon is null and lower(btrim(name)) = 'подарки';
update public.categories set icon = 'more-horizontal' where is_custom = false and icon is null and lower(btrim(name)) = 'другое';
