-- Этап 11 — RPC для целей накопления (ТЗ, п.27-28: "особенно" рекомендованы
-- create_goal()/add_goal_contribution()", "предпочтительно RPC для получения
-- цели вместе с агрегированной суммой"). Все четыре — SECURITY INVOKER (как
-- get_monthly_budget_summary, get_dashboard_summary): выполняются под
-- правами вызывающего, поэтому RLS goals/goal_contributions (и триггеры
-- goals_check_owner_in_family / goal_check_auto_complete) применяются
-- ВНУТРИ функции ровно так же, как и к прямому запросу с клиента — RPC
-- здесь не подменяет собой RLS, а только (а) определяет family_id/user_id
-- на сервере, никогда не принимая их параметром от фронта, и (б) считает
-- агрегаты одним запросом вместо загрузки всех contributions на клиент.

-- ─────────────────────────────────────────────────────────────────────────
-- create_goal — family_id ВСЕГДА определяется по auth.uid(), не параметр.
-- ─────────────────────────────────────────────────────────────────────────
create or replace function public.create_goal(
  p_goal_type text,
  p_owner_user_id uuid,
  p_title text,
  p_icon text,
  p_target_amount numeric,
  p_target_date date
)
returns uuid
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_family_id uuid;
  v_id uuid;
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  select fm.family_id into v_family_id
  from public.family_members fm
  where fm.user_id = v_user_id and fm.status = 'active'
  limit 1;

  if v_family_id is null then
    raise exception 'NO_FAMILY';
  end if;

  if p_goal_type not in ('personal', 'family') then
    raise exception 'INVALID_GOAL_TYPE';
  end if;

  -- Для personal без явного owner — по умолчанию сам создающий (ТЗ, п.9:
  -- "выбрать владельца" — по умолчанию логично предложить себя). RLS
  -- (goals_insert_own_or_family) и триггер (goals_check_owner_in_family)
  -- всё равно перепроверят реальные права независимо от этого значения.
  insert into public.goals (family_id, goal_type, owner_user_id, title, icon, target_amount, target_date)
  values (
    v_family_id,
    p_goal_type,
    case when p_goal_type = 'personal' then coalesce(p_owner_user_id, v_user_id) else null end,
    p_title,
    p_icon,
    p_target_amount,
    p_target_date
  )
  returning id into v_id;

  return v_id;
end;
$$;

revoke all on function public.create_goal(text, uuid, text, text, numeric, date) from public;
revoke execute on function public.create_goal(text, uuid, text, text, numeric, date) from anon;
grant execute on function public.create_goal(text, uuid, text, text, numeric, date) to authenticated;

-- ─────────────────────────────────────────────────────────────────────────
-- add_goal_contribution — user_id ВСЕГДА auth.uid(), НИКОГДА от клиента
-- (ТЗ, п.13). Дружелюбная ошибка GOAL_NOT_ACTIVE вместо голого отказа RLS
-- (сам INSERT всё равно защищён политикой goal_contributions_insert_own,
-- которая тоже проверяет status = 'active' — эта проверка здесь только
-- ради понятного сообщения на фронте, а не единственная граница).
-- ─────────────────────────────────────────────────────────────────────────
create or replace function public.add_goal_contribution(
  p_goal_id uuid,
  p_amount numeric,
  p_comment text,
  p_contributed_at date
)
returns uuid
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_status text;
  v_id uuid;
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  -- SECURITY INVOKER — этот SELECT тоже проходит через goals_select_visible,
  -- поэтому "цель не найдена" и "цель есть, но не в моей семье/не моя" дают
  -- одинаковый результат (v_status is null), без утечки факта существования.
  select status into v_status from public.goals where id = p_goal_id;

  if v_status is null then
    raise exception 'GOAL_NOT_FOUND';
  end if;

  if v_status <> 'active' then
    raise exception 'GOAL_NOT_ACTIVE';
  end if;

  insert into public.goal_contributions (goal_id, user_id, amount, comment, contributed_at)
  values (p_goal_id, v_user_id, p_amount, nullif(trim(p_comment), ''), coalesce(p_contributed_at, current_date))
  returning id into v_id;

  -- trg_goal_check_auto_complete (AFTER INSERT) переводит цель в completed
  -- здесь же, синхронно, если сумма взносов достигла target_amount.
  return v_id;
end;
$$;

revoke all on function public.add_goal_contribution(uuid, numeric, text, date) from public;
revoke execute on function public.add_goal_contribution(uuid, numeric, text, date) from anon;
grant execute on function public.add_goal_contribution(uuid, numeric, text, date) to authenticated;

-- ─────────────────────────────────────────────────────────────────────────
-- get_goal_summary — цель + агрегированная сумма взносов + остаток + % +
-- полная история взносов одним вызовом (ТЗ, п.28). null, если цель не
-- существует или не видна текущему пользователю (RLS решает видимость).
-- ─────────────────────────────────────────────────────────────────────────
create or replace function public.get_goal_summary(p_goal_id uuid)
returns jsonb
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_goal record;
  v_contributed numeric(14, 2);
  v_contributions jsonb;
begin
  select g.id, g.family_id, g.goal_type, g.owner_user_id, owner.full_name as owner_name,
         g.title, g.icon, g.target_amount, g.target_date, g.status, g.created_at
  into v_goal
  from public.goals g
  left join public.users owner on owner.id = g.owner_user_id
  where g.id = p_goal_id;

  if v_goal.id is null then
    return null;
  end if;

  select coalesce(sum(gc.amount), 0) into v_contributed
  from public.goal_contributions gc
  where gc.goal_id = p_goal_id;

  select coalesce(
    jsonb_agg(
      jsonb_build_object(
        'id', gc.id,
        'amount', gc.amount,
        'comment', gc.comment,
        'contributedAt', gc.contributed_at,
        'userId', gc.user_id,
        'userName', u.full_name
      )
      order by gc.contributed_at desc, gc.id desc
    ),
    '[]'::jsonb
  )
  into v_contributions
  from public.goal_contributions gc
  left join public.users u on u.id = gc.user_id
  where gc.goal_id = p_goal_id;

  return jsonb_build_object(
    'goal', jsonb_build_object(
      'id', v_goal.id,
      'familyId', v_goal.family_id,
      'goalType', v_goal.goal_type,
      'ownerUserId', v_goal.owner_user_id,
      'ownerName', v_goal.owner_name,
      'title', v_goal.title,
      'icon', v_goal.icon,
      'targetAmount', v_goal.target_amount,
      'targetDate', v_goal.target_date,
      'status', v_goal.status,
      'createdAt', v_goal.created_at
    ),
    -- contributedAmount — реальная сумма БЕЗ ограничения сверху (ТЗ, п.16-17:
    -- "фактическую накопленную сумму показывай полностью"), а remaining/percent
    -- ниже — уже ограниченные для отображения.
    'contributedAmount', v_contributed,
    'remainingAmount', greatest(v_goal.target_amount - v_contributed, 0),
    'percent', least(round(v_contributed / v_goal.target_amount * 100, 1), 100),
    'contributions', v_contributions
  );
end;
$$;

revoke all on function public.get_goal_summary(uuid) from public;
revoke execute on function public.get_goal_summary(uuid) from anon;
grant execute on function public.get_goal_summary(uuid) to authenticated;

-- ─────────────────────────────────────────────────────────────────────────
-- get_goals_list — список целей своей семьи с агрегатом (для /app/goals и
-- превью на Dashboard), без N+1 запросов на клиенте (ТЗ, п.28-29, 31).
-- ─────────────────────────────────────────────────────────────────────────
create or replace function public.get_goals_list()
returns jsonb
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_family_id uuid;
  v_goals jsonb;
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  select fm.family_id into v_family_id
  from public.family_members fm
  where fm.user_id = v_user_id and fm.status = 'active'
  limit 1;

  if v_family_id is null then
    return '[]'::jsonb;
  end if;

  select coalesce(
    jsonb_agg(
      jsonb_build_object(
        'id', g.id,
        'goalType', g.goal_type,
        'ownerUserId', g.owner_user_id,
        'ownerName', owner.full_name,
        'title', g.title,
        'icon', g.icon,
        'targetAmount', g.target_amount,
        'targetDate', g.target_date,
        'status', g.status,
        'contributedAmount', coalesce(contrib.total, 0),
        'remainingAmount', greatest(g.target_amount - coalesce(contrib.total, 0), 0),
        'percent', least(round(coalesce(contrib.total, 0) / g.target_amount * 100, 1), 100),
        'createdAt', g.created_at
      )
    ),
    '[]'::jsonb
  )
  into v_goals
  -- family_id = v_family_id — явный фильтр вдобавок к RLS (goals_select_visible),
  -- а не вместо неё: та же схема "двойного слоя", что и в
  -- get_monthly_budget_summary (миграция 0021).
  from public.goals g
  left join public.users owner on owner.id = g.owner_user_id
  left join lateral (
    select sum(gc.amount) as total from public.goal_contributions gc where gc.goal_id = g.id
  ) contrib on true
  where g.family_id = v_family_id;

  return v_goals;
end;
$$;

revoke all on function public.get_goals_list() from public;
revoke execute on function public.get_goals_list() from anon;
grant execute on function public.get_goals_list() to authenticated;
