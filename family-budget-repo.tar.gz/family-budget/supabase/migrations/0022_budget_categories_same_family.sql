-- Этап 10 — обнаружено при живом security-тестировании: RLS-политики
-- budget_categories_insert_adult_admin / update_adult_admin (миграция 0021)
-- проверяют, что пользователь admin/adult в семье бюджета (budget_id), но НЕ
-- проверяют, что сама категория (category_id) принадлежит ТОЙ ЖЕ семье.
--
-- Практически это означает: ADULT/ADMIN семьи A мог вставить в свой budget_id
-- строку budget_categories, указав category_id, принадлежащий чужой семье B
-- (если бы каким-то образом узнал её id) — get_monthly_budget_summary затем
-- вернул бы название/иконку/тип этой чужой категории (сумма расходов была бы
-- честно 0, т.к. агрегация расходов дополнительно фильтруется по
-- family_id = своя семья, но само раскрытие name/icon/type чужой категории —
-- уже утечка данных, а бюджет с "чужой" категорией — логически некорректное
-- состояние, независимо от того, откуда взялась запись).
--
-- Исправляется НЕ через RLS (WITH CHECK не может лаконично сверять два разных
-- FK через два JOIN на разные таблицы политики budgets/categories без ощутимого
-- дублирования), а через BEFORE INSERT/UPDATE триггер — он застрахует данные
-- даже от прямой записи под service_role/postgres в обход RLS (RLS в принципе
-- не применяется к ролям с BYPASSRLS), что даёт более сильную гарантию
-- целостности, чем полагаться только на RLS-политику.

create or replace function public.budget_categories_check_same_family()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_budget_family_id uuid;
  v_category_family_id uuid;
begin
  select family_id into v_budget_family_id from public.budgets where id = new.budget_id;
  select family_id into v_category_family_id from public.categories where id = new.category_id;

  if v_budget_family_id is null or v_category_family_id is null
     or v_budget_family_id <> v_category_family_id then
    raise exception 'CATEGORY_FAMILY_MISMATCH: category % does not belong to the same family as budget %',
      new.category_id, new.budget_id;
  end if;

  return new;
end;
$$;

drop trigger if exists trg_budget_categories_same_family on public.budget_categories;

create trigger trg_budget_categories_same_family
  before insert or update of budget_id, category_id on public.budget_categories
  for each row execute function public.budget_categories_check_same_family();
