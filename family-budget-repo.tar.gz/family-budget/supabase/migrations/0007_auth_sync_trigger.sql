-- Этап 3: синхронизация auth.users → public.users + public.user_settings.
-- Стандартный паттерн Supabase: после регистрации в auth.users автоматически
-- создаём профиль и настройки, чтобы фронт не занимался этим вручную и не мог
-- забыть один из шагов.
create or replace function public.handle_new_auth_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.users (id, full_name, avatar_url)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', new.email, 'Новый пользователь'),
    new.raw_user_meta_data ->> 'avatar_url'
  );

  insert into public.user_settings (user_id)
  values (new.id);

  return new;
end;
$$;
comment on function public.handle_new_auth_user() is
  'SECURITY DEFINER: выполняется от имени владельца функции (роль миграций, есть BYPASSRLS),
   поэтому вставка в public.users/user_settings проходит независимо от RLS-политик этих таблиц.';

create trigger trg_on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_auth_user();
