-- Этап 14: Аналитика (ТЗ, п.5-9, 13-14, 24-27).
--
-- Четыре новых RPC, все SECURITY INVOKER (как get_dashboard_summary/
-- get_monthly_budget_summary/get_transactions_page) — выполняются под правами
-- вызывающего, RLS-политика transactions_select_role_aware (CHILD видит
-- только свои операции, ADMIN/ADULT — всю семью) применяется к запросам
-- ВНУТРИ функций ровно так же, как к прямому SELECT с клиента. family_id
-- НИКОГДА не принимается параметром — семья определяется только через
-- family_members по auth.uid() (тот же принцип, что у всех агрегатов
-- проекта с Этапа 6), поэтому подмена любого входного параметра не может
-- вернуть данные чужой семьи.
--
-- Бюджетная аналитика (ТЗ, п.17-18) сознательно НЕ получает отдельного RPC —
-- переиспользуется существующий get_monthly_budget_summary (Этап 10) без
-- изменений, вызывается с analytics-страницы тем же способом, что и с
-- /app/budget. Цели (ТЗ, п.20) и планируемые расходы (ТЗ, п.19) тоже без
-- новых RPC — переиспользуются get_goals_list (Этап 11) и прямой SELECT
-- planned_expenses (Этап 12) с фильтрацией по периоду на клиенте (короткие
-- списки семьи, без пагинации — тот же принцип, что и на их родных страницах).
--
-- Ни одна из этих функций не обращается к planned_expenses/recurring_transactions —
-- источник данных строго transactions (ТЗ, п.1: "Аналитика работает только с
-- фактическими финансовыми операциями").

-- ─────────────────────────── get_analytics_summary ───────────────────────────
-- Доходы/расходы/баланс/количество операций за период (ТЗ, п.3, 6).

create or replace function public.get_analytics_summary(
  p_date_from date,
  p_date_to date
)
returns table (
  income numeric(14, 2),
  expenses numeric(14, 2),
  balance numeric(14, 2),
  transaction_count integer
)
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;
  if p_date_from is null or p_date_to is null or p_date_from > p_date_to then
    raise exception 'INVALID_PERIOD';
  end if;
  if p_date_to - p_date_from > 3660 then
    raise exception 'PERIOD_TOO_LONG';
  end if;

  return query
    select
      coalesce(sum(t.amount) filter (where t.type = 'income'), 0)::numeric(14, 2) as income,
      coalesce(sum(t.amount) filter (where t.type = 'expense'), 0)::numeric(14, 2) as expenses,
      (
        coalesce(sum(t.amount) filter (where t.type = 'income'), 0)
        - coalesce(sum(t.amount) filter (where t.type = 'expense'), 0)
      )::numeric(14, 2) as balance,
      count(*)::integer as transaction_count
    from public.transactions t
    where t.family_id in (
      select fm.family_id from public.family_members fm
      where fm.user_id = v_user_id and fm.status = 'active'
    )
    and t.transaction_date >= p_date_from
    and t.transaction_date <= p_date_to;
end;
$$;

revoke all on function public.get_analytics_summary(date, date) from public;
revoke execute on function public.get_analytics_summary(date, date) from anon;
grant execute on function public.get_analytics_summary(date, date) to authenticated;

-- ─────────────────────────── get_analytics_timeseries ───────────────────────────
-- Динамика доходов/расходов по времени (ТЗ, п.7-8) — адаптивная агрегация:
-- период <= 31 дня группируется по дням, > 31 дня (включая "этот год"/
-- "прошлый год") — по месяцам. Решение о granularity принимается на сервере
-- (а не присылается с клиента) — тот же принцип "не доверять фронтенду
-- параметр, который влияет на форму ответа", что и у p_category_mode в
-- get_transactions_page. Пустые интервалы (дни/месяцы без операций)
-- заполняются нулями через generate_series — иначе график "прыгал" бы между
-- реально существующими точками вместо ровной шкалы времени.
create or replace function public.get_analytics_timeseries(
  p_date_from date,
  p_date_to date
)
returns jsonb
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_family_ids uuid[];
  v_days integer;
  v_granularity text;
  v_points jsonb;
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;
  if p_date_from is null or p_date_to is null or p_date_from > p_date_to then
    raise exception 'INVALID_PERIOD';
  end if;
  if p_date_to - p_date_from > 3660 then
    raise exception 'PERIOD_TOO_LONG';
  end if;

  select array_agg(fm.family_id) into v_family_ids
  from public.family_members fm
  where fm.user_id = v_user_id and fm.status = 'active';

  v_days := (p_date_to - p_date_from) + 1;
  v_granularity := case when v_days <= 31 then 'day' else 'month' end;

  if v_granularity = 'day' then
    select coalesce(jsonb_agg(
      jsonb_build_object(
        'bucket', gs.d::date,
        'income', coalesce(agg.income, 0)::numeric(14, 2),
        'expenses', coalesce(agg.expenses, 0)::numeric(14, 2)
      )
      order by gs.d
    ), '[]'::jsonb)
    into v_points
    from generate_series(p_date_from::timestamp, p_date_to::timestamp, interval '1 day') as gs(d)
    left join (
      select
        t.transaction_date as bucket,
        sum(t.amount) filter (where t.type = 'income') as income,
        sum(t.amount) filter (where t.type = 'expense') as expenses
      from public.transactions t
      where t.family_id = any(coalesce(v_family_ids, array[]::uuid[]))
        and t.transaction_date >= p_date_from
        and t.transaction_date <= p_date_to
      group by t.transaction_date
    ) agg on agg.bucket = gs.d::date;
  else
    select coalesce(jsonb_agg(
      jsonb_build_object(
        'bucket', gs.d::date,
        'income', coalesce(agg.income, 0)::numeric(14, 2),
        'expenses', coalesce(agg.expenses, 0)::numeric(14, 2)
      )
      order by gs.d
    ), '[]'::jsonb)
    into v_points
    from generate_series(
      date_trunc('month', p_date_from::timestamp),
      date_trunc('month', p_date_to::timestamp),
      interval '1 month'
    ) as gs(d)
    left join (
      select
        date_trunc('month', t.transaction_date)::date as bucket,
        sum(t.amount) filter (where t.type = 'income') as income,
        sum(t.amount) filter (where t.type = 'expense') as expenses
      from public.transactions t
      where t.family_id = any(coalesce(v_family_ids, array[]::uuid[]))
        and t.transaction_date >= p_date_from
        and t.transaction_date <= p_date_to
      group by 1
    ) agg on agg.bucket = gs.d::date;
  end if;

  return jsonb_build_object('granularity', v_granularity, 'points', v_points);
end;
$$;

revoke all on function public.get_analytics_timeseries(date, date) from public;
revoke execute on function public.get_analytics_timeseries(date, date) from anon;
grant execute on function public.get_analytics_timeseries(date, date) to authenticated;

-- ─────────────────────────── get_analytics_categories ───────────────────────────
-- Расходы по категориям (ТЗ, п.9-13) + структура расходов по типу категории
-- (ТЗ, п.11 — OBLIGATORY/WANTS/GOALS/OTHER; операции без категории попадают в
-- отдельный псевдо-тип 'UNCATEGORIZED', а не теряются и не смешиваются с OTHER).
-- Один RPC вместо двух — оба разреза считаются по одной и той же выборке
-- transactions за один проход (ТЗ, п.25: "можно объединить часть данных в
-- одну RPC, если это разумно"). TOP-5 (ТЗ, п.13) — не отдельный запрос, а
-- первые 5 элементов уже отсортированного по убыванию `categories` на клиенте.
create or replace function public.get_analytics_categories(
  p_date_from date,
  p_date_to date
)
returns jsonb
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_family_ids uuid[];
  v_total numeric(14, 2);
  v_categories jsonb;
  v_by_type jsonb;
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;
  if p_date_from is null or p_date_to is null or p_date_from > p_date_to then
    raise exception 'INVALID_PERIOD';
  end if;
  if p_date_to - p_date_from > 3660 then
    raise exception 'PERIOD_TOO_LONG';
  end if;

  select array_agg(fm.family_id) into v_family_ids
  from public.family_members fm
  where fm.user_id = v_user_id and fm.status = 'active';

  select coalesce(sum(t.amount), 0)::numeric(14, 2)
  into v_total
  from public.transactions t
  where t.family_id = any(coalesce(v_family_ids, array[]::uuid[]))
    and t.type = 'expense'
    and t.transaction_date >= p_date_from
    and t.transaction_date <= p_date_to;

  select coalesce(
    jsonb_agg(
      jsonb_build_object(
        'categoryId', x.category_id,
        'categoryName', coalesce(x.category_name, 'Без категории'),
        'categoryIcon', x.category_icon,
        'categoryType', x.category_type,
        'amount', x.amount,
        'percent', case when v_total > 0 then round(x.amount / v_total * 100, 1) else 0 end
      )
      order by x.amount desc, x.category_name nulls last
    ),
    '[]'::jsonb
  )
  into v_categories
  from (
    select
      t.category_id,
      c.name as category_name,
      c.icon as category_icon,
      c.type as category_type,
      sum(t.amount)::numeric(14, 2) as amount
    from public.transactions t
    left join public.categories c on c.id = t.category_id
    where t.family_id = any(coalesce(v_family_ids, array[]::uuid[]))
      and t.type = 'expense'
      and t.transaction_date >= p_date_from
      and t.transaction_date <= p_date_to
    group by t.category_id, c.name, c.icon, c.type
  ) x;

  select coalesce(
    jsonb_agg(
      jsonb_build_object(
        'type', y.category_type,
        'amount', y.amount,
        'percent', case when v_total > 0 then round(y.amount / v_total * 100, 1) else 0 end
      )
      order by y.amount desc
    ),
    '[]'::jsonb
  )
  into v_by_type
  from (
    select
      coalesce(c.type, 'UNCATEGORIZED') as category_type,
      sum(t.amount)::numeric(14, 2) as amount
    from public.transactions t
    left join public.categories c on c.id = t.category_id
    where t.family_id = any(coalesce(v_family_ids, array[]::uuid[]))
      and t.type = 'expense'
      and t.transaction_date >= p_date_from
      and t.transaction_date <= p_date_to
    group by coalesce(c.type, 'UNCATEGORIZED')
  ) y;

  return jsonb_build_object('totalExpense', v_total, 'categories', v_categories, 'byType', v_by_type);
end;
$$;

revoke all on function public.get_analytics_categories(date, date) from public;
revoke execute on function public.get_analytics_categories(date, date) from anon;
grant execute on function public.get_analytics_categories(date, date) to authenticated;

-- ─────────────────────────── get_analytics_income_sources ───────────────────────────
-- Доходы по источникам (ТЗ, п.14). income_source возвращается как есть
-- (nullable) — маппинг null -> "Без источника" делается на клиенте, тем же
-- принципом, что и "Без категории" в остальных фичах проекта (RPC остаётся
-- чистой агрегацией, без строковых меток на русском внутри БД).
create or replace function public.get_analytics_income_sources(
  p_date_from date,
  p_date_to date
)
returns jsonb
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_family_ids uuid[];
  v_total numeric(14, 2);
  v_sources jsonb;
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;
  if p_date_from is null or p_date_to is null or p_date_from > p_date_to then
    raise exception 'INVALID_PERIOD';
  end if;
  if p_date_to - p_date_from > 3660 then
    raise exception 'PERIOD_TOO_LONG';
  end if;

  select array_agg(fm.family_id) into v_family_ids
  from public.family_members fm
  where fm.user_id = v_user_id and fm.status = 'active';

  select coalesce(sum(t.amount), 0)::numeric(14, 2)
  into v_total
  from public.transactions t
  where t.family_id = any(coalesce(v_family_ids, array[]::uuid[]))
    and t.type = 'income'
    and t.transaction_date >= p_date_from
    and t.transaction_date <= p_date_to;

  select coalesce(
    jsonb_agg(
      jsonb_build_object(
        'incomeSource', z.income_source,
        'amount', z.amount,
        'percent', case when v_total > 0 then round(z.amount / v_total * 100, 1) else 0 end
      )
      order by z.amount desc, z.income_source nulls last
    ),
    '[]'::jsonb
  )
  into v_sources
  from (
    select
      t.income_source,
      sum(t.amount)::numeric(14, 2) as amount
    from public.transactions t
    where t.family_id = any(coalesce(v_family_ids, array[]::uuid[]))
      and t.type = 'income'
      and t.transaction_date >= p_date_from
      and t.transaction_date <= p_date_to
    group by t.income_source
  ) z;

  return jsonb_build_object('totalIncome', v_total, 'sources', v_sources);
end;
$$;

revoke all on function public.get_analytics_income_sources(date, date) from public;
revoke execute on function public.get_analytics_income_sources(date, date) from anon;
grant execute on function public.get_analytics_income_sources(date, date) to authenticated;
