-- Этап 11 — два инварианта, которые не выразить лаконично внутри RLS
-- WITH CHECK (тот же принцип, что и в Этапе 10, миграция
-- budget_categories_same_family): используем BEFORE/AFTER триггеры,
-- SECURITY DEFINER, чтобы гарантия работала для ЛЮБОГО пути записи,
-- включая service_role/postgres (BYPASSRLS обходит RLS, но не триггеры).

-- ─── 1) owner_user_id личной цели должен быть АКТИВНЫМ участником ТОЙ ЖЕ
--        семьи, что и сама цель (ТЗ п.8: "нельзя выбрать пользователя из
--        другой семьи") ───
create or replace function public.goals_check_owner_in_family()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.owner_user_id is not null then
    if not exists (
      select 1 from public.family_members fm
      where fm.family_id = new.family_id
        and fm.user_id = new.owner_user_id
        and fm.status = 'active'
    ) then
      raise exception 'GOAL_OWNER_NOT_IN_FAMILY: user % is not an active member of family %',
        new.owner_user_id, new.family_id;
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_goals_check_owner_in_family on public.goals;
create trigger trg_goals_check_owner_in_family
  before insert or update of owner_user_id, family_id on public.goals
  for each row execute function public.goals_check_owner_in_family();

revoke all on function public.goals_check_owner_in_family() from public;
revoke execute on function public.goals_check_owner_in_family() from anon;
revoke execute on function public.goals_check_owner_in_family() from authenticated;

-- ─── 2) Авто-завершение цели при достижении суммы взносов (ТЗ п.18) ───
-- SECURITY DEFINER обязателен: обычный участник семьи, вносящий взнос в
-- СЕМЕЙНУЮ цель (goal_type='family'), не обязан быть admin/adult, значит
-- НЕ имеет права UPDATE на саму строку goals по
-- goals_update_owner_or_admin — но перевод в completed должен произойти
-- независимо от того, кто внёс завершающий взнос.
create or replace function public.goal_check_auto_complete()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_target numeric(14, 2);
  v_status text;
  v_contributed numeric(14, 2);
begin
  select target_amount, status into v_target, v_status
  from public.goals
  where id = new.goal_id;

  if v_status is distinct from 'active' then
    return new;
  end if;

  select coalesce(sum(amount), 0) into v_contributed
  from public.goal_contributions
  where goal_id = new.goal_id;

  if v_contributed >= v_target then
    update public.goals set status = 'completed' where id = new.goal_id and status = 'active';
  end if;

  return new;
end;
$$;

drop trigger if exists trg_goal_check_auto_complete on public.goal_contributions;
create trigger trg_goal_check_auto_complete
  after insert or update of amount on public.goal_contributions
  for each row execute function public.goal_check_auto_complete();

revoke all on function public.goal_check_auto_complete() from public;
revoke execute on function public.goal_check_auto_complete() from anon;
revoke execute on function public.goal_check_auto_complete() from authenticated;
