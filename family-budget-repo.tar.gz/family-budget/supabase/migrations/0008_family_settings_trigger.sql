-- Этап 3: автосоздание family_settings при создании семьи (families INSERT).
create or replace function public.handle_new_family()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.family_settings (family_id)
  values (new.id);

  return new;
end;
$$;
comment on function public.handle_new_family() is
  'SECURITY DEFINER: гарантирует, что у каждой семьи всегда есть ровно одна строка
   family_settings, независимо от RLS и от того, кто создаёт семью.';

create trigger trg_on_family_created
  after insert on public.families
  for each row execute function public.handle_new_family();
