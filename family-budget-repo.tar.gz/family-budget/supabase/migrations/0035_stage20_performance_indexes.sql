-- Этап 20 (полное тестирование): точечный аудит индексов (read-only,
-- через pg_indexes + get_advisors) нашёл ровно три реальных пробела — не
-- "индекс на каждое поле", а места, где для частого запроса уже есть только
-- ДВА раздельных однокол. индекса вместо одного составного, из-за чего
-- Postgres вынужден либо делать bitmap AND по двум индексам, либо сортировать
-- результат отдельно, вместо одного упорядоченного индексного скана — тот
-- же класс запроса, для которого уже с Этапа 3 существует
-- idx_transactions_family_id_transaction_date.
--
-- Остальные колонки из чек-листа Этапа 20 уже покрыты существующими
-- индексами (transactions/categories/budgets/goals/goal_contributions/
-- notifications(user_id,is_read) — Этапы 3 и 17) — дублирующих индексов
-- здесь не создаётся.

-- planned_expenses: типичный запрос — "планы этой семьи в диапазоне дат"
-- (вкладка "План" на /app/transactions, блок "Ближайшие планы" на Dashboard).
create index idx_planned_expenses_family_id_planned_date
  on public.planned_expenses (family_id, planned_date);

-- recurring_transactions: типичный запрос — "правила этой семьи, у которых
-- next_run_date наступил/наступает" (generate_due_planned_expenses(),
-- список на вкладке "Повторяющиеся").
create index idx_recurring_transactions_family_id_next_run_date
  on public.recurring_transactions (family_id, next_run_date);

-- notifications: типичный запрос — "последние уведомления этого
-- пользователя" (список на /app/notifications и в попапе колокольчика,
-- ORDER BY created_at DESC LIMIT N WHERE user_id = ...). DESC — тот же
-- порядок, что уже использует одноколоночный idx_notifications_created_at.
create index idx_notifications_user_id_created_at
  on public.notifications (user_id, created_at desc);
