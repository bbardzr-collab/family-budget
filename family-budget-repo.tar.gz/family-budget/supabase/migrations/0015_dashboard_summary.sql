-- Этап 6: агрегированная сводка Dashboard (доходы/расходы/остаток за период).
--
-- Осознанный выбор SECURITY INVOKER (не DEFINER, в отличие от RPC Этапа 5):
-- эта функция ничего не обходит и не проверяет вручную — она лишь оборачивает
-- обычный агрегатный SELECT к transactions/family_members, который выполняется
-- ПОД ролью и правами вызывающего пользователя. Это значит, что уже
-- существующие RLS-политики Этапа 3 (0010_rls_policies.sql) применяются к
-- этому запросу ровно так же, как к прямому SELECT из клиента:
--   - transactions_select_role_aware: ADMIN/ADULT видят сумму по всей семье,
--     CHILD — только по своим операциям (приватность ребёнка, заложенная в
--     Этапе 3, здесь НЕ ослабляется и не обходится);
--   - family_members_select_family: пользователь может прочитать свою
--     собственную запись членства, чтобы определить family_id.
--
-- family_id никогда не принимается параметром. Семья определяется только
-- через family_members по auth.uid(), поэтому пользователь не может получить
-- summary чужой семьи, даже если явно передаст её id (такого параметра
-- просто нет).
create or replace function public.get_dashboard_summary(
  p_period_start date,
  p_period_end date
)
returns table (
  income numeric(14, 2),
  expenses numeric(14, 2),
  balance numeric(14, 2),
  period_start date,
  period_end date
)
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  if p_period_start is null or p_period_end is null or p_period_start > p_period_end then
    raise exception 'INVALID_PERIOD';
  end if;

  return query
    select
      coalesce(sum(t.amount) filter (where t.type = 'income'), 0)::numeric(14, 2) as income,
      coalesce(sum(t.amount) filter (where t.type = 'expense'), 0)::numeric(14, 2) as expenses,
      (
        coalesce(sum(t.amount) filter (where t.type = 'income'), 0)
        - coalesce(sum(t.amount) filter (where t.type = 'expense'), 0)
      )::numeric(14, 2) as balance,
      p_period_start as period_start,
      p_period_end as period_end
    from public.transactions t
    where t.family_id in (
      select fm.family_id
      from public.family_members fm
      where fm.user_id = v_user_id
        and fm.status = 'active'
    )
    and t.transaction_date >= p_period_start
    and t.transaction_date <= p_period_end;
end;
$$;

-- Только для авторизованных — анонимам сводка не нужна и не должна быть
-- доступна (в отличие от get_invitation_by_token в Этапе 5).
revoke all on function public.get_dashboard_summary(date, date) from public;
grant execute on function public.get_dashboard_summary(date, date) to authenticated;
