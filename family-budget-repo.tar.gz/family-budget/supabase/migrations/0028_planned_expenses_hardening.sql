-- ЭТАП 12 — Планируемые расходы.
--
-- Таблица planned_expenses существует без изменений с Этапа 3 (миграция
-- 0002_tables.sql) вместе с базовыми RLS-политиками (миграция 0010). Аудит
-- этих политик относительно требований ТЗ Этапа 12 выявил два пробела —
-- ровно тот же класс проблем, что уже был найден и исправлен на Этапах 10
-- (budget_categories) и 11 (goals):
--
--  1. UPDATE/DELETE разрешены только владельцу (user_id = auth.uid()) или
--     ADMIN (is_family_admin) — ADULT не может управлять планами семьи,
--     в том числе НИЧЕЙ (user_id IS NULL, "семейный" план без ответственного).
--     Расширяем до admin/adult, тем же паттерном, что и в budgets/goals.
--  2. INSERT/UPDATE не проверяют, что назначенный user_id (ответственный) и
--     category_id реально принадлежат той же семье, что и сам план — ADMIN/
--     ADULT семьи A мог бы назначить ответственным пользователя из семьи B
--     или указать чужую категорию. WITH CHECK на INSERT/UPDATE такое явно не
--     проверяет (сверка требует JOIN на family_members/categories). Как и в
--     budget_categories_check_same_family (Этап 10) и
--     goals_check_owner_in_family (Этап 11), это исправлено триггером, а не
--     RLS-условием — триггер защищает данные и от прямой записи под
--     service_role/postgres (BYPASSRLS), чего WITH CHECK дать не может.

drop policy if exists planned_expenses_update_own_or_admin on public.planned_expenses;
drop policy if exists planned_expenses_delete_own_or_admin on public.planned_expenses;

create policy planned_expenses_update_own_or_admin
on public.planned_expenses
for update
using (
  user_id = auth.uid()
  or get_family_role(family_id) in ('admin', 'adult')
)
with check (
  is_family_member(family_id)
  and (
    user_id = auth.uid()
    or get_family_role(family_id) in ('admin', 'adult')
  )
);

create policy planned_expenses_delete_own_or_admin
on public.planned_expenses
for delete
using (
  user_id = auth.uid()
  or get_family_role(family_id) in ('admin', 'adult')
);

-- SELECT/INSERT политики (planned_expenses_select_role_aware,
-- planned_expenses_insert_family) не изменены — они уже реализуют нужную
-- модель (CHILD видит/создаёт только свои планы, ADMIN/ADULT — все планы
-- семьи, включая безымянные) без пробелов, найденных аудитом.

create or replace function public.planned_expenses_check_same_family()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.user_id is not null and not exists (
    select 1 from public.family_members fm
    where fm.family_id = new.family_id
      and fm.user_id = new.user_id
      and fm.status = 'active'
  ) then
    raise exception 'PLANNED_EXPENSE_USER_NOT_IN_FAMILY: user % is not an active member of family %',
      new.user_id, new.family_id
      using errcode = 'P0001';
  end if;

  if new.category_id is not null and not exists (
    select 1 from public.categories c
    where c.id = new.category_id
      and c.family_id = new.family_id
  ) then
    raise exception 'PLANNED_EXPENSE_CATEGORY_NOT_IN_FAMILY: category % does not belong to family %',
      new.category_id, new.family_id
      using errcode = 'P0001';
  end if;

  return new;
end;
$$;

revoke all on function public.planned_expenses_check_same_family() from public;
revoke execute on function public.planned_expenses_check_same_family() from anon;
revoke execute on function public.planned_expenses_check_same_family() from authenticated;

drop trigger if exists trg_planned_expenses_check_same_family on public.planned_expenses;
create trigger trg_planned_expenses_check_same_family
before insert or update of user_id, category_id, family_id on public.planned_expenses
for each row
execute function public.planned_expenses_check_same_family();
