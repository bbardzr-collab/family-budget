-- Этап 9 — исправление найденной security/QA-тестом ошибки в 0019.
--
-- Баг: category_mode='none' ("Без категории") проверялся как
-- `t.category_id is null`. Но category_id ВСЕГДА null у операций типа
-- income (доход не имеет категории в принципе — ТЗ, п.4: категория
-- "недоступна/не влияет" для доходов). В результате фильтр "Без категории"
-- при типе "Все" незаметно подмешивал в выдачу ВСЕ доходы семьи, а не только
-- расходы без категории, как того требует UX (категория — понятие,
-- применимое только к расходам).
--
-- Обнаружено сценарием 14 живого SQL-теста безопасности: вместо ожидаемых
-- 2 строк (200 ₽ без категории у admin A + 50 ₽ без категории у ребёнка)
-- фактически вернулось 3 — лишней оказалась операция дохода 90000 ₽.
--
-- Исправление: для p_category_mode='none' дополнительно требуем
-- t.type = 'expense'. Режим 'specific' уже был защищён от этой утечки сам
-- по себе — доход никогда не совпадёт с конкретным category_id (у него
-- category_id всегда null, а не равен какому-то uuid). Правим обе функции
-- (get_transactions_page — обе ветки сортировки, и get_transactions_totals),
-- чтобы "Без категории" в подсчёте итогов тоже не считал доходы.

create or replace function public.get_transactions_page(
  p_type text default 'all',
  p_date_from date default null,
  p_date_to date default null,
  p_category_mode text default 'all',
  p_category_id uuid default null,
  p_search text default null,
  p_sort text default 'date_desc',
  p_limit int default 30,
  p_offset int default 0
)
returns table (
  id uuid,
  type text,
  amount numeric(14, 2),
  transaction_date date,
  income_source text,
  comment text,
  user_id uuid,
  user_full_name text,
  category_id uuid,
  category_name text,
  category_icon text,
  category_is_active boolean,
  created_at timestamptz
)
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_search text := nullif(btrim(coalesce(p_search, '')), '');
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;
  if p_type not in ('all', 'expense', 'income') then
    raise exception 'INVALID_TYPE';
  end if;
  if p_category_mode not in ('all', 'none', 'specific') then
    raise exception 'INVALID_CATEGORY_MODE';
  end if;
  if p_sort not in ('date_desc', 'date_asc') then
    raise exception 'INVALID_SORT';
  end if;
  if p_limit is null or p_limit <= 0 or p_limit > 200 then
    raise exception 'INVALID_LIMIT';
  end if;
  if p_offset is null or p_offset < 0 then
    raise exception 'INVALID_OFFSET';
  end if;

  if p_sort = 'date_asc' then
    return query
      select
        t.id, t.type, t.amount, t.transaction_date, t.income_source, t.comment,
        t.user_id, u.full_name as user_full_name,
        t.category_id, c.name as category_name, c.icon as category_icon, c.is_active as category_is_active,
        t.created_at
      from public.transactions t
      left join public.categories c on c.id = t.category_id
      left join public.users u on u.id = t.user_id
      where t.family_id in (
        select fm.family_id from public.family_members fm
        where fm.user_id = v_user_id and fm.status = 'active'
      )
      and (p_type = 'all' or t.type = p_type)
      and (p_date_from is null or t.transaction_date >= p_date_from)
      and (p_date_to is null or t.transaction_date <= p_date_to)
      and (
        p_category_mode = 'all'
        or (p_category_mode = 'none' and t.category_id is null and t.type = 'expense')
        or (p_category_mode = 'specific' and t.category_id = p_category_id)
      )
      and (
        v_search is null
        or t.comment ilike '%' || v_search || '%'
        or t.income_source ilike '%' || v_search || '%'
        or c.name ilike '%' || v_search || '%'
      )
      order by t.transaction_date asc, t.created_at asc
      limit p_limit offset p_offset;
  else
    return query
      select
        t.id, t.type, t.amount, t.transaction_date, t.income_source, t.comment,
        t.user_id, u.full_name as user_full_name,
        t.category_id, c.name as category_name, c.icon as category_icon, c.is_active as category_is_active,
        t.created_at
      from public.transactions t
      left join public.categories c on c.id = t.category_id
      left join public.users u on u.id = t.user_id
      where t.family_id in (
        select fm.family_id from public.family_members fm
        where fm.user_id = v_user_id and fm.status = 'active'
      )
      and (p_type = 'all' or t.type = p_type)
      and (p_date_from is null or t.transaction_date >= p_date_from)
      and (p_date_to is null or t.transaction_date <= p_date_to)
      and (
        p_category_mode = 'all'
        or (p_category_mode = 'none' and t.category_id is null and t.type = 'expense')
        or (p_category_mode = 'specific' and t.category_id = p_category_id)
      )
      and (
        v_search is null
        or t.comment ilike '%' || v_search || '%'
        or t.income_source ilike '%' || v_search || '%'
        or c.name ilike '%' || v_search || '%'
      )
      order by t.transaction_date desc, t.created_at desc
      limit p_limit offset p_offset;
  end if;
end;
$$;

revoke all on function public.get_transactions_page(text, date, date, text, uuid, text, text, int, int) from public;
revoke execute on function public.get_transactions_page(text, date, date, text, uuid, text, text, int, int) from anon;
grant execute on function public.get_transactions_page(text, date, date, text, uuid, text, text, int, int) to authenticated;

create or replace function public.get_transactions_totals(
  p_type text default 'all',
  p_date_from date default null,
  p_date_to date default null,
  p_category_mode text default 'all',
  p_category_id uuid default null,
  p_search text default null
)
returns table (
  income numeric(14, 2),
  expenses numeric(14, 2),
  balance numeric(14, 2)
)
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_search text := nullif(btrim(coalesce(p_search, '')), '');
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;
  if p_type not in ('all', 'expense', 'income') then
    raise exception 'INVALID_TYPE';
  end if;
  if p_category_mode not in ('all', 'none', 'specific') then
    raise exception 'INVALID_CATEGORY_MODE';
  end if;

  return query
    select
      coalesce(sum(t.amount) filter (where t.type = 'income'), 0)::numeric(14, 2) as income,
      coalesce(sum(t.amount) filter (where t.type = 'expense'), 0)::numeric(14, 2) as expenses,
      (
        coalesce(sum(t.amount) filter (where t.type = 'income'), 0)
        - coalesce(sum(t.amount) filter (where t.type = 'expense'), 0)
      )::numeric(14, 2) as balance
    from public.transactions t
    left join public.categories c on c.id = t.category_id
    where t.family_id in (
      select fm.family_id from public.family_members fm
      where fm.user_id = v_user_id and fm.status = 'active'
    )
    and (p_type = 'all' or t.type = p_type)
    and (p_date_from is null or t.transaction_date >= p_date_from)
    and (p_date_to is null or t.transaction_date <= p_date_to)
    and (
      p_category_mode = 'all'
      or (p_category_mode = 'none' and t.category_id is null and t.type = 'expense')
      or (p_category_mode = 'specific' and t.category_id = p_category_id)
    )
    and (
      v_search is null
      or t.comment ilike '%' || v_search || '%'
      or t.income_source ilike '%' || v_search || '%'
      or c.name ilike '%' || v_search || '%'
    );
end;
$$;

revoke all on function public.get_transactions_totals(text, date, date, text, uuid, text) from public;
revoke execute on function public.get_transactions_totals(text, date, date, text, uuid, text) from anon;
grant execute on function public.get_transactions_totals(text, date, date, text, uuid, text) to authenticated;
