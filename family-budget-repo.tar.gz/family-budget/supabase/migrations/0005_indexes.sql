-- Этап 3: индексы — буквально по списку п.20 ТЗ (минимально необходимый набор,
-- без "индекса на каждое поле").

-- family_members
create index idx_family_members_family_id on public.family_members (family_id);
create index idx_family_members_user_id on public.family_members (user_id);

-- family_invitations
create index idx_family_invitations_family_id on public.family_invitations (family_id);
-- family_invitations(token) НЕ создаём отдельным индексом: колонка уже UNIQUE,
-- что само по себе создаёт индекс — дублирующий был бы "бессмысленным индексом"
-- (прямой запрет из того же п.20 ТЗ).
create index idx_family_invitations_expires_at on public.family_invitations (expires_at);

-- categories
create index idx_categories_family_id on public.categories (family_id);

-- transactions
create index idx_transactions_family_id on public.transactions (family_id);
create index idx_transactions_user_id on public.transactions (user_id);
create index idx_transactions_category_id on public.transactions (category_id);
create index idx_transactions_transaction_date on public.transactions (transaction_date);
create index idx_transactions_family_id_transaction_date on public.transactions (family_id, transaction_date);

-- budgets
create index idx_budgets_family_id on public.budgets (family_id);
create index idx_budgets_period_month on public.budgets (period_month);

-- budget_categories
create index idx_budget_categories_budget_id on public.budget_categories (budget_id);

-- goals
create index idx_goals_family_id on public.goals (family_id);
create index idx_goals_owner_user_id on public.goals (owner_user_id);

-- goal_contributions
create index idx_goal_contributions_goal_id on public.goal_contributions (goal_id);
create index idx_goal_contributions_user_id on public.goal_contributions (user_id);

-- planned_expenses
create index idx_planned_expenses_family_id on public.planned_expenses (family_id);
create index idx_planned_expenses_planned_date on public.planned_expenses (planned_date);
create index idx_planned_expenses_status on public.planned_expenses (status);

-- recurring_transactions
create index idx_recurring_transactions_family_id on public.recurring_transactions (family_id);
create index idx_recurring_transactions_next_run_date on public.recurring_transactions (next_run_date);
create index idx_recurring_transactions_is_active on public.recurring_transactions (is_active);

-- notifications
create index idx_notifications_family_id on public.notifications (family_id);
create index idx_notifications_user_id on public.notifications (user_id);
create index idx_notifications_is_read on public.notifications (is_read);

-- calendar_connections
create index idx_calendar_connections_family_id on public.calendar_connections (family_id);
create index idx_calendar_connections_user_id on public.calendar_connections (user_id);
