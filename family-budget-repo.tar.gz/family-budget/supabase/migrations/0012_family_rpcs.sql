-- Этап 5: создание семьи + приглашения — атомарные SECURITY DEFINER RPC
-- и ужесточение RLS вокруг них.
--
-- Общий принцип этого файла: family/family_members/family_invitations больше
-- НЕ создаются и НЕ обновляются прямыми frontend INSERT/UPDATE через
-- PostgREST — только через функции ниже. Это устраняет:
--   1) bootstrap-проблему (при создании семьи ещё нет ни одного admin, поэтому
--      обычная RLS-политика family_members_insert_admin не пропустила бы
--      первую запись) — уже была явно отмечена как известный пробел в
--      комментариях 0010_rls_policies.sql;
--   2) возможность обойти наши же проверки (предсказуемый token, role='admin'
--      в приглашении, вторая активная семья) прямым вызовом REST API в обход
--      frontend-кода.
--
-- Все функции: SECURITY DEFINER (выполняются от имени владельца, поэтому
-- сами не подчиняются RLS на таблицах, которые меняют), `set search_path =
-- public` (защита от search_path hijacking), auth.uid() определяется на
-- сервере — ничего из user_id/family_id/role не принимается от клиента как
-- источник истины.

-- ───────────────────────── 1. Структурные ограничения ─────────────────────────

-- "Один пользователь — одна активная семья" (п.1, п.24) — гарантируется не
-- только проверкой внутри RPC, но и на уровне схемы: конкурентные вызовы
-- create_family()/accept_family_invitation() не смогут создать вторую
-- активную запись даже при гонке двух одновременных запросов.
create unique index family_members_one_active_per_user
  on public.family_members (user_id)
  where status = 'active';
comment on index public.family_members_one_active_per_user is
  'В версии 1.0 пользователь может состоять только в одной активной семье (Этап 5, п.1, 24).';

-- ADMIN нельзя выдать через приглашение (п.25) — фиксируем это не только в
-- RPC create_family_invitation, но и в схеме, чтобы это было невозможно
-- обойти даже прямым INSERT (если бы он был кем-то разрешён).
alter table public.family_invitations
  add constraint family_invitations_role_not_admin check (role in ('adult', 'child'));

-- ───────────────────────── 2. Закрываем прямые INSERT/UPDATE ─────────────────────────
-- Создание семьи, создание и отмена приглашений — теперь только через RPC
-- ниже (они SECURITY DEFINER и сами обходят RLS). Прямые вызовы с фронтенда
-- через .from('families').insert(...) / .from('family_invitations')... были
-- возможны через RLS-политики Этапа 3, но:
--   - .insert() в families в обход create_family() создал бы "половину семьи"
--     (family_settings — триггером, но family_members и categories — нет);
--   - .insert() в family_invitations в обход create_family_invitation() допускал
--     бы предсказуемый token или role='admin' (последнее теперь дополнительно
--     закрыто CHECK-constraint выше, но закрываем и сам путь);
--   - .update() в family_invitations в обход cancel_family_invitation() позволял
--     бы менять статус без проверки "ещё pending".
-- SELECT/DELETE политики этих таблиц не трогаем — они не создают этих проблем.
drop policy if exists families_insert_self on public.families;
drop policy if exists family_invitations_insert_admin on public.family_invitations;
drop policy if exists family_invitations_update_admin on public.family_invitations;

-- ───────────────────────── 3. TTL приглашения — централизованно (п.15) ─────────────────────────
create or replace function public.family_invitation_ttl()
returns interval
language sql
immutable
as $$
  select interval '7 days';
$$;
comment on function public.family_invitation_ttl() is
  'Централизованный срок действия приглашения в семью. Изменить срок — поменять только здесь (Этап 5, п.15).';

-- ───────────────────────── 4. create_family(name) ─────────────────────────
create or replace function public.create_family(p_name text)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_name text;
  v_family_id uuid;
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  if not exists (select 1 from public.users where id = v_user_id) then
    raise exception 'USER_PROFILE_NOT_FOUND';
  end if;

  v_name := btrim(coalesce(p_name, ''));
  if char_length(v_name) < 2 then
    raise exception 'FAMILY_NAME_TOO_SHORT';
  end if;
  if char_length(v_name) > 100 then
    raise exception 'FAMILY_NAME_TOO_LONG';
  end if;

  if exists (
    select 1 from public.family_members
    where user_id = v_user_id and status = 'active'
  ) then
    raise exception 'FAMILY_ALREADY_EXISTS';
  end if;

  insert into public.families (name, created_by)
  values (v_name, v_user_id)
  returning id into v_family_id;

  -- Гонка двух параллельных вызовов create_family()/accept_family_invitation()
  -- для одного и того же пользователя ловится partial unique index выше —
  -- второй INSERT упадёт с unique_violation, что откатит ВСЮ транзакцию
  -- (включая уже вставленную выше families), т.к. исключение не перехвачено
  -- дальше по стеку. "Половины семьи" остаться не может.
  begin
    insert into public.family_members (family_id, user_id, role, status)
    values (v_family_id, v_user_id, 'admin', 'active');
  exception when unique_violation then
    raise exception 'FAMILY_ALREADY_EXISTS';
  end;

  -- family_settings создаётся автоматически триггером trg_on_family_created
  -- (0008_family_settings_trigger.sql, Этап 3) — не дублируем здесь (п.6).

  -- Стандартные категории (п.7).
  insert into public.categories (family_id, name, type, is_custom, is_active)
  select v_family_id, c.name, c.type, false, true
  from (values
    ('Продукты', 'OBLIGATORY'),
    ('Дом', 'OBLIGATORY'),
    ('Коммунальные услуги', 'OBLIGATORY'),
    ('Автомобиль', 'OBLIGATORY'),
    ('Бензин', 'OBLIGATORY'),
    ('Здоровье', 'OBLIGATORY'),
    ('Образование', 'OBLIGATORY'),
    ('Связь', 'OBLIGATORY'),
    ('Кредиты', 'OBLIGATORY'),
    ('Дети', 'OBLIGATORY'),
    ('Животные', 'OBLIGATORY'),
    ('Одежда', 'WANTS'),
    ('Развлечения', 'WANTS'),
    ('Кафе', 'WANTS'),
    ('Путешествия', 'WANTS'),
    ('Подарки', 'WANTS'),
    ('Другое', 'OTHER')
  ) as c(name, type);

  return v_family_id;
end;
$$;
comment on function public.create_family(text) is
  'Атомарно создаёт семью: families + family_members(admin,active) + 17 стандартных
   категорий; family_settings — триггером. auth.uid() определяется на сервере.
   Откатывается целиком при любой ошибке (Этап 5, п.3, 8).';

revoke execute on function public.create_family(text) from public;
revoke execute on function public.create_family(text) from anon;
grant execute on function public.create_family(text) to authenticated;

-- ───────────────────────── 5. create_family_invitation(role) ─────────────────────────
create or replace function public.create_family_invitation(p_role text)
returns table (
  id uuid,
  token text,
  role text,
  expires_at timestamptz,
  created_at timestamptz
)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_family_id uuid;
  v_my_role text;
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  select fm.family_id, fm.role into v_family_id, v_my_role
  from public.family_members fm
  where fm.user_id = v_user_id and fm.status = 'active'
  limit 1;

  if v_family_id is null then
    raise exception 'NO_FAMILY';
  end if;

  if v_my_role <> 'admin' then
    raise exception 'FORBIDDEN';
  end if;

  if p_role not in ('adult', 'child') then
    raise exception 'INVALID_ROLE';
  end if;

  return query
    insert into public.family_invitations (family_id, invited_by, role, token, expires_at)
    values (
      v_family_id,
      v_user_id,
      p_role,
      encode(extensions.gen_random_bytes(32), 'hex'),
      now() + public.family_invitation_ttl()
    )
    returning family_invitations.id, family_invitations.token, family_invitations.role,
              family_invitations.expires_at, family_invitations.created_at;
end;
$$;
comment on function public.create_family_invitation(text) is
  'Только ADMIN своей семьи; role ограничена adult/child (не admin — п.25); token —
   криптографически случайный (pgcrypto gen_random_bytes, 32 байта, п.14); expires_at —
   из family_invitation_ttl() (п.15).';

revoke execute on function public.create_family_invitation(text) from public;
revoke execute on function public.create_family_invitation(text) from anon;
grant execute on function public.create_family_invitation(text) to authenticated;

-- ───────────────────────── 6. cancel_family_invitation(id) ─────────────────────────
create or replace function public.cancel_family_invitation(p_invitation_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_family_id uuid;
  v_status text;
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  select fi.family_id, fi.status into v_family_id, v_status
  from public.family_invitations fi
  where fi.id = p_invitation_id;

  if v_family_id is null then
    raise exception 'INVITATION_NOT_FOUND';
  end if;

  if not public.is_family_admin(v_family_id) then
    raise exception 'FORBIDDEN';
  end if;

  if v_status <> 'pending' then
    raise exception 'INVITATION_NOT_PENDING';
  end if;

  update public.family_invitations
  set status = 'revoked'
  where id = p_invitation_id;
end;
$$;
comment on function public.cancel_family_invitation(uuid) is
  'Только ADMIN своей семьи может отменить своё же pending-приглашение (Этап 5, п.19).';

revoke execute on function public.cancel_family_invitation(uuid) from public;
revoke execute on function public.cancel_family_invitation(uuid) from anon;
grant execute on function public.cancel_family_invitation(uuid) to authenticated;

-- ───────────────────────── 7. get_invitation_by_token(token) ─────────────────────────
-- Единственный безопасный способ проверить приглашение до входа/регистрации
-- (/invite/:token может открыть кто угодно, п.20) — НЕ прямой SELECT
-- family_invitations (там токены и invited_by всех приглашений семьи), а узкая
-- SECURITY DEFINER функция, возвращающая только то, что нужно показать (п.28).
create or replace function public.get_invitation_by_token(p_token text)
returns table (
  family_name text,
  role text,
  status text,
  expires_at timestamptz,
  is_valid boolean
)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_id uuid;
  v_family_id uuid;
  v_role text;
  v_status text;
  v_expires_at timestamptz;
  v_family_name text;
begin
  select fi.id, fi.family_id, fi.role, fi.status, fi.expires_at
  into v_id, v_family_id, v_role, v_status, v_expires_at
  from public.family_invitations fi
  where fi.token = p_token;

  if v_id is null then
    return query select null::text, null::text, 'not_found'::text, null::timestamptz, false;
    return;
  end if;

  -- Ленивая просрочка: если срок истёк, а статус всё ещё pending — фиксируем
  -- это в БД сразу при первой же проверке ссылки, чтобы список приглашений
  -- у ADMIN тоже показывал актуальный статус.
  if v_status = 'pending' and v_expires_at <= now() then
    update public.family_invitations set status = 'expired' where id = v_id;
    v_status := 'expired';
  end if;

  select f.name into v_family_name from public.families f where f.id = v_family_id;

  return query select v_family_name, v_role, v_status, v_expires_at, (v_status = 'pending');
end;
$$;
comment on function public.get_invitation_by_token(text) is
  'Публичная (anon+authenticated) проверка приглашения по token. Возвращает ТОЛЬКО
   family_name/role/status/expires_at/is_valid — без token, invited_by, id и других
   приглашений (Этап 5, п.28).';

revoke execute on function public.get_invitation_by_token(text) from public;
grant execute on function public.get_invitation_by_token(text) to anon;
grant execute on function public.get_invitation_by_token(text) to authenticated;

-- ───────────────────────── 8. accept_family_invitation(token) ─────────────────────────
create or replace function public.accept_family_invitation(p_token text)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_id uuid;
  v_family_id uuid;
  v_role text;
  v_status text;
  v_expires_at timestamptz;
begin
  if v_user_id is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  -- FOR UPDATE: блокирует строку приглашения на время транзакции, чтобы два
  -- одновременных запроса на accept одним и тем же token не могли оба
  -- пройти проверку status='pending' до того, как первый успеет её сменить
  -- на 'accepted' (п.23, атомарность).
  select fi.id, fi.family_id, fi.role, fi.status, fi.expires_at
  into v_id, v_family_id, v_role, v_status, v_expires_at
  from public.family_invitations fi
  where fi.token = p_token
  for update;

  if v_id is null then
    raise exception 'INVITATION_NOT_FOUND';
  end if;

  if v_status = 'pending' and v_expires_at <= now() then
    update public.family_invitations set status = 'expired' where id = v_id;
    v_status := 'expired';
  end if;

  if v_status <> 'pending' then
    raise exception 'INVITATION_NOT_PENDING';
  end if;

  if exists (
    select 1 from public.family_members
    where user_id = v_user_id and status = 'active'
  ) then
    raise exception 'FAMILY_ALREADY_EXISTS';
  end if;

  begin
    insert into public.family_members (family_id, user_id, role, status)
    values (v_family_id, v_user_id, v_role, 'active');
  exception when unique_violation then
    raise exception 'FAMILY_ALREADY_EXISTS';
  end;

  update public.family_invitations set status = 'accepted' where id = v_id;

  return v_family_id;
end;
$$;
comment on function public.accept_family_invitation(text) is
  'user_id/family_id/role определяются сервером из auth.uid() и найденного по
   token приглашения — НИЧЕГО не принимается от клиента напрямую (Этап 5, п.23).';

revoke execute on function public.accept_family_invitation(text) from public;
revoke execute on function public.accept_family_invitation(text) from anon;
grant execute on function public.accept_family_invitation(text) to authenticated;
