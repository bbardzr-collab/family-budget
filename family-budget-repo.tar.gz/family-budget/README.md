# Семейный бюджет 1.0

Семейное финансовое веб-приложение: доходы, расходы, бюджет, цели, планирование и аналитика — для всей семьи, в одном месте. Работает как обычный сайт и как PWA (устанавливается на домашний экран телефона/десктоп).

> Статус: этапы 1–22 завершены. Backend (Postgres, RLS, RPC), полная бизнес-логика, тестирование, аудит безопасности (Этап 21) и подготовка к production (Этап 22) выполнены. Deployment на GitHub/Vercel — предмет отдельного, ещё не начатого этапа (см. «Deployment» ниже).

## О проекте

Приложение для одной семьи (в терминах ТЗ — одна активная семья на пользователя в версии 1.0): учёт доходов и расходов, месячный бюджет по категориям, личные и семейные финансовые цели с вкладами, запланированные (ещё не свершившиеся) расходы, регулярные платежи с напоминаниями, аналитика по периодам/категориям/источникам дохода, in-app уведомления и разграничение ролей ADMIN/ADULT/CHILD — в том числе приватность финансовых данных для роли CHILD, обеспеченная на уровне базы данных (Row Level Security), а не только интерфейса.

## Stack

- **React 19 + TypeScript** (strict mode) — UI и типобезопасность
- **Vite** — сборка и dev-сервер
- **Tailwind CSS v4** — стили и дизайн-токены
- **React Router v7** — маршрутизация (включая защищённые маршруты и 404)
- **TanStack Query v5** — работа с серверными данными, кэш, инвалидация
- **React Hook Form + Zod** — формы и валидация
- **Recharts** — графики аналитики
- **lucide-react** — иконки
- **vite-plugin-pwa** — PWA (manifest, Service Worker)
- **ESLint + Prettier** — качество и единообразие кода
- **Vitest + React Testing Library** — тесты
- **Supabase** (`@supabase/supabase-js`, Postgres + Auth + Row Level Security) — весь backend; отдельного серверного приложения в проекте нет — бизнес-логика, требующая повышенных прав, живёт в Postgres-функциях (`SECURITY DEFINER`), вызываемых через RPC под `anon`/`authenticated` ключом.

## Requirements

- **Node.js 20+** (разработано и протестировано на Node.js 22)
- **npm** (используется `package-lock.json` — не смешивать с yarn/pnpm)
- Аккаунт [Supabase](https://supabase.com) для backend (см. «Supabase setup»)
- Опционально: [Supabase CLI](https://supabase.com/docs/guides/local-development/cli/getting-started) — для применения миграций и локальной разработки с локальным стеком

## Installation

```bash
npm install
```

Устанавливает зависимости строго по `package-lock.json` (для чистой/production-подобной установки — `npm ci`).

## Environment variables

Приложение — чистый frontend (SPA), без собственного сервера: единственные env-переменные — **публичные** Supabase-ключи с обязательным префиксом `VITE_` (иначе Vite не включит их в бандл). Секретных серверных переменных в проекте нет и быть не должно.

| Переменная | Назначение | Обязательна | Где используется | Можно на frontend? |
|---|---|---|---|---|
| `VITE_SUPABASE_URL` | URL Supabase-проекта (`https://<ref>.supabase.co`) | Да | `src/lib/supabase.ts` | Да — публичная информация |
| `VITE_SUPABASE_ANON_KEY` | Публичный (`anon`) ключ Supabase API | Да | `src/lib/supabase.ts` | Да — рассчитан на публичное использование, реальная защита данных — RLS в Postgres, а не секретность этого ключа |

`Development` и `Production` используют один и тот же набор из двух переменных — разница только в значениях (dev/staging Supabase-проект локально, production Supabase-проект на хостинге):

- **Development** — файл `.env.local` (в `.gitignore`, никогда не попадает в Git), см. «Supabase setup» ниже.
- **Production** — те же две переменные задаются в настройках проекта на хостинге (например, в Vercel → Project Settings → Environment Variables), а не файлом.

Секреты, которые **никогда** не должны попадать в `.env*`/frontend/Git: `service_role` key Supabase и любые другие ключи с полным доступом в обход RLS. В кодовой базе таких ссылок нет (проверено в рамках Этапа 21 и Этапа 22 — см. `SECURITY_AUDIT_REPORT.md`).

Шаблон переменных — `.env.example` (только имена, без значений):

```bash
cp .env.example .env.local
# затем заполните .env.local реальными значениями (см. «Supabase setup»)
```

## Development

```bash
npm run dev
```

Приложение будет доступно на `http://localhost:5173`.

## Tests

```bash
npm run test          # Vitest — все тесты один раз (используется в CI-подобных проверках и перед каждым этапом)
npm run test:watch    # Vitest — в режиме наблюдения при разработке
```

Тесты — на Vitest + React Testing Library + jsdom, конфигурация в `vite.config.ts` (`test: {...}`), setup-файл `src/test/setup.ts`.

Также доступны:

```bash
npm run lint            # ESLint
npm run format           # Prettier — автоформатирование
npm run format:check     # Prettier — только проверка, без изменений
```

## Build

```bash
npm run build
```

Выполняет `tsc -b` (проверка типов по project references, без эмита) и затем `vite build`. Собирает production-бандл в `dist/` (включая сгенерированные `vite-plugin-pwa` артефакты — `manifest.webmanifest`, `sw.js`, precache-манифест). Build должен проходить без ошибок TypeScript и без ошибок сборки Vite с чистой установки зависимостей (`npm ci && npm run build`).

## Production preview

```bash
npm run preview
```

Поднимает локальный сервер поверх уже собранного `dist/` (production-режим, не dev-сервер) — на нём стоит проверять реальное поведение перед деплоем: маршрутизацию, PWA-установку, работу с production-сборкой Service Worker.

## Supabase setup

Backend проекта — [Supabase](https://supabase.com) (Postgres + Auth + Row Level Security). Ниже — как поднять его с нуля (например, на новой машине или в новом Supabase-аккаунте).

### 1. Создать Supabase-проект

1. Зайдите на [supabase.com](https://supabase.com) и создайте организацию (если ещё нет).
2. New Project → укажите имя (например, `family-budget`), пароль базы данных и регион.
3. Дождитесь, пока проект перейдёт в статус `ACTIVE_HEALTHY` (обычно 1–2 минуты).

### 2. Найти Project URL

Project Settings → **API** → **Project URL** (вид `https://<ref>.supabase.co`).

### 3. Найти anon / publishable key

Там же, Project Settings → **API** → **Project API keys**. Нужен ключ уровня **anon** / **public** (legacy JWT-формат `eyJ...` или новый `sb_publishable_...` — оба подходят). **Никогда** не используйте `service_role` key — он даёт полный доступ в обход RLS и не предназначен для frontend.

### 4. Создать `.env.local`

```bash
cp .env.example .env.local
```

И заполните двумя значениями из шагов 2–3:

```
VITE_SUPABASE_URL=https://<ref>.supabase.co
VITE_SUPABASE_ANON_KEY=<anon key>
```

`.env.local` уже в `.gitignore` — реальные ключи никогда не попадают в Git.

### 5. Применить миграции

См. «Database migrations» ниже.

### 6. Выполнить seed (опционально, только для локальной разработки)

`supabase/seed/seed.sql` — демонстрационные данные для **локальной** разработки (демо-семья + 17 стандартных категорий), никогда не запускается против боевого проекта. С установленным Supabase CLI и локальным стеком:

```bash
supabase start     # поднимает локальный Postgres/Auth в Docker
supabase db reset  # применяет миграции и автоматически выполняет supabase/seed/seed.sql
```

### 7. Сгенерировать TypeScript-типы

Актуальные типы уже лежат в `src/types/database.ts`. Перегенерировать после изменения схемы:

```bash
supabase gen types typescript --project-id <ref> > src/types/database.ts
```

### 8. Проверить подключение

Технический (dev-only) индикатор подключения — на странице «Настройки» (`/app/settings`), показывает только `Connected` / `Not connected`, без секретов.

### Auth: production URL

Redirect-адреса Supabase Auth (сброс пароля, приглашение в семью, callback-и) настраиваются в **Authentication → URL Configuration** Supabase-проекта и должны указывать на реальный production-домен. Production-домен ещё не зафиксирован (появится вместе с деплоем на Vercel — отдельный этап), поэтому это единственная Auth-настройка, которую нужно будет заполнить **после** появления домена, а не сейчас. См. «Deployment» → «Что нужно сделать перед deployment».

## Database migrations

Источник истины схемы — SQL-файлы в `supabase/migrations/` (создание таблиц вручную через Dashboard не используется). 35 миграций (`0001_...` — `0035_...`), применяются строго по порядку номера в имени файла.

Если установлен [Supabase CLI](https://supabase.com/docs/guides/local-development/cli/getting-started):

```bash
supabase login
supabase link --project-ref <ref>
supabase db push
```

Проверено на Этапе 22: миграции пронумерованы последовательно без пропусков и дублей, каждая создаёт/исправляет ровно одну зафиксированную вещь (таблицы, индексы, RLS, RPC, триггеры), несколько миграций — целенаправленные bugfix-исправления найденных в процессе разработки проблем (например, `0016_fix_dashboard_summary_anon_grant.sql`, `0020_fix_category_none_income_leak.sql`, `0022`/`0023` — same-family проверка для `budget_categories`), а не временные/тестовые файлы. Миграции не зависят от локального состояния и не требуют ручного редактирования SQL после применения.

## PWA

Приложение — полноценная Progressive Web App поверх той же кодовой базы: устанавливается на Android, iPhone/iPad и десктоп, работает с Service Worker, корректно обновляется и показывает понятное состояние при потере сети.

### Manifest и иконки

`vite.config.ts` (плагин `vite-plugin-pwa`, `manifest: {...}`) — единственный источник манифеста в проекте (нет отдельного `public/manifest.webmanifest`, он генерируется в `dist/` при сборке). `start_url: '/app'`. Иконки — `public/icons/icon-192.png`, `icon-512.png`, `icon-512-maskable.png` (maskable-вариант соблюдает safe zone), `apple-touch-icon.png` (180×180).

### Service Worker и обновление

`registerType: 'prompt'` — Service Worker не захватывает контроль сразу после установки, а ждёт явного подтверждения из приложения (баннер «Доступна новая версия» → кнопка «Обновить», `src/components/UpdateBanner.tsx`). В development Service Worker не регистрируется (`devOptions.enabled: false`).

### Что кешируется и что нет

| Кешируется (precache, app shell) | НЕ кешируется |
|---|---|
| JS/CSS/HTML сборки, favicon, manifest, иконки (`workbox.globPatterns`) | Supabase Auth/REST/RPC/Storage — весь `*.supabase.co` явно помечен `NetworkOnly` в `runtimeCaching`; транзакции, доходы, расходы, бюджеты, цели, семейные данные, уведомления — никогда в Cache Storage |

Это подтверждено при аудите Этапа 21/22: финансовые данные не остаются доступными из offline-кэша после logout, потому что они туда изначально не попадают. Дополнительно `signOut()` вызывает `queryClient.clear()` — оперативная (in-memory) копия данных тоже не переживает выход из аккаунта или смену пользователя на одном устройстве.

### Offline UX

`useOnlineStatus()` — реагирует на `window.online`/`window.offline`. `OfflineBanner` показывает баннер об отсутствии сети и о восстановлении соединения, после чего точечно инвалидирует ключевые React Query-домены (dashboard/transactions/budgets/goals/notifications). Офлайн-очередь операций (создание расхода без сети с последующей синхронизацией) сознательно не реализована — отдельная задача вне рамок версии 1.0.

### Известные ограничения

- Push-уведомления, background sync и offline-очередь финансовых операций — не входят в версию 1.0.
- `vercel.json`/`public/_redirects` присутствуют оба защитно (SPA fallback для прямых ссылок на разных платформах) — какой из них реально нужен, зависит от выбранной платформы деплоя (см. «Deployment»).

## Deployment

Целевая схема: **GitHub → Vercel → Supabase**. На Этапе 22 проект приведён в состояние готовности к этому деплою, но сам деплой (создание GitHub-репозитория, подключение к Vercel, реальный production-домен) — предмет отдельного, следующего этапа.

Что уже готово для Vercel:

- `vercel.json` — SPA rewrite (`/(.*) → /index.html`, чтобы прямое открытие `/app/transactions` и т.п. не возвращало 404) и security-заголовки (CSP, `X-Frame-Options`, `Referrer-Policy`, `Permissions-Policy`, HSTS) — добавлены на Этапе 21, CSP составлен под фактическое использование ресурсов проекта (без внешних CDN/шрифтов).
- Production build (`npm run build`) собирается с чистой установки без ошибок (проверено на Этапе 22).
- Никаких serverless functions проекту не требуется — это статический SPA-бандл поверх внешнего Supabase backend.

Что потребуется сделать при самом деплое (не на этом этапе):

1. Создать GitHub-репозиторий и запушить проект (сейчас — не git-репозиторий).
2. Подключить репозиторий к Vercel, задать `VITE_SUPABASE_URL`/`VITE_SUPABASE_ANON_KEY` в Vercel → Environment Variables (Production).
3. После получения реального production-домена — заполнить Auth → URL Configuration в Supabase (redirect URLs для сброса пароля/приглашений/callback-ов).
4. Проверить фактическую отдачу security-заголовков из `vercel.json` уже на реальном Vercel-деплое (заголовки заданы в конфиге, но не были верифицированы live в проде, так как деплоя ещё не было).

## Security

С Этапа 16 в приложении действует политика приватности для роли **CHILD**, реализованная на уровне **PostgreSQL (Row Level Security + `SECURITY DEFINER` RPC-функции)**, а не на уровне frontend-фильтрации. Этап 21 провёл полный аудит безопасности всего проекта (RLS по всем 16 таблицам, cross-family изоляция, эскалация ролей, IDOR, XSS/SQL-инъекции, секреты, PWA-кэш и другое) — полный отчёт в [`SECURITY_AUDIT_REPORT.md`](./SECURITY_AUDIT_REPORT.md), статус **PASS WITH LIMITATIONS**.

> **Frontend НЕ является границей безопасности.** React/TanStack Query могут скрывать или не запрашивать какие-то данные в интерфейсе для удобства UX, но это не защищает данные: реальная защита — RLS-политики и RPC-функции в Postgres, которые не отдадут запрещённые строки/поля вообще, даже при прямом запросе через `supabase-js`/REST/RPC в обход React-приложения.

### Что видит каждая роль

| Раздел | ADMIN / ADULT | CHILD |
|---|---|---|
| Операции (`transactions`) | Все операции семьи | Только свои собственные операции |
| Dashboard | Итоги по всей семье | Итоги по всей семье (агрегат, без разбивки по конкретным взрослым) |
| Бюджет | Создание/изменение | Просмотр, без данных о том, кто из взрослых сколько потратил |
| Личные цели | Свои | Только свои, чужие (включая других детей) не видны |
| Семейные цели | Полная детализация вкладов | Общий прогресс, без списка чужих вкладов по каждому взрослому |
| Запланированные операции | Все | Только свои |
| Регулярные платежи | Все | Только свои |
| Аналитика | Полная, включая помесячную динамику | Семейные агрегаты, без "кто сколько заработал/потратил" |
| Участники семьи | Имя, роль, финансовая активность | Имя и роль, без дохода/расхода/баланса |
| Настройки приватности (`family_settings.child_visibility`) | Изменяет только ADMIN | Не видит и не может изменить |

### Как это обеспечено технически

- RLS-политики на `transactions`/`planned_expenses`/`recurring_transactions` ограничивают CHILD строками `user_id = auth.uid()` в пределах своей семьи — на уровне базы.
- Агрегатные RPC (`get_dashboard_summary`, `get_monthly_budget_summary`, `get_analytics_*`, `get_goal_summary`, `get_goals_list`) — `SECURITY DEFINER`, сами определяют семью/роль вызывающего строго через `auth.uid()`; параметры `family_id`/`user_id`/`role` от клиента никогда не принимаются для авторизации.
- При выходе из аккаунта (`signOut()`) вызывается `queryClient.clear()` — кэш TanStack Query не переживает переключение пользователя на одном устройстве.
- В клиентском коде используются только `VITE_SUPABASE_URL`/`VITE_SUPABASE_ANON_KEY`; `service_role` key никогда не попадает в бандл, Git или `.env.example`.
- Security-заголовки (CSP/HSTS/X-Frame-Options/Referrer-Policy/Permissions-Policy) — `vercel.json` (Этап 21).

Подробности методологии, найденные и исправленные проблемы, а также зафиксированные ограничения (например, rate-limiting на публичных auth/invitation-эндпоинтах зависит от production-настроек Supabase и не может быть гарантирован кодом приложения) — в `SECURITY_AUDIT_REPORT.md`.

## Project structure

```
src/
├── app/              # роутинг (routes.tsx), провайдеры, навигация
├── layouts/           # AuthLayout, AppLayout
├── pages/              # экраны-маршруты
├── features/            # доменные модули (auth, family, transactions,
│                         # categories, budgets, goals, plannedExpenses,
│                         # recurringTransactions, analytics, notifications)
├── components/           # переиспользуемые компоненты (BottomNav, Sidebar, Header...)
│   └── ui/                 # базовые UI-примитивы (Button, Card, Input, Modal...)
├── hooks/                   # сквозные хуки
├── lib/                       # queryClient, supabase-клиент
├── types/                      # общие типы (включая database.ts)
├── utils/                       # форматирование денег/дат, cn()
└── test/                         # setup для Vitest

public/icons/    # PWA-иконки
supabase/
├── migrations/    # SQL-миграции — источник истины схемы БД
└── seed/            # seed.sql — демо-данные для локальной разработки, не для прода
```

## Этапы разработки

Проект разработан поэтапно, этапы 1–22 завершены (backend и RLS, авторизация, семьи и приглашения, категории, транзакции, бюджеты, цели, планирование, регулярные платежи, аналитика, уведомления, приватность CHILD, PWA, полное тестирование, аудит безопасности, production readiness). Полная история и архитектура — в отчётах `STAGE*_REPORT.md`/`SECURITY_AUDIT_REPORT.md` в корне репозитория и в проектной документации (`architecture-v1.md`).
